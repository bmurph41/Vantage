export const insertProspectingActivitySchema = createInsertSchema(prospectingActivities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProspectingActivity = z.infer<typeof insertProspectingActivitySchema>;
export type ProspectingActivity = typeof prospectingActivities.$inferSelect;

// Prospecting Weeks schema
export const insertProspectingWeekSchema = createInsertSchema(prospectingWeeks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProspectingWeek = z.infer<typeof insertProspectingWeekSchema>;
export type ProspectingWeek = typeof prospectingWeeks.$inferSelect;

