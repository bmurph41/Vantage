export const prospectingActivityTypeEnum = pgEnum("prospecting_activity_type", ["call", "email", "meeting", "voicemail", "text", "linkedin", "other"]);
export const prospectingActivityDirectionEnum = pgEnum("prospecting_activity_direction", ["outbound", "inbound", "internal"]);
export const prospectingActivityOutcomeEnum = pgEnum("prospecting_activity_outcome", ["connected", "no_answer", "left_message", "wrong_number", "gatekeeper", "not_interested", "interested", "scheduled", "sent", "opened", "replied", "bounced"]);
