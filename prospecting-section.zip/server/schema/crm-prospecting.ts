export const crmProspectingEntries = pgTable("crm_prospecting_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  year: integer("year").notNull(),
  quarter: integer("quarter").notNull(), // 1, 2, 3, 4
  weekNumber: integer("week_number").notNull(), // 1-13 within quarter
  weekStartDate: timestamp("week_start_date").notNull(),
  weekEndDate: timestamp("week_end_date").notNull(),
  
  // Weekly goals (up to 6 goals)
  goals: jsonb("goals").default([]), // Array of string goals
  
  // Enabled days of the week for this prospecting week
  enabledDays: jsonb("enabled_days").default(['monday', 'tuesday', 'wednesday', 'thursday', 'friday']), // Array of enabled day IDs
  
  // Daily activities tracking (Monday-Friday)
  dailyActivities: jsonb("daily_activities").default({}), // { monday: [], tuesday: [], etc. }
  
  // Summary metrics
  totalLeadGeneration: integer("total_lead_generation").default(0),
  totalCalls: integer("total_calls").default(0),
  totalEmails: integer("total_emails").default(0),
  totalMeetings: integer("total_meetings").default(0),
  
  // Reflection notes
  notes: text("notes"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prospecting Activities for detailed daily tracking

export const crmProspectingActivities = pgTable("crm_prospecting_activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  prospectingEntryId: varchar("prospecting_entry_id").references(() => crmProspectingEntries.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  
  // Activity details
  activityType: text("activity_type").notNull(), // 'call', 'voicemail', 'no_answer', 'not_interested', 'text', 'linkedin', 'email', 'meeting'
  outcome: text("outcome").notNull(), // 'connected', 'left_voicemail', 'no_answer', 'not_interested', 'callback_requested', 'meeting_scheduled', 'sent', 'opened', 'replied'
  
  // Timing
  dayOfWeek: text("day_of_week").notNull(), // 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'
  activityDate: timestamp("activity_date").notNull(),
  duration: integer("duration"), // in minutes for calls/meetings
  
  // Linking to CRM entities
  contactId: varchar("contact_id").references(() => crmContacts.id),
  dealId: varchar("deal_id").references(() => crmDeals.id),
  
  // Activity details
  notes: text("notes"),
  followUpRequired: boolean("follow_up_required").default(false),
  followUpDate: timestamp("follow_up_date"),
  
  // Tracking metadata
  phoneNumber: text("phone_number"), // for call activities
  emailAddress: text("email_address"), // for email activities
  linkedinProfile: text("linkedin_profile"), // for linkedin activities
  subject: text("subject"), // for emails/messages
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prospecting User Settings (per-user preferences)
export const crmProspectingUserSettings = pgTable("crm_prospecting_user_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull().unique(),
  orgId: varchar("org_id").references(() => organizations.id).notNull(),
  
  // Week start preference
  weekStartDay: text("week_start_day").default('monday'), // 'sunday', 'monday', 'saturday'
  
  // Future settings can be added here
  // e.g., timezone preference, notification preferences, etc.
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prospecting Goal Templates (recurring goal templates)
export const crmProspectingGoalTemplates = pgTable("crm_prospecting_goal_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id).notNull(),
  
  // Template details
  name: text("name").notNull(), // e.g., "Weekly Call Goal", "Monthly Lead Goal"
  description: text("description"),
  frequency: text("frequency").notNull(), // 'weekly', 'monthly'
  
  // Goal content (array of goal strings)
  goals: jsonb("goals").default([]).notNull(), // Array of string goals
  
  // Auto-instantiation
  autoInstantiate: boolean("auto_instantiate").default(false), // Auto-create goals for new weeks
  
  // Status
  isActive: boolean("is_active").default(true),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Email Communications (for email tracking)

export const crmEmailCommunications = pgTable("crm_email_communications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subject: text("subject").notNull(),
