  // Get all prospecting entries for a user (optionally filtered by year)
  app.get("/api/prospecting/entries", async (req: any, res) => {
    try {
      const year = req.query.year ? parseInt(req.query.year) : undefined;
      const entries = await storage.getProspectingEntriesForUser(req.user.id, year);
      res.json(entries);
    } catch (error: any) {
      console.error("Failed to get prospecting entries:", error);
      res.status(500).json({ error: "Failed to retrieve prospecting entries" });
    }
  });

  // Get dashboard stats with week-over-week changes
  app.get("/api/prospecting/dashboard-stats", async (req: any, res) => {
    try {
      const now = new Date();
      const currentYear = now.getFullYear();
      
      // Get all entries for the current year
      const entries = await storage.getProspectingEntriesForUser(req.user.id, currentYear);
      
      // Find current week and previous week entries
      const sortedEntries = entries.sort((a: any, b: any) => {
        if (a.year !== b.year) return b.year - a.year;
        if (a.quarter !== b.quarter) return b.quarter - a.quarter;
        return b.weekNumber - a.weekNumber;
      });
      
      // Get current week entry (most recent or current)
      const currentWeekEntry = sortedEntries[0] || null;
      const previousWeekEntry = sortedEntries[1] || null;
      
      // Calculate current week totals
      const currentCalls = currentWeekEntry?.totalCalls || 0;
      const currentEmails = currentWeekEntry?.totalEmails || 0;
      const currentLeads = currentWeekEntry?.totalLeadGeneration || 0;
      const currentMeetings = currentWeekEntry?.totalMeetings || 0;
      
      // Calculate previous week totals
      const prevCalls = previousWeekEntry?.totalCalls || 0;
      const prevEmails = previousWeekEntry?.totalEmails || 0;
      const prevLeads = previousWeekEntry?.totalLeadGeneration || 0;
      const prevMeetings = previousWeekEntry?.totalMeetings || 0;
      
      // Calculate percentage changes (handle division by zero)
      const calcChange = (current: number, prev: number) => {
        if (prev === 0) return current > 0 ? 100 : 0;
        return Math.round(((current - prev) / prev) * 100);
      };
      
      res.json({
        callsMade: currentCalls,
        emailsSent: currentEmails,
        leadsGenerated: currentLeads,
        meetingsBooked: currentMeetings,
        callsChange: calcChange(currentCalls, prevCalls),
        emailsChange: calcChange(currentEmails, prevEmails),
        leadsChange: calcChange(currentLeads, prevLeads),
        meetingsChange: calcChange(currentMeetings, prevMeetings),
        currentWeek: currentWeekEntry ? {
          year: currentWeekEntry.year,
          quarter: currentWeekEntry.quarter,
          weekNumber: currentWeekEntry.weekNumber,
        } : null,
        previousWeek: previousWeekEntry ? {
          year: previousWeekEntry.year,
          quarter: previousWeekEntry.quarter,
          weekNumber: previousWeekEntry.weekNumber,
        } : null,
      });
    } catch (error: any) {
      console.error("Failed to get prospecting dashboard stats:", error);
      res.status(500).json({ error: "Failed to retrieve dashboard stats" });
    }
  });

  // Get a specific prospecting entry by week
  app.get("/api/prospecting/entries/:year/:quarter/:weekNumber", async (req: any, res) => {
    try {
      const year = parseInt(req.params.year);
      const quarter = parseInt(req.params.quarter);
      const weekNumber = parseInt(req.params.weekNumber);
      
      const entry = await storage.getProspectingEntryByWeek(req.user.id, year, quarter, weekNumber);
      
      if (!entry) {
        return res.status(404).json({ error: "Prospecting entry not found" });
      }
      
      res.json(entry);
    } catch (error: any) {
      console.error("Failed to get prospecting entry:", error);
      res.status(500).json({ error: "Failed to retrieve prospecting entry" });
    }
  });

  // Create or update a prospecting entry
  app.post("/api/prospecting/entries", async (req: any, res) => {
    try {
      // Import schema for validation
      // Schema already imported at top of file
      
      // Convert date strings to Date objects before validation
      const bodyData = { ...req.body };
      if (bodyData.weekStartDate && typeof bodyData.weekStartDate === 'string') {
        bodyData.weekStartDate = new Date(bodyData.weekStartDate);
      }
      if (bodyData.weekEndDate && typeof bodyData.weekEndDate === 'string') {
        bodyData.weekEndDate = new Date(bodyData.weekEndDate);
      }
      
      // Validate request body
      const validated = insertProspectingEntrySchema.parse(bodyData);
      const { year, quarter, weekNumber, userId, ...entryData } = validated;
      
      // Check if entry already exists for this week
      const existing = await storage.getProspectingEntryByWeek(req.user.id, year, quarter, weekNumber);
      
      let entry;
      if (existing) {
        // Update existing entry (never allow userId to be changed)
        entry = await storage.updateProspectingEntry(existing.id, entryData);
      } else {
        // Create new entry (always use authenticated user's ID)
        entry = await storage.createProspectingEntry({
          ...entryData,
          userId: req.user.id,
          year,
          quarter,
          weekNumber,
        });
      }
      
      res.json(entry);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: "Invalid prospecting entry data", details: error.errors });
      }
      console.error("Failed to save prospecting entry:", error);
      res.status(500).json({ error: "Failed to save prospecting entry" });
    }
  });

  // Update a prospecting entry (create if doesnt exist)
  app.put("/api/prospecting/entries/:year/:quarter/:weekNumber", async (req: any, res) => {
    try {
      // Import schema for validation
      // Schema already imported at top of file
      
      const year = parseInt(req.params.year);
      const quarter = parseInt(req.params.quarter);
      const weekNumber = parseInt(req.params.weekNumber);
      
      // Check if entry exists
      const existingEntry = await storage.getProspectingEntryByWeek(req.user.id, year, quarter, weekNumber);
      
      // Convert date strings to Date objects before validation
      const bodyData = { ...req.body };
      if (bodyData.weekStartDate && typeof bodyData.weekStartDate === 'string') {
        bodyData.weekStartDate = new Date(bodyData.weekStartDate);
      }
      if (bodyData.weekEndDate && typeof bodyData.weekEndDate === 'string') {
        bodyData.weekEndDate = new Date(bodyData.weekEndDate);
      }
      
      // Validate request body
      const validated = insertProspectingEntrySchema.partial().parse(bodyData);
      
      // Strip userId to prevent reassignment attacks
      const { userId, ...updateData } = validated;
      
      let result;
      if (existingEntry) {
        // Update existing entry
        result = await storage.updateProspectingEntry(existingEntry.id, updateData);
      } else {
        // Create new entry with all required fields
        result = await storage.createProspectingEntry({
          ...updateData,
          userId: req.user.id,
          year,
          quarter,
          weekNumber,
          weekStartDate: updateData.weekStartDate || new Date(),
          weekEndDate: updateData.weekEndDate || new Date(),
        });
      }
      
      res.json(result);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        console.error("Validation error details:", JSON.stringify(error.errors, null, 2));
        return res.status(400).json({ error: "Invalid prospecting entry data", details: error.errors });
      }
      console.error("Failed to update prospecting entry:", error);
      res.status(500).json({ error: "Failed to update prospecting entry" });
    }
  });

  // Delete a prospecting entry
  app.delete("/api/prospecting/entries/:id", async (req: any, res) => {
    try {
      // First verify the entry exists and belongs to the user
      const entry = await storage.getProspectingEntry(req.params.id);
      
      if (!entry) {
        return res.status(404).json({ error: "Prospecting entry not found" });
      }
      
      // Verify entry belongs to authenticated user
      if (entry.userId !== req.user.id) {
        return res.status(403).json({ error: "Unauthorized to delete this prospecting entry" });
      }
      
      await storage.deleteProspectingEntry(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Failed to delete prospecting entry:", error);
      res.status(500).json({ error: "Failed to delete prospecting entry" });
    }
  });

  // ===================================================================
  // CRM Prospecting Settings
  // ===================================================================

  // Get user prospecting settings (create default if doesn't exist)
  app.get("/api/prospecting/settings", async (req: any, res) => {
    try {
      let settings = await storage.getProspectingUserSettings(req.user.id);
      
      // Create default settings if they don't exist
      if (!settings) {
        settings = await storage.createProspectingUserSettings({
          userId: req.user.id,
          orgId: req.user.orgId,
          weekStartDay: 'monday'
        });
      }
      
      res.json(settings);
    } catch (error: any) {
      console.error("Failed to get prospecting settings:", error);
      res.status(500).json({ error: "Failed to retrieve prospecting settings" });
    }
  });

  // Update user prospecting settings
  app.put("/api/prospecting/settings", async (req: any, res) => {
    try {
      const { insertCrmProspectingUserSettingsSchema } = await import("@shared/schema");
      const validated = insertCrmProspectingUserSettingsSchema.partial().parse(req.body);
      
      // Check if settings exist
      const existing = await storage.getProspectingUserSettings(req.user.id);
      
      let settings;
      if (existing) {
        settings = await storage.updateProspectingUserSettings(req.user.id, validated);
      } else {
        settings = await storage.createProspectingUserSettings({
          ...validated,
          userId: req.user.id,
          orgId: req.user.orgId
        });
      }
      
      res.json(settings);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: "Invalid settings data", details: error.errors });
      }
      console.error("Failed to update prospecting settings:", error);
      res.status(500).json({ error: "Failed to update prospecting settings" });
    }
  });

  // ===================================================================
  // CRM Prospecting Goal Templates
  // ===================================================================

  // Get all goal templates for user
  app.get("/api/prospecting/goal-templates", async (req: any, res) => {
    try {
      const templates = await storage.getProspectingGoalTemplates(req.user.id);
      res.json(templates);
    } catch (error: any) {
      console.error("Failed to get goal templates:", error);
      res.status(500).json({ error: "Failed to retrieve goal templates" });
    }
  });

  // Create a new goal template
  app.post("/api/prospecting/goal-templates", async (req: any, res) => {
    try {
      const { insertCrmProspectingGoalTemplateSchema } = await import("@shared/schema");
      const validated = insertCrmProspectingGoalTemplateSchema.parse({
        ...req.body,
        userId: req.user.id,
        orgId: req.user.orgId
      });
      
      const template = await storage.createProspectingGoalTemplate(validated);
      res.json(template);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: "Invalid goal template data", details: error.errors });
      }
      console.error("Failed to create goal template:", error);
      res.status(500).json({ error: "Failed to create goal template" });
    }
  });

  // Update a goal template
  app.put("/api/prospecting/goal-templates/:id", async (req: any, res) => {
    try {
      const template = await storage.getProspectingGoalTemplate(req.params.id);
      
      if (!template) {
        return res.status(404).json({ error: "Goal template not found" });
      }
      
      if (template.userId !== req.user.id) {
        return res.status(403).json({ error: "Unauthorized to update this goal template" });
      }
      
      const { insertCrmProspectingGoalTemplateSchema } = await import("@shared/schema");
      const validated = insertCrmProspectingGoalTemplateSchema.partial().parse(req.body);
      
      const updated = await storage.updateProspectingGoalTemplate(req.params.id, validated);
      res.json(updated);
    } catch (error: any) {
      if (error.name === 'ZodError') {
        return res.status(400).json({ error: "Invalid goal template data", details: error.errors });
      }
      console.error("Failed to update goal template:", error);
      res.status(500).json({ error: "Failed to update goal template" });
    }
  });

  // Delete a goal template
  app.delete("/api/prospecting/goal-templates/:id", async (req: any, res) => {
    try {
      const template = await storage.getProspectingGoalTemplate(req.params.id);
      
