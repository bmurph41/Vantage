# MarinaMatch Prospecting Section

Complete export of the Prospecting module for CRM outreach and activity tracking.

## Contents

### Client Pages (8 files)
- `client/pages/prospecting.tsx` - Main prospecting page
- `client/pages/Overview.tsx` - Prospecting overview/dashboard
- `client/pages/Board.tsx` - Kanban-style prospecting board
- `client/pages/Workroom.tsx` - Daily prospecting workroom
- `client/pages/Markets.tsx` - Market targets management
- `client/pages/Campaigns.tsx` - Outreach campaigns
- `client/pages/Analytics.tsx` - Prospecting analytics
- `client/pages/Dashboard.tsx` - Prospecting dashboard

### Client Components (2 files)
- `client/components/week-prospecting-modal.tsx` - Weekly prospecting entry modal
- `client/components/prospecting-settings-dialog.tsx` - User settings dialog

### Client Hooks (1 file)
- `client/hooks/use-prospecting.tsx` - Prospecting data hook with TanStack Query

### Server Routes (1 file)
- `server/routes/prospecting-routes.ts` - API endpoints for prospecting CRUD

### Schema Definitions (4 files)
- `server/schema/prospecting-enums.ts` - Activity type, direction, outcome enums
- `server/schema/prospecting-activities.ts` - Activities and weeks tables
- `server/schema/crm-prospecting.ts` - CRM prospecting entries, activities, settings
- `server/schema/prospecting-types.ts` - Insert schemas and TypeScript types

## Features

- Weekly prospecting goal tracking
- Activity logging (calls, emails, meetings, LinkedIn, etc.)
- Outbound/inbound activity direction tracking
- Activity outcomes (connected, no_answer, left_message, etc.)
- User-configurable goal templates
- Market target management
- Campaign management
- Analytics and reporting

## API Endpoints

- `GET /api/prospecting/entries` - Get all prospecting entries
- `GET /api/prospecting/entries/:year/:quarter/:weekNumber` - Get specific week
- `POST /api/prospecting/entries` - Create prospecting entry
- `PUT /api/prospecting/entries/:year/:quarter/:weekNumber` - Update entry
- `DELETE /api/prospecting/entries/:id` - Delete entry
- `GET /api/prospecting/settings` - Get user settings
- `PUT /api/prospecting/settings` - Update user settings
- `GET /api/prospecting/goal-templates` - Get goal templates
- `POST /api/prospecting/goal-templates` - Create template
- `PUT /api/prospecting/goal-templates/:id` - Update template
- `DELETE /api/prospecting/goal-templates/:id` - Delete template
- `GET /api/prospecting/dashboard-stats` - Get dashboard statistics

## Pack Requirements

Prospecting is a premium add-on pack requiring the `prospecting` pack subscription.
