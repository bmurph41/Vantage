export const dealStageEnum = ['prospect', 'initial_outreach', 'qualified', 'loi_submitted', 'loi_negotiated', 'loi_executed', 'psa_drafting', 'psa_executed', 'due_diligence', 'dd_extension', 'deposits_hard', 'financing', 'clear_to_close', 'closed', 'transition', 'lease_up', 'stabilized', 'disposition', 'dead_lost'] as const;

// Underwriting stages for Financial Model
export const uwStageEnum = [
  "not_started", "initial_screening", "data_collection", "building_model",
  "sensitivity_analysis", "ic_review", "approved", "passed", "on_hold"
] as const;
export type UWStage = (typeof uwStageEnum)[number];

export const uwStageLabels: Record<string, string> = {
  not_started: "Not Started",
  initial_screening: "Initial Screening",
  data_collection: "Data Collection",
  building_model: "Building Model",
  sensitivity_analysis: "Sensitivity Analysis",
  ic_review: "IC Review",
  approved: "Approved",
  passed: "Passed",
  on_hold: "On Hold",
};

// Sub-statuses per UW stage
export const uwSubStatuses: Record<string, { value: string; label: string }[]> = {
  not_started: [
    { value: "queued", label: "Queued" },
    { value: "awaiting_om", label: "Awaiting OM" },
  ],
  initial_screening: [
    { value: "reviewing_om", label: "Reviewing OM" },
    { value: "back_of_envelope", label: "Back-of-Envelope" },
    { value: "go_no_go", label: "Go/No-Go Decision" },
  ],
  data_collection: [
    { value: "waiting_on_financials", label: "Waiting on Financials" },
    { value: "waiting_on_rent_roll", label: "Waiting on Rent Roll" },
    { value: "waiting_on_pnl", label: "Waiting on P\u0026L" },
    { value: "waiting_on_leases", label: "Waiting on Leases" },
    { value: "documents_received", label: "Documents Received" },
  ],
  building_model: [
    { value: "revenue_assumptions", label: "Revenue Assumptions" },
    { value: "expense_assumptions", label: "Expense Assumptions" },
    { value: "debt_structuring", label: "Debt Structuring" },
    { value: "exit_modeling", label: "Exit Modeling" },
    { value: "reviewing", label: "Reviewing" },
  ],
  sensitivity_analysis: [
    { value: "running_scenarios", label: "Running Scenarios" },
    { value: "stress_testing", label: "Stress Testing" },
    { value: "finalizing", label: "Finalizing" },
  ],
  ic_review: [
    { value: "submitted", label: "Submitted to IC" },
    { value: "questions_pending", label: "Questions Pending" },
    { value: "revisions_requested", label: "Revisions Requested" },
    { value: "final_review", label: "Final Review" },
  ],
  approved: [],
  passed: [
    { value: "pricing", label: "Pricing Too High" },
    { value: "returns", label: "Returns Below Threshold" },
    { value: "risk", label: "Risk Factors" },
    { value: "timing", label: "Timing/Capacity" },
    { value: "other", label: "Other" },
  ],
  on_hold: [
    { value: "seller_delay", label: "Seller Delay" },
    { value: "financing_delay", label: "Financing Delay" },
    { value: "internal", label: "Internal Hold" },
  ],
};

// Default valuation metric per asset class
export const assetClassValuationDefaults: Record<string, { metric: string; label: string }> = {
  marina: { metric: "cap_rate", label: "Cap Rate" },
  multifamily: { metric: "cap_rate", label: "Cap Rate" },
  retail: { metric: "cap_rate", label: "Cap Rate" },
  office: { metric: "cap_rate", label: "Cap Rate" },
  industrial: { metric: "cap_rate", label: "Cap Rate" },
  self_storage: { metric: "cap_rate", label: "Cap Rate" },
  mixed_use: { metric: "cap_rate", label: "Cap Rate" },
  hotel: { metric: "ebitda_multiple", label: "EBITDA Multiple" },
  str: { metric: "grm", label: "GRM" },
  sfr: { metric: "grm", label: "GRM" },
  duplex: { metric: "grm", label: "GRM" },
  laundromat: { metric: "ebitda_multiple", label: "EBITDA Multiple" },
  medical_office: { metric: "cap_rate", label: "Cap Rate" },
  business: { metric: "ebitda_multiple", label: "EBITDA Multiple" },
};

// Lease types for marina properties
export const leaseTypeOptions = [
  'ground_lease',
  'submerged_land_lease',
  'dock_lease',
  'slip_lease',
  'mooring_lease',
  'facility_lease',
  'other'
] as const;

export type LeaseType = typeof leaseTypeOptions[number];

export interface Lease {
  id?: string;
  type: string; // ground_lease, submerged_land_lease, etc.
  lessor: string; // Who it's with (landlord/lessor name)
  startDate: string | null; // ISO date string
  endDate: string | null; // ISO date string  
  extensionEnabled: boolean;
  extensionNotes?: string; // Details about extension options
}

// Enhanced Deals/Opportunities table

export const crmDeals = pgTable("crm_deals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  type: text("type"), // Deal type: storage_lease, marina_acquisition, new_listing, etc.
  description: text("description"),
  value: decimal("value", { precision: 12, scale: 2 }),
  amount: decimal("amount", { precision: 12, scale: 2 }),
  // Pipeline & Stage Management (Pipedrive-like) - nullable for backward compatibility
  pipelineId: varchar("pipeline_id").references(() => crmPipelines.id),
  stageId: varchar("stage_id").references(() => crmPipelineStages.id),
  stageOrder: integer("stage_order").default(0), // position within stage for drag & drop
  // Legacy stage field for backward compatibility
  stage: text("stage").notNull().default('lead'),
  probability: integer("probability").default(10), // 0-100 percentage
  priority: text("priority").notNull().default('medium'), // low, medium, high, critical
  expectedCloseDate: timestamp("expected_close_date"),
  leadSource: text("lead_source"),
  lastActivityDate: timestamp("last_activity_date"),
  daysInCurrentStage: integer("days_in_current_stage").default(0),
  currentStageEnteredAt: timestamp("current_stage_entered_at").defaultNow(),
  lostReason: text("lost_reason"),
  competitorId: varchar("competitor_id"),
  forecastCategory: text("forecast_category"),
  // Commission Tracking
  commissionAmount: decimal("commission_amount", { precision: 12, scale: 2 }),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }), // percentage (e.g., 3.50 for 3.5%)
  commissionType: text("commission_type").default('percentage'), // percentage, fixed, tiered
  dealSource: text("deal_source"), // inbound, outbound, referral, partner, organic
  sourceDetails: jsonb("source_details").default({}), // Additional source metadata
  // Marina-specific fields
  marinaName: text("marina_name"),
  slipNumber: text("slip_number"),
  dockLocation: text("dock_location"),
  boatName: text("boat_name"),
  boatMake: text("boat_make"),
  boatModel: text("boat_model"),
  boatYear: integer("boat_year"),
  boatLength: decimal("boat_length", { precision: 6, scale: 2 }), // in feet
  boatType: text("boat_type"), // sailboat, powerboat, yacht, etc.
  propertyType: text("property_type"), // slip, boat, mooring, dry_storage
  assetClass: text("asset_class").default('marina'), // marina, multifamily, retail, office, industrial, hotel, mixed_use, land, self_storage, mobile_home_park, other
  leaseTermMonths: integer("lease_term_months"),
  leases: jsonb("leases").default([]), // Array of {type, lessor, startDate, endDate, extensionEnabled, extensionNotes}
  // Property Details - comprehensive marina property information from OMs
  propertyDetails: jsonb("property_details").default({}), // Structured property data including capacity, equipment, financials, location, etc.
  // DD Deal Details fields - mirror DD project setup fields
  city: text("city"),
  state: text("state"),
  anchorType: text("anchor_type").default('psa'), // psa or custom
  useBusinessDays: boolean("use_business_days").default(false),
  holidayCalendar: text("holiday_calendar").default('us_federal'), // us_federal or none
  tz: text("tz").default('America/New_York'),
  psaSignedDate: timestamp("psa_signed_date"),
  ddExpirationDate: timestamp("dd_expiration_date"),
  closingDate: timestamp("closing_date"),
  ddPeriodDays: integer("dd_period_days"),
  hasExtensions: boolean("has_extensions").default(false),
  extensionCount: integer("extension_count").default(0),
  extensionDays: integer("extension_days").array(),
  daysToClosing: integer("days_to_closing"),
  // Key Contacts (arrays of contact IDs or names)
  seller: text("seller").array(),
  ourAttorney: text("our_attorney").array(),
  titleInsuranceCompany: text("title_insurance_company"),
  lender: text("lender"),
  // Deposit Information
  firstDepositAmount: decimal("first_deposit_amount", { precision: 12, scale: 2 }),
  firstDepositDays: integer("first_deposit_days"),
  firstDepositDueDate: timestamp("first_deposit_due_date"),
  secondDepositAmount: decimal("second_deposit_amount", { precision: 12, scale: 2 }),
  secondDepositDays: integer("second_deposit_days"),
  secondDepositDueDate: timestamp("second_deposit_due_date"),
  customDeadlines: jsonb("custom_deadlines").default([]), // Array of {label, date, showOnTimeline}
  // Relationships - matching actual database structure
  leadId: varchar("lead_id"),
  accountId: varchar("account_id"),
  primaryContactId: varchar("primary_contact_id"),
  campaignId: varchar("campaign_id"),
  contactId: varchar("contact_id"), // Legacy column
  companyId: varchar("company_id"), // Legacy column  
  // Team members
  referralAgentId: varchar("referral_agent_id").references(() => crmContacts.id), // External referring agent
  transactionCoordinatorId: varchar("transaction_coordinator_id").references(() => users.id), // Internal TC
  ownerId: varchar("owner_id").notNull(),
  // DD Project Integration
  ddProjectId: varchar("dd_project_id").references(() => projects.id), // Links to DD project if converted
  // Closed Deal Tracking
  isClosed: boolean("is_closed").default(false),
  closedAt: timestamp("closed_at"),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  // Performance indexes for dashboard queries
  ownerCreatedAtIdx: index("crm_deals_owner_created_at").on(table.ownerId, table.createdAt),
  stageIdx: index("crm_deals_stage").on(table.stage),
  createdAtIdx: index("crm_deals_created_at").on(table.createdAt),
}));

// CRM Deal Stage History - Tracks all stage transitions for analytics
export const crmDealStageHistory = pgTable("crm_deal_stage_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").notNull().references(() => crmDeals.id, { onDelete: "cascade" }),
  stageId: varchar("stage_id").notNull().references(() => crmPipelineStages.id),
  stageName: text("stage_name").notNull(), // Denormalized for historical accuracy
  pipelineId: varchar("pipeline_id").references(() => crmPipelines.id),
  enteredAt: timestamp("entered_at").notNull().defaultNow(),
  exitedAt: timestamp("exited_at"),
  durationSeconds: integer("duration_seconds"), // Calculated when exiting stage
  durationBusinessDays: integer("duration_business_days"), // Calculated excluding weekends/holidays
  transitionReason: text("transition_reason"), // Optional note for why stage changed
  transitionedBy: varchar("transitioned_by").references(() => users.id),
  isCurrentStage: boolean("is_current_stage").default(true).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  dealIdx: index("crm_deal_stage_history_deal_idx").on(table.dealId),
  stageIdx: index("crm_deal_stage_history_stage_idx").on(table.stageId),
  enteredAtIdx: index("crm_deal_stage_history_entered_at_idx").on(table.enteredAt),
  currentStageIdx: index("crm_deal_stage_history_current_idx").on(table.dealId, table.isCurrentStage),
}));

// CRM Timeline Events - Unified event tracking across entities
export const crmTimelineEventTypeEnum = pgEnum("crm_timeline_event_type", [
  "stage_change",
  "deal_created",
  "deal_won",
  "deal_lost",
  "activity_logged",
  "note_added",
  "file_uploaded",
  "email_sent",
  "email_received",
  "call_logged",
  "meeting_scheduled",
  "meeting_completed",
  "task_created",
  "task_completed",
  "contact_added",
  "company_added",
  "property_linked",
  "value_changed",
  "owner_changed",
  "comment_added",
  "document_signed",
  "milestone_reached",
  "custom"
]);

export const crmTimelineEvents = pgTable("crm_timeline_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  eventType: crmTimelineEventTypeEnum("event_type").notNull(),
  entityType: text("entity_type").notNull(), // deal, contact, company, property
  entityId: varchar("entity_id").notNull(),
  relatedEntityType: text("related_entity_type"), // For events that link entities
  relatedEntityId: varchar("related_entity_id"),
  title: text("title").notNull(),
  description: text("description"),
  metadata: jsonb("metadata").default({}).notNull(), // Flexible payload for event-specific data
  occurredAt: timestamp("occurred_at").notNull().defaultNow(),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("crm_timeline_events_org_idx").on(table.orgId),
  entityIdx: index("crm_timeline_events_entity_idx").on(table.entityType, table.entityId),
  occurredAtIdx: index("crm_timeline_events_occurred_at_idx").on(table.occurredAt),
  eventTypeIdx: index("crm_timeline_events_type_idx").on(table.eventType),
}));

// CRM Deal Engagement Scores - Tracks engagement metrics for win probability
export const crmDealEngagementScores = pgTable("crm_deal_engagement_scores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").notNull().references(() => crmDeals.id, { onDelete: "cascade" }).unique(),
  engagementScore: integer("engagement_score").default(0).notNull(), // 0-100 composite score
  activityScore: integer("activity_score").default(0), // Based on activity frequency
  responseScore: integer("response_score").default(0), // Based on email/call response rates
  meetingScore: integer("meeting_score").default(0), // Based on meeting attendance
  documentScore: integer("document_score").default(0), // Based on document activity
  recencyScore: integer("recency_score").default(0), // Based on last activity recency
  stageVelocityScore: integer("stage_velocity_score").default(0), // Based on stage progression speed
  winProbability: integer("win_probability").default(10), // 0-100 calculated probability
  factors: jsonb("factors").default({}).notNull(), // Detailed breakdown of score factors
  lastCalculatedAt: timestamp("last_calculated_at").defaultNow().notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  dealIdx: index("crm_deal_engagement_deal_idx").on(table.dealId),
  scoreIdx: index("crm_deal_engagement_score_idx").on(table.engagementScore),
  probabilityIdx: index("crm_deal_engagement_probability_idx").on(table.winProbability),
}));

// Contact Engagement Scores - Tracks engagement metrics for contacts
export const crmContactEngagementScores = pgTable("crm_contact_engagement_scores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  contactId: varchar("contact_id").notNull().references(() => crmContacts.id, { onDelete: "cascade" }).unique(),
  engagementScore: integer("engagement_score").default(0).notNull(), // 0-100 composite score
  emailScore: integer("email_score").default(0), // Based on email opens and clicks
  meetingScore: integer("meeting_score").default(0), // Based on meeting attendance
  callScore: integer("call_score").default(0), // Based on call frequency
  dealInvolvementScore: integer("deal_involvement_score").default(0), // Based on deals associated
  recencyScore: integer("recency_score").default(0), // Based on last interaction recency
  responseScore: integer("response_score").default(0), // Based on response rates
  emailsOpened: integer("emails_opened").default(0),
  emailsClicked: integer("emails_clicked").default(0),
  emailsSent: integer("emails_sent").default(0),
  totalMeetings: integer("total_meetings").default(0),
  totalCalls: integer("total_calls").default(0),
  dealsInvolved: integer("deals_involved").default(0),
  lastEmailOpen: timestamp("last_email_open"),
  lastEmailClick: timestamp("last_email_click"),
  lastMeeting: timestamp("last_meeting"),
  lastCall: timestamp("last_call"),
  lastInteraction: timestamp("last_interaction"),
  factors: jsonb("factors").default({}).notNull(), // Detailed breakdown of score factors
  lastCalculatedAt: timestamp("last_calculated_at").defaultNow().notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  contactIdx: index("crm_contact_engagement_contact_idx").on(table.contactId),
  scoreIdx: index("crm_contact_engagement_score_idx").on(table.engagementScore),
}));

// Products table - for revenue tracking

export const crmProducts = pgTable("crm_products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  code: text("code"), // product SKU or code
  description: text("description"),
  unit: text("unit").default('unit'), // unit, hour, month, year, etc.
  price: decimal("price", { precision: 12, scale: 2 }).notNull().default('0'),
  cost: decimal("cost", { precision: 12, scale: 2 }),
  category: text("category"), // Service, Product, License, etc.
  isActive: boolean("is_active").default(true),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type CrmProduct = typeof crmProducts.$inferSelect;
export type InsertCrmProduct = typeof crmProducts.$inferInsert;

// Deal Products junction table - for associating products with deals and tracking recurring revenue

export const crmDealProducts = pgTable("crm_deal_products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id).notNull(),
  productId: varchar("product_id").references(() => crmProducts.id).notNull(),
  quantity: integer("quantity").notNull().default(1),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(), // price at time of deal
  discount: decimal("discount", { precision: 5, scale: 2 }).default('0'), // percentage discount
  totalPrice: decimal("total_price", { precision: 12, scale: 2 }).notNull(),
  isRecurring: boolean("is_recurring").default(false),
  billingCycle: text("billing_cycle"), // monthly, quarterly, annually
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  notes: text("notes"),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Notes table - structured notes that can be attached to any entity

export const crmNotes = pgTable("crm_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  content: text("content").notNull(),
  isPinned: boolean("is_pinned").default(false),
  entityType: text("entity_type").notNull(), // deal, contact, company, property, lead, etc.
  orgId: varchar("org_id").references(() => organizations.id),
  entityId: varchar("entity_id").notNull(),
  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  ownerId: varchar("owner_id").references(() => users.id).notNull(), // for multi-tenant access control
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Files table - file attachments that can be associated with any entity

export const crmFiles = pgTable("crm_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // display name
  fileName: text("file_name").notNull(), // actual file name with extension
  size: integer("size").notNull(), // file size in bytes
  mimeType: text("mime_type").notNull(), // e.g., 'application/pdf', 'image/jpeg'
  url: text("url").notNull(), // file URL or path
  entityType: text("entity_type").notNull(), // deal, contact, company, property, lead, etc.
  entityId: varchar("entity_id").notNull(),
  uploadedById: varchar("uploaded_by_id").references(() => users.id).notNull(),
  ownerId: varchar("owner_id").references(() => users.id).notNull(), // for multi-tenant access control
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// CRM ASSOCIATIONS - Entity linking graph for relationships
// ============================================================================

export const associationTypeEnum = pgEnum("association_type", [
  "company_contact",
  "company_property",
  "company_deal",
  "contact_deal",
  "contact_property",
  "property_deal",
  "deal_project",
]);

export const crmAssociations = pgTable("crm_associations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  associationType: associationTypeEnum("association_type").notNull(),
  sourceEntityType: text("source_entity_type").notNull(),
  sourceEntityId: varchar("source_entity_id").notNull(),
  targetEntityType: text("target_entity_type").notNull(),
  targetEntityId: varchar("target_entity_id").notNull(),
  metadata: jsonb("metadata").$type<Record<string, any>>(),
  createdById: varchar("created_by_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// PROSPECTING & OUTREACH MODULE - Deal sourcing and activity tracking
// ============================================================================ - Deal sourcing and activity tracking
// ============================================================================

// Prospecting Activities - Tracks all outreach touches (calls, emails, meetings, etc.)
export const prospectingActivities = pgTable("prospecting_activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  type: prospectingActivityTypeEnum("type").notNull(), // call, email, meeting, voicemail, text, linkedin, other
  direction: prospectingActivityDirectionEnum("direction").notNull().default("outbound"), // outbound, inbound, internal
  outcome: prospectingActivityOutcomeEnum("outcome"), // connected, no_answer, left_message, etc.
  subject: text("subject"),
  description: text("description"),
  duration: integer("duration"), // Duration in seconds (for calls/meetings)
  scheduledAt: timestamp("scheduled_at"), // When the activity was scheduled
  completedAt: timestamp("completed_at"), // When it was actually completed
  contactId: varchar("contact_id").references(() => crmContacts.id),
  companyId: varchar("company_id").references(() => crmCompanies.id),
  propertyId: varchar("property_id").references(() => crmProperties.id),
  dealId: varchar("deal_id").references(() => crmDeals.id),
  campaignId: varchar("campaign_id"), // Links to outreach campaign if part of one
  weekId: varchar("week_id"), // Links to prospecting week for weekly tracking
  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("prospecting_activities_org_idx").on(table.orgId),
  ownerIdx: index("prospecting_activities_owner_idx").on(table.ownerId),
  typeIdx: index("prospecting_activities_type_idx").on(table.type),
  contactIdx: index("prospecting_activities_contact_idx").on(table.contactId),
  weekIdx: index("prospecting_activities_week_idx").on(table.weekId),
  createdAtIdx: index("prospecting_activities_created_at_idx").on(table.createdAt),
}));

// Prospecting Weeks - Weekly activity tracking and goal setting
export const prospectingWeeks = pgTable("prospecting_weeks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  weekStart: date("week_start").notNull(), // Monday of the week
  weekEnd: date("week_end").notNull(), // Sunday of the week
  // Goals
  callsGoal: integer("calls_goal").default(50),
  emailsGoal: integer("emails_goal").default(100),
  meetingsGoal: integer("meetings_goal").default(10),
  leadsGoal: integer("leads_goal").default(5),
  // Actual counts (computed or manually updated)
  callsActual: integer("calls_actual").default(0),
  emailsActual: integer("emails_actual").default(0),
  meetingsActual: integer("meetings_actual").default(0),
  leadsActual: integer("leads_actual").default(0),
  // Additional metrics
  conversations: integer("conversations").default(0), // Successful connections
  dealsCreated: integer("deals_created").default(0),
  notes: text("notes"),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgOwnerWeekIdx: unique().on(table.orgId, table.ownerId, table.weekStart),
  weekStartIdx: index("prospecting_weeks_week_start_idx").on(table.weekStart),
}));

// Outreach Campaigns - Email/call campaigns for systematic prospecting
export const outreachCampaigns = pgTable("outreach_campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  type: outreachCampaignTypeEnum("type").notNull().default("email"), // email, call, mixed
  status: outreachCampaignStatusEnum("status").notNull().default("draft"), // draft, active, paused, completed, archived
  description: text("description"),
  // Target criteria (stored as JSON for flexibility)
  targetCriteria: jsonb("target_criteria").default({}), // Filters for selecting targets
  targetCount: integer("target_count").default(0), // Number of contacts in campaign
  // Metrics
  sentCount: integer("sent_count").default(0),
  openedCount: integer("opened_count").default(0),
  repliedCount: integer("replied_count").default(0),
  bouncedCount: integer("bounced_count").default(0),
  // Schedule
  startDate: date("start_date"),
  endDate: date("end_date"),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgStatusIdx: index("outreach_campaigns_org_status_idx").on(table.orgId, table.status),
}));

// Outreach Templates - Reusable email/call scripts
export const outreachTemplates = pgTable("outreach_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  type: text("type").notNull().default("email"), // email, call_script
  category: text("category"), // Cold Outreach, Follow-up, Nurture, etc.
  subject: text("subject"), // For emails
  content: text("content").notNull(), // Template content with merge fields
  usageCount: integer("usage_count").default(0),
  lastUsedAt: timestamp("last_used_at"),
  isActive: boolean("is_active").default(true),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Market Targets - Geographic/segment targets for prospecting
export const marketTargets = pgTable("market_targets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(), // e.g., "Tampa Bay", "Great Lakes Region"
  region: text("region"), // Broader region (e.g., "Southeast", "Midwest")
  states: text("states").array().default(sql`ARRAY[]::text[]`), // States included
  status: marketTargetStatusEnum("status").notNull().default("research"), // research, active, saturated, paused
  priority: marketTargetPriorityEnum("priority").notNull().default("medium"),
  // Market metrics
  totalMarinas: integer("total_marinas").default(0),
  targetedMarinas: integer("targeted_marinas").default(0),
  contactedMarinas: integer("contacted_marinas").default(0),
  convertedDeals: integer("converted_deals").default(0),
  // Notes and research
  notes: text("notes"),
  researchNotes: jsonb("research_notes").default({}), // Structured research data
  assignedToId: varchar("assigned_to_id").references(() => users.id),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgStatusIdx: index("market_targets_org_status_idx").on(table.orgId, table.status),
}));

// Deal Contacts Junction - Many-to-many relationship between deals and contacts with roles
export const crmDealContacts = pgTable("crm_deal_contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id).notNull(),
  contactId: varchar("contact_id").references(() => crmContacts.id).notNull(),
  role: text("role"), // seller, buyer, broker, attorney, lender, etc.
  isPrimary: boolean("is_primary").default(false),
  notes: text("notes"),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  uniqueDealContact: unique().on(table.dealId, table.contactId),
}));

// Deal Companies Junction - Many-to-many relationship between deals and companies
export const crmDealCompanies = pgTable("crm_deal_companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id).notNull(),
  companyId: varchar("company_id").references(() => crmCompanies.id).notNull(),
  role: text("role"), // seller, buyer, broker_firm, lender, title_company, etc.
  isPrimary: boolean("is_primary").default(false),
  notes: text("notes"),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  uniqueDealCompany: unique().on(table.dealId, table.companyId),
}));

// ============================================================================
// VIRTUAL DATA ROOM (VDR) - DealRoom-competitive secure document repository
// ============================================================================

// VDR Folders - Hierarchical folder structure for document organization
export const vdrFolders = pgTable("vdr_folders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  parentFolderId: varchar("parent_folder_id"), // Self-reference for hierarchy
  name: text("name").notNull(),
  path: text("path").notNull(), // Full path for easy breadcrumb navigation
  displayOrder: integer("display_order").notNull().default(0),
  description: text("description"),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  deletedAt: timestamp("deleted_at"), // Soft delete support
}, (table) => ({
  projectIdx: index("vdr_folders_project_idx").on(table.projectId),
  parentIdx: index("vdr_folders_parent_idx").on(table.parentFolderId),
  orgIdx: index("vdr_folders_org_idx").on(table.orgId),
}));

// VDR Documents - Core document storage with versioning support
export const vdrDocuments = pgTable("vdr_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  folderId: varchar("folder_id").notNull().references(() => vdrFolders.id),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  filename: text("filename").notNull(), // Display name
  originalFilename: text("original_filename").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(), // bytes
  checksum: text("checksum").notNull(), // SHA-256 for integrity verification
  storagePath: text("storage_path").notNull(), // S3 key or filesystem path
  thumbnailPath: text("thumbnail_path"), // For images/PDFs
  version: integer("version").notNull().default(1),
  isCurrentVersion: boolean("is_current_version").notNull().default(true),
  parentDocumentId: varchar("parent_document_id"), // Link to original for versions
  // AI-extracted metadata
  extractedText: text("extracted_text"), // OCR or PDF text extraction
  aiCategory: text("ai_category"), // Auto-categorized by AI
  aiTags: text("ai_tags").array().default(sql`'{}'`),
  aiSummary: text("ai_summary"),
  aiRiskFlags: jsonb("ai_risk_flags").default(sql`'[]'`), // Array of {flag, severity, description}
  // User metadata
  description: text("description"),
  tags: text("tags").array().default(sql`'{}'`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  uploadedBy: varchar("uploaded_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  deletedAt: timestamp("deleted_at"), // Soft delete support
}, (table) => ({
  folderIdx: index("vdr_documents_folder_idx").on(table.folderId),
  projectIdx: index("vdr_documents_project_idx").on(table.projectId),
  versionIdx: index("vdr_documents_version_idx").on(table.parentDocumentId, table.version),
  orgIdx: index("vdr_documents_org_idx").on(table.orgId),
}));

// VDR Document Permissions - Granular access control (user/role/folder/document level)
export const vdrDocumentPermissions = pgTable("vdr_document_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  // Permission target (one of these must be set)
  documentId: varchar("document_id").references(() => vdrDocuments.id),
  folderId: varchar("folder_id").references(() => vdrFolders.id),
  projectId: varchar("project_id").references(() => projects.id),
  // Permission subject (one of these must be set)
  userId: varchar("user_id").references(() => users.id),
  externalUserId: varchar("external_user_id"), // References external_users (defined below)
  roleEnum: roleEnum("role_enum"), // Apply to all users with this role
  // Permission details
  permissionLevel: vdrPermissionLevelEnum("permission_level").notNull(),
  expiresAt: timestamp("expires_at"), // Time-limited access
  ipWhitelist: text("ip_whitelist").array().default(sql`'{}'`), // Restrict to IPs
  deviceRestrictions: jsonb("device_restrictions").default(sql`'{}'`), // {allowMobile: false, etc}
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  grantedBy: varchar("granted_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  documentIdx: index("vdr_permissions_document_idx").on(table.documentId),
  folderIdx: index("vdr_permissions_folder_idx").on(table.folderId),
  userIdx: index("vdr_permissions_user_idx").on(table.userId),
  externalUserIdx: index("vdr_permissions_external_user_idx").on(table.externalUserId),
  orgIdx: index("vdr_document_permissions_org_idx").on(table.orgId),
}));

// VDR Watermarks - Dynamic/static watermark configuration
export const vdrWatermarks = pgTable("vdr_watermarks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  // Watermark target (apply to document, folder, or whole project)
  documentId: varchar("document_id").references(() => vdrDocuments.id),
  folderId: varchar("folder_id").references(() => vdrFolders.id),
  projectId: varchar("project_id").references(() => projects.id),
  watermarkType: watermarkTypeEnum("watermark_type").notNull(),
  staticText: text("static_text"), // For static watermarks
  isDynamic: boolean("is_dynamic").notNull().default(true), // Show viewer name/email/time
  opacity: integer("opacity").notNull().default(30), // 0-100
  position: text("position").notNull().default("diagonal"), // diagonal, center, corners, tiled
  includeQrCode: boolean("include_qr_code").notNull().default(false),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  documentIdx: index("vdr_watermarks_document_idx").on(table.documentId),
  folderIdx: index("vdr_watermarks_folder_idx").on(table.folderId),
  projectIdx: index("vdr_watermarks_project_idx").on(table.projectId),
}));

// VDR Audit Logs - Comprehensive document activity tracking
export const vdrAuditLogs = pgTable("vdr_audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  documentId: varchar("document_id").references(() => vdrDocuments.id),
  folderId: varchar("folder_id").references(() => vdrFolders.id),
  // Actor (who performed the action)
  userId: varchar("user_id").references(() => users.id),
  externalUserId: varchar("external_user_id"), // References external_users
  eventType: auditEventTypeEnum("event_type").notNull(),
  // Event details
  duration: integer("duration"), // Time spent viewing (seconds)
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  deviceInfo: jsonb("device_info").default(sql`'{}'`), // {browser, os, deviceType}
  metadata: jsonb("metadata").default(sql`'{}'`), // Additional event context
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
}, (table) => ({
  documentIdx: index("vdr_audit_logs_document_idx").on(table.documentId),
  userIdx: index("vdr_audit_logs_user_idx").on(table.userId),
  externalUserIdx: index("vdr_audit_logs_external_user_idx").on(table.externalUserId),
  timestampIdx: index("vdr_audit_logs_timestamp_idx").on(table.timestamp),
  orgIdx: index("vdr_audit_logs_org_idx").on(table.orgId),
}));

// VDR Folder Templates - Reusable folder structures for real estate deals
export const vdrTemplates = pgTable("vdr_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull().default("real_estate"), // real_estate, custom, etc.
  isDefault: boolean("is_default").notNull().default(false), // System-provided templates
  isPublic: boolean("is_public").notNull().default(true), // Available to all orgs
  orgId: varchar("org_id").references(() => organizations.id), // null for system templates
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  categoryIdx: index("vdr_templates_category_idx").on(table.category),
  orgIdx: index("vdr_templates_org_idx").on(table.orgId),
}));

// VDR Template Folders - Folder definitions within templates
export const vdrTemplateFolders = pgTable("vdr_template_folders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  templateId: varchar("template_id").notNull().references(() => vdrTemplates.id, { onDelete: 'cascade' }),
  name: text("name").notNull(),
  parentFolderId: varchar("parent_folder_id"), // Self-reference for hierarchy within template
  displayOrder: integer("display_order").notNull().default(0),
  description: text("description"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  templateIdx: index("vdr_template_folders_template_idx").on(table.templateId),
  parentIdx: index("vdr_template_folders_parent_idx").on(table.parentFolderId),
}));

// ============================================================================
// DILIGENCE REQUEST MANAGEMENT - DealRoom-style request tracking
// ============================================================================

// Diligence Requests - Document requests separate from tasks
export const diligenceRequests = pgTable("diligence_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  taskId: varchar("task_id").references(() => tasks.id), // Optional link to DD task
  category: requestCategoryEnum("category").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  priority: requestPriorityEnum("priority").notNull().default("medium"),
  status: requestStatusEnum("status").notNull().default("pending"),
  // Assignment
  assigneeId: varchar("assignee_id").references(() => users.id),
  externalAssigneeId: varchar("external_assignee_id"), // References external_users
  externalAssigneeEmail: text("external_assignee_email"), // For manual entry
  requestorId: varchar("requestor_id").notNull().references(() => users.id),
  // Dates
  dueDate: date("due_date"),
  respondedAt: timestamp("responded_at"),
  completedAt: timestamp("completed_at"),
  // Response
  responseText: text("response_text"),
  // SLA tracking
  slaHours: integer("sla_hours"), // Expected response time
  isOverdue: boolean("is_overdue").notNull().default(false),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  deletedAt: timestamp("deleted_at"), // Soft delete support
}, (table) => ({
  projectIdx: index("diligence_requests_project_idx").on(table.projectId),
  assigneeIdx: index("diligence_requests_assignee_idx").on(table.assigneeId),
  statusIdx: index("diligence_requests_status_idx").on(table.status),
  orgIdx: index("diligence_requests_org_idx").on(table.orgId),
}));

// Request Documents - Link documents to requests (many-to-many)
export const requestDocuments = pgTable("request_documents", {
  requestId: varchar("request_id").notNull().references(() => diligenceRequests.id),
  documentId: varchar("document_id").notNull().references(() => vdrDocuments.id),
  linkedBy: varchar("linked_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  pk: primaryKey({ columns: [table.requestId, table.documentId] }),
  requestIdx: index("request_documents_request_idx").on(table.requestId),
  documentIdx: index("request_documents_document_idx").on(table.documentId),
}));

// Request Comments - Threaded Q&A on requests
export const requestComments = pgTable("request_comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requestId: varchar("request_id").notNull().references(() => diligenceRequests.id),
  parentCommentId: varchar("parent_comment_id"), // For threading
  userId: varchar("user_id").references(() => users.id),
  externalUserId: varchar("external_user_id"), // References external_users
  content: text("content").notNull(),
  mentions: text("mentions").array().default(sql`'{}'`), // User IDs mentioned with @
  isAnswer: boolean("is_answer").notNull().default(false), // Mark as official answer
  reactions: jsonb("reactions").default(sql`'{}'`), // {👍: [userId1, userId2], ❤️: [...]}
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  requestIdx: index("request_comments_request_idx").on(table.requestId),
  parentIdx: index("request_comments_parent_idx").on(table.parentCommentId),
}));

// Request Templates - Pre-built request lists by category
export const requestTemplates = pgTable("request_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: requestCategoryEnum("category").notNull(),
  isGlobal: boolean("is_global").notNull().default(false), // Available to all orgs
  requests: jsonb("requests").notNull().default(sql`'[]'`), // Array of {title, description, priority}
  orgId: varchar("org_id").references(() => organizations.id), // Null for global templates
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  categoryIdx: index("request_templates_category_idx").on(table.category),
  orgIdx: index("request_templates_org_idx").on(table.orgId),
}));

// ============================================================================
// VDR DATA REQUEST - Document checklist and status tracking for VDR projects
// ============================================================================

// VDR Data Request Templates - Reusable document checklist templates
export const vdrDataRequestTemplates = pgTable("vdr_data_request_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull().default("real_estate"), // real_estate, financial, legal, etc.
  isGlobal: boolean("is_global").notNull().default(false), // Available to all orgs
  orgId: varchar("org_id").references(() => organizations.id), // Null for global templates
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  categoryIdx: index("vdr_data_request_templates_category_idx").on(table.category),
  orgIdx: index("vdr_data_request_templates_org_idx").on(table.orgId),
}));

// VDR Diligence Categories - Organization-specific diligence categories
export const vdrDiligenceCategories = pgTable("vdr_diligence_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  slug: text("slug").notNull(), // Stable identifier for default categories
  name: text("name").notNull(),
  description: text("description"),
  displayOrder: integer("display_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("vdr_diligence_categories_org_idx").on(table.orgId),
  slugOrgIdx: unique("vdr_diligence_categories_slug_org_idx").on(table.slug, table.orgId),
}));

// VDR Due Date Presets - Organization-specific quick-select due date presets
export const vdrDueDatePresets = pgTable("vdr_due_date_presets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  slug: text("slug").notNull(), // Stable identifier for default presets
  name: text("name").notNull(), // e.g., "One Week", "Two Weeks", "One Month"
  days: integer("days").notNull(), // Number of days to add to today
  displayOrder: integer("display_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("vdr_due_date_presets_org_idx").on(table.orgId),
  slugOrgIdx: unique("vdr_due_date_presets_slug_org_idx").on(table.slug, table.orgId),
}));

// VDR Data Request Items - Individual document items in a project's data request checklist
export const vdrDataRequestItems = pgTable("vdr_data_request_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  templateId: varchar("template_id").references(() => vdrDataRequestTemplates.id), // Optional link to template
  category: text("category").notNull(), // Financial, Legal, Operational, etc.
  documentName: text("document_name").notNull(),
  description: text("description"),
  displayOrder: integer("display_order").notNull().default(0),
  status: dataRequestItemStatusEnum("status").notNull().default("outstanding"),
  priority: dataRequestPriorityEnum("priority").notNull().default("medium"),
  // Assignment
  assigneeId: varchar("assignee_id").references(() => users.id), // Internal team member
  externalAssigneeId: varchar("external_assignee_id").references(() => externalUsers.id), // External user (seller, attorney, etc.)
  // Link to VDR document when received
  linkedDocumentId: varchar("linked_document_id").references(() => vdrDocuments.id),
  isInDataRoom: boolean("is_in_data_room").notNull().default(false), // Checkbox sync with data room
  notes: text("notes"),
  dueDate: date("due_date"),
  receivedDate: date("received_date"),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  projectIdx: index("vdr_data_request_items_project_idx").on(table.projectId),
  statusIdx: index("vdr_data_request_items_status_idx").on(table.status),
  categoryIdx: index("vdr_data_request_items_category_idx").on(table.category),
  assigneeIdx: index("vdr_data_request_items_assignee_idx").on(table.assigneeId),
  priorityIdx: index("vdr_data_request_items_priority_idx").on(table.priority),
  orgIdx: index("vdr_data_request_items_org_idx").on(table.orgId),
}));

// ============================================================================
// EXTERNAL USER ACCESS - Seller/buyer/advisor portal
// ============================================================================

// External Users - Non-org users with limited access
export const externalUsers = pgTable("external_users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull(),
  name: text("name").notNull(),
  company: text("company"),
  role: externalUserRoleEnum("role").notNull(),
  invitedBy: varchar("invited_by").notNull().references(() => users.id),
  invitationToken: text("invitation_token").unique(),
  invitationSentAt: timestamp("invitation_sent_at"),
  acceptedAt: timestamp("accepted_at"),
  lastLoginAt: timestamp("last_login_at"),
  twoFactorEnabled: boolean("two_factor_enabled").notNull().default(false),
  twoFactorSecret: text("two_factor_secret"),
  isActive: boolean("is_active").notNull().default(true),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  emailOrgIdx: unique("external_users_email_org_idx").on(table.email, table.orgId),
  tokenIdx: index("external_users_token_idx").on(table.invitationToken),
  orgIdx: index("external_users_org_idx").on(table.orgId),
}));

// External User Project Access - Which projects external users can access
export const externalUserProjectAccess = pgTable("external_user_project_access", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  externalUserId: varchar("external_user_id").notNull().references(() => externalUsers.id),
  projectId: varchar("project_id").notNull().references(() => projects.id),
  canViewFolders: text("can_view_folders").array().default(sql`'{}'`), // Folder IDs
  canViewRequests: text("can_view_requests").array().default(sql`'{}'`), // Request IDs
  expiresAt: timestamp("expires_at"),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  grantedBy: varchar("granted_by").notNull().references(() => users.id),
  status: externalUserProjectAccessStatusEnum("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  // Security hardening fields
  ipWhitelist: text("ip_whitelist").array().default(sql`'{}'`), // Allowed IP addresses/CIDR ranges
  downloadLimit: integer("download_limit"), // Max downloads per document (null = unlimited)
  downloadCount: integer("download_count").notNull().default(0), // Current download count
  accessToken: text("access_token").unique(), // Secure token for external access
  tokenExpiresAt: timestamp("token_expires_at"), // Token-specific expiration
  lastAccessAt: timestamp("last_access_at"), // Track last access time
  lastAccessIp: text("last_access_ip"), // Track last access IP
}, (table) => ({
  externalUserIdx: index("external_project_access_user_idx").on(table.externalUserId),
  projectIdx: index("external_project_access_project_idx").on(table.projectId),
  accessTokenIdx: index("external_project_access_token_idx").on(table.accessToken),
}));

// Contact Roles table - defines relationships between contacts and deals

export const crmContactRoles = pgTable("crm_contact_roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id).notNull(),
  contactId: varchar("contact_id").references(() => crmContacts.id).notNull(),
  role: text("role").notNull().default('buyer'), // buyer, seller, listing_agent, buyer_agent, co_buyer, decision_maker
  isPrimary: boolean("is_primary").default(false),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
// Tasks table - action items and to-dos

export const crmTasks = pgTable("crm_tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type").notNull().default('task'), // task, follow_up, call, email, meeting
  priority: text("priority").notNull().default('medium'), // low, medium, high, urgent
  status: text("status").notNull().default('pending'), // pending, in_progress, completed, cancelled
  dueDate: timestamp("due_date"),
  completed: boolean("completed").notNull().default(false),
  dealId: varchar("deal_id").references(() => crmDeals.id),
  contactId: varchar("contact_id").references(() => crmContacts.id),
  companyId: varchar("company_id").references(() => crmCompanies.id),
  propertyId: varchar("property_id").references(() => crmProperties.id),
  assigneeId: varchar("assignee_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Activities table
// Tasks table

export const crmActivities = pgTable("crm_activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // call, email, sms, meeting, showing, note, mail, document, website_visit, social_media, form_submission
  subject: text("subject"),
  description: text("description").notNull(),
  direction: text("direction"), // inbound, outbound
  duration: integer("duration"), // minutes for calls/meetings
  outcome: text("outcome"),
  status: text("status").default('completed'), // scheduled, in_progress, completed, cancelled
  entityType: text("entity_type").notNull(), // lead, contact, deal, account, property, campaign
  entityId: varchar("entity_id"),
  userId: varchar("user_id").references(() => users.id).notNull(),
  campaignId: varchar("campaign_id").references(() => crmCampaigns.id),
  scheduledAt: timestamp("scheduled_at"),
  completedAt: timestamp("completed_at"),
  metadata: jsonb("metadata"), // phone number, email subject, document URL, page visited, social platform, etc.
  score: integer("score").default(0), // activity scoring for lead qualification
  calendarEventId: text("calendar_event_id"), // Google Calendar event ID
  syncedToCalendar: boolean("synced_to_calendar").default(false),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const crmActivityAssociations = pgTable("crm_activity_associations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  activityId: varchar("activity_id").notNull().references(() => crmActivities.id, { onDelete: 'cascade' }),
  objectType: text("object_type").notNull(),
  objectId: varchar("object_id").notNull(),
  isPrimary: boolean("is_primary").default(false),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  activityIdx: index("crm_activity_assoc_activity_idx").on(table.activityId),
  objectIdx: index("crm_activity_assoc_object_idx").on(table.objectType, table.objectId),
  orgIdx: index("crm_activity_assoc_org_idx").on(table.orgId),
  uniqueAssoc: unique().on(table.activityId, table.objectType, table.objectId),
}));

export const crmSavedViews = pgTable("crm_saved_views", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  objectType: text("object_type").notNull(),
  filters: jsonb("filters").default(sql`'{}'`),
  columns: jsonb("columns").default(sql`'[]'`),
  sortBy: text("sort_by"),
  sortOrder: text("sort_order").default('asc'),
  isDefault: boolean("is_default").default(false),
  isShared: boolean("is_shared").default(false),
  userId: varchar("user_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("crm_saved_views_user_idx").on(table.userId),
  orgIdx: index("crm_saved_views_org_idx").on(table.orgId),
  objectTypeIdx: index("crm_saved_views_object_type_idx").on(table.objectType),
}));

// Activity Templates for quick activity creation

export const crmActivityTemplates = pgTable("crm_activity_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(), // call, email, sms, meeting, showing, note
  subjectTemplate: text("subject_template"),
  descriptionTemplate: text("description_template"),
  defaultDuration: integer("default_duration"), // minutes
  defaultDirection: text("default_direction"), // inbound, outbound
  isGlobal: boolean("is_global").default(false), // true for system templates, false for user templates
  userId: varchar("user_id").references(() => users.id), // null for global templates
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prospecting entries for weekly tracking

export const crmProspectingEntries = pgTable("crm_prospecting_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  year: integer("year").notNull(),
  quarter: integer("quarter").notNull(), // 1, 2, 3, 4
  weekNumber: integer("week_number").notNull(), // 1-13 within quarter
  weekStartDate: timestamp("week_start_date").notNull(),
  weekEndDate: timestamp("week_end_date").notNull(),

  // Weekly goals (up to 6 goals)
  goals: jsonb("goals").default([]), // Array of string goals

  // Enabled days of the week for this prospecting week
  enabledDays: jsonb("enabled_days").default(['monday', 'tuesday', 'wednesday', 'thursday', 'friday']), // Array of enabled day IDs

  // Daily activities tracking (Monday-Friday)
  dailyActivities: jsonb("daily_activities").default({}), // { monday: [], tuesday: [], etc. }

  // Summary metrics
  totalLeadGeneration: integer("total_lead_generation").default(0),
  totalCalls: integer("total_calls").default(0),
  totalEmails: integer("total_emails").default(0),
  totalMeetings: integer("total_meetings").default(0),

  // Reflection notes
  notes: text("notes"),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prospecting Activities for detailed daily tracking

export const crmProspectingActivities = pgTable("crm_prospecting_activities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  prospectingEntryId: varchar("prospecting_entry_id").references(() => crmProspectingEntries.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),

  // Activity details
  activityType: text("activity_type").notNull(), // 'call', 'voicemail', 'no_answer', 'not_interested', 'text', 'linkedin', 'email', 'meeting'
  outcome: text("outcome").notNull(), // 'connected', 'left_voicemail', 'no_answer', 'not_interested', 'callback_requested', 'meeting_scheduled', 'sent', 'opened', 'replied'

  // Timing
  dayOfWeek: text("day_of_week").notNull(), // 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'
  activityDate: timestamp("activity_date").notNull(),
  duration: integer("duration"), // in minutes for calls/meetings

  // Linking to CRM entities
  contactId: varchar("contact_id").references(() => crmContacts.id),
  companyId: varchar("company_id").references(() => crmCompanies.id),
  propertyId: varchar("property_id").references(() => crmProperties.id),
  dealId: varchar("deal_id").references(() => crmDeals.id),

  // Activity details
  notes: text("notes"),
  followUpRequired: boolean("follow_up_required").default(false),
  followUpDate: timestamp("follow_up_date"),

  // Tracking metadata
  phoneNumber: text("phone_number"), // for call activities
  emailAddress: text("email_address"), // for email activities
  linkedinProfile: text("linkedin_profile"), // for linkedin activities
  subject: text("subject"), // for emails/messages

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prospecting User Settings (per-user preferences)
export const crmProspectingUserSettings = pgTable("crm_prospecting_user_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull().unique(),
  orgId: varchar("org_id").references(() => organizations.id).notNull(),

  // Week start preference
  weekStartDay: text("week_start_day").default('monday'), // 'sunday', 'monday', 'saturday'

  // Future settings can be added here
  // e.g., timezone preference, notification preferences, etc.

  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Prospecting Goal Templates (recurring goal templates)
export const crmProspectingGoalTemplates = pgTable("crm_prospecting_goal_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id).notNull(),

  // Template details
  name: text("name").notNull(), // e.g., "Weekly Call Goal", "Monthly Lead Goal"
  description: text("description"),
  frequency: text("frequency").notNull(), // 'weekly', 'monthly'

  // Goal content (array of goal strings)
  goals: jsonb("goals").default([]).notNull(), // Array of string goals

  // Auto-instantiation
  autoInstantiate: boolean("auto_instantiate").default(false), // Auto-create goals for new weeks

  // Status
  isActive: boolean("is_active").default(true),

  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Email Communications (for email tracking)

export const crmEmailCommunications = pgTable("crm_email_communications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  fromEmail: text("from_email").notNull(),
  toEmail: text("to_email").notNull(),
  ccEmails: jsonb("cc_emails").default([]),
  bccEmails: jsonb("bcc_emails").default([]),
  status: text("status").notNull().default('sent'), // draft, sent, delivered, opened, clicked, bounced, failed
  isTemplateUsed: boolean("is_template_used").default(false),
  templateId: varchar("template_id").references(() => crmEmailTemplates.id),
  sequenceId: varchar("sequence_id").references(() => crmEmailSequences.id),
  leadId: varchar("lead_id").references(() => crmLeads.id),
  contactId: varchar("contact_id").references(() => crmContacts.id),
  dealId: varchar("deal_id").references(() => crmDeals.id),
  campaignId: varchar("campaign_id").references(() => crmCampaigns.id),
  sentById: varchar("sent_by_id").references(() => users.id).notNull(),
  sentAt: timestamp("sent_at").defaultNow().notNull(),
  openedAt: timestamp("opened_at"),
  clickedAt: timestamp("clicked_at"),
  bouncedAt: timestamp("bounced_at"),
  metadata: jsonb("metadata").default({}), // tracking pixels, links clicked, etc.
});

// Lead/Contact Scoring Rules

export const crmScoringRules = pgTable("crm_scoring_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  triggerEvent: text("trigger_event").notNull(), // email_opened, form_submitted, page_visited, etc.
  conditions: jsonb("conditions").notNull(), // criteria for scoring
  points: integer("points").notNull(),
  isActive: boolean("is_active").default(true),
  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Website Visitor Tracking

export const crmWebsiteVisitors = pgTable("crm_website_visitors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  visitorId: text("visitor_id").notNull(), // anonymous tracking ID or known contact ID
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  location: jsonb("location").default({}), // country, city, etc.
  pageUrl: text("page_url").notNull(),
  pageTitle: text("page_title"),
  referrerUrl: text("referrer_url"),
  sessionDuration: integer("session_duration"), // seconds
  leadId: varchar("lead_id").references(() => crmLeads.id),
  contactId: varchar("contact_id").references(() => crmContacts.id),
  campaignId: varchar("campaign_id").references(() => crmCampaigns.id),
  visitedAt: timestamp("visited_at").defaultNow().notNull(),
});

// Lead Scoring Events - Track all behavioral events for scoring

export const crmLeadScoringEvents = pgTable("crm_lead_scoring_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").references(() => crmLeads.id),
  contactId: varchar("contact_id").references(() => crmContacts.id),

  // Event Details
  eventType: text("event_type").notNull(), // page_visit, email_open, email_click, form_submit, call_made, meeting_attended, etc.
  eventCategory: text("event_category").notNull(), // behavioral, engagement, demographic, marina_specific
  eventAction: text("event_action").notNull(), // specific action taken
  eventLabel: text("event_label"), // additional context
  eventValue: integer("event_value"), // numeric value if applicable

  // Scoring Impact
  pointsAwarded: integer("points_awarded").default(0),
  scoringRuleId: varchar("scoring_rule_id").references(() => crmScoringRules.id),

  // Event Context
  entityType: text("entity_type"), // deal, property, campaign, form, etc.
  entityId: varchar("entity_id"),
  sessionId: text("session_id"),

  // Event Metadata
  metadata: jsonb("metadata").default({}), // flexible JSON for event-specific data

  // Marina/Boat Specific Context
  boatType: text("boat_type"), // sailboat, powerboat, yacht, catamaran
  marinaService: text("marina_service"), // slip_rental, maintenance, storage, fuel
  priceRange: text("price_range"), // under_50k, 50k_100k, 100k_250k, 250k_500k, over_500k
  location: text("location"), // marina or boat location

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Lead Scoring History - Track score changes over time

export const crmLeadScoringHistory = pgTable("crm_lead_scoring_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").references(() => crmLeads.id),
  contactId: varchar("contact_id").references(() => crmContacts.id),

  // Score Change Details
  previousScore: integer("previous_score").default(0),
  newScore: integer("new_score").notNull(),
  scoreDelta: integer("score_delta").notNull(), // positive or negative change

  // Score Temperature Classification
  previousTemperature: text("previous_temperature"), // hot, warm, cold
  newTemperature: text("new_temperature").notNull(), // hot, warm, cold

  // Change Trigger
  triggerEventId: varchar("trigger_event_id").references(() => crmLeadScoringEvents.id),
  triggerEventType: text("trigger_event_type").notNull(),
  changeReason: text("change_reason"), // rule_triggered, manual_adjustment, decay_applied, bulk_update

  // Scoring Context
  scoringRuleId: varchar("scoring_rule_id").references(() => crmScoringRules.id),
  userId: varchar("user_id").references(() => users.id), // if manual change

  // Metadata
  notes: text("notes"),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Lead Engagement Metrics - Calculated engagement patterns

export const crmLeadEngagementMetrics = pgTable("crm_lead_engagement_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").references(() => crmLeads.id).notNull(),
  contactId: varchar("contact_id").references(() => crmContacts.id),

  // Email Engagement
  emailsSent: integer("emails_sent").default(0),
  emailsOpened: integer("emails_opened").default(0),
  emailsClicked: integer("emails_clicked").default(0),
  emailOpenRate: decimal("email_open_rate", { precision: 5, scale: 4 }).default('0'),
  emailClickRate: decimal("email_click_rate", { precision: 5, scale: 4 }).default('0'),

  // Website Engagement
  pageVisits: integer("page_visits").default(0),
  uniquePageVisits: integer("unique_page_visits").default(0),
  totalTimeOnSite: integer("total_time_on_site").default(0), // seconds
  averageSessionDuration: integer("average_session_duration").default(0), // seconds
  bounceRate: decimal("bounce_rate", { precision: 5, scale: 4 }).default('0'),

  // Form Engagement
  formsViewed: integer("forms_viewed").default(0),
  formsStarted: integer("forms_started").default(0),
  formsCompleted: integer("forms_completed").default(0),
  formCompletionRate: decimal("form_completion_rate", { precision: 5, scale: 4 }).default('0'),

  // Communication Response
  callsReceived: integer("calls_received").default(0),
  callsAnswered: integer("calls_answered").default(0),
  callAnswerRate: decimal("call_answer_rate", { precision: 5, scale: 4 }).default('0'),
  averageResponseTime: integer("average_response_time").default(0), // minutes

  // Meeting Engagement
  meetingsScheduled: integer("meetings_scheduled").default(0),
  meetingsAttended: integer("meetings_attended").default(0),
  meetingAttendanceRate: decimal("meeting_attendance_rate", { precision: 5, scale: 4 }).default('0'),

  // Overall Engagement Score
  engagementScore: decimal("engagement_score", { precision: 5, scale: 2 }).default('0'), // 0-100
  engagementTrend: text("engagement_trend").default('stable'), // increasing, decreasing, stable

  // Recency Metrics
  lastEmailOpen: timestamp("last_email_open"),
  lastWebsiteVisit: timestamp("last_website_visit"),
  lastFormSubmission: timestamp("last_form_submission"),
  lastCommunication: timestamp("last_communication"),

  // Activity Level
  activityLevel: text("activity_level").default('low'), // high, medium, low
  daysSinceLastActivity: integer("days_since_last_activity").default(0),

  // Calculation Metadata
  calculatedAt: timestamp("calculated_at").defaultNow().notNull(),
  calculationPeriod: integer("calculation_period").default(30), // days

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Marina Specific Lead Data - Industry-specific lead information

export const crmMarinaLeadData = pgTable("crm_marina_lead_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  leadId: varchar("lead_id").references(() => crmLeads.id).notNull(),
  contactId: varchar("contact_id").references(() => crmContacts.id),

  // Boat Ownership & Interest
  currentBoatOwner: boolean("current_boat_owner").default(false),
  boatOwnershipExperience: text("boat_ownership_experience"), // first_time, experienced, expert
  interestedBoatTypes: jsonb("interested_boat_types").default([]), // sailboat, powerboat, yacht, etc.
  budgetRange: text("budget_range"), // under_50k, 50k_100k, 100k_250k, 250k_500k, over_500k

  // Marina Services Interest
  servicesNeeded: jsonb("services_needed").default([]), // slip_rental, maintenance, storage, fuel, etc.
  preferredMarinaSize: text("preferred_marina_size"), // small, medium, large, megayacht
  preferredAmenities: jsonb("preferred_amenities").default([]), // restaurant, pool, security, etc.

  // Location & Geographic Preferences
  preferredRegions: jsonb("preferred_regions").default([]), // geographic areas
  maxDistanceFromHome: integer("max_distance_from_home"), // miles
  seasonalUsage: text("seasonal_usage"), // year_round, seasonal, occasional

  // Purchase Timeline & Intent
  purchaseTimeline: text("purchase_timeline"), // immediate, 3_months, 6_months, 1_year, exploring
  purchaseType: text("purchase_type"), // buy, lease, rent, charter
  hasFinancing: boolean("has_financing").default(false),
  tradeInVehicle: boolean("trade_in_vehicle").default(false),

  // Industry Role & Expertise
  industryRole: text("industry_role"), // boat_owner, marina_manager, yacht_broker, boat_dealer, service_provider
  boatingExperience: text("boating_experience"), // beginner, intermediate, advanced, professional
  certifications: jsonb("certifications").default([]), // captain_license, sailing_certification, etc.

  // Event & Show Attendance
  boatShowAttendance: jsonb("boat_show_attendance").default([]), // recent boat shows attended
  marinaEventInterest: jsonb("marina_event_interest").default([]), // types of events interested in

  // Referral & Social Proof
  referralSource: text("referral_source"), // friend, family, broker, online, advertisement
  socialProofFactors: jsonb("social_proof_factors").default([]), // reviews_reader, brand_conscious, etc.

  // Scoring Multipliers (Marina-specific scoring factors)
  locationScoreMultiplier: decimal("location_score_multiplier", { precision: 3, scale: 2 }).default('1.0'),
  seasonalityMultiplier: decimal("seasonality_multiplier", { precision: 3, scale: 2 }).default('1.0'),
  budgetQualificationScore: integer("budget_qualification_score").default(0),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Pipelines table (Pipedrive-like pipeline management)

export const crmPipelines = pgTable("crm_pipelines", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  isDefault: boolean("is_default").default(false),
  isActive: boolean("is_active").default(true),
  color: text("color").default('#3B82F6'),
  type: text("type").notNull().default('sales'), // sales, marketing, service, marina_sales, boat_sales
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Pipeline Stages (configurable stages with pipeline association)

export const crmPipelineStages = pgTable("crm_pipeline_stages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pipelineId: varchar("pipeline_id").references(() => crmPipelines.id),
  name: text("name").notNull(),
  description: text("description"),
  stageOrder: integer("stage_order").notNull(),
  probability: integer("probability").default(0), // default win probability %
  isActive: boolean("is_active").default(true),
  color: text("color").default('#3B82F6'),
  // Legacy field for backward compatibility
  pipelineType: text("pipeline_type").notNull().default('sales'), // sales, marketing, service
  // CRE-specific stage metadata (Oracle RCM style)
  stageType: text("stage_type").default('active'), // active, won, lost
  slaWarningDays: integer("sla_warning_days"), // days before SLA warning shows
  slaMaxDays: integer("sla_max_days"), // maximum days allowed in stage
  requiredFields: jsonb("required_fields").default([]), // fields required to enter stage
  taskTemplates: jsonb("task_templates").default([]), // auto-create tasks on entry
  automations: jsonb("automations").default([]), // workflow automations for this stage
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Deal Playbooks - Configurable stage-based checklists and automation templates
export const crmPlaybooks = pgTable("crm_playbooks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  description: text("description"),
  pipelineId: varchar("pipeline_id").references(() => crmPipelines.id),
  stageId: varchar("stage_id").references(() => crmPipelineStages.id),
  dealType: text("deal_type"), // marina_acquisition, storage_lease, new_listing - null means all
  isActive: boolean("is_active").default(true),
  isDefault: boolean("is_default").default(false),
  sortOrder: integer("sort_order").default(0),
  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("crm_playbooks_org_idx").on(table.orgId),
  pipelineIdx: index("crm_playbooks_pipeline_idx").on(table.pipelineId),
  stageIdx: index("crm_playbooks_stage_idx").on(table.stageId),
}));

// Playbook Items - Individual checklist items within a playbook
export const crmPlaybookItems = pgTable("crm_playbook_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  playbookId: varchar("playbook_id").references(() => crmPlaybooks.id, { onDelete: 'cascade' }).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  itemType: text("item_type").notNull().default('checklist'), // checklist, task, document, approval, milestone
  sortOrder: integer("sort_order").default(0),
  isRequired: boolean("is_required").default(false),
  dueDaysOffset: integer("due_days_offset"), // days from stage entry to due
  assigneeType: text("assignee_type").default('deal_owner'), // deal_owner, specific_user, role
  assigneeId: varchar("assignee_id"), // specific user ID if assigneeType = specific_user
  assigneeRole: text("assignee_role"), // role name if assigneeType = role
  automationTrigger: text("automation_trigger"), // on_complete, on_skip, on_overdue
  automationAction: jsonb("automation_action").default({}), // {type: 'create_task', 'send_email', 'move_stage', etc.}
  documentType: text("document_type"), // for document items: psa, loi, insurance, environmental, etc.
  approvalRequiredBy: text("approval_required_by").array(), // role names that can approve
  metadata: jsonb("metadata").default({}),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  playbookIdx: index("crm_playbook_items_playbook_idx").on(table.playbookId),
}));

// Deal Playbook Progress - Track completion of playbook items per deal
export const crmDealPlaybookProgress = pgTable("crm_deal_playbook_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id, { onDelete: 'cascade' }).notNull(),
  playbookId: varchar("playbook_id").references(() => crmPlaybooks.id).notNull(),
  playbookItemId: varchar("playbook_item_id").references(() => crmPlaybookItems.id, { onDelete: 'cascade' }).notNull(),
  status: text("status").notNull().default('pending'), // pending, in_progress, completed, skipped, blocked
  completedById: varchar("completed_by_id").references(() => users.id),
  completedAt: timestamp("completed_at"),
  skippedReason: text("skipped_reason"),
  dueDate: timestamp("due_date"),
  notes: text("notes"),
  documentUrl: text("document_url"), // for document items
  approvedById: varchar("approved_by_id").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  dealIdx: index("crm_deal_playbook_progress_deal_idx").on(table.dealId),
  playbookIdx: index("crm_deal_playbook_progress_playbook_idx").on(table.playbookId),
  statusIdx: index("crm_deal_playbook_progress_status_idx").on(table.status),
  uniqueProgress: unique().on(table.dealId, table.playbookItemId),
}));

// Phase Gate Approvals - Track approval workflow for stage transitions
export const crmPhaseGateApprovals = pgTable("crm_phase_gate_approvals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id, { onDelete: 'cascade' }).notNull(),
  fromStageId: varchar("from_stage_id").references(() => crmPipelineStages.id),
  toStageId: varchar("to_stage_id").references(() => crmPipelineStages.id).notNull(),
  status: text("status").notNull().default('pending'), // pending, approved, rejected, bypassed
  requestedById: varchar("requested_by_id").references(() => users.id).notNull(),
  requestedAt: timestamp("requested_at").defaultNow().notNull(),
  reviewedById: varchar("reviewed_by_id").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  rejectionReason: text("rejection_reason"),
  requiredApproverRole: text("required_approver_role"), // manager, director, vp, etc.
  requiredApproverId: varchar("required_approver_id").references(() => users.id),
  autoApproveAfterDays: integer("auto_approve_after_days"), // optional auto-approval
  gateConditions: jsonb("gate_conditions").default([]), // snapshot of conditions at request time
  conditionsMetAt: timestamp("conditions_met_at"),
  metadata: jsonb("metadata").default({}),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  dealIdx: index("crm_phase_gate_approvals_deal_idx").on(table.dealId),
  toStageIdx: index("crm_phase_gate_approvals_to_stage_idx").on(table.toStageId),
  statusIdx: index("crm_phase_gate_approvals_status_idx").on(table.status),
}));

// Red Flag Escalation - Auto-notify deal leads about blockers, issues, and deal health concerns
export const crmRedFlagStatusEnum = pgEnum("crm_red_flag_status", ["open", "acknowledged", "resolved", "dismissed"]);
export const crmRedFlagSeverityEnum = pgEnum("crm_red_flag_severity", ["low", "medium", "high", "critical"]);
export const crmRedFlagCategoryEnum = pgEnum("crm_red_flag_category", [
  "stale_deal", "deadline_missed", "value_discrepancy", "missing_documents",
  "approval_blocked", "communication_gap", "risk_identified", "compliance_issue", "custom"
]);

export const crmRedFlags = pgTable("crm_red_flags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id, { onDelete: 'cascade' }).notNull(),
  category: crmRedFlagCategoryEnum("category").notNull(),
  severity: crmRedFlagSeverityEnum("severity").notNull().default("medium"),
  status: crmRedFlagStatusEnum("status").notNull().default("open"),
  title: text("title").notNull(),
  description: text("description"),
  triggeredBy: text("triggered_by").notNull().default("system"), // system, manual, automation
  triggerCondition: jsonb("trigger_condition").default({}),
  raisedById: varchar("raised_by_id").references(() => users.id),
  raisedAt: timestamp("raised_at").defaultNow().notNull(),
  acknowledgedById: varchar("acknowledged_by_id").references(() => users.id),
  acknowledgedAt: timestamp("acknowledged_at"),
  resolvedById: varchar("resolved_by_id").references(() => users.id),
  resolvedAt: timestamp("resolved_at"),
  resolutionNotes: text("resolution_notes"),
  dismissedById: varchar("dismissed_by_id").references(() => users.id),
  dismissedAt: timestamp("dismissed_at"),
  dismissReason: text("dismiss_reason"),
  dueDate: timestamp("due_date"),
  autoEscalateAfterDays: integer("auto_escalate_after_days"),
  metadata: jsonb("metadata").default({}),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  dealIdx: index("crm_red_flags_deal_idx").on(table.dealId),
  statusIdx: index("crm_red_flags_status_idx").on(table.status),
  severityIdx: index("crm_red_flags_severity_idx").on(table.severity),
  categoryIdx: index("crm_red_flags_category_idx").on(table.category),
}));

// Red Flag Escalations - Track escalation history and notifications
export const crmRedFlagEscalations = pgTable("crm_red_flag_escalations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  redFlagId: varchar("red_flag_id").references(() => crmRedFlags.id, { onDelete: 'cascade' }).notNull(),
  escalationLevel: integer("escalation_level").notNull().default(1),
  escalatedToId: varchar("escalated_to_id").references(() => users.id).notNull(),
  escalatedToRole: text("escalated_to_role"), // deal_owner, manager, director, vp
  notificationMethod: text("notification_method").notNull().default("in_app"), // in_app, email, sms
  notificationSent: boolean("notification_sent").default(false),
  notificationSentAt: timestamp("notification_sent_at"),
  responseStatus: text("response_status").default("pending"), // pending, viewed, responded
  respondedAt: timestamp("responded_at"),
  responseNotes: text("response_notes"),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  redFlagIdx: index("crm_red_flag_escalations_red_flag_idx").on(table.redFlagId),
  escalatedToIdx: index("crm_red_flag_escalations_escalated_to_idx").on(table.escalatedToId),
  levelIdx: index("crm_red_flag_escalations_level_idx").on(table.escalationLevel),
}));

// Red Flag Rules - Configurable rules for auto-detecting red flags
export const crmRedFlagRules = pgTable("crm_red_flag_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  category: crmRedFlagCategoryEnum("category").notNull(),
  severity: crmRedFlagSeverityEnum("severity").notNull().default("medium"),
  isActive: boolean("is_active").default(true),
  pipelineId: varchar("pipeline_id").references(() => crmPipelines.id),
  conditions: jsonb("conditions").notNull().default([]),
  escalationChain: jsonb("escalation_chain").default([]),
  autoEscalateAfterDays: integer("auto_escalate_after_days").default(3),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  categoryIdx: index("crm_red_flag_rules_category_idx").on(table.category),
  activeIdx: index("crm_red_flag_rules_active_idx").on(table.isActive),
  pipelineIdx: index("crm_red_flag_rules_pipeline_idx").on(table.pipelineId),
}));

// Deal History table (audit trail for drag & drop and field changes)

export const crmDealHistory = pgTable("crm_deal_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dealId: varchar("deal_id").references(() => crmDeals.id).notNull(),
  field: text("field").notNull(), // stage, value, owner, etc.
  oldValue: jsonb("old_value"),
  newValue: jsonb("new_value").notNull(),
  changeType: text("change_type").notNull(), // update, stage_move, create, delete
  changedById: varchar("changed_by_id").references(() => users.id).notNull(),
  changedAt: timestamp("changed_at").defaultNow().notNull(),
  metadata: jsonb("metadata").default({}), // additional context like drag & drop positions
});

// Workflows table

export const crmWorkflows = pgTable("crm_workflows", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),

  // Trigger configuration - when to execute this workflow
  // Examples: { type: 'deal_stage_changed', stageId: 'uuid', pipelineId: 'uuid' }
  //           { type: 'label_added', labelId: 'uuid', entityType: 'contact' }
  //           { type: 'field_updated', entityType: 'deal', field: 'value' }
  //           { type: 'deal_created', pipelineId: 'uuid' }
  trigger: jsonb("trigger").notNull(),

  // Conditions - when to proceed with actions (optional)
  // Examples: [{ field: 'value', operator: 'greater_than', value: 10000 }]
  //           [{ field: 'status', operator: 'equals', value: 'qualified' }]
  conditions: jsonb("conditions").default([]),

  // Actions - what to execute when triggered and conditions pass
  // Examples: [{ type: 'send_email', templateId: 'uuid', to: 'contact_email' }]
  //           [{ type: 'create_task', title: 'Follow up', assigneeId: 'uuid' }]
  //           [{ type: 'add_label', labelId: 'uuid' }]
  //           [{ type: 'update_field', field: 'priority', value: 'high' }]
  //           [{ type: 'webhook', url: 'https://...', method: 'POST' }]
  actions: jsonb("actions").notNull(),

  isActive: boolean("is_active").default(true),
  triggerCount: integer("trigger_count").default(0),
  lastTriggeredAt: timestamp("last_triggered_at"),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Webhooks table - stores webhook subscriptions

export const crmWebhooks = pgTable("crm_webhooks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  url: text("url").notNull(),
  method: text("method").notNull().default('POST'), // POST, GET, PUT, PATCH, DELETE
  ownerId: varchar("owner_id").references(() => users.id).notNull(),

  // Events to subscribe to
  // Examples: ['deal.created', 'deal.updated', 'contact.created', 'lead.converted']
  events: jsonb("events").notNull().default([]),

  // Headers to send with the webhook (for authentication, etc.)
  headers: jsonb("headers").default({}),

  // Secret for signature verification (optional)
  secret: text("secret"),

  isActive: boolean("is_active").default(true),

  // Statistics
  totalCalls: integer("total_calls").default(0),
  successfulCalls: integer("successful_calls").default(0),
  failedCalls: integer("failed_calls").default(0),
  lastCalledAt: timestamp("last_called_at"),
  lastStatus: integer("last_status"), // HTTP status code

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Webhook Logs table - stores webhook call history

export const crmWebhookLogs = pgTable("crm_webhook_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  webhookId: varchar("webhook_id").references(() => crmWebhooks.id, { onDelete: 'cascade' }).notNull(),

  event: text("event").notNull(), // e.g., 'deal.created'
  payload: jsonb("payload").notNull(), // Data sent to the webhook

  // Response data
  statusCode: integer("status_code"), // HTTP status code
  responseBody: text("response_body"), // Response from the webhook
  responseTime: integer("response_time"), // Time in milliseconds

  // Error information
  errorMessage: text("error_message"),

  success: boolean("success").notNull(),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// AI Conversations table - stores AI advisor conversation sessions

export const crmAiConversations = pgTable("crm_ai_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  ownerId: varchar("owner_id").references(() => users.id).notNull(),

  // Conversation metadata
  title: text("title"), // Optional title for the conversation

  // Context - what the user was viewing when they started the conversation
  contextType: text("context_type"), // 'deal', 'contact', 'company', 'property', 'general'
  contextId: varchar("context_id"), // ID of the entity they were viewing
  contextData: jsonb("context_data"), // Snapshot of context data

  // Settings
  provider: text("provider").notNull().default('openai'), // 'openai' or 'anthropic'
  model: text("model").default('gpt-4o'), // Model used

  // Status
  isActive: boolean("is_active").default(true),
  lastMessageAt: timestamp("last_message_at"),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// AI Messages table - stores individual messages in conversations

export const crmAiMessages = pgTable("crm_ai_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  conversationId: varchar("conversation_id").references(() => crmAiConversations.id, { onDelete: 'cascade' }).notNull(),

  // Message content
  role: text("role").notNull(), // 'user', 'assistant', 'system', 'function'
  content: text("content"), // Message text content

  // Function calling
  functionCall: jsonb("function_call"), // { name: string, arguments: string }
  functionResult: jsonb("function_result"), // Result of function execution
  toolCalls: jsonb("tool_calls"), // Array of tool calls (for multi-tool calls)
  toolResults: jsonb("tool_results"), // Array of tool results

  // Metadata
  tokenCount: integer("token_count"), // Approximate token count
  model: text("model"), // Model used for this message
  finishReason: text("finish_reason"), // 'stop', 'length', 'function_call', 'tool_calls'

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// AI Assistant Feedback table - stores user feedback on AI responses for quality tracking

export const aiAssistantFeedback = pgTable("ai_assistant_feedback", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").notNull(),

  // Feedback details
  messageId: varchar("message_id").notNull(), // Client-side message ID
  rating: text("rating").notNull(), // 'positive' or 'negative'
  advisoryMode: text("advisory_mode").notNull(), // The mode used for this response
  page: text("page").notNull(), // The page context where feedback was given

  // Optional additional context
  messageContent: text("message_content"), // The AI response content (for analysis)
  userQuery: text("user_query"), // What the user asked

  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("ai_assistant_feedback_org_idx").on(table.orgId),
  userIdx: index("ai_assistant_feedback_user_idx").on(table.userId),
  ratingIdx: index("ai_assistant_feedback_rating_idx").on(table.rating),
}));

// Dedupe Rules table - stores rules for detecting duplicate records

export const crmDedupeRules = pgTable("crm_dedupe_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // Descriptive name for the rule
  entityType: text("entity_type").notNull(), // 'contact', 'company', 'lead'

  // Matching configuration
  matchFields: jsonb("match_fields").notNull(), // Array of field names to match on, e.g., ['email'] or ['firstName', 'lastName']
  matchStrategy: text("match_strategy").notNull().default('exact'), // 'exact', 'fuzzy', 'contains'
  caseSensitive: boolean("case_sensitive").default(false),

  // Merge behavior
  autoMerge: boolean("auto_merge").default(false), // Whether to automatically merge or just flag for review
  priorityField: text("priority_field"), // Field to determine which record to keep (e.g., 'createdAt', 'updatedAt', 'leadScore')
  priorityOrder: text("priority_order").default('desc'), // 'asc' or 'desc'

  // Status
  isActive: boolean("is_active").default(true),

  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Merge History table - tracks all merged records for audit trail

export const crmMergeHistory = pgTable("crm_merge_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityType: text("entity_type").notNull(), // 'contact', 'company', 'lead'

  // Merge details
  primaryRecordId: varchar("primary_record_id").notNull(), // The record that was kept
  mergedRecordIds: jsonb("merged_record_ids").notNull(), // Array of UUIDs that were merged into primary

  // Field-level merge details
  fieldsMerged: jsonb("fields_merged"), // JSON of which fields were taken from which record
  conflictResolutions: jsonb("conflict_resolutions"), // How conflicts were resolved

  // Merge metadata
  mergedBy: varchar("merged_by").references(() => users.id).notNull(),
  mergedAt: timestamp("merged_at").defaultNow().notNull(),
  dedupeRuleId: varchar("dedupe_rule_id").references(() => crmDedupeRules.id), // Optional - if triggered by a rule

  // Undo capability
  canUndo: boolean("can_undo").default(true),
  undoneAt: timestamp("undone_at"),
  undoneBy: varchar("undone_by").references(() => users.id),

  ownerId: varchar("owner_id").references(() => users.id).notNull(),
});

// Forms System Tables

// Forms table - stores form definitions and configuration

export const crmForms = pgTable("crm_forms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull().default('contact'), // contact, demo, newsletter, property_inquiry, boat_inquiry, quote, download
  status: text("status").notNull().default('draft'), // draft, active, paused, archived

  // Form Configuration
  title: text("title"), // Display title on the form
  subtitle: text("subtitle"), // Form description/subtitle
  thankYouMessage: text("thank_you_message").default('Thank you for your submission!'),
  redirectUrl: text("redirect_url"), // Redirect after submission
  submitButtonText: text("submit_button_text").default('Submit'),

  // Form Settings
  requiresApproval: boolean("requires_approval").default(false),
  allowMultipleSubmissions: boolean("allow_multiple_submissions").default(true),
  captchaEnabled: boolean("captcha_enabled").default(false),
  progressBar: boolean("progress_bar").default(false),

  // Styling and Layout
  theme: text("theme").default('default'), // default, marina, boat, modern, minimal
  primaryColor: text("primary_color").default('#3B82F6'),
  backgroundColor: text("background_color").default('#FFFFFF'),
  fontFamily: text("font_family").default('Inter'),
  customCss: text("custom_css"),
  layout: text("layout").default('single_column'), // single_column, two_column, wizard

  // SEO and Meta
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  socialImage: text("social_image"),

  // Lead Routing and Automation
  autoAssignUser: varchar("auto_assign_user").references(() => users.id),
  leadScore: integer("lead_score").default(0), // Base score for form submissions
  followUpSequenceId: varchar("follow_up_sequence_id").references(() => crmEmailSequences.id),
  notificationEmails: jsonb("notification_emails").default([]), // Array of email addresses

  // A/B Testing
  isTestVariant: boolean("is_test_variant").default(false),
  parentFormId: varchar("parent_form_id"), // Reference to original form for A/B testing
  testSplitPercentage: integer("test_split_percentage").default(50), // 0-100

  // Analytics and Performance
  submissionCount: integer("submission_count").default(0),
  conversionRate: decimal("conversion_rate", { precision: 5, scale: 4 }).default('0'), // Percentage as decimal
  averageCompletionTime: integer("average_completion_time").default(0), // Seconds

  // Marina/Boat Specific Settings
  propertyType: text("property_type"), // marina, boat, slip, dry_storage (for property inquiry forms)
  inquiryType: text("inquiry_type"), // buy, sell, rent, service, financing
  targetBudgetRange: jsonb("target_budget_range").default({}), // { min: number, max: number }

  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type Form = typeof crmForms.$inferSelect;
export type InsertForm = typeof crmForms.$inferInsert;

// Form Fields table - stores individual field configurations

export const crmFormFields = pgTable("crm_form_fields", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  formId: varchar("form_id").references(() => crmForms.id, { onDelete: 'cascade' }).notNull(),

  // Field Configuration
  fieldType: text("field_type").notNull(), // text, email, phone, number, select, checkbox, radio, textarea, date, file, hidden
  fieldName: text("field_name").notNull(), // Field identifier/key
  label: text("label").notNull(),
  placeholder: text("placeholder"),
  helpText: text("help_text"),
  defaultValue: text("default_value"),

  // Validation Rules
  required: boolean("required").default(false),
  minLength: integer("min_length"),
  maxLength: integer("max_length"),
  pattern: text("pattern"), // Regex pattern for validation
  validationMessage: text("validation_message"),

  // Field Options (for select, radio, checkbox)
  options: jsonb("options").default([]), // Array of {label: string, value: string, score?: number}
  allowOther: boolean("allow_other").default(false),

  // Layout and Display
  fieldOrder: integer("field_order").notNull(),
  width: text("width").default('full'), // full, half, third, quarter
  cssClasses: text("css_classes"),
  isConditional: boolean("is_conditional").default(false),
  conditionalLogic: jsonb("conditional_logic").default({}), // Show/hide based on other fields

  // Lead Scoring
  scoreWeight: integer("score_weight").default(0), // Points for completion
  optionScoring: jsonb("option_scoring").default({}), // Different scores for different options

  // Marina/Boat Specific Fields
  boatSpecField: text("boat_spec_field"), // length, type, year, make, model, price_range
  marinaSpecField: text("marina_spec_field"), // slip_size, amenities, location_preference

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Form Submissions table - tracks all form submissions with analytics

export const crmFormSubmissions = pgTable("crm_form_submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  formId: varchar("form_id").references(() => crmForms.id).notNull(),

  // Submission Data
  submissionData: jsonb("submission_data").notNull(), // All form field values
  leadId: varchar("lead_id").references(() => crmLeads.id), // Created lead (if applicable)
  contactId: varchar("contact_id").references(() => crmContacts.id), // Existing contact (if found)

  // Session and Attribution Data
  sessionId: text("session_id"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  deviceType: text("device_type"), // desktop, mobile, tablet
  browserInfo: text("browser_info"),

  // UTM and Source Tracking
  utmSource: text("utm_source"),
  utmMedium: text("utm_medium"),
  utmCampaign: text("utm_campaign"),
  utmTerm: text("utm_term"),
  utmContent: text("utm_content"),
  referrerUrl: text("referrer_url"),
  landingPageUrl: text("landing_page_url"),

  // Form Analytics
  startedAt: timestamp("started_at"), // When user first interacted with form
  completionTime: integer("completion_time"), // Seconds to complete
  fieldInteractions: jsonb("field_interactions").default([]), // Array of field interaction events
  abandonedAt: timestamp("abandoned_at"), // If form was abandoned
  abandonedAtField: text("abandoned_at_field"), // Which field caused abandonment

  // Lead Qualification
  calculatedScore: integer("calculated_score").default(0),
  qualificationStatus: text("qualification_status").default('unqualified'), // unqualified, marketing_qualified, sales_qualified

  // Geographic Information
  geolocation: jsonb("geolocation").default({}), // { country, region, city, timezone }

  // Processing Status
  status: text("status").default('pending'), // pending, processed, error
  processingErrors: jsonb("processing_errors").default([]),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Landing Pages table - stores landing page templates and configurations

export const crmLandingPages = pgTable("crm_landing_pages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(), // URL slug for the landing page
  title: text("title").notNull(),
  description: text("description"),

  // Page Content
  heroTitle: text("hero_title"),
  heroSubtitle: text("hero_subtitle"),
  heroImage: text("hero_image"),
  bodyContent: text("body_content"), // HTML content

  // SEO Configuration
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  metaKeywords: text("meta_keywords"),
  ogTitle: text("og_title"),
  ogDescription: text("og_description"),
  ogImage: text("og_image"),

  // Page Settings
  template: text("template").notNull().default('marina'), // marina, boat, generic, minimal
  status: text("status").notNull().default('draft'), // draft, active, archived
  isPublished: boolean("is_published").default(false),
  passwordProtected: boolean("password_protected").default(false),
  password: text("password"),

  // Form Integration
  formId: varchar("form_id").references(() => crmForms.id),
  formPlacement: text("form_placement").default('bottom'), // top, bottom, sidebar, inline, popup

  // A/B Testing
  isTestVariant: boolean("is_test_variant").default(false),
  parentPageId: varchar("parent_page_id"),
  testSplitPercentage: integer("test_split_percentage").default(50),

  // Analytics
  viewCount: integer("view_count").default(0),
  uniqueVisitors: integer("unique_visitors").default(0),
  conversionRate: decimal("conversion_rate", { precision: 5, scale: 4 }).default('0'),
  bounceRate: decimal("bounce_rate", { precision: 5, scale: 4 }).default('0'),
  averageTimeOnPage: integer("average_time_on_page").default(0), // Seconds

  // Custom Styling
  customCss: text("custom_css"),
  customJs: text("custom_js"),
  theme: jsonb("theme").default({}), // Color scheme and styling preferences

  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Form Analytics table - stores aggregated analytics data for forms

export const crmFormAnalytics = pgTable("crm_form_analytics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  formId: varchar("form_id").references(() => crmForms.id).notNull(),
  date: text("date").notNull(), // YYYY-MM-DD format for daily aggregation

  // Traffic Metrics
  views: integer("views").default(0),
  uniqueVisitors: integer("unique_visitors").default(0),

  // Conversion Metrics
  submissions: integer("submissions").default(0),
  completedSubmissions: integer("completed_submissions").default(0),
  conversionRate: decimal("conversion_rate", { precision: 5, scale: 4 }).default('0'),

  // Engagement Metrics
  averageTimeOnForm: integer("average_time_on_form").default(0), // Seconds
  bounceRate: decimal("bounce_rate", { precision: 5, scale: 4 }).default('0'),
  abandonmentRate: decimal("abandonment_rate", { precision: 5, scale: 4 }).default('0'),

  // Field-Level Analytics
  fieldDropoffRates: jsonb("field_dropoff_rates").default({}), // { fieldName: rate }
  fieldCompletionTimes: jsonb("field_completion_times").default({}), // Average time per field
  fieldErrorRates: jsonb("field_error_rates").default({}), // Validation error rates per field

  // Source Analytics
  sourceBreakdown: jsonb("source_breakdown").default({}), // Traffic by source
  deviceBreakdown: jsonb("device_breakdown").default({}), // Desktop vs mobile
  locationBreakdown: jsonb("location_breakdown").default({}), // Geographic data

  // Lead Quality Metrics
  qualifiedLeads: integer("qualified_leads").default(0),
  averageLeadScore: decimal("average_lead_score", { precision: 5, scale: 2 }).default('0'),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Form Versions table - for A/B testing and version history

export const crmFormVersions = pgTable("crm_form_versions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  formId: varchar("form_id").references(() => crmForms.id).notNull(),
  versionNumber: integer("version_number").notNull(),
  name: text("name"), // Version name/label
  description: text("description"),

  // Version Data (snapshot of form and fields configuration)
  formData: jsonb("form_data").notNull(), // Complete form configuration
  fieldsData: jsonb("fields_data").notNull(), // Complete fields configuration

  // A/B Test Results
  testStatus: text("test_status").default('draft'), // draft, active, completed, winner
  trafficAllocation: integer("traffic_allocation").default(50), // Percentage of traffic
  conversionRate: decimal("conversion_rate", { precision: 5, scale: 4 }),
  submissions: integer("submissions").default(0),

  createdById: varchar("created_by_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// CSV IMPORT SYSTEM TABLES
// ============================================================================

export const crmImportJobs = pgTable("crm_import_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size").notNull(),
  totalRows: integer("total_rows").notNull(),
  processedRows: integer("processed_rows").default(0),
  successfulRows: integer("successful_rows").default(0),
  failedRows: integer("failed_rows").default(0),
  duplicatesFound: integer("duplicates_found").default(0),

  importType: text("import_type").notNull().default('contacts'),
  fieldMappings: jsonb("field_mappings").notNull(),
  duplicateStrategy: text("duplicate_strategy").default('skip'),

  status: text("status").notNull().default('pending'),
  currentStep: text("current_step"),
  progress: integer("progress").default(0),

  errorLog: jsonb("error_log").default(sql`'[]'::jsonb`),
  validationWarnings: jsonb("validation_warnings").default(sql`'[]'::jsonb`),
  importSummary: jsonb("import_summary").default(sql`'{}'::jsonb`),

  csvData: jsonb("csv_data"),
  originalHeaders: jsonb("original_headers").default(sql`'[]'::jsonb`),

  canRollback: boolean("can_rollback").default(true),
  rolledBackAt: timestamp("rolled_back_at"),
  rolledBackBy: varchar("rolled_back_by").references(() => users.id),

  ownerId: varchar("owner_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const crmImportedRecords = pgTable("crm_imported_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  importJobId: varchar("import_job_id").references(() => crmImportJobs.id).notNull(),

  recordType: text("record_type").notNull(),
  recordId: varchar("record_id").notNull(),
  action: text("action").notNull(),

  rowNumber: integer("row_number").notNull(),
  originalData: jsonb("original_data").notNull(),

  wasNew: boolean("was_new").default(true),
  matchedBy: text("matched_by"),
  validationIssues: jsonb("validation_issues").default(sql`'[]'::jsonb`),

  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Email Sequence Steps - Multi-step drip campaign support

export const crmEmailSequenceSteps = pgTable("crm_email_sequence_steps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sequenceId: varchar("sequence_id").references(() => crmEmailSequences.id).notNull(),
  stepOrder: integer("step_order").notNull(),
  delayDays: integer("delay_days").default(0),
  delayHours: integer("delay_hours").default(0),
  emailTemplateId: varchar("email_template_id").references(() => crmEmailTemplates.id),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  sendTime: text("send_time"),
  skipWeekends: boolean("skip_weekends").default(true),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const crmEmailSequenceEnrollments = pgTable("crm_email_sequence_enrollments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sequenceId: varchar("sequence_id").references(() => crmEmailSequences.id).notNull(),
  entityType: text("entity_type").notNull(),
  entityId: varchar("entity_id").notNull(),
  status: text("status").notNull().default('active'),
  currentStep: integer("current_step").default(0),
  enrolledAt: timestamp("enrolled_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  pausedAt: timestamp("paused_at"),
  cancelledAt: timestamp("cancelled_at"),
  exitReason: text("exit_reason"),
  enrolledById: varchar("enrolled_by_id").references(() => users.id).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const crmEmailSequenceStepExecutions = pgTable("crm_email_sequence_step_executions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  enrollmentId: varchar("enrollment_id").references(() => crmEmailSequenceEnrollments.id).notNull(),
  stepId: varchar("step_id").references(() => crmEmailSequenceSteps.id).notNull(),
  status: text("status").notNull().default('pending'),
  scheduledAt: timestamp("scheduled_at").notNull(),
  sentAt: timestamp("sent_at"),
  deliveredAt: timestamp("delivered_at"),
  openedAt: timestamp("opened_at"),
  clickedAt: timestamp("clicked_at"),
  bouncedAt: timestamp("bounced_at"),
  errorMessage: text("error_message"),
  emailCommunicationId: varchar("email_communication_id").references(() => crmEmailCommunications.id),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// CRM Type Exports
export type CrmDeal = typeof crmDeals.$inferSelect;
export type CrmLead = typeof crmLeads.$inferSelect;
export type CrmContact = typeof crmContacts.$inferSelect;
export type CrmCompany = typeof crmCompanies.$inferSelect;
export type CrmPipeline = typeof crmPipelines.$inferSelect;
export type CrmPipelineStage = typeof crmPipelineStages.$inferSelect;
export type CrmActivity = typeof crmActivities.$inferSelect;

// Deal Analytics Type Exports
export type CrmDealStageHistory = typeof crmDealStageHistory.$inferSelect;
export type CrmTimelineEvent = typeof crmTimelineEvents.$inferSelect;
export type CrmDealEngagementScore = typeof crmDealEngagementScores.$inferSelect;
export type CrmContactEngagementScore = typeof crmContactEngagementScores.$inferSelect;

// CRM Insert Schemas
export const insertCrmDealSchema = createInsertSchema(crmDeals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmDeal = z.infer<typeof insertCrmDealSchema>;

export const insertCrmLeadSchema = createInsertSchema(crmLeads).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmLead = z.infer<typeof insertCrmLeadSchema>;

export const phoneSchema = z.object({
  type: z.enum(["office", "mobile", "home"]),
  number: z.string().min(1, "Phone number is required"),
});

export const insertCrmContactSchema = createInsertSchema(crmContacts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  leadStatus: z.enum(["none", "new", "contacted", "qualified", "unqualified", "converted"]).nullable().optional(), // Explicitly allow null to clear when contactTag != 'lead'
  phones: z.array(phoneSchema).optional().default([]), // Array of phone objects with type and number
});
export type InsertCrmContact = z.infer<typeof insertCrmContactSchema>;
export type Phone = z.infer<typeof phoneSchema>;

export const insertCrmCompanySchema = createInsertSchema(crmCompanies).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmCompany = z.infer<typeof insertCrmCompanySchema>;

export const insertCrmPipelineSchema = createInsertSchema(crmPipelines).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmPipeline = z.infer<typeof insertCrmPipelineSchema>;

export const insertCrmPipelineStageSchema = createInsertSchema(crmPipelineStages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmPipelineStage = z.infer<typeof insertCrmPipelineStageSchema>;

// Playbook schemas and types
export type CrmPlaybook = typeof crmPlaybooks.$inferSelect;
export type CrmPlaybookItem = typeof crmPlaybookItems.$inferSelect;
export type CrmDealPlaybookProgress = typeof crmDealPlaybookProgress.$inferSelect;

export const insertCrmPlaybookSchema = createInsertSchema(crmPlaybooks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmPlaybook = z.infer<typeof insertCrmPlaybookSchema>;

export const insertCrmPlaybookItemSchema = createInsertSchema(crmPlaybookItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmPlaybookItem = z.infer<typeof insertCrmPlaybookItemSchema>;

export const insertCrmDealPlaybookProgressSchema = createInsertSchema(crmDealPlaybookProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmDealPlaybookProgress = z.infer<typeof insertCrmDealPlaybookProgressSchema>;

export const insertCrmPhaseGateApprovalSchema = createInsertSchema(crmPhaseGateApprovals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmPhaseGateApproval = z.infer<typeof insertCrmPhaseGateApprovalSchema>;

// ============================================================================
// CRM ARCHIVE SYSTEM - Archived Contacts & Companies Post-Sale
// ============================================================================

// Archive reason enum
export const archiveReasonEnum = pgEnum("archive_reason", [
  "property_sold",
  "out_of_industry", 
  "duplicate",
  "inactive",
  "deceased",
  "other"
]);

// Archived Contacts - Separate storage for contacts archived after property sale
export const archivedContacts = pgTable("archived_contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  originalContactId: varchar("original_contact_id").notNull(), // Original contact ID for reference

  // Copied contact data (snapshot at time of archive)
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email"),
  phone: text("phone"),
  phones: jsonb("phones").default(sql`'[]'`),
  position: text("position"),
  address: text("address"),
  unit: text("unit"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  company: text("company"),
  role: text("role"),
  contactType: text("contact_type"),
  contactTag: text("contact_tag"),
  labels: text("labels").array().default(sql`ARRAY[]::text[]`),
  linkedinUrl: text("linkedin_url"),
  twitterHandle: text("twitter_handle"),
  photoDataUrl: text("photo_data_url"),

  // Archive metadata
  archiveReason: archiveReasonEnum("archive_reason").notNull().default("property_sold"),
  archiveNotes: text("archive_notes"),
  archivedBy: varchar("archived_by").notNull().references(() => users.id),
  archivedAt: timestamp("archived_at").defaultNow().notNull(),

  // Associated sale information
  salesCompId: varchar("sales_comp_id").references(() => salesComps.id, { onDelete: 'set null' }),
  saleDate: timestamp("sale_date"),

  // Original record timestamps
  originalCreatedAt: timestamp("original_created_at"),
  originalUpdatedAt: timestamp("original_updated_at"),

  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("archived_contacts_org_idx").on(table.orgId),
  originalContactIdx: index("archived_contacts_original_idx").on(table.originalContactId),
  salesCompIdx: index("archived_contacts_sales_comp_idx").on(table.salesCompId),
  archivedAtIdx: index("archived_contacts_archived_at_idx").on(table.archivedAt),
}));

// Archived Companies - Separate storage for companies archived after property sale
export const archivedCompanies = pgTable("archived_companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  originalCompanyId: varchar("original_company_id").notNull(), // Original company ID for reference

  // Copied company data (snapshot at time of archive)
  name: text("name").notNull(),
  domain: text("domain"),
  industry: text("industry"),
  size: text("size"),
  address: text("address"),
  phone: text("phone"),
  website: text("website"),
  description: text("description"),
  labels: text("labels").array().default(sql`ARRAY[]::text[]`),
  annualRevenue: decimal("annual_revenue", { precision: 14, scale: 2 }),
  annualMarinaSpend: decimal("annual_marina_spend", { precision: 14, scale: 2 }),
  acquisitionInterest: text("acquisition_interest"),
  portfolioCount: integer("portfolio_count"),

  // Archive metadata
  archiveReason: archiveReasonEnum("archive_reason").notNull().default("property_sold"),
  archiveNotes: text("archive_notes"),
  archivedBy: varchar("archived_by").notNull().references(() => users.id),
  archivedAt: timestamp("archived_at").defaultNow().notNull(),

  // Associated sale information
  salesCompId: varchar("sales_comp_id").references(() => salesComps.id, { onDelete: 'set null' }),
  saleDate: timestamp("sale_date"),

  // Original record timestamps
  originalCreatedAt: timestamp("original_created_at"),
  originalUpdatedAt: timestamp("original_updated_at"),
  originalOwnerId: varchar("original_owner_id"),

  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("archived_companies_org_idx").on(table.orgId),
  originalCompanyIdx: index("archived_companies_original_idx").on(table.originalCompanyId),
  salesCompIdx: index("archived_companies_sales_comp_idx").on(table.salesCompId),
  archivedAtIdx: index("archived_companies_archived_at_idx").on(table.archivedAt),
}));

// Archive Property Associations - Track which properties were associated with archived entities
export const archivePropertyAssociations = pgTable("archive_property_associations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),

  // Link to archived entity (one of these will be set)
  archivedContactId: varchar("archived_contact_id").references(() => archivedContacts.id, { onDelete: 'cascade' }),
  archivedCompanyId: varchar("archived_company_id").references(() => archivedCompanies.id, { onDelete: 'cascade' }),

  // Property information (snapshot)
  propertyId: varchar("property_id"), // Original property ID (may no longer exist)
  propertyName: text("property_name").notNull(),
  propertyAddress: text("property_address"),
  propertyCity: text("property_city"),
  propertyState: text("property_state"),

  // Sales comp reference
  salesCompId: varchar("sales_comp_id").references(() => salesComps.id, { onDelete: 'set null' }),

  // Relationship details
  relationship: text("relationship"), // "Owner", "Seller", "Manager", etc.
  ownershipStartDate: timestamp("ownership_start_date"),
  ownershipEndDate: timestamp("ownership_end_date"), // Sale date

  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("archive_property_assoc_org_idx").on(table.orgId),
  archivedContactIdx: index("archive_property_assoc_contact_idx").on(table.archivedContactId),
  archivedCompanyIdx: index("archive_property_assoc_company_idx").on(table.archivedCompanyId),
  salesCompIdx: index("archive_property_assoc_sales_comp_idx").on(table.salesCompId),
}));

// Archive Types & Schemas
export type ArchivedContact = typeof archivedContacts.$inferSelect;
export type ArchivedCompany = typeof archivedCompanies.$inferSelect;
export type ArchivePropertyAssociation = typeof archivePropertyAssociations.$inferSelect;

export const insertArchivedContactSchema = createInsertSchema(archivedContacts).omit({
  id: true,
  createdAt: true,
});
export type InsertArchivedContact = z.infer<typeof insertArchivedContactSchema>;

export const insertArchivedCompanySchema = createInsertSchema(archivedCompanies).omit({
  id: true,
  createdAt: true,
});
export type InsertArchivedCompany = z.infer<typeof insertArchivedCompanySchema>;

export const insertArchivePropertyAssociationSchema = createInsertSchema(archivePropertyAssociations).omit({
  id: true,
  createdAt: true,
});
export type InsertArchivePropertyAssociation = z.infer<typeof insertArchivePropertyAssociationSchema>;
export type CrmPhaseGateApproval = typeof crmPhaseGateApprovals.$inferSelect;

export const insertCrmRedFlagSchema = createInsertSchema(crmRedFlags).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmRedFlag = z.infer<typeof insertCrmRedFlagSchema>;
export type CrmRedFlag = typeof crmRedFlags.$inferSelect;

export const insertCrmRedFlagEscalationSchema = createInsertSchema(crmRedFlagEscalations).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmRedFlagEscalation = z.infer<typeof insertCrmRedFlagEscalationSchema>;
export type CrmRedFlagEscalation = typeof crmRedFlagEscalations.$inferSelect;

export const insertCrmRedFlagRuleSchema = createInsertSchema(crmRedFlagRules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmRedFlagRule = z.infer<typeof insertCrmRedFlagRuleSchema>;
export type CrmRedFlagRule = typeof crmRedFlagRules.$inferSelect;

export const insertCrmActivitySchema = createInsertSchema(crmActivities).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmActivity = z.infer<typeof insertCrmActivitySchema>;

export type CrmActivityAssociation = typeof crmActivityAssociations.$inferSelect;
export const insertCrmActivityAssociationSchema = createInsertSchema(crmActivityAssociations).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmActivityAssociation = z.infer<typeof insertCrmActivityAssociationSchema>;

export type CrmSavedView = typeof crmSavedViews.$inferSelect;
export const insertCrmSavedViewSchema = createInsertSchema(crmSavedViews).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmSavedView = z.infer<typeof insertCrmSavedViewSchema>;

// Deal Analytics Insert Schemas
export const insertCrmDealStageHistorySchema = createInsertSchema(crmDealStageHistory).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmDealStageHistory = z.infer<typeof insertCrmDealStageHistorySchema>;

export const insertCrmTimelineEventSchema = createInsertSchema(crmTimelineEvents).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmTimelineEvent = z.infer<typeof insertCrmTimelineEventSchema>;

export const insertCrmDealEngagementScoreSchema = createInsertSchema(crmDealEngagementScores).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastCalculatedAt: true,
});
export type InsertCrmDealEngagementScore = z.infer<typeof insertCrmDealEngagementScoreSchema>;

export const insertCrmContactEngagementScoreSchema = createInsertSchema(crmContactEngagementScores).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastCalculatedAt: true,
});
export type InsertCrmContactEngagementScore = z.infer<typeof insertCrmContactEngagementScoreSchema>;

// CRM Workflow schema
export const insertCrmWorkflowSchema = createInsertSchema(crmWorkflows).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmWorkflow = z.infer<typeof insertCrmWorkflowSchema>;

// CRM Task schema
export const insertCrmTaskSchema = createInsertSchema(crmTasks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmTask = z.infer<typeof insertCrmTaskSchema>;

// CRM Property schema
export const insertCrmPropertySchema = createInsertSchema(crmProperties).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmProperty = z.infer<typeof insertCrmPropertySchema>;

// CRM Storage Types schema
export const insertCrmStorageTypeSchema = createInsertSchema(crmStorageTypes).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmStorageType = z.infer<typeof insertCrmStorageTypeSchema>;
export type CrmStorageType = typeof crmStorageTypes.$inferSelect;

// CRM Property Storage Entries schema
export const insertCrmPropertyStorageEntrySchema = createInsertSchema(crmPropertyStorageEntries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmPropertyStorageEntry = z.infer<typeof insertCrmPropertyStorageEntrySchema>;
export type CrmPropertyStorageEntry = typeof crmPropertyStorageEntries.$inferSelect;

// Predefined CRM storage types (matches rraStorageTypeEnum for consistency across modules)
export const PREDEFINED_CRM_STORAGE_TYPES = [
  "Wet Slip",
  "Lift Slip",
  "Mooring",
  "Jet Ski",
  "Dry Rack - Indoor",
  "Dry Rack - Outdoor",
  "Houseboat",
  "Liveaboard",
  "Land Storage",
  "Boat on Trailer",
  "Trailer Only",
  "Carport",
  "RV Site",
  "Kayak/SUP",
  "Other"
] as const;

export type PredefinedCrmStorageType = typeof PREDEFINED_CRM_STORAGE_TYPES[number];

// Pending Property schema
export const insertPendingPropertySchema = createInsertSchema(pendingProperties).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
  createdPropertyId: true,
});
export type InsertPendingProperty = z.infer<typeof insertPendingPropertySchema>;
export type PendingProperty = typeof pendingProperties.$inferSelect;

// Pending Contact schema
export const insertPendingContactSchema = createInsertSchema(pendingContacts).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
  createdContactId: true,
});
export type InsertPendingContact = z.infer<typeof insertPendingContactSchema>;
export type PendingContact = typeof pendingContacts.$inferSelect;

// Pending Company schema
export const insertPendingCompanySchema = createInsertSchema(pendingCompanies).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
  createdCompanyId: true,
});
export type InsertPendingCompany = z.infer<typeof insertPendingCompanySchema>;
export type PendingCompany = typeof pendingCompanies.$inferSelect;

// Pending Sales Comp schema
export const insertPendingSalesCompSchema = createInsertSchema(pendingSalesComps).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
  createdSalesCompId: true,
});
export type InsertPendingSalesComp = z.infer<typeof insertPendingSalesCompSchema>;
export type PendingSalesComp = typeof pendingSalesComps.$inferSelect;

// Property Ownership History schema
export const insertPropertyOwnershipHistorySchema = createInsertSchema(propertyOwnershipHistory).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertPropertyOwnershipHistory = z.infer<typeof insertPropertyOwnershipHistorySchema>;
export type PropertyOwnershipHistory = typeof propertyOwnershipHistory.$inferSelect;

// CRM Match Results schema
export const insertCrmMatchResultSchema = createInsertSchema(crmMatchResults).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
});
export type InsertCrmMatchResult = z.infer<typeof insertCrmMatchResultSchema>;
export type CrmMatchResult = typeof crmMatchResults.$inferSelect;

// CRM File schema
export const insertCrmFileSchema = createInsertSchema(crmFiles).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmFile = z.infer<typeof insertCrmFileSchema>;
export type CrmFile = typeof crmFiles.$inferSelect;

// ============================================================================
// PROSPECTING MODULE SCHEMAS & TYPES
// ============================================================================

// Prospecting Activities schema
export const insertProspectingActivitySchema = createInsertSchema(prospectingActivities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProspectingActivity = z.infer<typeof insertProspectingActivitySchema>;
export type ProspectingActivity = typeof prospectingActivities.$inferSelect;

// Prospecting Weeks schema
export const insertProspectingWeekSchema = createInsertSchema(prospectingWeeks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProspectingWeek = z.infer<typeof insertProspectingWeekSchema>;
export type ProspectingWeek = typeof prospectingWeeks.$inferSelect;


// CRM Prospecting Activities schema
export const insertCrmProspectingActivitySchema = createInsertSchema(crmProspectingActivities).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmProspectingActivity = z.infer<typeof insertCrmProspectingActivitySchema>;
export type CrmProspectingActivity = typeof crmProspectingActivities.$inferSelect;
// Outreach Campaigns schema
export const insertOutreachCampaignSchema = createInsertSchema(outreachCampaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertOutreachCampaign = z.infer<typeof insertOutreachCampaignSchema>;
export type OutreachCampaign = typeof outreachCampaigns.$inferSelect;

// Outreach Templates schema
export const insertOutreachTemplateSchema = createInsertSchema(outreachTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertOutreachTemplate = z.infer<typeof insertOutreachTemplateSchema>;
export type OutreachTemplate = typeof outreachTemplates.$inferSelect;

// Market Targets schema
export const insertMarketTargetSchema = createInsertSchema(marketTargets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertMarketTarget = z.infer<typeof insertMarketTargetSchema>;
export type MarketTarget = typeof marketTargets.$inferSelect;

// Deal Contacts Junction schema
export const insertCrmDealContactSchema = createInsertSchema(crmDealContacts).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmDealContact = z.infer<typeof insertCrmDealContactSchema>;
export type CrmDealContact = typeof crmDealContacts.$inferSelect;

// Deal Companies Junction schema
export const insertCrmDealCompanySchema = createInsertSchema(crmDealCompanies).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmDealCompany = z.infer<typeof insertCrmDealCompanySchema>;
export type CrmDealCompany = typeof crmDealCompanies.$inferSelect;

// CRM Schema Aliases (for backward compatibility with original CRM code)
export const insertDealSchema = insertCrmDealSchema;
export type InsertDeal = InsertCrmDeal;
export const insertLeadSchema = insertCrmLeadSchema;
export type InsertLead = InsertCrmLead;
export const insertCompanySchema = insertCrmCompanySchema;
export type InsertCompany = InsertCrmCompany;
export const insertContactSchema = insertCrmContactSchema;
export type InsertContact = InsertCrmContact;
export const insertTaskSchema = insertCrmTaskSchema;
export type InsertTask = InsertCrmTask;
export const insertPropertySchema = insertCrmPropertySchema;
export type InsertProperty = InsertCrmProperty;
export const insertActivitySchema = insertCrmActivitySchema;
export type InsertActivity = InsertCrmActivity;
export const insertWorkflowSchema = insertCrmWorkflowSchema;
export type InsertWorkflow = InsertCrmWorkflow;
export const insertPipelineSchema = insertCrmPipelineSchema;
export type InsertPipeline = InsertCrmPipeline;
export const insertPipelineStageSchema = insertCrmPipelineStageSchema;
export type InsertPipelineStage = InsertCrmPipelineStage;

// CRM Type Aliases
export type Deal = typeof crmDeals.$inferSelect;
export type Lead = typeof crmLeads.$inferSelect;
export type Contact = typeof crmContacts.$inferSelect;
export type Company = typeof crmCompanies.$inferSelect;
export type Activity = typeof crmActivities.$inferSelect;
export type Workflow = typeof crmWorkflows.$inferSelect;
export type Pipeline = typeof crmPipelines.$inferSelect;
export type PipelineStage = typeof crmPipelineStages.$inferSelect;

// Additional CRM Type Aliases for backward compatibility
export type Task = typeof crmTasks.$inferSelect;
export type Property = typeof crmProperties.$inferSelect;
export type ContactCompany = typeof crmContactCompanies.$inferSelect;
export type CompanyProperty = typeof crmCompanyProperties.$inferSelect;
export type EntityDDProjectLink = typeof crmEntityDDProjectLinks.$inferSelect;

// --- Pipeline Automation & Templates ---
export const pipelineAutomationRules = pgTable("pipeline_automation_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  triggerType: text("trigger_type").notNull(), // stage_change, days_in_stage, field_update, manual
  triggerConfig: jsonb("trigger_config").notNull().default('{}'),
  actionType: text("action_type").notNull(), // move_stage, send_notification, create_task, update_field, assign_owner
  actionConfig: jsonb("action_config").notNull().default('{}'),
  isActive: boolean("is_active").notNull().default(true),
  executionCount: integer("execution_count").default(0),
  lastExecutedAt: timestamp("last_executed_at"),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
export type PipelineAutomationRule = typeof pipelineAutomationRules.$inferSelect;
export type InsertPipelineAutomationRule = typeof pipelineAutomationRules.$inferInsert;

// ─── Deal Scoring Models & Scores ────────────────────────────────────────────
export const dealScoringModels = pgTable("deal_scoring_models", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull().default("Default"),
  criteria: jsonb("criteria").notNull().default('[]'),
  isDefault: boolean("is_default").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
export type DealScoringModel = typeof dealScoringModels.$inferSelect;
export type InsertDealScoringModel = typeof dealScoringModels.$inferInsert;

export const dealScores = pgTable("deal_scores", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  dealId: varchar("deal_id").notNull(),
  modelId: varchar("model_id").references(() => dealScoringModels.id),
  scores: jsonb("scores").notNull().default('{}'),
  totalScore: decimal("total_score", { precision: 5, scale: 1 }),
  grade: text("grade"),
  scoredBy: varchar("scored_by").references(() => users.id),
  scoredAt: timestamp("scored_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
export type DealScore = typeof dealScores.$inferSelect;
export type InsertDealScore = typeof dealScores.$inferInsert;

// ─── Pipeline Templates ──────────────────────────────────────────────────────
export const pipelineTemplates = pgTable("pipeline_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  dealType: text("deal_type").notNull(),
  stages: jsonb("stages").notNull().default('[]'),
  defaultChecklistTemplate: varchar("default_checklist_template"),
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
export type PipelineTemplate = typeof pipelineTemplates.$inferSelect;
export type InsertPipelineTemplate = typeof pipelineTemplates.$inferInsert;

// ─── Deal Competitors ────────────────────────────────────────────────────────
export const dealCompetitors = pgTable("deal_competitors", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  dealId: varchar("deal_id").notNull(),

// --- Deal Stage Configs ---
export const dealStageConfigs = pgTable("deal_stage_configs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  assetClass: varchar("asset_class", { length: 100 }).notNull(),
  stages: jsonb("stages").notNull(), // [{ id, label, color, order, probability, requiredFields, defaultTasks }]
  isDefault: boolean("is_default").default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});
export type DealStageConfig = typeof dealStageConfigs.$inferSelect;
export type InsertDealStageConfig = typeof dealStageConfigs.$inferInsert;

// ── 10.6 Email Send Integration ─────────────────────────────────────────

export const emailMessages = pgTable("email_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  dealId: varchar("deal_id").references(() => crmDeals.id),
