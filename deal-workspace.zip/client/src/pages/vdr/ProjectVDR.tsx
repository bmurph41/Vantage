import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, FolderLock, FileText, Users, Shield, ClipboardList, Activity, CheckSquare, BarChart3 } from "lucide-react";
import { DocumentsWorkspace } from "@/components/vdr/DocumentsWorkspace";
import { PermissionViewer } from "@/components/vdr/PermissionViewer";
import { ExternalUsersTab } from "@/components/vdr/ExternalUsersTab";
import { DiligenceRequestsTab } from "@/components/vdr/DiligenceRequestsTab";
import { AuditLogViewer } from "@/components/vdr/AuditLogViewer";
import { AnalyticsDashboard } from "@/components/vdr/AnalyticsDashboard";

export default function ProjectVDR() {
  const [, params] = useRoute("/vdr/projects/:id");
  const projectId = params?.id;

  const { data: project, isLoading: projectLoading } = useQuery({
    queryKey: [`/api/dd/projects/${projectId}`],
    enabled: !!projectId,
  });

  const { data: folders, isLoading: foldersLoading } = useQuery({
    queryKey: [`/api/vdr/projects/${projectId}/folders`],
    enabled: !!projectId,
  });

  if (projectLoading) {
    return (
      <div className="p-8 space-y-6">
        <Skeleton className="h-10 w-96" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="p-8">
        <Card>
          <CardContent className="p-12 text-center">
            <h3 className="text-lg font-semibold text-gray-900">Project Not Found</h3>
            <p className="text-gray-600 mt-2">The requested project could not be found.</p>
            <Link href="/vdr">
              <Button className="mt-4">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to VDR
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/vdr">
          <Button variant="ghost" size="icon" data-testid="button-back-to-vdr">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <FolderLock className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-3xl font-bold text-gray-900" data-testid="text-project-name">{project.name}</h1>
              <p className="text-gray-600">{project.description || `${project.name} Data Room`}</p>
            </div>
          </div>
        </div>
        <Link href={`/projects/${projectId}`}>
          <Button variant="outline" data-testid="link-dd-project">
            <CheckSquare className="h-4 w-4 mr-2" />
            DD Project
          </Button>
        </Link>
      </div>

      <Tabs defaultValue="documents" className="space-y-4">
        <TabsList>
          <TabsTrigger value="documents" data-testid="tab-documents">
            <FileText className="h-4 w-4 mr-2" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="analytics" data-testid="tab-analytics">
            <BarChart3 className="h-4 w-4 mr-2" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="permissions" data-testid="tab-permissions">
            <Shield className="h-4 w-4 mr-2" />
            Permissions
          </TabsTrigger>
          <TabsTrigger value="external-users" data-testid="tab-external-users">
            <Users className="h-4 w-4 mr-2" />
            External Users
          </TabsTrigger>
          <TabsTrigger value="requests" data-testid="tab-requests">
            <ClipboardList className="h-4 w-4 mr-2" />
            Requests
          </TabsTrigger>
          <TabsTrigger value="audit" data-testid="tab-audit">
            <Activity className="h-4 w-4 mr-2" />
            Audit Log
          </TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="h-[calc(100vh-20rem)]">
          <DocumentsWorkspace projectId={projectId!} />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <AnalyticsDashboard projectId={projectId!} />
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <PermissionViewer 
            resourceType="project" 
            resourceId={projectId!} 
            projectId={projectId!}
          />
        </TabsContent>

        <TabsContent value="external-users" className="space-y-4">
          <ExternalUsersTab projectId={projectId!} />
        </TabsContent>

        <TabsContent value="requests" className="space-y-4">
          <DiligenceRequestsTab projectId={projectId!} />
        </TabsContent>

        <TabsContent value="audit" className="space-y-4">
          <AuditLogViewer projectId={projectId!} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
