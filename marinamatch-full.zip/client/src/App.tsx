import { Switch, Route, useParams } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AuthGuard } from "@/components/auth/AuthGuard";

import RentRollDashboard from "@/pages/rent-roll-dashboard";
import ExecutiveDashboard from "@/pages/executive-dashboard";
import ProjectHub from "@/pages/project-hub";
import ReportsPage from "@/pages/reports";
import ScenariosPage from "@/pages/scenarios";
import PortfolioPage from "@/pages/portfolio";
import CohortAnalysisPage from "@/pages/cohort-analysis";
import LoginPage from "@/pages/login";
import OrgSetupPage from "@/pages/org-setup";
import AdminTypeManagement from "@/pages/AdminTypeManagement";
import ReconciliationPage from "@/pages/reconciliation";
import GLReconciliationPage from "@/pages/gl-reconciliation";
import ReportPackagesPage from "@/pages/report-packages";
import SnapshotsPage from "@/pages/snapshots";
import IntegrationsPage from "@/pages/integrations";
import ProjectLayout from "@/layouts/ProjectLayout";
import PortfolioLayout from "@/layouts/PortfolioLayout";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/login" component={LoginPage} />
      
      {/* Protected routes */}
      <Route path="/org-setup">
        <AuthGuard>
          <OrgSetupPage />
        </AuthGuard>
      </Route>
      {/* Executive Summary - main dashboard */}
      <Route path="/">
        <AuthGuard>
          <ExecutiveDashboard />
        </AuthGuard>
      </Route>
      
      {/* Projects Hub */}
      <Route path="/rent-roll">
        <AuthGuard>
          <ProjectHub />
        </AuthGuard>
      </Route>
      <Route path="/admin/types">
        <AuthGuard>
          <AdminTypeManagement />
        </AuthGuard>
      </Route>
      <Route path="/reconciliation">
        <AuthGuard>
          <ReconciliationPage />
        </AuthGuard>
      </Route>
      <Route path="/gl-reconciliation">
        <AuthGuard>
          <GLReconciliationPage />
        </AuthGuard>
      </Route>
      <Route path="/report-packages">
        <AuthGuard>
          <ReportPackagesPage />
        </AuthGuard>
      </Route>
      <Route path="/snapshots">
        <AuthGuard>
          <SnapshotsPage />
        </AuthGuard>
      </Route>
      <Route path="/integrations">
        <AuthGuard>
          <IntegrationsPage />
        </AuthGuard>
      </Route>
      
      {/* Project-scoped routes - more specific paths must come first */}
      <Route path="/projects/:id/reports">
        <AuthGuard>
          <ProjectLayout>
            <ReportsPage />
          </ProjectLayout>
        </AuthGuard>
      </Route>
      <Route path="/projects/:id/scenarios">
        <AuthGuard>
          <ProjectLayout>
            <ScenariosPage />
          </ProjectLayout>
        </AuthGuard>
      </Route>
      <Route path="/projects/:id/cohorts">
        <AuthGuard>
          <ProjectLayout>
            <CohortAnalysisPage />
          </ProjectLayout>
        </AuthGuard>
      </Route>
      <Route path="/projects/:id/data-quality">
        <AuthGuard>
          <ProjectLayout>
            <ReconciliationPage />
          </ProjectLayout>
        </AuthGuard>
      </Route>
      <Route path="/projects/:id">
        <AuthGuard>
          <ProjectLayout>
            <RentRollDashboard />
          </ProjectLayout>
        </AuthGuard>
      </Route>
      
      {/* Portfolio-scoped routes - more specific paths must come first */}
      <Route path="/portfolio/reports">
        <AuthGuard>
          <PortfolioLayout>
            <ReportsPage />
          </PortfolioLayout>
        </AuthGuard>
      </Route>
      <Route path="/portfolio/cohorts">
        <AuthGuard>
          <PortfolioLayout>
            <CohortAnalysisPage />
          </PortfolioLayout>
        </AuthGuard>
      </Route>
      <Route path="/portfolio/data-quality">
        <AuthGuard>
          <PortfolioLayout>
            <ReconciliationPage />
          </PortfolioLayout>
        </AuthGuard>
      </Route>
      <Route path="/portfolio">
        <AuthGuard>
          <PortfolioLayout>
            <PortfolioPage />
          </PortfolioLayout>
        </AuthGuard>
      </Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
