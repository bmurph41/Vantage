# Rent Roll Analysis Module - Design Guidelines

## Design Approach
**Selected System:** Carbon Design System with modern data-dashboard refinements  
**Rationale:** Carbon excels at data-heavy enterprise applications with complex tables, forms, and metrics visualization - perfect for financial management tools requiring clarity and efficiency over visual flair.

## Core Design Principles
1. **Data Clarity First:** Information hierarchy optimized for scanning large datasets
2. **Efficient Workflows:** Minimize clicks for common tasks (add lease, import events, view cash flows)
3. **Trust & Precision:** Professional aesthetic that reinforces accuracy of financial data
4. **Responsive Data Display:** Tables and grids that adapt gracefully across viewports

## Typography System
- **Headings:** Inter or IBM Plex Sans
  - H1 (Dashboard title): text-3xl font-semibold
  - H2 (Section headers): text-2xl font-semibold  
  - H3 (Card titles): text-lg font-medium
  - H4 (Table headers): text-sm font-semibold uppercase tracking-wide
- **Body:** text-sm for dense data tables, text-base for forms and descriptions
- **Numbers/Metrics:** tabular-nums (monospace numbers for alignment)
- **Financial Values:** font-medium for emphasis on revenue/amounts

## Layout System
**Spacing Units:** Tailwind units of 2, 4, 6, and 8 for consistency
- Component padding: p-4 to p-6
- Section spacing: space-y-6 to space-y-8
- Card gaps: gap-4 to gap-6
- Table cell padding: px-4 py-3

**Grid Structure:**
- Dashboard: 12-column grid (grid-cols-12)
- Summary cards: 4-column on desktop (md:grid-cols-2 lg:grid-cols-4)
- Main content: max-w-7xl container with px-4 to px-6

## Component Library

### Dashboard Layout
- **Top Bar:** Sticky header with module title, date range selector, export actions
- **Summary Cards Row:** 4 metric cards showing KPIs (Rent Roll Count, Monthly Revenue, Net Moves, Discrepancy)
- **Tab Navigation:** Horizontal tabs for Leases, Cash Flows, Move Events, Heat Map views
- **Main Content Area:** Full-width table or grid based on active tab

### Data Tables
- **Style:** Dense, bordered tables with zebra striping (even rows slightly lighter)
- **Headers:** Sticky top, sortable columns with arrow indicators
- **Row Actions:** Inline edit/delete icons on hover (right-aligned)
- **Pagination:** Bottom-aligned with rows-per-page selector
- **Empty States:** Centered icon + text + primary action button

### Forms & Drawers
- **Lease Form Drawer:** Slides from right, 480px wide, scrollable content
- **Form Layout:** Single column with grouped fields (Tenant Info, Lease Terms, Boat Details)
- **Input Fields:** Full-width with clear labels above, helper text below
- **Date Pickers:** Calendar dropdown with manual input fallback
- **Actions:** Fixed footer with Cancel (ghost) + Save (primary) buttons

### Summary Cards
- **Structure:** Icon + Label + Large Value + Trend Indicator
- **Layout:** Vertical stack with p-6 padding
- **Values:** text-3xl font-bold for primary metric
- **Trends:** Small badge with arrow icon (↑ green, ↓ red) and percentage change

### Cash Flow Grid
- **Header Row:** Sticky with period labels (Jan 2024, Feb 2024...)
- **Metrics Rows:** 
  - Contracted Revenue (bold, primary color)
  - P&L Revenue (user-editable inline, lighter background)
  - Delta (conditional formatting: green if positive, red if negative)
  - Rent Roll Count, Move-Ins, Move-Outs, Net Moves
  - Discrepancy (highlighted if non-zero)
- **Scroll:** Horizontal scroll for many months, fixed first column (metric names)

### Heat Map Table
- **Columns:** Location (State/City) | Count | Visual Bar
- **Bar Chart:** Inline horizontal bar (max-width proportional to highest count)
- **Sorting:** Default by count descending
- **Toggle:** Switch between State/City views

### Buttons & Actions
- **Primary:** Filled button for main actions (Add Lease, Import Events)
- **Secondary:** Outlined button for secondary actions (Export, Cancel)
- **Ghost:** Text-only for tertiary actions (Clear filters)
- **Icon Buttons:** Small, square, ghost style for row actions

## Interactive States
- **Hover:** Subtle background lift on cards/rows (transition-colors duration-150)
- **Active/Selected:** Slightly darker background, no dramatic effects
- **Focus:** Clear 2px outline offset for keyboard navigation
- **Loading:** Skeleton loaders for tables, spinner for actions

## Animations
**Minimal Usage:**
- Drawer slide-in: duration-300 ease-out
- Dropdown/popover fade: duration-200
- Button hover: transition-colors duration-150
- NO scroll animations, parallax, or decorative motion

## Accessibility
- All tables use proper semantic markup (thead, tbody, th, td)
- Form inputs have associated labels (not placeholders as labels)
- Color never sole indicator (use icons + text for status)
- Keyboard navigation fully supported (tab order, arrow keys in tables)
- ARIA labels for icon-only buttons
- Consistent focus indicators across all interactive elements

## Page Structure
Single-page dashboard with tabbed sections - no marketing elements needed. Focus entirely on functional workspace layout with maximum information density while maintaining scanability.