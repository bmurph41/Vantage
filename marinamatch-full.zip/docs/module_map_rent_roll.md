# MarinaMatch Rent Roll Module Map

**Generated**: December 17, 2025  
**Purpose**: Internal architecture reference for institutional-grade upgrade implementation

---

## 1. Overview

MarinaMatch is a marina lease management and financial analysis platform with:
- Multi-tenant organization-scoped data isolation
- Rent roll import, cash flow generation, scenario modeling
- Executive dashboard with KPIs, revenue analytics, occupancy metrics
- Audit logging and role-based access control

**Tech Stack**:
- Frontend: React 18, TypeScript, Vite, Wouter, shadcn/ui, TanStack Query
- Backend: Express.js, TypeScript, Drizzle ORM
- Database: Neon Serverless PostgreSQL

---

## 2. Frontend Structure

### Pages (`client/src/pages/`)

| Page | Route | Purpose |
|------|-------|---------|
| `login.tsx` | `/` | Replit Auth login |
| `org-setup.tsx` | `/org-setup` | Organization onboarding |
| `project-hub.tsx` | `/project-hub` | Project portfolio overview |
| `rent-roll-dashboard.tsx` | `/rent-roll/:locationId` | Main rent roll view |
| `executive-dashboard.tsx` | `/executive-dashboard` | KPIs and analytics |
| `portfolio.tsx` | `/portfolio` | Cross-project analytics |
| `scenarios.tsx` | `/scenarios` | What-if scenario modeling |
| `reports.tsx` | `/reports` | Report generation |
| `reconciliation.tsx` | `/reconciliation` | GL reconciliation (exists) |
| `cohort-analysis.tsx` | `/cohort-analysis` | Customer cohort analysis |
| `AdminTypeManagement.tsx` | `/admin/types` | Admin type management |

### Key Component Directories (`client/src/components/`)

| Directory | Purpose |
|-----------|---------|
| `rent-roll/` | Rent roll table, filters, import wizard, lease forms |
| `executive/` | Dashboard cards, charts, KPI visualizations |
| `locations/` | Project/location management forms |
| `navigation/` | Sidebar, header, navigation components |
| `auth/` | Authentication components |
| `comments/` | Comment/notes system |
| `ui/` | shadcn/ui base components |

---

## 3. Backend Structure

### Server Files (`server/`)

| File | Purpose |
|------|---------|
| `index.ts` | Express app entry point |
| `routes.ts` | All API route definitions (~5,400 lines) |
| `rentRollService.ts` | Core business logic (~6,000+ lines) |
| `marinaLeaseEngine.ts` | Cash flow generation engine |
| `storage.ts` | IStorage interface + database operations |
| `db.ts` | Drizzle database connection |
| `replitAuth.ts` | Replit OpenID Connect authentication |
| `authorizationMiddleware.ts` | Org-scoped authorization, RBAC middleware |
| `auditService.ts` | Audit logging functions |
| `bulkLeaseImport.ts` | Bulk import processing |
| `reportsService.ts` | Report generation logic |
| `scenarioService.ts` | Scenario modeling calculations |
| `aiAddressParser.ts` | AI-powered address parsing |
| `aiReportNarratives.ts` | AI executive summary generation |
| `rateConversion.ts` | Rate type conversion utilities |

---

## 4. Database Tables (`shared/schema.ts`)

### Core Tables

| Table | Purpose | Key Columns |
|-------|---------|-------------|
| `users` | User accounts | id, email, firstName, lastName |
| `organizations` | Multi-tenant orgs | id, name, createdAt |
| `organizationUsers` | Org membership + roles | orgId, userId, role (owner/admin/analyst/viewer) |
| `marinaLocations` | Projects/assets | id, orgId, name, projectType, includeInExecutive |
| `storageLocations` | Physical slips/docks | id, projectId, name, postedRate |
| `tenants` | Lease customers | id, orgId, name, email, address |
| `leases` | Lease records | id, tenantId, locationId, leaseAmount, contractTerm, storageType |
| `leaseLineItems` | Fee components | id, leaseId, lineType, amount, startDate, endDate |

### Cash Flow / Financial Tables

| Table | Purpose |
|-------|---------|
| `contractCharges` | Flexible pricing rules per lease |
| `periods` | Monthly period reference |
| `leaseCashFlows` | Generated monthly cash flows per lease |
| `pnlRackRevenue` | P&L rack revenue tracking |
| `rentRollSnapshots` | Point-in-time snapshots (exists, minimal implementation) |

### Analytics / Reporting Tables

| Table | Purpose |
|-------|---------|
| `moveEvents` | Move-in/out tracking |
| `projectBudgets` | Budget vs actuals |
| `scenarios` | What-if scenario definitions |
| `scenarioCashFlows` | Scenario-specific projections |
| `savedReports` | Saved report configurations |

### System Tables

| Table | Purpose |
|-------|---------|
| `sessions` | Express session store |
| `auditLogs` | Comprehensive audit trail |
| `uploadedFiles` | Import file metadata |
| `leaseImports` | Import tracking per lease |
| `comments` | Entity comments/notes |
| `projectDetailsConfig` | Project-level settings (seasons, defaults) |

### Custom Type Tables

| Table | Purpose |
|-------|---------|
| `customStorageTypes` | Org-specific storage types |
| `customContractTerms` | Org-specific contract terms |
| `customRateTypes` | Org-specific rate types |
| `customSlipStatuses` | Org-specific slip statuses |
| `globalPromotedTypes` | System-wide promoted types |
| `adminTypeReviewQueue` | Admin review queue |

---

## 5. API Endpoints Summary

### Authentication & Organizations
- `GET /api/auth/user` - Current user
- `GET/POST/PUT/DELETE /api/organizations` - Org CRUD
- `GET/POST/DELETE /api/organizations/:id/members` - Membership management
- `GET /api/organizations/:id/audit-logs` - Audit history

### Leases
- `GET /api/rent-roll/leases` - List with filters
- `GET /api/rent-roll/leases/:id` - Single lease
- `POST /api/rent-roll/leases` - Create with tenant
- `PUT /api/rent-roll/leases/:id` - Update
- `DELETE /api/rent-roll/leases/:id` - Soft delete
- `POST /api/rent-roll/leases/bulk-delete` - Bulk delete
- `POST /api/rent-roll/leases/bulk-update` - Bulk update

### Lease Line Items
- `GET/POST /api/rent-roll/leases/:leaseId/line-items`
- `POST /api/rent-roll/leases/:leaseId/line-items/bulk`
- `GET/PUT/DELETE /api/rent-roll/line-items/:id`

### Locations (Projects)
- `GET /api/rent-roll/locations` - All projects
- `GET /api/rent-roll/locations/active` - Active projects
- `POST /api/rent-roll/locations` - Create project
- `PUT /api/rent-roll/locations/:id` - Update
- `DELETE /api/rent-roll/locations/:id` - Delete
- `POST /api/rent-roll/locations/:id/reset` - Reset project data
- `POST /api/rent-roll/locations/:id/regenerate-cashflows` - Regenerate

### Storage Locations
- `GET /api/rent-roll/storage-locations` - By project
- `POST/PUT/DELETE /api/rent-roll/storage-locations/:id`

### Import Pipeline
- `POST /api/rent-roll/leases/import/detect-values` - Auto-detect values
- `POST /api/rent-roll/leases/import/suggest-mappings` - Column mapping
- `POST /api/rent-roll/leases/import/suggest-column-mappings` - AI mapping
- `POST /api/rent-roll/leases/import/pdf` - PDF extraction
- `POST /api/rent-roll/leases/import/parse` - Parse uploaded file
- `POST /api/rent-roll/leases/import` - Execute import

### Executive Dashboard
- `GET /api/executive-dashboard/metrics` - KPI summary
- `GET /api/executive-dashboard/revenue-trend` - Revenue over time
- `GET /api/executive-dashboard/revenue-trend-by-storage-type`
- `GET /api/executive-dashboard/move-events-detail`
- `GET /api/executive-dashboard/revenue-by-project`
- `GET /api/executive-dashboard/occupancy-by-project`
- `GET /api/executive-dashboard/avg-lease-value-by-project`
- `GET /api/executive-dashboard/avg-boat-size`
- `GET /api/executive-dashboard/seasonal-move-events`
- `GET /api/executive-dashboard/contract-term-occupancy`

### Reports
- `GET /api/reports/options` - Filter options
- `POST /api/reports/generate` - Generate report data
- `POST /api/reports/export/excel` - Excel export
- `POST /api/reports/export/pdf` - PDF export

### Scenarios
- `GET/POST /api/scenarios` - List/create scenarios
- `GET/PUT/DELETE /api/scenarios/:id`

---

## 6. Cash Flow Generation Entry Points

### Primary Engine: `server/marinaLeaseEngine.ts`

**Key Functions**:
- `generateCashFlowForLease()` - Main cash flow generation
- `calculateProRataFactor()` - Partial period proration
- `isMonthInSeasonalRange()` - Seasonal gating
- `applyEscalation()` - Rent escalation logic

**Supported Features**:
- Multiple basis types: per_ft_per_month, per_month, per_year, per_season
- Charge frequencies: monthly, annual, seasonal, daily, one_time
- Escalation methods: none, fixed_step, index_linked
- Pro-rata calculations for partial periods
- Seasonal charge gating by month range

### Legacy Cash Flow: `server/rentRollService.ts`

**Function**: `generateLeaseCashFlows()`
- Creates monthly records in `leaseCashFlows` table
- Used for basic monthly rent allocation
- Called on lease create/update

**Trigger Points**:
1. Lease creation → `createLeaseWithTenant()` → `generateLeaseCashFlows()`
2. Lease update → `updateLease()` → regenerate if dates/amounts change
3. Bulk operations → `bulkUpdateLeases()` → regenerate for affected leases
4. Manual regeneration → `regenerateAllCashFlowsForProject()`

---

## 7. Import Pipeline Steps

### Workflow: 4-Step Import Process

1. **Upload** (`/api/rent-roll/leases/import/parse`)
   - Accept CSV/Excel file
   - Parse to JSON rows
   - Return preview data

2. **Mapping** (`/api/rent-roll/leases/import/suggest-mappings`)
   - Auto-detect column mappings
   - Support AI-assisted mapping
   - User confirmation

3. **Preview** (Client-side validation)
   - Data quality checks
   - Duplicate detection
   - Validation warnings

4. **Import** (`/api/rent-roll/leases/import`)
   - Execute import with mode: Create, Append, Replace
   - Generate lease keys
   - Create tenants + leases
   - Trigger cash flow generation

### PDF Import: `bulkLeaseImport.ts`
- Uses OpenAI GPT-4o-mini for extraction
- Returns structured lease data with confidence scores

---

## 8. RBAC Behavior

### Role Hierarchy (`shared/schema.ts`)

```typescript
organizationRoleEnum: ['owner', 'admin', 'analyst', 'viewer']
```

### Permission Matrix

| Permission | Owner | Admin | Analyst | Viewer |
|------------|-------|-------|---------|--------|
| `VIEW_RENTROLL` | ✓ | ✓ | ✓ | ✓ |
| `EDIT_RENTROLL` | ✓ | ✓ | ✓ | ✗ |
| `DELETE_RENTROLL` | ✓ | ✓ | ✗ | ✗ |
| `MANAGE_USERS` | ✓ | ✓ | ✗ | ✗ |
| `MANAGE_ORG` | ✓ | ✗ | ✗ | ✗ |
| `VIEW_AUDIT` | ✓ | ✓ | ✓ | ✗ |
| `EXPORT_REPORTS` | ✓ | ✓ | ✓ | ✓ |

### Authorization Middleware (`authorizationMiddleware.ts`)

- `isAuthenticated` - Verify JWT token
- `requireLocationAccess` - Org-scoped project access
- `requireLeaseAccess` - Lease ownership verification
- `requireStorageLocationAccess` - Storage location verification
- `requirePermission()` - Role-based permission check (added)
- `validateLocationOwnership()` - Cross-check location org

### Audit Logging (`auditService.ts`)

All mutations logged with:
- User ID, Organization ID
- Entity type/ID
- Action (CREATE, UPDATE, DELETE)
- Previous/new values
- Timestamp

---

## 9. Fragile / Tightly Coupled Areas

### High Coupling Risks

1. **routes.ts (~5,400 lines)**
   - Monolithic file with all endpoints
   - Mixed business logic in route handlers
   - Consider splitting by domain

2. **rentRollService.ts (~6,000+ lines)**
   - Contains all business logic
   - Mixed concerns: CRUD, analytics, import, cash flows
   - Should be split into domain services

3. **Cash Flow Dual Systems**
   - `marinaLeaseEngine.ts` (new contract charges system)
   - `generateLeaseCashFlows()` in rentRollService (legacy)
   - Need unified approach

4. **Lease Amount Semantics**
   - `leaseAmount` meaning varies by `rateType`
   - Seasonal/annual = total value
   - Monthly = monthly amount
   - Complex calculation logic scattered

### Data Integrity Concerns

1. **Snapshot table exists but minimal**
   - `rentRollSnapshots` has basic schema
   - No snapshot items table
   - No compare/lock functionality

2. **No formal lease terms/steps/escalations**
   - Basic escalation in `contractCharges`
   - No rent step tracking
   - No concession tracking

3. **File storage is base64 in DB**
   - `uploadedFiles` table
   - Should migrate to object storage

---

## 10. Integration Seams Needed

### For Parent App Mounting

1. **Route constants** - Centralized route definitions
2. **Permission constants** - Shared permission keys
3. **Event system** - For cross-module communication
4. **Design tokens** - Consistent theming
5. **Sidebar entries** - Exportable nav structure

### External System Stubs

1. **QuickBooks/Yardi** - Financial export sources
2. **Data Room** - Document parsing triggers
3. **Global Dashboard** - KPI summary endpoints

---

## 11. Upgrade Path Summary

| Phase | Scope | Risk Level |
|-------|-------|------------|
| 1A | Lease Economics Engine | Medium - Additive, fallback to legacy |
| 1B | Snapshots | Low - New tables, new endpoints |
| 1C | Reconciliation | Low - New feature, optional UI |
| 1D | Report Package | Low - Extends existing exports |
| 1E | File Storage | Medium - Migration script needed |
| 2 | Integration Seams | Low - Refactor, no logic change |
| 3 | Feature Flags | Low - UI gating only |

---

*Document maintained for institutional upgrade implementation.*
