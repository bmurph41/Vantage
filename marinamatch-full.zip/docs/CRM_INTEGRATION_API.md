# MarinaMatch CRM Integration API Documentation

This document describes the integration API for synchronizing data between MarinaMatch and external CRM systems.

## Overview

The CRM integration enables bidirectional synchronization:
- **CRM → MarinaMatch**: Property/Company data synced via webhook or API push
- **MarinaMatch → CRM**: Lease/Tenant changes emitted via configurable webhook endpoints

## Authentication

All integration endpoints use API key authentication.

### Obtaining an API Key

API keys are managed through the MarinaMatch Integration Dashboard:
1. Navigate to Settings → Integrations
2. Click "Create API Key"
3. Copy the full key immediately (it cannot be retrieved later)

### Using the API Key

Include the key in the Authorization header:

```http
Authorization: Bearer mm_int_xxxxxxxx...
```

### Key Format

API keys follow the format: `mm_int_<8-char-prefix><32-char-random>`

## Inbound Endpoints (CRM → MarinaMatch)

### Sync Project (Property)

Create or update a marina project from CRM property data.

```http
POST /api/integrations/projects
Authorization: Bearer <api_key>
Content-Type: application/json
X-Idempotency-Key: <unique-request-id>
```

**Request Body:**

```json
{
  "externalId": "crm-property-12345",
  "name": "Marina Bay Resort",
  "code": "MBR",
  "description": "Full-service marina with 120 wet slips",
  "status": "active",
  "projectType": "OWNED",
  "capacity": 120,
  "seasonType": "year-round",
  "metadata": {
    "region": "Southeast",
    "manager": "John Smith"
  }
}
```

**Required Fields:**
- `externalId` (string): Unique identifier in the CRM system
- `name` (string): Project/marina name

**Optional Fields:**
- `code` (string): Short code for the project
- `description` (string): Project description
- `status` (string): Project status
- `projectType` (string): "OWNED" or "DEAL"
- `capacity` (integer): Number of slips/units
- `seasonType` (string): Seasonality type
- `metadata` (object): Additional CRM-specific data

**Response (200 OK):**

```json
{
  "success": true,
  "marinaMatchId": "uuid-of-project",
  "externalId": "crm-property-12345",
  "action": "created" | "updated"
}
```

### Sync Tenant (Company/Contact)

Create or update a tenant from CRM company or contact data.

```http
POST /api/integrations/tenants
Authorization: Bearer <api_key>
Content-Type: application/json
X-Idempotency-Key: <unique-request-id>
```

**Request Body:**

```json
{
  "externalId": "crm-company-67890",
  "name": "John Smith",
  "address1": "123 Main Street",
  "address2": "Suite 100",
  "city": "Miami",
  "state": "FL",
  "zip": "33101",
  "boatMake": "Sea Ray",
  "boatYear": 2020,
  "boatLength": "42",
  "boatWidth": "14",
  "metadata": {
    "membershipTier": "Gold",
    "referralSource": "Website"
  }
}
```

**Required Fields:**
- `externalId` (string): Unique identifier in the CRM system
- `name` (string): Tenant name

**Optional Fields:**
- `address1`, `address2` (string): Address lines
- `city`, `state`, `zip` (string): Address components
- `boatMake` (string): Boat manufacturer
- `boatYear` (integer): Boat year
- `boatLength`, `boatWidth` (string): Boat dimensions
- `metadata` (object): Additional CRM-specific data

**Response (200 OK):**

```json
{
  "success": true,
  "marinaMatchId": "uuid-of-tenant",
  "externalId": "crm-company-67890",
  "action": "created" | "updated"
}
```

### Sync Lease

Create or update a lease from CRM deal data.

```http
POST /api/integrations/leases
Authorization: Bearer <api_key>
Content-Type: application/json
X-Idempotency-Key: <unique-request-id>
```

**Request Body:**

```json
{
  "externalId": "crm-deal-11111",
  "projectExternalId": "crm-property-12345",
  "tenantExternalId": "crm-company-67890",
  "leaseCommencement": "2025-01-01",
  "leaseExpiration": "2025-12-31",
  "leaseAmount": "1500.00",
  "rateType": "Annual",
  "contractTerm": "12 months",
  "storageType": "Wet Slip",
  "unitNumber": "A-42",
  "unitLocation": "A Dock",
  "slipStatus": "Occupied",
  "metadata": {}
}
```

**Required Fields:**
- `externalId` (string): Unique identifier in the CRM system
- `tenantExternalId` (string): Must match an existing tenant mapping

**Optional Fields:**
- `projectExternalId` (string): Project external ID
- `leaseCommencement`, `leaseExpiration` (string: YYYY-MM-DD): Lease dates
- `leaseAmount` (string): Monthly rent amount
- `rateType`, `contractTerm` (string): Rate and term info
- `storageType` (string): Type of storage (Wet Slip, Dry Rack, etc.)
- `unitNumber`, `unitLocation` (string): Unit identification
- `slipStatus` (string): Occupancy status
- `metadata` (object): Additional CRM-specific data

## Outbound Webhooks (MarinaMatch → CRM)

MarinaMatch can send webhook events when data changes. Configure webhook endpoints in the Integration Dashboard.

### Configuring Webhook Endpoints

```http
POST /api/integrations/webhooks/endpoints
Authorization: Bearer <session_cookie>
Content-Type: application/json

{
  "name": "CRM Webhook",
  "url": "https://your-crm.com/webhooks/marinamatch",
  "secret": "your-shared-secret",
  "eventTypes": ["lease.created", "lease.updated", "lease.deleted"],
  "entityTypes": ["lease", "tenant"]
}
```

### Webhook Payload Format

```json
{
  "id": "webhook-delivery-uuid",
  "event": "lease.created",
  "timestamp": "2025-01-15T10:30:00.000Z",
  "data": {
    "id": "uuid-of-lease",
    "tenantId": "uuid-of-tenant",
    "locationId": "uuid-of-project",
    "leaseCommencement": "2025-01-01",
    "leaseExpiration": "2025-12-31",
    "leaseAmount": "1500.00",
    "storageType": "Wet Slip",
    "unitNumber": "A-42",
    "slipStatus": "Occupied",
    "tenant": {
      "id": "uuid-of-tenant",
      "name": "John Smith",
      "address1": "123 Main Street",
      "city": "Miami",
      "state": "FL",
      "zip": "33101"
    }
  },
  "externalId": "crm-deal-11111"
}
```

### Webhook Headers

```http
X-Webhook-Event: lease.created
X-Webhook-Timestamp: 2025-01-15T10:30:00.000Z
X-Webhook-Delivery: <delivery-uuid>
X-Webhook-Signature: sha256=<hmac-signature>
```

### Verifying Webhook Signatures

Webhooks are signed using HMAC-SHA256 with your configured secret:

```javascript
const crypto = require('crypto');

function verifyWebhookSignature(payload, signature, secret) {
  const expected = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(payload))
    .digest('hex');
  return `sha256=${expected}` === signature;
}

// Express.js example
app.post('/webhooks/marinamatch', (req, res) => {
  const signature = req.headers['x-webhook-signature'];
  const isValid = verifyWebhookSignature(req.body, signature, process.env.MARINAMATCH_WEBHOOK_SECRET);
  
  if (!isValid) {
    return res.status(401).json({ error: 'Invalid signature' });
  }
  
  // Process the webhook
  const { event, data, externalId } = req.body;
  console.log(`Received ${event} for entity ${externalId || data.id}`);
  
  res.status(200).json({ received: true });
});
```

### Event Types

| Event | Description |
|-------|-------------|
| `lease.created` | A new lease was created |
| `lease.updated` | An existing lease was modified |
| `lease.deleted` | A lease was deleted (soft delete) |
| `tenant.created` | A new tenant was created |
| `tenant.updated` | An existing tenant was modified |
| `tenant.deleted` | A tenant was deleted |

### Retry Policy

Failed webhook deliveries are retried with exponential backoff. The retry policy is configurable per endpoint.

**Default Retry Policy:**
| Parameter | Default Value | Description |
|-----------|---------------|-------------|
| `maxRetries` | 3 | Total retry attempts after initial failure |
| `initialDelayMs` | 1000 | Initial delay before first retry (1 second) |
| `maxDelayMs` | 30000 | Maximum delay between retries (30 seconds) |
| `backoffMultiplier` | 2 | Delay multiplier for exponential backoff |

**Retry Sequence Example:**
1. Initial attempt fails → wait 1s
2. Retry 1 fails → wait 2s (1s * 2)
3. Retry 2 fails → wait 4s (2s * 2)
4. Retry 3 fails → mark as failed, logged to webhook logs

**Custom Retry Policy:**
When creating a webhook endpoint, you can specify a custom retry policy:

```json
{
  "name": "CRM Webhook",
  "url": "https://your-crm.com/webhooks",
  "secret": "your-32-char-secret-key",
  "retryPolicy": {
    "maxRetries": 5,
    "initialDelayMs": 2000,
    "maxDelayMs": 60000,
    "backoffMultiplier": 1.5
  }
}
```

**Delivery Guarantees:**
- Webhooks are delivered **at-least-once** - your endpoint may receive duplicate events
- Use the `X-Webhook-Delivery` header as an idempotency key to detect duplicates
- Events are sent asynchronously and non-blocking to the main application flow
- All delivery attempts (success and failure) are logged in the Integration Dashboard

### Lease Webhook Payload Details

The `data` field in lease events contains the following structure:

```json
{
  "data": {
    "id": "uuid-of-lease",
    "tenantId": "uuid-of-tenant",
    "locationId": "uuid-of-project",
    "storageLocationId": "uuid-of-storage-location",
    "leaseCommencement": "2025-01-01",
    "leaseExpiration": "2025-12-31",
    "leaseAmount": "1500.00",
    "rateType": "Annual",
    "contractTerm": "12 months",
    "storageType": "Wet Slip",
    "unitLocation": "A Dock",
    "unitNumber": "A-42",
    "boatDimensions": "42' x 14'",
    "slipStatus": "Occupied",
    "tenant": {
      "id": "uuid-of-tenant",
      "name": "John Smith",
      "address1": "123 Main Street",
      "address2": "Suite 100",
      "city": "Miami",
      "state": "FL",
      "zip": "33101"
    }
  }
}
```

**Notes:**
- The `tenant` object is included in `lease.created` and `lease.updated` events
- The `tenant` object is omitted in `lease.deleted` events (only core IDs are sent)
- The `externalId` field is included if the entity was originally synced from the CRM

## Error Handling

### Error Response Format

```json
{
  "error": "Error message description"
}
```

### Common Error Codes

| Code | Description |
|------|-------------|
| 400 | Bad Request - Missing or invalid fields |
| 401 | Unauthorized - Invalid or missing API key |
| 403 | Forbidden - API key does not have access |
| 404 | Not Found - Referenced entity does not exist |
| 409 | Conflict - Duplicate or conflicting data |
| 500 | Internal Server Error |

## Best Practices

1. **Idempotency**: Always include the `X-Idempotency-Key` header with a unique value per request to prevent duplicate processing.

2. **Webhook Acknowledgment**: Respond to webhooks within 10 seconds with a 2xx status code.

3. **Error Retry**: Implement exponential backoff for failed requests with a maximum of 5 retries.

4. **Data Validation**: Validate all data before sending to avoid 400 errors.

5. **Monitoring**: Use the Integration Dashboard to monitor sync status and troubleshoot failures.

## Sample CRM Integration Code

### Node.js / Express Example

```javascript
const crypto = require('crypto');
const axios = require('axios');

class MarinaMatchClient {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseUrl = 'https://your-app.replit.app/api/integrations';
  }

  async syncProject(property) {
    const response = await axios.post(
      `${this.baseUrl}/projects`,
      {
        externalId: property.id,
        name: property.name,
        description: property.description,
        capacity: property.slipCount,
        projectType: 'OWNED',
      },
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'X-Idempotency-Key': `project-${property.id}-${Date.now()}`,
        },
      }
    );
    return response.data;
  }

  async syncTenant(company) {
    const response = await axios.post(
      `${this.baseUrl}/tenants`,
      {
        externalId: company.id,
        name: company.name,
        address1: company.address?.line1,
        address2: company.address?.line2,
        city: company.address?.city,
        state: company.address?.state,
        zip: company.address?.postalCode,
        boatMake: company.customFields?.boatMake,
        boatLength: company.customFields?.boatLength,
      },
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'X-Idempotency-Key': `tenant-${company.id}-${Date.now()}`,
        },
      }
    );
    return response.data;
  }
}

// Webhook receiver
app.post('/webhooks/marinamatch', (req, res) => {
  const { event, data, externalId } = req.body;
  
  switch (event) {
    case 'lease.created':
      console.log(`New lease created: ${data.id}`);
      // Update CRM deal status
      break;
    case 'lease.updated':
      console.log(`Lease updated: ${data.id}`);
      // Sync changes back to CRM
      break;
    case 'lease.deleted':
      console.log(`Lease deleted: ${data.id}`);
      // Mark CRM deal as cancelled
      break;
  }
  
  res.status(200).json({ received: true });
});
```

## Entity Mapping Reference

| CRM Entity | MarinaMatch Entity | Notes |
|------------|-------------------|-------|
| Property | Project (marina_locations) | One-to-one mapping |
| Company | Tenant | One-to-one mapping |
| Contact | Tenant Contact | Future enhancement |
| Deal | Lease | Requires tenant mapping |

## Rate Limits

- API requests: 100 requests per minute per API key
- Webhook deliveries: No limit, but responses must be under 10 seconds

## Support

For integration support, contact the MarinaMatch team or use the Integration Dashboard to monitor sync status and review webhook logs.
