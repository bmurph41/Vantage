# Rent Roll Integration Fix Guide

## Problem Identified

The exported rent roll code was using **incorrect OpenAI configuration** which caused AI features (column mapping, value mapping, address parsing, PDF extraction) to fail.

### Files With Incorrect Configuration:
1. `server/services/rent-roll-v2/ai-import-mapper.ts`
2. `server/services/rent-roll-document-parser.ts`

### The Bug

**WRONG (old code):**
```typescript
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;
```

**CORRECT (fixed code):**
```typescript
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});
```

---

## How to Fix Your Other Repl

### Option 1: Manual Fix (Quickest)

In your other Repl, find and replace in these two files:

**File 1: `server/services/rent-roll-v2/ai-import-mapper.ts`**

Find this code near the top:
```typescript
const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const AI_ENABLED = !!openai;
```

Replace with:
```typescript
// Use Replit AI Integrations - provides OpenAI-compatible API access
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

// Check if AI integrations are properly configured
const AI_ENABLED = !!(process.env.AI_INTEGRATIONS_OPENAI_BASE_URL && process.env.AI_INTEGRATIONS_OPENAI_API_KEY);
```

**File 2: `server/services/rent-roll-document-parser.ts`**

Find this code near the top:
```typescript
const openai = process.env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const AI_ENABLED = !!openai;
```

Replace with:
```typescript
// Use Replit AI Integrations - provides OpenAI-compatible API access
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

// Check if AI integrations are properly configured
const AI_ENABLED = !!(process.env.AI_INTEGRATIONS_OPENAI_BASE_URL && process.env.AI_INTEGRATIONS_OPENAI_API_KEY);
```

### Option 2: Use the Corrected Archive

A corrected archive has been created at:
```
attached_assets/rent-roll-corrected.tar.gz
```

---

## Verify AI Integration is Installed

In your other Repl, make sure the **javascript_openai_ai_integrations** integration is installed:

1. Open the Repl
2. Look for "Integrations" in the sidebar
3. Search for "OpenAI" or "AI Integrations"
4. If not installed, install it

Once installed, these environment variables will be available:
- `AI_INTEGRATIONS_OPENAI_BASE_URL`
- `AI_INTEGRATIONS_OPENAI_API_KEY`

### Quick Test

Add this temporary endpoint to test:
```typescript
app.get("/api/test-ai-config", (req, res) => {
  res.json({
    hasBaseUrl: !!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
    hasApiKey: !!process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  });
});
```

Both should return `true`.

---

## What Each Fix Does

| Feature | Fixed By |
|---------|----------|
| AI Column Mapping | `ai-import-mapper.ts` fix |
| AI Value Mapping | `ai-import-mapper.ts` fix |
| AI Address Parsing | Uses correct env vars now |
| PDF Text Extraction | `rent-roll-document-parser.ts` fix |
| AI Executive Summaries | Already using correct config |

---

## After Fixing

1. Restart your server/workflow
2. Try uploading a CSV or Excel file
3. AI column suggestions should now appear
4. PDF parsing should now work with AI extraction
