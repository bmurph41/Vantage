import { db } from "./db";
import { 
  integrationWebhookEndpoints, 
  integrationWebhookLogs,
  integrationMappings,
} from "@shared/schema";
import { eq, and, sql } from "drizzle-orm";
import crypto from "crypto";

type EntityType = "lease" | "tenant" | "project" | "contact";
type EventAction = "created" | "updated" | "deleted";

interface WebhookEvent {
  eventType: string;
  entityType: EntityType;
  entityId: string;
  organizationId: string;
  timestamp: string;
  data: Record<string, unknown>;
  externalId?: string;
}

interface WebhookPayload {
  id: string;
  event: string;
  timestamp: string;
  data: Record<string, unknown>;
  externalId?: string;
}

function generateSignature(payload: string, secret: string): string {
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

async function getExternalId(entityType: EntityType, entityId: string): Promise<string | null> {
  try {
    const mapping = await db
      .select({ externalId: integrationMappings.externalId })
      .from(integrationMappings)
      .where(
        and(
          eq(integrationMappings.entityType, entityType),
          eq(integrationMappings.marinaMatchId, entityId)
        )
      )
      .limit(1);
    
    return mapping.length > 0 ? mapping[0].externalId : null;
  } catch {
    return null;
  }
}

async function getEndpointsForEvent(
  organizationId: string,
  eventType: string,
  entityType: EntityType
): Promise<typeof integrationWebhookEndpoints.$inferSelect[]> {
  try {
    const endpoints = await db
      .select()
      .from(integrationWebhookEndpoints)
      .where(
        and(
          eq(integrationWebhookEndpoints.organizationId, organizationId),
          eq(integrationWebhookEndpoints.isActive, true)
        )
      );
    
    return endpoints.filter(endpoint => {
      const eventTypes = endpoint.eventTypes as string[] | null;
      const entityTypes = endpoint.entityTypes as string[] | null;
      
      const matchesEvent = !eventTypes || eventTypes.includes(eventType) || eventTypes.includes(`${entityType}.*`);
      const matchesEntity = !entityTypes || entityTypes.includes(entityType);
      
      return matchesEvent && matchesEntity;
    });
  } catch (error) {
    console.error("Error fetching webhook endpoints:", error);
    return [];
  }
}

async function sendWebhook(
  endpoint: typeof integrationWebhookEndpoints.$inferSelect,
  event: WebhookEvent,
  attempt: number = 1
): Promise<boolean> {
  const payload: WebhookPayload = {
    id: crypto.randomUUID(),
    event: event.eventType,
    timestamp: event.timestamp,
    data: event.data,
    externalId: event.externalId,
  };
  
  const payloadStr = JSON.stringify(payload);
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Webhook-Event': event.eventType,
    'X-Webhook-Timestamp': event.timestamp,
    'X-Webhook-Delivery': payload.id,
  };
  
  if (endpoint.secret) {
    headers['X-Webhook-Signature'] = `sha256=${generateSignature(payloadStr, endpoint.secret)}`;
  }
  
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    
    const response = await fetch(endpoint.url, {
      method: 'POST',
      headers,
      body: payloadStr,
      signal: controller.signal,
    });
    
    clearTimeout(timeout);
    
    const statusCode = response.status;
    const success = statusCode >= 200 && statusCode < 300;
    
    let responseBody: unknown;
    try {
      responseBody = await response.json();
    } catch {
      responseBody = await response.text();
    }
    
    await logOutboundWebhook({
      organizationId: event.organizationId,
      eventType: event.eventType,
      endpointId: endpoint.id,
      requestPayload: payload,
      responsePayload: responseBody,
      statusCode,
      entityType: event.entityType,
      entityId: event.entityId,
      externalId: event.externalId,
      success,
      attempt,
    });
    
    if (success) {
      await db
        .update(integrationWebhookEndpoints)
        .set({ 
          successCount: sql`${integrationWebhookEndpoints.successCount} + 1`,
          lastSuccessAt: new Date(),
        })
        .where(eq(integrationWebhookEndpoints.id, endpoint.id));
    } else {
      await db
        .update(integrationWebhookEndpoints)
        .set({ 
          failureCount: sql`${integrationWebhookEndpoints.failureCount} + 1`,
          lastFailureAt: new Date(),
          lastError: `HTTP ${statusCode}`,
        })
        .where(eq(integrationWebhookEndpoints.id, endpoint.id));
    }
    
    return success;
    
  } catch (error: any) {
    const errorMessage = error.name === 'AbortError' ? 'Timeout' : error.message;
    
    await logOutboundWebhook({
      organizationId: event.organizationId,
      eventType: event.eventType,
      endpointId: endpoint.id,
      requestPayload: payload,
      statusCode: 0,
      entityType: event.entityType,
      entityId: event.entityId,
      externalId: event.externalId,
      success: false,
      errorMessage,
      attempt,
    });
    
    await db
      .update(integrationWebhookEndpoints)
      .set({ 
        failureCount: sql`${integrationWebhookEndpoints.failureCount} + 1`,
        lastFailureAt: new Date(),
        lastError: errorMessage,
      })
      .where(eq(integrationWebhookEndpoints.id, endpoint.id));
    
    return false;
  }
}

async function logOutboundWebhook(params: {
  organizationId: string;
  eventType: string;
  endpointId: string;
  requestPayload: unknown;
  responsePayload?: unknown;
  statusCode: number;
  entityType: EntityType;
  entityId: string;
  externalId?: string;
  success: boolean;
  errorMessage?: string;
  attempt: number;
}) {
  try {
    await db.insert(integrationWebhookLogs).values({
      organizationId: params.organizationId,
      direction: "outbound",
      eventType: params.eventType,
      externalSystem: "crm",
      requestPayload: params.requestPayload as Record<string, unknown>,
      responsePayload: params.responsePayload as Record<string, unknown>,
      statusCode: params.statusCode,
      entityType: params.entityType,
      entityId: params.entityId,
      externalId: params.externalId,
      processedAt: new Date(),
      errorMessage: params.errorMessage,
      retryCount: params.attempt - 1,
    });
  } catch (err) {
    console.error("Failed to log outbound webhook:", err);
  }
}

async function sendWithRetry(
  endpoint: typeof integrationWebhookEndpoints.$inferSelect,
  event: WebhookEvent
): Promise<void> {
  const retryPolicy = endpoint.retryPolicy as {
    maxRetries: number;
    initialDelayMs: number;
    maxDelayMs: number;
    backoffMultiplier: number;
  } | null;
  
  const maxRetries = retryPolicy?.maxRetries ?? 3;
  const initialDelay = retryPolicy?.initialDelayMs ?? 1000;
  const maxDelay = retryPolicy?.maxDelayMs ?? 30000;
  const multiplier = retryPolicy?.backoffMultiplier ?? 2;
  
  let delay = initialDelay;
  
  for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {
    const success = await sendWebhook(endpoint, event, attempt);
    
    if (success || attempt > maxRetries) {
      break;
    }
    
    await new Promise(resolve => setTimeout(resolve, delay));
    delay = Math.min(delay * multiplier, maxDelay);
  }
}

export async function publishWebhookEvent(
  organizationId: string,
  entityType: EntityType,
  entityId: string,
  action: EventAction,
  data: Record<string, unknown>
): Promise<void> {
  const eventType = `${entityType}.${action}`;
  const timestamp = new Date().toISOString();
  
  const externalId = await getExternalId(entityType, entityId);
  
  const endpoints = await getEndpointsForEvent(organizationId, eventType, entityType);
  
  if (endpoints.length === 0) {
    return;
  }
  
  const event: WebhookEvent = {
    eventType,
    entityType,
    entityId,
    organizationId,
    timestamp,
    data,
    externalId: externalId || undefined,
  };
  
  await Promise.all(
    endpoints.map(endpoint => sendWithRetry(endpoint, event))
  );
}

interface LeaseEventData {
  id: string;
  tenantId?: string;
  locationId?: string | null;
  storageLocationId?: string | null;
  leaseCommencement?: string | null;
  leaseExpiration?: string | null;
  leaseAmount?: string | null;
  rateType?: string | null;
  contractTerm?: string | null;
  storageType?: string;
  unitLocation?: string | null;
  unitNumber?: string | null;
  boatDimensions?: string | null;
  slipStatus?: string | null;
}

interface TenantEventData {
  id: string;
  name?: string;
  address1?: string | null;
  address2?: string | null;
  city?: string | null;
  state?: string | null;
  zip?: string | null;
  boatMake?: string | null;
  boatYear?: number | null;
  boatLength?: string | null;
  boatWidth?: string | null;
}

export async function publishLeaseEvent(
  action: EventAction,
  lease: LeaseEventData,
  organizationId: string,
  tenant?: TenantEventData
): Promise<void> {
  const data: Record<string, unknown> = {
    id: lease.id,
    tenantId: lease.tenantId,
    locationId: lease.locationId,
    storageLocationId: lease.storageLocationId,
    leaseCommencement: lease.leaseCommencement,
    leaseExpiration: lease.leaseExpiration,
    leaseAmount: lease.leaseAmount,
    rateType: lease.rateType,
    contractTerm: lease.contractTerm,
    storageType: lease.storageType,
    unitLocation: lease.unitLocation,
    unitNumber: lease.unitNumber,
    boatDimensions: lease.boatDimensions,
    slipStatus: lease.slipStatus,
  };
  
  if (tenant) {
    data.tenant = {
      id: tenant.id,
      name: tenant.name,
      address1: tenant.address1,
      address2: tenant.address2,
      city: tenant.city,
      state: tenant.state,
      zip: tenant.zip,
      boatMake: tenant.boatMake,
      boatYear: tenant.boatYear,
      boatLength: tenant.boatLength,
      boatWidth: tenant.boatWidth,
    };
  }
  
  await publishWebhookEvent(organizationId, "lease", lease.id, action, data);
}

export async function publishTenantEvent(
  action: EventAction,
  tenant: TenantEventData,
  organizationId: string
): Promise<void> {
  const data: Record<string, unknown> = {
    id: tenant.id,
    name: tenant.name,
    address1: tenant.address1,
    address2: tenant.address2,
    city: tenant.city,
    state: tenant.state,
    zip: tenant.zip,
    boatMake: tenant.boatMake,
    boatYear: tenant.boatYear,
    boatLength: tenant.boatLength,
    boatWidth: tenant.boatWidth,
  };
  
  await publishWebhookEvent(organizationId, "tenant", tenant.id, action, data);
}
