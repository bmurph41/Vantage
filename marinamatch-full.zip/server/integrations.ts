import { Express, Request, Response, NextFunction } from "express";
import { db } from "./db";
import { 
  integrationMappings, 
  integrationWebhookLogs, 
  integrationApiKeys,
  integrationWebhookEndpoints,
  marinaLocations,
  tenants,
  leases,
  organizations,
  type IntegrationMapping,
  type InsertIntegrationMapping,
} from "@shared/schema";
import { eq, and, desc, inArray, gte } from "drizzle-orm";
import { users } from "@shared/schema";
import crypto from "crypto";
import { storage } from "./storage";
import { z } from "zod";

// Validation schemas for webhook endpoints
const webhookEndpointCreateSchema = z.object({
  name: z.string().min(1).max(100),
  url: z.string().url(),
  secret: z.string().min(16).optional(),
  eventTypes: z.array(z.string()).optional(),
  entityTypes: z.array(z.enum(["lease", "tenant", "project", "contact"])).optional(),
  isActive: z.boolean().optional().default(true),
});

const webhookEndpointUpdateSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  url: z.string().url().optional(),
  secret: z.string().min(16).optional(),
  eventTypes: z.array(z.string()).optional().nullable(),
  entityTypes: z.array(z.enum(["lease", "tenant", "project", "contact"])).optional().nullable(),
  isActive: z.boolean().optional(),
});

// ============================================================================
// SERVICE-TO-SERVICE AUTHENTICATION MIDDLEWARE
// ============================================================================

interface IntegrationRequest extends Request {
  integration?: {
    organizationId: string;
    apiKeyId: string;
    permissions: string[];
  };
}

async function verifyApiKey(apiKey: string): Promise<{
  organizationId: string;
  apiKeyId: string;
  permissions: string[];
} | null> {
  if (!apiKey) return null;
  
  const keyPrefix = apiKey.substring(0, 8);
  
  const keys = await db
    .select()
    .from(integrationApiKeys)
    .where(
      and(
        eq(integrationApiKeys.keyPrefix, keyPrefix),
        eq(integrationApiKeys.isActive, true)
      )
    );
  
  for (const key of keys) {
    const hash = crypto.createHash('sha256').update(apiKey).digest('hex');
    if (hash === key.keyHash) {
      if (key.expiresAt && new Date(key.expiresAt) < new Date()) {
        return null;
      }
      
      await db
        .update(integrationApiKeys)
        .set({ lastUsedAt: new Date() })
        .where(eq(integrationApiKeys.id, key.id));
      
      return {
        organizationId: key.organizationId,
        apiKeyId: key.id,
        permissions: (key.permissions as string[]) || [],
      };
    }
  }
  
  return null;
}

export function integrationAuth(req: IntegrationRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: "Missing or invalid authorization header" });
  }
  
  const apiKey = authHeader.substring(7);
  
  verifyApiKey(apiKey)
    .then(result => {
      if (!result) {
        return res.status(401).json({ error: "Invalid API key" });
      }
      req.integration = result;
      next();
    })
    .catch(err => {
      console.error("API key verification error:", err);
      res.status(500).json({ error: "Authentication error" });
    });
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function generateSyncHash(data: Record<string, unknown>): string {
  return crypto.createHash('md5').update(JSON.stringify(data)).digest('hex');
}

async function logWebhook(params: {
  organizationId: string | null;
  direction: "inbound" | "outbound";
  eventType: string;
  externalSystem: string;
  requestPayload?: unknown;
  responsePayload?: unknown;
  statusCode?: number;
  entityType?: "project" | "tenant" | "lease" | "contact";
  entityId?: string;
  externalId?: string;
  errorMessage?: string;
  idempotencyKey?: string;
}) {
  try {
    await db.insert(integrationWebhookLogs).values({
      organizationId: params.organizationId,
      direction: params.direction,
      eventType: params.eventType,
      externalSystem: params.externalSystem,
      requestPayload: params.requestPayload as Record<string, unknown>,
      responsePayload: params.responsePayload as Record<string, unknown>,
      statusCode: params.statusCode,
      entityType: params.entityType,
      entityId: params.entityId,
      externalId: params.externalId,
      processedAt: new Date(),
      errorMessage: params.errorMessage,
      idempotencyKey: params.idempotencyKey,
    });
  } catch (err) {
    console.error("Failed to log webhook:", err);
  }
}

// ============================================================================
// INTEGRATION ROUTES
// ============================================================================

export function registerIntegrationRoutes(app: Express) {
  
  // ============================================================================
  // PROJECT SYNC ENDPOINTS (CRM Property -> MarinaMatch Project)
  // ============================================================================
  
  app.post("/api/integrations/projects", integrationAuth, async (req: IntegrationRequest, res) => {
    const { organizationId } = req.integration!;
    const idempotencyKey = req.headers['x-idempotency-key'] as string;
    
    try {
      const { 
        externalId, 
        name, 
        code,
        description,
        status,
        projectType,
        capacity,
        seasonType,
        metadata,
      } = req.body;
      
      if (!externalId || !name) {
        return res.status(400).json({ error: "externalId and name are required" });
      }
      
      const existingMapping = await db
        .select()
        .from(integrationMappings)
        .where(
          and(
            eq(integrationMappings.externalSystem, "crm"),
            eq(integrationMappings.entityType, "project"),
            eq(integrationMappings.externalId, externalId)
          )
        )
        .limit(1);
      
      let marinaMatchId: string;
      let isNew = false;
      
      if (existingMapping.length > 0) {
        marinaMatchId = existingMapping[0].marinaMatchId;
        
        await db
          .update(marinaLocations)
          .set({
            name,
            code: code || null,
            description: description || null,
            status: status || null,
            projectType: projectType || "DEAL",
            capacity: capacity || null,
            updatedAt: new Date(),
          })
          .where(eq(marinaLocations.id, marinaMatchId));
        
        const syncHash = generateSyncHash(req.body);
        await db
          .update(integrationMappings)
          .set({
            syncHash,
            syncStatus: "synced",
            lastSyncedAt: new Date(),
            lastExternalUpdate: new Date(),
            externalData: req.body,
            updatedAt: new Date(),
          })
          .where(eq(integrationMappings.id, existingMapping[0].id));
        
      } else {
        const [newProject] = await db
          .insert(marinaLocations)
          .values({
            organizationId,
            name,
            code: code || null,
            description: description || null,
            status: status || null,
            projectType: projectType || "DEAL",
            capacity: capacity || null,
          })
          .returning();
        
        marinaMatchId = newProject.id;
        isNew = true;
        
        const syncHash = generateSyncHash(req.body);
        await db.insert(integrationMappings).values({
          organizationId,
          entityType: "project",
          marinaMatchId,
          externalId,
          externalSystem: "crm",
          syncHash,
          syncStatus: "synced",
          lastSyncedAt: new Date(),
          lastExternalUpdate: new Date(),
          externalData: req.body,
        });
      }
      
      const response = {
        success: true,
        marinaMatchId,
        externalId,
        action: isNew ? "created" : "updated",
      };
      
      await logWebhook({
        organizationId,
        direction: "inbound",
        eventType: isNew ? "project.created" : "project.updated",
        externalSystem: "crm",
        requestPayload: req.body,
        responsePayload: response,
        statusCode: 200,
        entityType: "project",
        entityId: marinaMatchId,
        externalId,
        idempotencyKey,
      });
      
      res.json(response);
      
    } catch (error: any) {
      console.error("Error syncing project:", error);
      
      await logWebhook({
        organizationId,
        direction: "inbound",
        eventType: "project.sync_error",
        externalSystem: "crm",
        requestPayload: req.body,
        statusCode: 500,
        errorMessage: error.message,
        idempotencyKey,
      });
      
      res.status(500).json({ error: "Failed to sync project" });
    }
  });
  
  // ============================================================================
  // TENANT SYNC ENDPOINTS (CRM Company/Contact -> MarinaMatch Tenant)
  // ============================================================================
  
  app.post("/api/integrations/tenants", integrationAuth, async (req: IntegrationRequest, res) => {
    const { organizationId } = req.integration!;
    const idempotencyKey = req.headers['x-idempotency-key'] as string;
    
    try {
      const {
        externalId,
        name,
        address1,
        address2,
        city,
        state,
        zip,
        boatMake,
        boatYear,
        boatLength,
        boatWidth,
        metadata,
      } = req.body;
      
      if (!externalId || !name) {
        return res.status(400).json({ error: "externalId and name are required" });
      }
      
      const existingMapping = await db
        .select()
        .from(integrationMappings)
        .where(
          and(
            eq(integrationMappings.externalSystem, "crm"),
            eq(integrationMappings.entityType, "tenant"),
            eq(integrationMappings.externalId, externalId)
          )
        )
        .limit(1);
      
      let marinaMatchId: string;
      let isNew = false;
      
      if (existingMapping.length > 0) {
        marinaMatchId = existingMapping[0].marinaMatchId;
        
        await db
          .update(tenants)
          .set({
            name,
            address1: address1 || null,
            address2: address2 || null,
            city: city || null,
            state: state || null,
            zip: zip || null,
            boatMake: boatMake || null,
            boatYear: boatYear || null,
            boatLength: boatLength?.toString() || null,
            boatWidth: boatWidth?.toString() || null,
            updatedAt: new Date(),
          })
          .where(eq(tenants.id, marinaMatchId));
        
        const syncHash = generateSyncHash(req.body);
        await db
          .update(integrationMappings)
          .set({
            syncHash,
            syncStatus: "synced",
            lastSyncedAt: new Date(),
            lastExternalUpdate: new Date(),
            externalData: req.body,
            updatedAt: new Date(),
          })
          .where(eq(integrationMappings.id, existingMapping[0].id));
        
      } else {
        const [newTenant] = await db
          .insert(tenants)
          .values({
            name,
            address1: address1 || null,
            address2: address2 || null,
            city: city || null,
            state: state || null,
            zip: zip || null,
            boatMake: boatMake || null,
            boatYear: boatYear || null,
            boatLength: boatLength?.toString() || null,
            boatWidth: boatWidth?.toString() || null,
          })
          .returning();
        
        marinaMatchId = newTenant.id;
        isNew = true;
        
        const syncHash = generateSyncHash(req.body);
        await db.insert(integrationMappings).values({
          organizationId,
          entityType: "tenant",
          marinaMatchId,
          externalId,
          externalSystem: "crm",
          syncHash,
          syncStatus: "synced",
          lastSyncedAt: new Date(),
          lastExternalUpdate: new Date(),
          externalData: req.body,
        });
      }
      
      const response = {
        success: true,
        marinaMatchId,
        externalId,
        action: isNew ? "created" : "updated",
      };
      
      await logWebhook({
        organizationId,
        direction: "inbound",
        eventType: isNew ? "tenant.created" : "tenant.updated",
        externalSystem: "crm",
        requestPayload: req.body,
        responsePayload: response,
        statusCode: 200,
        entityType: "tenant",
        entityId: marinaMatchId,
        externalId,
        idempotencyKey,
      });
      
      res.json(response);
      
    } catch (error: any) {
      console.error("Error syncing tenant:", error);
      
      await logWebhook({
        organizationId,
        direction: "inbound",
        eventType: "tenant.sync_error",
        externalSystem: "crm",
        requestPayload: req.body,
        statusCode: 500,
        errorMessage: error.message,
        idempotencyKey,
      });
      
      res.status(500).json({ error: "Failed to sync tenant" });
    }
  });
  
  // ============================================================================
  // MAPPING LOOKUP ENDPOINTS
  // ============================================================================
  
  app.get("/api/integrations/mappings", integrationAuth, async (req: IntegrationRequest, res) => {
    const { organizationId } = req.integration!;
    
    try {
      const { entityType, syncStatus, externalId, marinaMatchId } = req.query;
      
      let query = db
        .select()
        .from(integrationMappings)
        .where(eq(integrationMappings.organizationId, organizationId));
      
      const mappings = await query;
      
      let filtered = mappings;
      if (entityType) {
        filtered = filtered.filter(m => m.entityType === entityType);
      }
      if (syncStatus) {
        filtered = filtered.filter(m => m.syncStatus === syncStatus);
      }
      if (externalId) {
        filtered = filtered.filter(m => m.externalId === externalId);
      }
      if (marinaMatchId) {
        filtered = filtered.filter(m => m.marinaMatchId === marinaMatchId);
      }
      
      res.json({ mappings: filtered });
      
    } catch (error: any) {
      console.error("Error fetching mappings:", error);
      res.status(500).json({ error: "Failed to fetch mappings" });
    }
  });
  
  app.get("/api/integrations/mappings/:externalId", integrationAuth, async (req: IntegrationRequest, res) => {
    const { organizationId } = req.integration!;
    const { externalId } = req.params;
    const { entityType } = req.query;
    
    try {
      const mapping = await db
        .select()
        .from(integrationMappings)
        .where(
          and(
            eq(integrationMappings.organizationId, organizationId),
            eq(integrationMappings.externalId, externalId),
            entityType ? eq(integrationMappings.entityType, entityType as any) : undefined
          )
        )
        .limit(1);
      
      if (mapping.length === 0) {
        return res.status(404).json({ error: "Mapping not found" });
      }
      
      res.json({ mapping: mapping[0] });
      
    } catch (error: any) {
      console.error("Error fetching mapping:", error);
      res.status(500).json({ error: "Failed to fetch mapping" });
    }
  });
  
  // ============================================================================
  // WEBHOOK LOG ENDPOINTS
  // ============================================================================
  
  app.get("/api/integrations/webhook-logs", integrationAuth, async (req: IntegrationRequest, res) => {
    const { organizationId } = req.integration!;
    
    try {
      const { direction, eventType, limit = "50" } = req.query;
      
      const logs = await db
        .select()
        .from(integrationWebhookLogs)
        .where(eq(integrationWebhookLogs.organizationId, organizationId))
        .orderBy(desc(integrationWebhookLogs.createdAt))
        .limit(parseInt(limit as string));
      
      let filtered = logs;
      if (direction) {
        filtered = filtered.filter(l => l.direction === direction);
      }
      if (eventType) {
        filtered = filtered.filter(l => l.eventType === eventType);
      }
      
      res.json({ logs: filtered });
      
    } catch (error: any) {
      console.error("Error fetching webhook logs:", error);
      res.status(500).json({ error: "Failed to fetch webhook logs" });
    }
  });
  
  // ============================================================================
  // SYNC STATUS ENDPOINTS
  // ============================================================================
  
  app.get("/api/integrations/status", integrationAuth, async (req: IntegrationRequest, res) => {
    const { organizationId } = req.integration!;
    
    try {
      const mappings = await db
        .select()
        .from(integrationMappings)
        .where(eq(integrationMappings.organizationId, organizationId));
      
      const statusCounts = {
        synced: 0,
        pending: 0,
        error: 0,
        conflict: 0,
      };
      
      const entityCounts = {
        project: 0,
        tenant: 0,
        lease: 0,
        contact: 0,
      };
      
      mappings.forEach(m => {
        statusCounts[m.syncStatus]++;
        entityCounts[m.entityType]++;
      });
      
      const recentLogs = await db
        .select()
        .from(integrationWebhookLogs)
        .where(eq(integrationWebhookLogs.organizationId, organizationId))
        .orderBy(desc(integrationWebhookLogs.createdAt))
        .limit(10);
      
      const errorLogs = recentLogs.filter(l => l.errorMessage);
      
      res.json({
        totalMappings: mappings.length,
        statusCounts,
        entityCounts,
        recentErrors: errorLogs.length,
        lastSyncAt: mappings.length > 0 
          ? mappings.reduce((latest, m) => {
              const syncDate = m.lastSyncedAt ? new Date(m.lastSyncedAt) : null;
              return syncDate && (!latest || syncDate > latest) ? syncDate : latest;
            }, null as Date | null)
          : null,
      });
      
    } catch (error: any) {
      console.error("Error fetching integration status:", error);
      res.status(500).json({ error: "Failed to fetch integration status" });
    }
  });
  
  // ============================================================================
  // API KEY MANAGEMENT (for authenticated users, not integration auth)
  // ============================================================================
  
  // Helper to get user's organization ID
  async function getUserOrganizationId(userId: string): Promise<string | null> {
    const userOrgs = await storage.getUserOrganizations(userId);
    if (userOrgs.length === 0) return null;
    return userOrgs[0].organizationId || userOrgs[0].id;
  }
  
  app.post("/api/integrations/api-keys", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      
      const { name, externalSystem, scopes, expiresInDays } = req.body;
      
      if (!name) {
        return res.status(400).json({ error: "name is required" });
      }
      
      const rawKey = `mm_${crypto.randomBytes(32).toString('hex')}`;
      const keyPrefix = rawKey.substring(0, 8);
      const keyHash = crypto.createHash('sha256').update(rawKey).digest('hex');
      
      const expiresAt = expiresInDays 
        ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
        : null;
      
      const [apiKey] = await db
        .insert(integrationApiKeys)
        .values({
          organizationId,
          name,
          keyHash,
          keyPrefix,
          externalSystem: externalSystem || "crm",
          scopes: scopes || ["projects.read", "projects.write", "tenants.read", "tenants.write"],
          isActive: true,
          expiresAt,
          createdBy: userId,
        })
        .returning();
      
      res.json({
        id: apiKey.id,
        name: apiKey.name,
        keyPrefix: apiKey.keyPrefix,
        apiKey: rawKey,
        expiresAt: apiKey.expiresAt,
        message: "Save this API key now - it won't be shown again!",
      });
      
    } catch (error: any) {
      console.error("Error creating API key:", error);
      res.status(500).json({ error: "Failed to create API key" });
    }
  });
  
  app.get("/api/integrations/api-keys", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.json([]);
      }
      
      const keys = await db
        .select({
          id: integrationApiKeys.id,
          name: integrationApiKeys.name,
          keyPrefix: integrationApiKeys.keyPrefix,
          externalSystem: integrationApiKeys.externalSystem,
          scopes: integrationApiKeys.scopes,
          isActive: integrationApiKeys.isActive,
          lastUsedAt: integrationApiKeys.lastUsedAt,
          expiresAt: integrationApiKeys.expiresAt,
          createdAt: integrationApiKeys.createdAt,
        })
        .from(integrationApiKeys)
        .where(eq(integrationApiKeys.organizationId, organizationId))
        .orderBy(desc(integrationApiKeys.createdAt));
      
      res.json(keys);
      
    } catch (error: any) {
      console.error("Error fetching API keys:", error);
      res.status(500).json({ error: "Failed to fetch API keys" });
    }
  });
  
  app.delete("/api/integrations/api-keys/:id", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      
      const { id } = req.params;
      
      // Only allow deactivating keys within user's organization
      await db
        .update(integrationApiKeys)
        .set({ isActive: false, updatedAt: new Date() })
        .where(
          and(
            eq(integrationApiKeys.id, id),
            eq(integrationApiKeys.organizationId, organizationId)
          )
        );
      
      res.json({ success: true });
      
    } catch (error: any) {
      console.error("Error deactivating API key:", error);
      res.status(500).json({ error: "Failed to deactivate API key" });
    }
  });
  
  // ============================================================================
  // USER-AUTHENTICATED DASHBOARD ENDPOINTS
  // ============================================================================
  
  // Get integration stats for the dashboard
  app.get("/api/integrations/stats", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.json({
          totalMappings: 0,
          syncedCount: 0,
          pendingCount: 0,
          errorCount: 0,
          webhooksLast24h: 0,
          inboundCount: 0,
          outboundCount: 0,
          errorWebhooks: 0,
        });
      }
      
      // Get mappings scoped to user's organization
      const allMappings = await db
        .select()
        .from(integrationMappings)
        .where(eq(integrationMappings.organizationId, organizationId));
      
      // Count by status
      let syncedCount = 0;
      let pendingCount = 0;
      let errorCount = 0;
      
      allMappings.forEach(m => {
        if (m.syncStatus === 'synced') syncedCount++;
        else if (m.syncStatus === 'pending') pendingCount++;
        else if (m.syncStatus === 'error') errorCount++;
      });
      
      // Get webhook stats for last 24 hours scoped to organization
      const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const recentLogs = await db
        .select()
        .from(integrationWebhookLogs)
        .where(
          and(
            eq(integrationWebhookLogs.organizationId, organizationId),
            gte(integrationWebhookLogs.createdAt, twentyFourHoursAgo)
          )
        );
      
      let inboundCount = 0;
      let outboundCount = 0;
      let errorWebhooks = 0;
      
      recentLogs.forEach(l => {
        if (l.direction === 'inbound') inboundCount++;
        else outboundCount++;
        if (l.errorMessage) errorWebhooks++;
      });
      
      res.json({
        totalMappings: allMappings.length,
        syncedCount,
        pendingCount,
        errorCount,
        webhooksLast24h: recentLogs.length,
        inboundCount,
        outboundCount,
        errorWebhooks,
      });
      
    } catch (error: any) {
      console.error("Error fetching integration stats:", error);
      res.status(500).json({ error: "Failed to fetch integration stats" });
    }
  });
  
  // Get mappings for dashboard (user authenticated)
  app.get("/api/integrations/mappings-dashboard", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.json([]);
      }
      
      const mappings = await db
        .select()
        .from(integrationMappings)
        .where(eq(integrationMappings.organizationId, organizationId))
        .orderBy(desc(integrationMappings.createdAt))
        .limit(100);
      
      res.json(mappings);
      
    } catch (error: any) {
      console.error("Error fetching mappings:", error);
      res.status(500).json({ error: "Failed to fetch mappings" });
    }
  });
  
  // Get webhook logs for dashboard (user authenticated)
  app.get("/api/integrations/webhooks/logs", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.json([]);
      }
      
      const logs = await db
        .select()
        .from(integrationWebhookLogs)
        .where(eq(integrationWebhookLogs.organizationId, organizationId))
        .orderBy(desc(integrationWebhookLogs.createdAt))
        .limit(100);
      
      res.json(logs);
      
    } catch (error: any) {
      console.error("Error fetching webhook logs:", error);
      res.status(500).json({ error: "Failed to fetch webhook logs" });
    }
  });

  // ============================================================================
  // WEBHOOK ENDPOINTS MANAGEMENT (for outbound webhooks)
  // ============================================================================
  
  // List webhook endpoints (user authenticated)
  app.get("/api/integrations/webhooks/endpoints", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.json([]);
      }
      
      const endpoints = await db
        .select({
          id: integrationWebhookEndpoints.id,
          name: integrationWebhookEndpoints.name,
          url: integrationWebhookEndpoints.url,
          eventTypes: integrationWebhookEndpoints.eventTypes,
          entityTypes: integrationWebhookEndpoints.entityTypes,
          isActive: integrationWebhookEndpoints.isActive,
          successCount: integrationWebhookEndpoints.successCount,
          failureCount: integrationWebhookEndpoints.failureCount,
          lastSuccessAt: integrationWebhookEndpoints.lastSuccessAt,
          lastFailureAt: integrationWebhookEndpoints.lastFailureAt,
          lastError: integrationWebhookEndpoints.lastError,
          createdAt: integrationWebhookEndpoints.createdAt,
        })
        .from(integrationWebhookEndpoints)
        .where(eq(integrationWebhookEndpoints.organizationId, organizationId))
        .orderBy(desc(integrationWebhookEndpoints.createdAt));
      
      res.json(endpoints);
      
    } catch (error: any) {
      console.error("Error fetching webhook endpoints:", error);
      res.status(500).json({ error: "Failed to fetch webhook endpoints" });
    }
  });
  
  // Create webhook endpoint (user authenticated)
  app.post("/api/integrations/webhooks/endpoints", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      
      if (!organizationId) {
        return res.status(403).json({ error: "No organization found" });
      }
      
      // Validate request body
      const validatedData = webhookEndpointCreateSchema.safeParse(req.body);
      if (!validatedData.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validatedData.error.errors 
        });
      }
      
      const { name, url, secret, eventTypes, entityTypes, isActive } = validatedData.data;
      
      const [endpoint] = await db
        .insert(integrationWebhookEndpoints)
        .values({
          organizationId,
          name,
          url,
          secret: secret || null,
          eventTypes: eventTypes || null,
          entityTypes: entityTypes || null,
          isActive: isActive,
        })
        .returning();
      
      res.status(201).json({
        id: endpoint.id,
        name: endpoint.name,
        url: endpoint.url,
        eventTypes: endpoint.eventTypes,
        entityTypes: endpoint.entityTypes,
        isActive: endpoint.isActive,
        createdAt: endpoint.createdAt,
      });
      
    } catch (error: any) {
      console.error("Error creating webhook endpoint:", error);
      res.status(500).json({ error: "Failed to create webhook endpoint" });
    }
  });
  
  // Update webhook endpoint (user authenticated)
  app.put("/api/integrations/webhooks/endpoints/:id", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      const { id } = req.params;
      
      if (!organizationId) {
        return res.status(403).json({ error: "No organization found" });
      }
      
      // Validate request body using schema (only allows specific fields)
      const validatedData = webhookEndpointUpdateSchema.safeParse(req.body);
      if (!validatedData.success) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: validatedData.error.errors 
        });
      }
      
      // Verify ownership
      const existing = await db
        .select()
        .from(integrationWebhookEndpoints)
        .where(
          and(
            eq(integrationWebhookEndpoints.id, id),
            eq(integrationWebhookEndpoints.organizationId, organizationId)
          )
        )
        .limit(1);
      
      if (existing.length === 0) {
        return res.status(404).json({ error: "Webhook endpoint not found" });
      }
      
      const { name, url, secret, eventTypes, entityTypes, isActive } = validatedData.data;
      
      const updates: Record<string, unknown> = { updatedAt: new Date() };
      if (name !== undefined) updates.name = name;
      if (url !== undefined) updates.url = url;
      if (secret !== undefined) updates.secret = secret;
      if (eventTypes !== undefined) updates.eventTypes = eventTypes;
      if (entityTypes !== undefined) updates.entityTypes = entityTypes;
      if (isActive !== undefined) updates.isActive = isActive;
      
      const [updated] = await db
        .update(integrationWebhookEndpoints)
        .set(updates)
        .where(eq(integrationWebhookEndpoints.id, id))
        .returning();
      
      res.json({
        id: updated.id,
        name: updated.name,
        url: updated.url,
        eventTypes: updated.eventTypes,
        entityTypes: updated.entityTypes,
        isActive: updated.isActive,
        updatedAt: updated.updatedAt,
      });
      
    } catch (error: any) {
      console.error("Error updating webhook endpoint:", error);
      res.status(500).json({ error: "Failed to update webhook endpoint" });
    }
  });
  
  // Delete webhook endpoint (user authenticated)
  app.delete("/api/integrations/webhooks/endpoints/:id", async (req: any, res) => {
    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    
    try {
      const userId = req.user.claims.sub;
      const organizationId = await getUserOrganizationId(userId);
      const { id } = req.params;
      
      if (!organizationId) {
        return res.status(403).json({ error: "No organization found" });
      }
      
      // Verify ownership before deletion
      const existing = await db
        .select()
        .from(integrationWebhookEndpoints)
        .where(
          and(
            eq(integrationWebhookEndpoints.id, id),
            eq(integrationWebhookEndpoints.organizationId, organizationId)
          )
        )
        .limit(1);
      
      if (existing.length === 0) {
        return res.status(404).json({ error: "Webhook endpoint not found" });
      }
      
      await db
        .delete(integrationWebhookEndpoints)
        .where(eq(integrationWebhookEndpoints.id, id));
      
      res.status(204).send();
      
    } catch (error: any) {
      console.error("Error deleting webhook endpoint:", error);
      res.status(500).json({ error: "Failed to delete webhook endpoint" });
    }
  });

  console.log("Integration routes registered");
}
