import { Request, Response, NextFunction } from "express";
import { db } from "./db";
import { marinaLocations, leases, storageLocations, organizationUsers, auditLogs, snapshotVersions, orgFeatureFlags, hasPermission, type Permission, type OrganizationRole, type InsertAuditLog } from "@shared/schema";
import { eq, inArray, and } from "drizzle-orm";
import type { IStorage } from "./storage";

export interface AuthorizedRequest extends Request {
  user: {
    claims: {
      sub: string;
      email?: string;
    };
  };
  userOrganizationIds?: string[];
}

/**
 * Middleware to load user's organization IDs and attach to request
 * Must be called after isAuthenticated middleware
 */
export function loadUserOrganizations(storage: IStorage) {
  return async (req: AuthorizedRequest, res: Response, next: NextFunction) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      req.userOrganizationIds = userOrgs.map(org => org.id);
      next();
    } catch (error) {
      console.error("Error loading user organizations:", error);
      res.status(500).json({ error: "Failed to load user organizations" });
    }
  };
}

/**
 * Middleware to verify user has access to a specific location
 * Checks if location's organizationId is in user's organizations
 */
export function requireLocationAccess(storage: IStorage) {
  return async (req: AuthorizedRequest, res: Response, next: NextFunction) => {
    try {
      const locationId = req.params.id || req.params.locationId || req.body.locationId;
      
      if (!locationId) {
        return res.status(400).json({ error: "Location ID is required" });
      }

      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);

      if (organizationIds.length === 0) {
        return res.status(403).json({ 
          error: "Access denied: You are not a member of any organization" 
        });
      }

      const location = await db
        .select({ organizationId: marinaLocations.organizationId })
        .from(marinaLocations)
        .where(eq(marinaLocations.id, locationId))
        .limit(1);

      if (location.length === 0) {
        return res.status(404).json({ error: "Location not found" });
      }

      if (!organizationIds.includes(location[0].organizationId)) {
        return res.status(403).json({ 
          error: "Access denied: This location belongs to a different organization" 
        });
      }

      next();
    } catch (error) {
      console.error("Error verifying location access:", error);
      res.status(500).json({ error: "Failed to verify location access" });
    }
  };
}

/**
 * Middleware to verify user has access to a specific lease
 * Checks if lease's location's organizationId is in user's organizations
 */
export function requireLeaseAccess(storage: IStorage) {
  return async (req: AuthorizedRequest, res: Response, next: NextFunction) => {
    try {
      const leaseId = req.params.id || req.params.leaseId || req.body.leaseId;
      
      if (!leaseId) {
        return res.status(400).json({ error: "Lease ID is required" });
      }

      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);

      if (organizationIds.length === 0) {
        return res.status(403).json({ 
          error: "Access denied: You are not a member of any organization" 
        });
      }

      // Get lease's location and verify organization membership
      const leaseData = await db
        .select({ 
          locationId: leases.locationId,
          organizationId: marinaLocations.organizationId 
        })
        .from(leases)
        .innerJoin(marinaLocations, eq(leases.locationId, marinaLocations.id))
        .where(eq(leases.id, leaseId))
        .limit(1);

      if (leaseData.length === 0) {
        return res.status(404).json({ error: "Lease not found" });
      }

      if (!organizationIds.includes(leaseData[0].organizationId)) {
        return res.status(403).json({ 
          error: "Access denied: This lease belongs to a different organization" 
        });
      }

      next();
    } catch (error) {
      console.error("Error verifying lease access:", error);
      res.status(500).json({ error: "Failed to verify lease access" });
    }
  };
}

/**
 * Middleware to verify user has access to a specific storage location
 * Checks if storage location's projectId is in user's accessible locations
 */
export function requireStorageLocationAccess(storage: IStorage) {
  return async (req: AuthorizedRequest, res: Response, next: NextFunction) => {
    try {
      const storageLocationId = req.params.id || req.body.id;
      
      if (!storageLocationId) {
        return res.status(400).json({ error: "Storage location ID is required" });
      }

      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);

      if (organizationIds.length === 0) {
        return res.status(403).json({ 
          error: "Access denied: You are not a member of any organization" 
        });
      }

      // Get storage location's project and verify organization membership
      const storageLocationData = await db
        .select({ 
          projectId: storageLocations.projectId,
          organizationId: marinaLocations.organizationId 
        })
        .from(storageLocations)
        .innerJoin(marinaLocations, eq(storageLocations.projectId, marinaLocations.id))
        .where(eq(storageLocations.id, storageLocationId))
        .limit(1);

      if (storageLocationData.length === 0) {
        return res.status(404).json({ error: "Storage location not found" });
      }

      if (!organizationIds.includes(storageLocationData[0].organizationId)) {
        return res.status(403).json({ 
          error: "Access denied: This storage location belongs to a different organization" 
        });
      }

      next();
    } catch (error) {
      console.error("Error verifying storage location access:", error);
      res.status(500).json({ error: "Failed to verify storage location access" });
    }
  };
}

/**
 * Validate that a locationId in the request body belongs to user's organizations
 * Used when creating new resources that reference a location
 */
export async function validateLocationOwnership(
  locationId: string,
  organizationIds: string[]
): Promise<{ valid: boolean; error?: string }> {
  try {
    if (!locationId) {
      return { valid: false, error: "Location ID is required" };
    }

    if (organizationIds.length === 0) {
      return { valid: false, error: "You are not a member of any organization" };
    }

    const location = await db
      .select({ organizationId: marinaLocations.organizationId })
      .from(marinaLocations)
      .where(eq(marinaLocations.id, locationId))
      .limit(1);

    if (location.length === 0) {
      return { valid: false, error: "Location not found" };
    }

    if (!organizationIds.includes(location[0].organizationId)) {
      return { 
        valid: false, 
        error: "Access denied: This location belongs to a different organization" 
      };
    }

    return { valid: true };
  } catch (error) {
    console.error("Error validating location ownership:", error);
    return { valid: false, error: "Failed to validate location ownership" };
  }
}

// Extended request with role information
export interface AuthorizedRequestWithRole extends AuthorizedRequest {
  userRole?: OrganizationRole;
  userOrganizationId?: string;
}

/**
 * Middleware to require a specific permission
 * Checks user's role in the organization and verifies they have the required permission
 */
export function requirePermission(permission: Permission, storage: IStorage) {
  return async (req: AuthorizedRequestWithRole, res: Response, next: NextFunction) => {
    try {
      const userId = req.user.claims.sub;
      
      // Get user's organization memberships with roles
      const userOrgMemberships = await db
        .select({
          organizationId: organizationUsers.organizationId,
          role: organizationUsers.role,
        })
        .from(organizationUsers)
        .where(eq(organizationUsers.userId, userId));

      if (userOrgMemberships.length === 0) {
        return res.status(403).json({
          error: "Access denied: You are not a member of any organization"
        });
      }

      // Check if any of the user's roles have the required permission
      const hasRequiredPermission = userOrgMemberships.some(membership => 
        hasPermission(membership.role, permission)
      );

      if (!hasRequiredPermission) {
        return res.status(403).json({
          error: `Access denied: You do not have the '${permission}' permission`
        });
      }

      // Attach the highest role to the request for downstream use
      const roleHierarchy: OrganizationRole[] = ['owner', 'admin', 'analyst', 'viewer'];
      const highestRole = userOrgMemberships.reduce((highest, current) => {
        const currentIdx = roleHierarchy.indexOf(current.role);
        const highestIdx = roleHierarchy.indexOf(highest);
        return currentIdx < highestIdx ? current.role : highest;
      }, 'viewer' as OrganizationRole);

      req.userRole = highestRole;
      req.userOrganizationIds = userOrgMemberships.map(m => m.organizationId);

      next();
    } catch (error) {
      console.error("Error checking permission:", error);
      res.status(500).json({ error: "Failed to verify permissions" });
    }
  };
}

/**
 * Verify user has access to a V2 economics resource via its parent lease
 * Used for PUT/DELETE operations on lease-terms, rent-steps, escalations, concessions, billing-rules
 */
export async function verifyV2ResourceAccess(
  table: any,
  resourceId: string,
  userId: string,
  storage: IStorage
): Promise<{ valid: boolean; error?: string; status?: number }> {
  try {
    // Get the leaseId from the resource
    const [resource] = await db
      .select({ leaseId: table.leaseId })
      .from(table)
      .where(eq(table.id, resourceId))
      .limit(1);

    if (!resource) {
      return { valid: false, error: "Resource not found", status: 404 };
    }

    // Get user's organizations
    const userOrgs = await storage.getUserOrganizations(userId);
    const organizationIds = userOrgs.map(org => org.id);

    if (organizationIds.length === 0) {
      return { 
        valid: false, 
        error: "Access denied: You are not a member of any organization",
        status: 403
      };
    }

    // Verify the lease belongs to user's organization
    const leaseData = await db
      .select({ 
        organizationId: marinaLocations.organizationId 
      })
      .from(leases)
      .innerJoin(marinaLocations, eq(leases.locationId, marinaLocations.id))
      .where(eq(leases.id, resource.leaseId))
      .limit(1);

    if (leaseData.length === 0) {
      return { valid: false, error: "Parent lease not found", status: 404 };
    }

    if (!organizationIds.includes(leaseData[0].organizationId)) {
      return { 
        valid: false, 
        error: "Access denied: This resource belongs to a different organization",
        status: 403
      };
    }

    return { valid: true };
  } catch (error) {
    console.error("Error verifying V2 resource access:", error);
    return { valid: false, error: "Failed to verify resource access", status: 500 };
  }
}

/**
 * Verify user has access to a snapshot via its parent project/organization
 * Used for snapshot operations
 */
export async function verifySnapshotAccess(
  snapshotId: string,
  userId: string,
  storage: IStorage
): Promise<{ valid: boolean; error?: string; status?: number; snapshot?: any }> {
  try {
    // Get the snapshot with its projectId
    const [snapshot] = await db
      .select({
        id: snapshotVersions.id,
        projectId: snapshotVersions.projectId,
        status: snapshotVersions.status,
      })
      .from(snapshotVersions)
      .where(eq(snapshotVersions.id, snapshotId))
      .limit(1);

    if (!snapshot) {
      return { valid: false, error: "Snapshot not found", status: 404 };
    }

    // Get user's organizations
    const userOrgs = await storage.getUserOrganizations(userId);
    const organizationIds = userOrgs.map(org => org.id);

    if (organizationIds.length === 0) {
      return { 
        valid: false, 
        error: "Access denied: You are not a member of any organization",
        status: 403
      };
    }

    // Verify the project belongs to user's organization
    const [projectData] = await db
      .select({ 
        organizationId: marinaLocations.organizationId 
      })
      .from(marinaLocations)
      .where(eq(marinaLocations.id, snapshot.projectId))
      .limit(1);

    if (!projectData) {
      return { valid: false, error: "Project not found", status: 404 };
    }

    if (!organizationIds.includes(projectData.organizationId)) {
      return { 
        valid: false, 
        error: "Access denied: This snapshot belongs to a different organization",
        status: 403
      };
    }

    // Check if RENTROLL_SNAPSHOTS feature flag is enabled
    const [flag] = await db
      .select()
      .from(orgFeatureFlags)
      .where(and(
        eq(orgFeatureFlags.organizationId, projectData.organizationId),
        eq(orgFeatureFlags.key, 'RENTROLL_SNAPSHOTS')
      ))
      .limit(1);
    
    if (!flag?.enabled) {
      return { 
        valid: false, 
        error: "Snapshot versioning feature is not enabled for your organization",
        status: 403
      };
    }

    return { valid: true, snapshot };
  } catch (error) {
    console.error("Error verifying snapshot access:", error);
    return { valid: false, error: "Failed to verify snapshot access", status: 500 };
  }
}

/**
 * Log an audit event to the database
 */
export async function logAuditEvent(params: {
  organizationId?: string;
  userId?: string;
  action: InsertAuditLog["action"];
  entityType: InsertAuditLog["entityType"];
  entityId?: string;
  entityName?: string;
  previousValue?: any;
  newValue?: any;
  metadata?: any;
}): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      organizationId: params.organizationId,
      userId: params.userId,
      action: params.action,
      entityType: params.entityType,
      entityId: params.entityId,
      entityName: params.entityName,
      previousValue: params.previousValue,
      newValue: params.newValue,
      metadata: params.metadata,
    });
  } catch (error) {
    // Log but don't throw - audit logging should not block operations
    console.error("Failed to log audit event:", error, params);
  }
}

/**
 * Create audit logging middleware that logs requests after they complete
 */
export function auditMiddleware(entityType: InsertAuditLog["entityType"], action: InsertAuditLog["action"]) {
  return async (req: AuthorizedRequestWithRole, res: Response, next: NextFunction) => {
    // Store original json method to intercept response
    const originalJson = res.json.bind(res);
    
    res.json = function(body: any) {
      // Only log successful mutations (2xx status codes)
      if (res.statusCode >= 200 && res.statusCode < 300) {
        const userId = req.user?.claims?.sub;
        const organizationId = req.userOrganizationIds?.[0];
        const entityId = req.params.id || body?.id;
        
        logAuditEvent({
          organizationId,
          userId,
          action,
          entityType,
          entityId,
          entityName: body?.name || body?.customerName,
          newValue: action !== 'DELETE' ? body : undefined,
          metadata: {
            method: req.method,
            path: req.path,
            ip: req.ip,
            userAgent: req.get('user-agent'),
          }
        });
      }
      
      return originalJson(body);
    };
    
    next();
  };
}
