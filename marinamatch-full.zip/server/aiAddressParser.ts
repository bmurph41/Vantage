import OpenAI from "openai";

// This is using Replit's AI Integrations service, which provides OpenAI-compatible API access
// without requiring your own OpenAI API key.
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

export interface ParsedAddress {
  address1: string | null;
  address2: string | null;
  city: string | null;
  state: string | null;
  zip: string | null;
}

/**
 * Uses OpenAI to parse a full address string into its components
 * @param fullAddress The complete address in a single string
 * @returns Parsed address components
 */
export async function parseAddressWithAI(fullAddress: any): Promise<ParsedAddress> {
  // Safely convert to string - handle numbers, null, undefined, etc.
  const addressStr = fullAddress != null ? String(fullAddress).trim() : "";
  
  if (!addressStr) {
    return {
      address1: null,
      address2: null,
      city: null,
      state: null,
      zip: null,
    };
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are an address parsing assistant. Parse the given address into its components:
- address1: Street number and street name (primary address line)
- address2: Apartment, suite, unit number, or any secondary address information (can be empty)
- city: City name
- state: State code (e.g., "CA", "NY") or full state name
- zip: ZIP or postal code

Return ONLY a valid JSON object with these exact fields. If a field is not present, use null.
Example: {"address1": "123 Main St", "address2": "Apt 4B", "city": "New York", "state": "NY", "zip": "10001"}`,
        },
        {
          role: "user",
          content: `Parse this address: ${addressStr}`,
        },
      ],
      temperature: 0.1, // Low temperature for consistent parsing
      response_format: { type: "json_object" },
    });

    const content = completion.choices[0]?.message?.content;
    if (!content) {
      console.warn("No response from OpenAI for address parsing");
      return fallbackAddressParse(addressStr);
    }

    const parsed = JSON.parse(content) as ParsedAddress;
    
    // Ensure all expected fields exist
    return {
      address1: parsed.address1 || null,
      address2: parsed.address2 || null,
      city: parsed.city || null,
      state: parsed.state || null,
      zip: parsed.zip || null,
    };
  } catch (error) {
    console.error("Error parsing address with AI:", error);
    // Fallback to simple splitting if AI fails
    return fallbackAddressParse(addressStr);
  }
}

/**
 * Fallback address parser using simple string splitting
 * Used when AI is unavailable or fails
 */
function fallbackAddressParse(fullAddress: any): ParsedAddress {
  // Safely convert to string - handle numbers, null, undefined, etc.
  const addressStr = fullAddress != null ? String(fullAddress).trim() : "";
  
  // Simple fallback: just put everything in address1
  // Better than failing completely
  return {
    address1: addressStr || null,
    address2: null,
    city: null,
    state: null,
    zip: null,
  };
}

/**
 * Batch parse multiple addresses efficiently
 * Processes addresses in parallel with rate limiting
 */
export async function parseAddressesBatch(
  fullAddresses: any[]
): Promise<ParsedAddress[]> {
  const BATCH_SIZE = 10; // Process 10 at a time to avoid rate limits
  const results: ParsedAddress[] = [];

  for (let i = 0; i < fullAddresses.length; i += BATCH_SIZE) {
    const batch = fullAddresses.slice(i, i + BATCH_SIZE);
    const batchResults = await Promise.all(
      batch.map((addr) => parseAddressWithAI(addr))
    );
    results.push(...batchResults);
  }

  return results;
}

export interface ValueMappingSuggestion {
  originalValue: string;
  suggestedValue: string | null;
  confidence: "high" | "medium" | "low";
}

export interface FieldMappingSuggestions {
  fieldId: string;
  fieldLabel: string;
  suggestions: ValueMappingSuggestion[];
}

/**
 * Uses AI to suggest mappings for unrecognized values to valid options
 * @param unrecognizedValues Object containing field info and values to map
 * @returns Suggested mappings for each field's unrecognized values
 */
export async function suggestValueMappings(
  unrecognizedValues: Record<string, {
    fieldLabel: string;
    values: string[];
    validOptions: string[];
  }>
): Promise<FieldMappingSuggestions[]> {
  const results: FieldMappingSuggestions[] = [];

  for (const [fieldId, fieldInfo] of Object.entries(unrecognizedValues)) {
    const suggestions: ValueMappingSuggestion[] = [];

    // Process each unrecognized value
    for (const value of fieldInfo.values) {
      try {
        const suggestion = await suggestSingleValueMapping(
          value,
          fieldInfo.validOptions,
          fieldInfo.fieldLabel
        );
        suggestions.push(suggestion);
      } catch (error) {
        console.error(`Error getting AI suggestion for ${value}:`, error);
        // Fallback: no suggestion
        suggestions.push({
          originalValue: value,
          suggestedValue: null,
          confidence: "low",
        });
      }
    }

    results.push({
      fieldId,
      fieldLabel: fieldInfo.fieldLabel,
      suggestions,
    });
  }

  return results;
}

/**
 * Get AI suggestion for a single value mapping
 */
async function suggestSingleValueMapping(
  originalValue: string,
  validOptions: string[],
  fieldLabel: string
): Promise<ValueMappingSuggestion> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a data mapping assistant for marina management software. Your task is to match unrecognized values to the closest valid option from a predefined list.

For the field "${fieldLabel}", you must map values to one of these valid options:
${validOptions.map(opt => `- "${opt}"`).join('\n')}

Rules:
1. Find the semantically closest match from the valid options
2. Consider common abbreviations, synonyms, and alternate terms
3. If no reasonable match exists, return null
4. Be conservative - only suggest high confidence matches

Return a JSON object with:
- "suggestedValue": the best matching valid option (exact string from the list), or null if no good match
- "confidence": "high" (clear match), "medium" (reasonable match), or "low" (uncertain)

Examples for Storage Type:
- "Dock" → "Wet Slip" (high) - docks typically refer to wet slips
- "Covered Slip" → "Lift Slip" (medium) - covered slips often have lifts
- "Outside Storage" → "Land Storage" (high) - clear outdoor storage match
- "XYZ123" → null (low) - no semantic meaning`,
        },
        {
          role: "user",
          content: `Map this value to the best valid option: "${originalValue}"`,
        },
      ],
      temperature: 0.1,
      response_format: { type: "json_object" },
    });

    const content = completion.choices[0]?.message?.content;
    if (!content) {
      return {
        originalValue,
        suggestedValue: null,
        confidence: "low",
      };
    }

    const parsed = JSON.parse(content) as {
      suggestedValue: string | null;
      confidence: "high" | "medium" | "low";
    };

    // Validate that the suggested value is actually in the valid options
    if (parsed.suggestedValue && !validOptions.includes(parsed.suggestedValue)) {
      // AI returned an invalid option, try to find closest match
      const closestMatch = findClosestMatch(parsed.suggestedValue, validOptions);
      return {
        originalValue,
        suggestedValue: closestMatch,
        confidence: closestMatch ? "medium" : "low",
      };
    }

    return {
      originalValue,
      suggestedValue: parsed.suggestedValue,
      confidence: parsed.confidence || "medium",
    };
  } catch (error) {
    console.error("Error in AI value mapping suggestion:", error);
    return {
      originalValue,
      suggestedValue: null,
      confidence: "low",
    };
  }
}

/**
 * Find the closest matching string from a list of options
 * Simple implementation using string similarity
 */
function findClosestMatch(target: string, options: string[]): string | null {
  const targetLower = target.toLowerCase();
  
  // First try exact match (case-insensitive)
  const exactMatch = options.find(opt => opt.toLowerCase() === targetLower);
  if (exactMatch) return exactMatch;
  
  // Try contains match
  const containsMatch = options.find(opt => 
    opt.toLowerCase().includes(targetLower) || 
    targetLower.includes(opt.toLowerCase())
  );
  if (containsMatch) return containsMatch;
  
  return null;
}

/**
 * Interface for PDF extraction results
 */
export interface PdfExtractionResult {
  success: boolean;
  headers: string[];
  rows: Record<string, string>[];
  confidence: "high" | "medium" | "low";
  warnings: string[];
  pageCount: number;
}

/**
 * Detect column headers from PDF text using heuristics
 * Looks for lines with multiple whitespace-separated values that appear to be headers
 */
function detectHeadersFromText(pdfText: string): { detectedHeaders: string[], headerLine: string } {
  const lines = pdfText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
  
  // Common header keywords to look for
  const headerKeywords = [
    'type', 'date', 'num', 'name', 'memo', 'clr', 'split', 'debit', 'credit', 'balance',
    'tenant', 'slip', 'unit', 'rent', 'amount', 'start', 'end', 'boat', 'address',
    'city', 'state', 'zip', 'phone', 'email', 'description', 'account', 'invoice'
  ];
  
  // Find potential header lines - lines that have multiple tokens and contain header-like words
  for (const line of lines.slice(0, 30)) { // Check first 30 lines
    const tokens = line.split(/\s{2,}/).map(t => t.trim()).filter(t => t.length > 0);
    
    // A header line should have multiple columns (at least 3)
    if (tokens.length >= 3) {
      // Check if this looks like a header row (contains known keywords)
      const lowercaseTokens = tokens.map(t => t.toLowerCase());
      const matchCount = lowercaseTokens.filter(t => 
        headerKeywords.some(kw => t.includes(kw))
      ).length;
      
      // If at least 30% of tokens look like headers, this is probably a header row
      if (matchCount >= Math.max(2, tokens.length * 0.3)) {
        return { detectedHeaders: tokens, headerLine: line };
      }
    }
  }
  
  return { detectedHeaders: [], headerLine: '' };
}

/**
 * Extract data from PDF text using AI
 * This function preserves the EXACT column headers from the document
 * @param pdfText The extracted text content from the PDF
 * @returns Structured data with original headers and rows
 */
export async function extractLeasesFromPdfText(pdfText: string): Promise<PdfExtractionResult> {
  if (!pdfText || pdfText.trim().length === 0) {
    return {
      success: false,
      headers: [],
      rows: [],
      confidence: "low",
      warnings: ["PDF appears to be empty or contains no extractable text"],
      pageCount: 0,
    };
  }

  // Try to detect headers from the text first
  const { detectedHeaders, headerLine } = detectHeadersFromText(pdfText);
  
  // Truncate very long PDFs to avoid token limits (roughly 100k chars = ~25k tokens)
  const maxChars = 100000;
  const truncatedText = pdfText.length > maxChars 
    ? pdfText.substring(0, maxChars) + "\n...[Content truncated due to length]"
    : pdfText;

  // Build context about detected headers for the AI
  const headerContext = detectedHeaders.length > 0
    ? `\nDETECTED HEADER LINE: "${headerLine}"\nDETECTED COLUMNS: ${JSON.stringify(detectedHeaders)}\n\nYou MUST use these exact column names as headers.`
    : '';

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a document parser that extracts tabular data from PDF text while PRESERVING THE EXACT COLUMN HEADERS from the original document.

CRITICAL REQUIREMENT: You MUST use the EXACT column header names as they appear in the source document. DO NOT rename, translate, or map them to different field names.

For example:
- If the document has "Name" as a column, use "Name" (not "Tenant Name")
- If the document has "Date" as a column, use "Date" (not "Commencement Date")  
- If the document has "Credit" as a column, use "Credit" (not "Base Rent 1")
- If the document has "Num" as a column, use "Num" (not "Slip/Unit")
${headerContext}

IMPORTANT: Return ONLY a valid JSON object with this exact structure:
{
  "headers": ["exact_header_1", "exact_header_2", ...],
  "rows": [
    {"exact_header_1": "value1", "exact_header_2": "value2", ...},
    ...
  ],
  "confidence": "high" | "medium" | "low",
  "warnings": ["any issues or uncertainties"]
}

EXTRACTION RULES:
1. Extract ALL data rows found in the document
2. The "headers" array MUST contain the EXACT column names from the document (case-sensitive, no modifications)
3. Each row object MUST use these exact header names as keys
4. Preserve original data values exactly (don't modify dates, amounts, names)
5. If a value is unclear or missing, use empty string ""
6. Skip summary/total rows - only extract data rows
7. Skip header rows from the rows array (headers go in the "headers" field)

Set confidence:
- "high": Clear tabular data with consistent columns and most cells populated
- "medium": Some data extracted but with gaps or uncertainties
- "low": Minimal data found or unclear table structure`,
        },
        {
          role: "user",
          content: `Extract the tabular data from this PDF content, preserving the EXACT column headers:\n\n${truncatedText}`,
        },
      ],
      temperature: 0.1,
      response_format: { type: "json_object" },
      max_tokens: 4096,
    });

    const content = completion.choices[0]?.message?.content;
    if (!content) {
      return {
        success: false,
        headers: [],
        rows: [],
        confidence: "low",
        warnings: ["AI did not return a response"],
        pageCount: 0,
      };
    }

    const parsed = JSON.parse(content) as {
      headers?: string[];
      rows?: Record<string, string>[];
      confidence?: "high" | "medium" | "low";
      warnings?: string[];
    };

    // Validate the response structure
    let headers = Array.isArray(parsed.headers) ? parsed.headers : [];
    let rows = Array.isArray(parsed.rows) ? parsed.rows : [];
    const warnings = Array.isArray(parsed.warnings) ? parsed.warnings : [];

    if (rows.length === 0) {
      warnings.push("No data records were extracted from the PDF");
    }

    // CRITICAL: If we detected headers from the document, ALWAYS use those
    // This ensures the dropdown shows EXACTLY what's in the document
    if (detectedHeaders.length > 0 && rows.length > 0) {
      // Force use of detected headers - remap ALL row data to detected headers
      const remappedRows: Record<string, string>[] = rows.map(row => {
        const newRow: Record<string, string> = {};
        const rowValues = Object.values(row);
        
        // Strategy 1: Try to match AI headers to detected headers by name
        const aiHeaders = Object.keys(row);
        const usedDetectedHeaders = new Set<string>();
        
        for (const aiHeader of aiHeaders) {
          const lowerAiHeader = aiHeader.toLowerCase();
          // Find matching detected header
          for (const detected of detectedHeaders) {
            if (usedDetectedHeaders.has(detected)) continue;
            const lowerDetected = detected.toLowerCase();
            if (lowerAiHeader === lowerDetected || 
                lowerAiHeader.includes(lowerDetected) || 
                lowerDetected.includes(lowerAiHeader)) {
              newRow[detected] = row[aiHeader];
              usedDetectedHeaders.add(detected);
              break;
            }
          }
        }
        
        // Strategy 2: For any unmapped detected headers, use positional mapping
        // This handles cases where AI renamed headers completely
        if (usedDetectedHeaders.size < detectedHeaders.length && rowValues.length >= detectedHeaders.length) {
          let valueIdx = 0;
          for (const detected of detectedHeaders) {
            if (!usedDetectedHeaders.has(detected) && valueIdx < rowValues.length) {
              newRow[detected] = String(rowValues[valueIdx] || '');
            }
            valueIdx++;
          }
        }
        
        // Strategy 3: If we still have unmapped headers, try direct key access
        for (const detected of detectedHeaders) {
          if (newRow[detected] === undefined) {
            // Try exact match
            if (row[detected] !== undefined) {
              newRow[detected] = row[detected];
            } else {
              newRow[detected] = ''; // Default to empty for unmapped columns
            }
          }
        }
        
        return newRow;
      });

      // ALWAYS use detected headers when available
      headers = detectedHeaders;
      rows = remappedRows;
    }

    return {
      success: rows.length > 0,
      headers,
      rows,
      confidence: parsed.confidence || (rows.length > 0 ? "medium" : "low"),
      warnings,
      pageCount: 0, // Will be set by caller
    };
  } catch (error) {
    console.error("Error extracting data from PDF:", error);
    return {
      success: false,
      headers: [],
      rows: [],
      confidence: "low",
      warnings: [`AI extraction failed: ${error instanceof Error ? error.message : "Unknown error"}`],
      pageCount: 0,
    };
  }
}

// ============================================================================
// AI-Powered Column Mapping for Bulk Import
// ============================================================================

export interface ColumnMappingSuggestion {
  csvColumn: string;
  suggestedField: string | null;
  confidence: "high" | "medium" | "low";
  reason?: string;
}

export interface AIColumnMappingResult {
  suggestions: ColumnMappingSuggestion[];
  contractTermHints: {
    column: string;
    detectedTerms: string[];
  }[];
  rateStructureHint: "annual" | "seasonal" | "mixed" | null;
}

// Keywords for pattern matching fallback
const COLUMN_KEYWORD_PATTERNS: Record<string, { keywords: string[]; field: string }[]> = {
  tenant: [
    { keywords: ['name', 'tenant', 'customer', 'owner', 'renter', 'client', 'lessee'], field: 'name' },
    { keywords: ['boat make', 'make', 'manufacturer', 'brand'], field: 'boatMake' },
    { keywords: ['boat year', 'year built', 'model year'], field: 'boatYear' },
    { keywords: ['boat size', 'boat length', 'loa', 'length overall', 'vessel length'], field: 'boatSize' },
    { keywords: ['address', 'street', 'addr1', 'address 1', 'address1', 'street address'], field: 'address1' },
    { keywords: ['apt', 'suite', 'unit', 'address 2', 'address2', 'addr2'], field: 'address2' },
    { keywords: ['city', 'town'], field: 'city' },
    { keywords: ['state', 'province', 'st'], field: 'state' },
    { keywords: ['zip', 'postal', 'zipcode', 'zip code'], field: 'zip' },
    { keywords: ['full address', 'complete address', 'mailing address'], field: 'fullAddress' },
  ],
  lease: [
    { keywords: ['commencement', 'start date', 'lease start', 'begin', 'effective', 'move in'], field: 'leaseCommencement' },
    { keywords: ['expiration', 'end date', 'lease end', 'expires', 'termination', 'move out'], field: 'leaseExpiration' },
    { keywords: ['rent', 'amount', 'monthly', 'rate', 'base rent', 'lease amount', 'price', 'fee', 'charge'], field: 'leaseAmount' },
    { keywords: ['rent 2', 'base rent 2', 'rate 2', 'second rate'], field: 'baseRent2' },
    { keywords: ['rent 3', 'base rent 3', 'rate 3', 'third rate'], field: 'baseRent3' },
    { keywords: ['term', 'contract term', 'lease term', 'duration', 'period'], field: 'contractTerm' },
    { keywords: ['storage', 'type', 'slip type', 'space type', 'dock type'], field: 'storageType' },
    { keywords: ['location', 'slip', 'dock', 'space', 'unit', 'berth', 'slip #', 'dock #'], field: 'unitLocation' },
    { keywords: ['status', 'slip status', 'availability'], field: 'slipStatus' },
    { keywords: ['dimensions', 'beam', 'boat dim'], field: 'boatDimensions' },
    { keywords: ['slip length', 'dock length', 'space length'], field: 'slipLength' },
    { keywords: ['slip width', 'dock width', 'space width'], field: 'slipWidth' },
  ],
  lineItems: [
    { keywords: ['winter', 'winter rate', 'winter amount', 'winter fee', 'wtr', 'off-season', 'off season'], field: 'winterAmount' },
    { keywords: ['summer', 'summer rate', 'summer amount', 'summer fee', 'smr', 'in-season', 'in season'], field: 'summerAmount' },
    { keywords: ['seasonal', 'season rate', 'season amount', 'season fee'], field: 'seasonalAmount' },
    { keywords: ['liveaboard', 'live aboard', 'live-aboard', 'living aboard', 'la fee'], field: 'liveaboardAmount' },
    { keywords: ['electric', 'electricity', 'power', 'elec', 'utilities', 'shore power'], field: 'electricAmount' },
    { keywords: ['winter slip', 'wtr slip', 'winter location', 'winter dock'], field: 'winterSlip' },
    { keywords: ['summer slip', 'smr slip', 'summer location', 'summer dock'], field: 'summerSlip' },
  ],
};

// Contract term keywords for detection
const CONTRACT_TERM_KEYWORDS = {
  annual: ['annual', 'yearly', '12 month', '12-month', '1 year', 'one year', 'full year'],
  seasonal: ['seasonal', 'summer', 'in-season', 'in season', 'peak season'],
  winter: ['winter', 'off-season', 'off season', 'cold season'],
  monthly: ['monthly', 'mtm', 'month-to-month', 'month to month', 'm2m', 'rolling'],
  sixMonth: ['6 month', '6-month', 'six month', 'half year'],
  threeMonth: ['3 month', '3-month', 'three month', 'quarterly'],
};

/**
 * Pattern-based fallback for column mapping when AI is unavailable
 */
function patternBasedColumnMapping(headers: string[]): ColumnMappingSuggestion[] {
  const suggestions: ColumnMappingSuggestion[] = [];
  const allPatterns = [
    ...COLUMN_KEYWORD_PATTERNS.tenant,
    ...COLUMN_KEYWORD_PATTERNS.lease,
    ...COLUMN_KEYWORD_PATTERNS.lineItems,
  ];

  for (const header of headers) {
    const normalizedHeader = header.toLowerCase().trim();
    let bestMatch: { field: string; confidence: "high" | "medium" | "low" } | null = null;

    for (const pattern of allPatterns) {
      for (const keyword of pattern.keywords) {
        if (normalizedHeader === keyword) {
          bestMatch = { field: pattern.field, confidence: "high" };
          break;
        } else if (normalizedHeader.includes(keyword) || keyword.includes(normalizedHeader)) {
          if (!bestMatch || bestMatch.confidence !== "high") {
            bestMatch = { field: pattern.field, confidence: "medium" };
          }
        }
      }
      if (bestMatch?.confidence === "high") break;
    }

    suggestions.push({
      csvColumn: header,
      suggestedField: bestMatch?.field || null,
      confidence: bestMatch?.confidence || "low",
      reason: bestMatch ? "Keyword pattern match" : undefined,
    });
  }

  return suggestions;
}

/**
 * Detect contract terms in sample data values
 */
function detectContractTermsInData(
  headers: string[],
  sampleRows: Record<string, any>[]
): { column: string; detectedTerms: string[] }[] {
  const results: { column: string; detectedTerms: string[] }[] = [];
  
  // Look for columns that might contain contract term info
  const potentialTermColumns = headers.filter(h => {
    const lower = h.toLowerCase();
    return lower.includes('term') || lower.includes('type') || lower.includes('period') || 
           lower.includes('duration') || lower.includes('contract');
  });

  for (const column of potentialTermColumns) {
    const detectedTerms: Set<string> = new Set();
    
    for (const row of sampleRows) {
      const value = String(row[column] || '').toLowerCase();
      
      for (const [termType, keywords] of Object.entries(CONTRACT_TERM_KEYWORDS)) {
        if (keywords.some(kw => value.includes(kw))) {
          detectedTerms.add(termType);
        }
      }
    }
    
    if (detectedTerms.size > 0) {
      results.push({ column, detectedTerms: Array.from(detectedTerms) });
    }
  }

  return results;
}

/**
 * Detect rate structure from column headers
 */
function detectRateStructure(headers: string[]): "annual" | "seasonal" | "mixed" | null {
  const normalizedHeaders = headers.map(h => h.toLowerCase());
  
  const hasWinterColumn = normalizedHeaders.some(h => 
    h.includes('winter') || h.includes('off-season') || h.includes('off season')
  );
  const hasSummerColumn = normalizedHeaders.some(h => 
    h.includes('summer') || h.includes('in-season') || h.includes('in season') || h.includes('seasonal')
  );
  const hasAnnualColumn = normalizedHeaders.some(h => 
    h.includes('annual') || h.includes('yearly')
  );
  const hasBaseRentColumn = normalizedHeaders.some(h => 
    (h.includes('rent') || h.includes('rate') || h.includes('amount')) && 
    !h.includes('winter') && !h.includes('summer') && !h.includes('seasonal')
  );

  if (hasWinterColumn && hasSummerColumn) {
    return "seasonal";
  } else if (hasWinterColumn || hasSummerColumn) {
    return "mixed";
  } else if (hasAnnualColumn || hasBaseRentColumn) {
    return "annual";
  }
  
  return null;
}

/**
 * AI-powered column mapping with fallback to pattern matching
 */
export async function suggestColumnMappings(
  headers: string[],
  sampleRows: Record<string, any>[],
  availableFields: { value: string; label: string }[]
): Promise<AIColumnMappingResult> {
  // Detect contract terms and rate structure regardless of AI
  const contractTermHints = detectContractTermsInData(headers, sampleRows);
  const rateStructureHint = detectRateStructure(headers);

  try {
    // Try AI-powered mapping first
    const fieldList = availableFields.map(f => `- "${f.value}" (${f.label})`).join('\n');
    
    // Prepare sample data for AI context
    const samplePreview = sampleRows.slice(0, 5).map(row => {
      const preview: Record<string, string> = {};
      for (const header of headers) {
        const value = row[header];
        if (value !== undefined && value !== null && String(value).trim() !== '') {
          preview[header] = String(value).substring(0, 50);
        }
      }
      return preview;
    });

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a data mapping assistant for marina management software. Your task is to analyze CSV/Excel column headers and sample data to suggest the best field mappings.

Available target fields:
${fieldList}

Rules:
1. Analyze both the column header names AND the sample values to determine the best mapping
2. Look for marina-specific terminology: slip, dock, berth, vessel, boat, LOA, etc.
3. Recognize seasonal patterns: winter/summer rates, off-season/in-season
4. Identify contract terms: Annual, Seasonal, Monthly, MTM, etc.
5. Be conservative - only suggest mappings you're confident about
6. Headers like "Winter Rate" or "Wtr Amt" should map to "winterAmount"
7. Headers like "Summer Fee" or "Smr Rate" should map to "summerAmount"

Return a JSON object with:
{
  "mappings": [
    { "csvColumn": "original header", "suggestedField": "field value or null", "confidence": "high/medium/low", "reason": "brief explanation" }
  ]
}`
        },
        {
          role: "user",
          content: `Analyze these column headers and sample data to suggest field mappings:

Headers: ${JSON.stringify(headers)}

Sample data (first 5 rows):
${JSON.stringify(samplePreview, null, 2)}

Suggest the best field mapping for each column.`
        }
      ],
      temperature: 0.1,
      response_format: { type: "json_object" },
    });

    const content = completion.choices[0]?.message?.content;
    if (content) {
      const parsed = JSON.parse(content) as { mappings: ColumnMappingSuggestion[] };
      
      // Validate suggestions against available fields
      const validFieldValues = new Set(availableFields.map(f => f.value));
      const validatedSuggestions = parsed.mappings.map(s => ({
        ...s,
        suggestedField: s.suggestedField && validFieldValues.has(s.suggestedField) 
          ? s.suggestedField 
          : null,
      }));

      return {
        suggestions: validatedSuggestions,
        contractTermHints,
        rateStructureHint,
      };
    }
  } catch (error) {
    console.error("AI column mapping failed, falling back to pattern matching:", error);
  }

  // Fallback to pattern-based mapping
  const patternSuggestions = patternBasedColumnMapping(headers);
  
  return {
    suggestions: patternSuggestions,
    contractTermHints,
    rateStructureHint,
  };
}
