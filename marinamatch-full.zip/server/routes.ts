import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { setupAuth, isAuthenticated } from "./replitAuth";
import {
  requireLocationAccess,
  requireLeaseAccess,
  requireStorageLocationAccess,
  validateLocationOwnership,
  requirePermission,
  logAuditEvent,
  verifyV2ResourceAccess,
  verifySnapshotAccess,
  type AuthorizedRequest,
  type AuthorizedRequestWithRole,
} from "./authorizationMiddleware";
import { publishLeaseEvent } from "./webhookPublisher";
import { 
  createLeaseWithTenant,
  updateLease,
  getAllLeasesWithTenants,
  deleteLease,
  bulkDeleteLeases,
  bulkUpdateLeases,
  resetProjectData,
  regenerateAllCashFlowsForProject,
  getMonthlySummary,
  upsertPnlRackRevenue,
  createMoveEvent,
  getAllMoveEvents,
  getAddressHeatMap,
  getRevenueByStorageType,
  getExecutiveDashboardMetrics,
  getRevenueTrendData,
  getRevenueTrendByStorageType,
  getAllLocations,
  getActiveLocations,
  getLocationById,
  createLocation,
  updateLocation,
  deleteLocation,
  getLocationOccupancy,
  getProjectHubMetrics,
  getLeaseCashFlowMatrix,
  getDataQualitySummary,
  getStorageLocationsByProject,
  getStorageLocationsOccupancy,
  getStorageLocationById,
  createStorageLocation,
  updateStorageLocation,
  deleteStorageLocation,
  getProjectDetailsConfig,
  upsertProjectDetailsConfig,
  getMoveEventsDetail,
  getRevenueByProject,
  getRevenueByMonth,
  getRevenueByMonthByProject,
  getLeasesByProject,
  getOccupancyByProject,
  getAvgLeaseValueByProject,
  getProjectKPIs,
  getProjectMoveEvents,
  getProjectMoveEventLeases,
  getProjectRevenueTrend,
  getProjectRevenueByStorage,
  backfillCashFlowsForIncompleteLeasesWithAmounts,
  getEconomicVacancyMetrics,
  getSeasonalOccupancyMetrics,
  getSeasonalMoveEvents,
  getSeasonalRevenue,
  getUnifiedSeasonalMetrics,
  getExecutiveSeasonalMoveEvents,
  getContractTermOccupancy,
  getExecutiveContractTermOccupancy,
  getExecutiveAvgBoatSize,
  getAvailableStorageTypes,
  getLeasesByStorageLocation,
  getAvgLeaseValueByStorageType,
  getProjectAvgLeaseValueByStorageType,
  getLeaseLineItems,
  getLeaseLineItemById,
  createLeaseLineItem,
  createLeaseLineItemsBulk,
  updateLeaseLineItem,
  deleteLeaseLineItem,
  getLineItemsForLeases,
  type MoveEventType,
  type KpiFilterOptions,
} from "./rentRollService";
import {
  createLeaseWithTenantSchema,
  insertTenantSchema,
  insertLeaseSchema,
  insertLeaseLineItemSchema,
  insertMoveEventSchema,
  insertMarinaLocationSchema,
  insertStorageLocationSchema,
  insertOrganizationSchema,
  insertOrganizationUserSchema,
  leases,
  tenants,
  marinaLocations,
  storageLocations,
  leaseCashFlows,
  periods,
  moveEvents,
  customStorageTypes,
  customContractTerms,
  customRateTypes,
  customSlipStatuses,
  globalPromotedTypes,
  adminTypeReviewQueue,
  organizations,
  comments,
  users,
  insertCommentSchema,
  hasPermission,
  type ParsedImportRow,
  type OrganizationRole,
  type InsertLeaseLineItem,
  leaseTerms,
  leaseRentSteps,
  leaseEscalations,
  leaseConcessions,
  leaseBillingRules,
  orgFeatureFlags,
  insertLeaseTermSchema,
  insertLeaseRentStepSchema,
  insertLeaseEscalationSchema,
  insertLeaseConcessionSchema,
  insertLeaseBillingRuleSchema,
  insertOrgFeatureFlagSchema,
  FEATURE_FLAG_KEYS,
} from "@shared/schema";
import {
  generateLeaseEconomicsCashFlows,
  hasEconomicsV2Data,
} from "./services/leaseEconomics";
import {
  logLeaseCreate,
  logLeaseUpdate,
  logLeaseDelete,
  logBulkImport,
  logBulkEdit,
  logProjectCreate,
  logProjectUpdate,
  logRoleChange,
  type AuditLogContext,
} from "./auditService";
import {
  createSnapshot,
  getProjectSnapshots,
  getSnapshotDetails,
  getSnapshotCashFlows,
  finalizeSnapshot,
  compareSnapshots,
  deleteSnapshot,
} from "./services/snapshotVersioning/snapshotService";
import { eq, and, desc, asc, inArray, sql, gte, lte, isNotNull, isNull } from "drizzle-orm";
import { 
  mapColumnHeaders,
  parseImportRow,
  findDuplicateTenants,
  validateSlipUniqueness,
  validateContractOverlaps,
  importLeases,
} from "./bulkLeaseImport";
import { parseAddressesBatch, suggestValueMappings, suggestColumnMappings } from "./aiAddressParser";

/**
 * Process rows with full addresses using AI to split them into components
 * @param rows Import rows that may contain fullAddress field
 * @param columnMap Mapping of column names to field IDs
 * @returns Processed rows with address components filled in
 */
async function processFullAddresses(
  rows: Record<string, any>[],
  columnMap: Map<string, string>
): Promise<Record<string, any>[]> {
  // Check if fullAddress is mapped
  const hasFullAddress = Array.from(columnMap.values()).includes("fullAddress");
  
  if (!hasFullAddress) {
    return rows; // No full address column, return as is
  }

  // Find the column name that maps to fullAddress
  let fullAddressColumn: string | null = null;
  for (const [col, fieldId] of columnMap.entries()) {
    if (fieldId === "fullAddress") {
      fullAddressColumn = col;
      break;
    }
  }

  if (!fullAddressColumn) {
    return rows;
  }

  // Extract full addresses from rows
  const fullAddresses = rows.map(row => row[fullAddressColumn!] || "");

  // Parse addresses using AI in batch
  const parsedAddresses = await parseAddressesBatch(fullAddresses);

  // Create new rows with parsed address components
  const processedRows = rows.map((row, index) => {
    const parsed = parsedAddresses[index];
    const newRow = { ...row };

    // Add parsed address components to the row
    if (parsed.address1) newRow.address1 = parsed.address1;
    if (parsed.address2) newRow.address2 = parsed.address2;
    if (parsed.city) newRow.city = parsed.city;
    if (parsed.state) newRow.state = parsed.state;
    if (parsed.zip) newRow.zip = parsed.zip;

    // Remove fullAddress from the row (it's been processed)
    delete newRow[fullAddressColumn!];

    return newRow;
  });

  // Update columnMap to include the new address fields
  columnMap.set("address1", "address1");
  columnMap.set("address2", "address2");
  columnMap.set("city", "city");
  columnMap.set("state", "state");
  columnMap.set("zip", "zip");
  // Remove fullAddress from the map
  columnMap.delete(fullAddressColumn);

  return processedRows;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // ============================================================================
  // AUTHENTICATION SETUP (Replit Auth)
  // ============================================================================
  
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Auto-create default organization for new users if they don't have one
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        const userEmail = req.user.claims.email || `user-${userId.substring(0, 8)}`;
        const defaultOrgName = `${userEmail.split('@')[0]}'s Organization`;
        
        await storage.createOrganization(
          { name: defaultOrgName },
          userId
        );
      }
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // ============================================================================
  // ORGANIZATION MANAGEMENT ROUTES (Protected)
  // ============================================================================

  // GET /api/organizations - Get all organizations for the current user
  app.get('/api/organizations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const organizations = await storage.getUserOrganizations(userId);
      res.json(organizations);
    } catch (error) {
      console.error("Error fetching organizations:", error);
      res.status(500).json({ message: "Failed to fetch organizations" });
    }
  });

  // GET /api/organizations/:id - Get a single organization by ID
  app.get('/api/organizations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const userRole = await storage.getUserOrganizationRole(userId, id);
      if (!userRole) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const organization = await storage.getOrganization(id);
      if (!organization) {
        return res.status(404).json({ message: "Organization not found" });
      }
      
      res.json(organization);
    } catch (error) {
      console.error("Error fetching organization:", error);
      res.status(500).json({ message: "Failed to fetch organization" });
    }
  });

  // POST /api/organizations - Create a new organization
  app.post('/api/organizations', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validated = insertOrganizationSchema.parse(req.body);
      const organization = await storage.createOrganization(validated, userId);
      res.status(201).json(organization);
    } catch (error) {
      console.error("Error creating organization:", error);
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create organization" });
      }
    }
  });

  // PUT /api/organizations/:id - Update an organization
  app.put('/api/organizations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const userRole = await storage.getUserOrganizationRole(userId, id);
      if (!userRole || !hasPermission(userRole, 'canManageOrganization')) {
        return res.status(403).json({ message: "Only owners and admins can update organizations" });
      }
      
      const validated = insertOrganizationSchema.partial().parse(req.body);
      const organization = await storage.updateOrganization(id, validated);
      
      if (!organization) {
        return res.status(404).json({ message: "Organization not found" });
      }
      
      res.json(organization);
    } catch (error) {
      console.error("Error updating organization:", error);
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to update organization" });
      }
    }
  });

  // DELETE /api/organizations/:id - Delete an organization
  app.delete('/api/organizations/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const userRole = await storage.getUserOrganizationRole(userId, id);
      if (userRole !== 'owner') {
        return res.status(403).json({ message: "Only owners can delete organizations" });
      }
      
      const success = await storage.deleteOrganization(id);
      if (!success) {
        return res.status(404).json({ message: "Organization not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting organization:", error);
      res.status(500).json({ message: "Failed to delete organization" });
    }
  });

  // GET /api/organizations/:id/members - Get all members of an organization
  app.get('/api/organizations/:id/members', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const userRole = await storage.getUserOrganizationRole(userId, id);
      if (!userRole) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const members = await storage.getOrganizationMembers(id);
      res.json(members);
    } catch (error) {
      console.error("Error fetching organization members:", error);
      res.status(500).json({ message: "Failed to fetch organization members" });
    }
  });

  // POST /api/organizations/:id/members - Add a user to an organization
  app.post('/api/organizations/:id/members', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const { userId: newUserId, role } = req.body;
      
      const userRole = await storage.getUserOrganizationRole(userId, id);
      if (!userRole || !hasPermission(userRole, 'canManageUsers')) {
        return res.status(403).json({ message: "Only owners and admins can add members" });
      }
      
      if (!newUserId || !role) {
        return res.status(400).json({ message: "userId and role are required" });
      }
      
      const member = await storage.addUserToOrganization(id, newUserId, role as OrganizationRole);
      res.status(201).json(member);
    } catch (error) {
      console.error("Error adding organization member:", error);
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to add organization member" });
      }
    }
  });

  // DELETE /api/organizations/:id/members/:userId - Remove a user from an organization
  app.delete('/api/organizations/:id/members/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id, userId: targetUserId } = req.params;
      
      const userRole = await storage.getUserOrganizationRole(userId, id);
      if (!userRole || !hasPermission(userRole, 'canManageUsers')) {
        return res.status(403).json({ message: "Only owners and admins can remove members" });
      }
      
      const success = await storage.removeUserFromOrganization(id, targetUserId);
      if (!success) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error removing organization member:", error);
      res.status(500).json({ message: "Failed to remove organization member" });
    }
  });

  // PUT /api/organizations/:id/members/:userId/role - Update a user's role in an organization
  app.put('/api/organizations/:id/members/:userId/role', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id, userId: targetUserId } = req.params;
      const { role } = req.body;
      
      const userRole = await storage.getUserOrganizationRole(userId, id);
      if (userRole !== 'owner') {
        return res.status(403).json({ message: "Only owners can update member roles" });
      }
      
      if (!role) {
        return res.status(400).json({ message: "role is required" });
      }
      
      // Get previous role and target user info for audit log
      const previousRole = await storage.getUserOrganizationRole(targetUserId, id);
      const targetUser = await storage.getUser(targetUserId);
      const targetUserName = targetUser?.email || targetUser?.firstName || targetUserId;
      
      const updated = await storage.updateUserRole(id, targetUserId, role as OrganizationRole);
      if (!updated) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      // Audit log: role change
      const auditContext: AuditLogContext = { userId, organizationId: id };
      await logRoleChange(auditContext, targetUserId, targetUserName, previousRole || 'unknown', role);
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating member role:", error);
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to update member role" });
      }
    }
  });

  // ============================================================================
  // AUDIT LOG ROUTES (Protected - Admin/Owner Only)
  // ============================================================================

  // GET /api/organizations/:id/audit-logs - Get audit logs for an organization
  app.get('/api/organizations/:id/audit-logs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id: organizationId } = req.params;
      
      const userRole = await storage.getUserOrganizationRole(userId, organizationId);
      if (!userRole || !hasPermission(userRole, 'canViewAuditLogs')) {
        return res.status(403).json({ message: "Only owners and admins can view audit logs" });
      }
      
      const { entityType, entityId, action, startDate, endDate, limit, offset } = req.query;
      
      const filters = {
        entityType: entityType as string | undefined,
        entityId: entityId as string | undefined,
        action: action as string | undefined,
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        limit: limit ? parseInt(limit as string) : 50,
        offset: offset ? parseInt(offset as string) : 0,
      };
      
      const result = await storage.getAuditLogs(organizationId, filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching audit logs:", error);
      res.status(500).json({ message: "Failed to fetch audit logs" });
    }
  });

  // ============================================================================
  // RENT ROLL ANALYSIS ROUTES (Protected)
  // ============================================================================

  // GET /api/rent-roll/leases/:id - Get a single lease by ID
  app.get("/api/rent-roll/leases/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const lease = await db.query.leases.findFirst({
        where: eq(leases.id, id),
        with: { tenant: true },
      });
      
      if (!lease) {
        return res.status(404).json({ error: "Lease not found" });
      }
      
      res.json(lease);
    } catch (error) {
      console.error("Error fetching lease:", error);
      res.status(500).json({ error: "Failed to fetch lease" });
    }
  });

  // GET /api/rent-roll/leases - Get all leases with tenant data
  app.get("/api/rent-roll/leases", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const { state, isActive, storageType, page, pageSize, locationId } = req.query;
      
      const filters = {
        state: state as string | undefined,
        isActive: isActive === "true" ? true : isActive === "false" ? false : undefined,
        storageType: storageType as string | undefined,
        page: page ? parseInt(page as string) : undefined,
        pageSize: pageSize ? parseInt(pageSize as string) : undefined,
        organizationIds,
        locationId: locationId as string | undefined,
      };
      
      const result = await getAllLeasesWithTenants(filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching leases:", error);
      res.status(500).json({ error: "Failed to fetch leases" });
    }
  });

  // GET /api/rent-roll/available-years?locationId=:locationId - Get available years from lease data
  app.get("/api/rent-roll/available-years", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const { locationId } = req.query;
      
      // Get all leases with their associated marina locations
      const leasesData = locationId 
        ? await db.query.leases.findMany({
            where: eq(leases.locationId, locationId as string),
          })
        : await db.query.leases.findMany();
      
      // Get all marina locations for organization filtering
      const locations = await db.query.marinaLocations.findMany({
        where: inArray(marinaLocations.organizationId, organizationIds),
      });
      
      const accessibleLocationIds = new Set(locations.map(loc => loc.id));
      
      // Filter leases by organization access
      const accessibleLeases = leasesData.filter(lease => 
        lease.locationId && accessibleLocationIds.has(lease.locationId)
      );
      
      // Extract years from lease dates
      const yearsSet = new Set<number>();
      const currentYear = new Date().getFullYear();
      // Filter out unrealistic years: anything before 2000 or more than 10 years in the future
      const MIN_VALID_YEAR = 2000;
      const MAX_VALID_YEAR = currentYear + 10;
      
      accessibleLeases.forEach(lease => {
        if (lease.leaseCommencement) {
          const startYear = new Date(lease.leaseCommencement).getFullYear();
          if (startYear >= MIN_VALID_YEAR && startYear <= MAX_VALID_YEAR) {
            yearsSet.add(startYear);
          }
        }
        
        if (lease.leaseExpiration) {
          const endYear = new Date(lease.leaseExpiration).getFullYear();
          // Don't include 2099 (our sentinel value for open-ended leases)
          // and filter out unrealistic years
          if (endYear >= MIN_VALID_YEAR && endYear < 2099 && endYear <= MAX_VALID_YEAR) {
            yearsSet.add(endYear);
          }
        }
      });
      
      // Convert to sorted array (newest first)
      const years = Array.from(yearsSet).sort((a, b) => b - a);
      
      res.json(years);
    } catch (error) {
      console.error("Error fetching available years:", error);
      res.status(500).json({ error: "Failed to fetch available years" });
    }
  });

  // POST /api/rent-roll/leases - Create new lease with tenant
  app.post("/api/rent-roll/leases", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const validated = createLeaseWithTenantSchema.parse(req.body);
      
      // Validate user has access to the location
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // locationId is nested in the lease object
      const validation = await validateLocationOwnership(validated.lease.locationId!, organizationIds);
      if (!validation.valid) {
        return res.status(403).json({ error: validation.error });
      }
      
      const lease = await createLeaseWithTenant(validated);
      
      // Audit log: lease creation
      if (userOrgs.length > 0) {
        const auditContext: AuditLogContext = { userId, organizationId: userOrgs[0].id };
        await logLeaseCreate(auditContext, lease.id, {
          tenantName: validated.tenant.name,
          ...validated.lease,
        });
        
        // Publish webhook event (non-blocking)
        publishLeaseEvent("created", {
          id: lease.id,
          tenantId: lease.tenantId,
          locationId: lease.locationId,
          storageLocationId: lease.storageLocationId,
          leaseCommencement: lease.leaseCommencement,
          leaseExpiration: lease.leaseExpiration,
          leaseAmount: lease.leaseAmount,
          rateType: lease.rateType,
          contractTerm: lease.contractTerm,
          storageType: lease.storageType,
          unitLocation: lease.unitLocation,
          unitNumber: lease.unitNumber,
          boatDimensions: lease.boatDimensions,
          slipStatus: lease.slipStatus,
        }, userOrgs[0].id, {
          id: lease.tenantId,
          name: validated.tenant.name,
          address1: validated.tenant.address1,
          city: validated.tenant.city,
          state: validated.tenant.state,
          zip: validated.tenant.zip,
        }).catch(err => console.error("Webhook publish error:", err));
      }
      
      res.status(201).json(lease);
    } catch (error) {
      console.error("Error creating lease:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create lease" });
      }
    }
  });

  // PUT /api/rent-roll/leases/:id - Update existing lease
  app.put("/api/rent-roll/leases/:id", isAuthenticated, requireLeaseAccess(storage), async (req: any, res) => {
    try {
      const { id } = req.params;
      const { tenant, lease } = req.body;
      
      // Get previous lease data for audit log
      const previousLease = await db.query.leases.findFirst({
        where: eq(leases.id, id),
        with: { tenant: true },
      });
      
      const updatedLease = await updateLease(id, tenant || {}, lease || {});
      
      // Audit log: lease update
      const userId = req.user?.claims?.sub;
      if (userId && previousLease) {
        const userOrgs = await storage.getUserOrganizations(userId);
        if (userOrgs.length > 0) {
          const auditContext: AuditLogContext = { userId, organizationId: userOrgs[0].id };
          await logLeaseUpdate(auditContext, id, previousLease, { tenant, lease });
          
          // Publish webhook event (non-blocking)
          publishLeaseEvent("updated", {
            id: updatedLease.id,
            tenantId: updatedLease.tenantId,
            locationId: updatedLease.locationId,
            storageLocationId: updatedLease.storageLocationId,
            leaseCommencement: updatedLease.leaseCommencement,
            leaseExpiration: updatedLease.leaseExpiration,
            leaseAmount: updatedLease.leaseAmount,
            rateType: updatedLease.rateType,
            contractTerm: updatedLease.contractTerm,
            storageType: updatedLease.storageType,
            unitLocation: updatedLease.unitLocation,
            unitNumber: updatedLease.unitNumber,
            boatDimensions: updatedLease.boatDimensions,
            slipStatus: updatedLease.slipStatus,
          }, userOrgs[0].id, updatedLease.tenant ? {
            id: updatedLease.tenant.id,
            name: updatedLease.tenant.name,
            address1: updatedLease.tenant.address1,
            city: updatedLease.tenant.city,
            state: updatedLease.tenant.state,
            zip: updatedLease.tenant.zip,
          } : undefined).catch(err => console.error("Webhook publish error:", err));
        }
      }
      
      res.json(updatedLease);
    } catch (error) {
      console.error("Error updating lease:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to update lease" });
      }
    }
  });

  // DELETE /api/rent-roll/leases/:id - Soft delete lease
  app.delete("/api/rent-roll/leases/:id", isAuthenticated, requireLeaseAccess(storage), async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Get lease data for audit log before deletion
      const leaseData = await db.query.leases.findFirst({
        where: eq(leases.id, id),
        with: { tenant: true },
      });
      
      await deleteLease(id);
      
      // Audit log: lease deletion
      const userId = req.user?.claims?.sub;
      if (userId && leaseData) {
        const userOrgs = await storage.getUserOrganizations(userId);
        if (userOrgs.length > 0) {
          const auditContext: AuditLogContext = { userId, organizationId: userOrgs[0].id };
          await logLeaseDelete(auditContext, id, { tenantName: leaseData.tenant?.name, ...leaseData });
          
          // Publish webhook event (non-blocking)
          publishLeaseEvent("deleted", {
            id: leaseData.id,
            tenantId: leaseData.tenantId,
            locationId: leaseData.locationId,
            storageLocationId: leaseData.storageLocationId,
          }, userOrgs[0].id).catch(err => console.error("Webhook publish error:", err));
        }
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting lease:", error);
      res.status(500).json({ error: "Failed to delete lease" });
    }
  });

  // POST /api/rent-roll/leases/bulk-delete - Bulk delete multiple leases
  app.post("/api/rent-roll/leases/bulk-delete", isAuthenticated, async (req: any, res) => {
    try {
      const { leaseIds } = req.body;
      
      if (!Array.isArray(leaseIds) || leaseIds.length === 0) {
        return res.status(400).json({ error: "leaseIds array is required" });
      }
      
      // Get user's organization IDs for authorization
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      if (organizationIds.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      
      // Use the first organization ID for validation (user can only belong to one org typically)
      const orgId = organizationIds[0];
      
      const deletedCount = await bulkDeleteLeases(leaseIds, orgId);
      
      // Audit log: bulk delete
      const auditContext: AuditLogContext = { userId, organizationId: orgId };
      await logBulkEdit(auditContext, "lease", leaseIds, { action: "delete" });
      
      res.json({ deletedCount });
    } catch (error) {
      console.error("Error bulk deleting leases:", error);
      res.status(500).json({ error: "Failed to delete leases" });
    }
  });

  // POST /api/rent-roll/leases/bulk-update - Bulk update multiple leases with same values
  app.post("/api/rent-roll/leases/bulk-update", isAuthenticated, async (req: any, res) => {
    try {
      const { leaseIds, updates } = req.body;
      
      if (!Array.isArray(leaseIds) || leaseIds.length === 0) {
        return res.status(400).json({ error: "leaseIds array is required" });
      }
      
      if (!updates || typeof updates !== 'object') {
        return res.status(400).json({ error: "updates object is required" });
      }
      
      // Get user's organization IDs for authorization
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      if (organizationIds.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      
      // Use the first organization ID for validation
      const orgId = organizationIds[0];
      
      const updatedCount = await bulkUpdateLeases(leaseIds, updates, orgId);
      
      // Audit log: bulk update
      const auditContext: AuditLogContext = { userId, organizationId: orgId };
      await logBulkEdit(auditContext, "lease", leaseIds, updates);
      
      res.json({ updatedCount });
    } catch (error) {
      console.error("Error bulk updating leases:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to update leases" });
      }
    }
  });

  // ============================================================================
  // LEASE LINE ITEMS ROUTES
  // ============================================================================

  // GET /api/rent-roll/leases/:leaseId/line-items - Get all line items for a lease
  app.get("/api/rent-roll/leases/:leaseId/line-items", isAuthenticated, async (req, res) => {
    try {
      const { leaseId } = req.params;
      const items = await getLeaseLineItems(leaseId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching lease line items:", error);
      res.status(500).json({ error: "Failed to fetch line items" });
    }
  });

  // POST /api/rent-roll/leases/:leaseId/line-items - Create a new line item
  app.post("/api/rent-roll/leases/:leaseId/line-items", isAuthenticated, async (req, res) => {
    try {
      const { leaseId } = req.params;
      const data = { ...req.body, leaseId };
      
      const validated = insertLeaseLineItemSchema.parse(data);
      const item = await createLeaseLineItem(validated);
      res.status(201).json(item);
    } catch (error) {
      console.error("Error creating lease line item:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create line item" });
      }
    }
  });

  // POST /api/rent-roll/leases/:leaseId/line-items/bulk - Create multiple line items
  app.post("/api/rent-roll/leases/:leaseId/line-items/bulk", isAuthenticated, async (req, res) => {
    try {
      const { leaseId } = req.params;
      const { items } = req.body;
      
      if (!Array.isArray(items)) {
        return res.status(400).json({ error: "items array is required" });
      }
      
      const dataItems: InsertLeaseLineItem[] = items.map(item => ({
        ...item,
        leaseId,
      }));
      
      const created = await createLeaseLineItemsBulk(dataItems);
      res.status(201).json(created);
    } catch (error) {
      console.error("Error bulk creating lease line items:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create line items" });
      }
    }
  });

  // PUT /api/rent-roll/line-items/:id - Update a line item
  app.put("/api/rent-roll/line-items/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const updated = await updateLeaseLineItem(id, req.body);
      
      if (!updated) {
        return res.status(404).json({ error: "Line item not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating lease line item:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to update line item" });
      }
    }
  });

  // DELETE /api/rent-roll/line-items/:id - Delete a line item
  app.delete("/api/rent-roll/line-items/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await deleteLeaseLineItem(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Line item not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting lease line item:", error);
      res.status(500).json({ error: "Failed to delete line item" });
    }
  });

  // GET /api/rent-roll/line-items/:id - Get a single line item
  app.get("/api/rent-roll/line-items/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const item = await getLeaseLineItemById(id);
      
      if (!item) {
        return res.status(404).json({ error: "Line item not found" });
      }
      
      res.json(item);
    } catch (error) {
      console.error("Error fetching lease line item:", error);
      res.status(500).json({ error: "Failed to fetch line item" });
    }
  });

  // ============================================================================
  // MARINA LOCATIONS ROUTES
  // ============================================================================

  // GET /api/rent-roll/locations - Get all marina locations
  app.get("/api/rent-roll/locations", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const locations = await getAllLocations(organizationIds);
      res.json(locations);
    } catch (error) {
      console.error("Error fetching locations:", error);
      res.status(500).json({ error: "Failed to fetch locations" });
    }
  });

  // GET /api/rent-roll/locations/active - Get active locations only
  app.get("/api/rent-roll/locations/active", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const locations = await getActiveLocations(organizationIds);
      res.json(locations);
    } catch (error) {
      console.error("Error fetching active locations:", error);
      res.status(500).json({ error: "Failed to fetch active locations" });
    }
  });

  // GET /api/rent-roll/locations/:id - Get a single location by ID
  app.get("/api/rent-roll/locations/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const location = await getLocationById(id);
      
      if (!location) {
        return res.status(404).json({ error: "Location not found" });
      }
      
      res.json(location);
    } catch (error) {
      console.error("Error fetching location:", error);
      res.status(500).json({ error: "Failed to fetch location" });
    }
  });

  // POST /api/rent-roll/locations/check-duplicate - Check if project name already exists
  // Note: Database has a global unique constraint on name, so we check all projects
  app.post("/api/rent-roll/locations/check-duplicate", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const { name } = req.body;
      
      if (!name || typeof name !== 'string') {
        return res.status(400).json({ error: "Name is required" });
      }
      
      // Check ALL locations since database has global unique constraint on name
      const allLocations = await db.query.marinaLocations.findMany();
      
      // Check for case-insensitive name match
      const normalizedName = name.trim().toLowerCase();
      const existingProject = allLocations.find(
        loc => loc.name.trim().toLowerCase() === normalizedName
      );
      
      if (existingProject) {
        // Check if the existing project belongs to user's organization
        const isUserProject = organizationIds.includes(existingProject.organizationId);
        
        res.json({
          isDuplicate: true,
          existingProject: {
            id: existingProject.id,
            name: existingProject.name,
            projectType: existingProject.projectType,
          },
          // Only allow merge/replace if user owns the project
          canModify: isUserProject,
        });
      } else {
        res.json({ isDuplicate: false });
      }
    } catch (error) {
      console.error("Error checking duplicate:", error);
      res.status(500).json({ error: "Failed to check for duplicate" });
    }
  });

  // POST /api/rent-roll/locations - Create new marina location
  app.post("/api/rent-roll/locations", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      
      if (userOrgs.length === 0) {
        return res.status(403).json({ 
          error: "Access denied: You must belong to an organization" 
        });
      }
      
      // Auto-assign to user's first organization if not specified
      const organizationId = req.body.organizationId || userOrgs[0].id;
      const organizationIds = userOrgs.map(org => org.id);
      
      if (!organizationIds.includes(organizationId)) {
        return res.status(403).json({ 
          error: "Access denied: You must specify an organization you belong to" 
        });
      }
      
      const validated = insertMarinaLocationSchema.parse({
        ...req.body,
        organizationId,
      });
      
      const location = await createLocation(validated);
      
      // Audit log: project creation
      const auditContext: AuditLogContext = { userId, organizationId };
      await logProjectCreate(auditContext, location.id, {
        name: location.name,
        projectType: location.projectType,
      });
      
      res.status(201).json(location);
    } catch (error) {
      console.error("Error creating location:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create location" });
      }
    }
  });

  // PUT /api/rent-roll/locations/:id - Update existing marina location
  app.put("/api/rent-roll/locations/:id", isAuthenticated, requireLocationAccess(storage), async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Get previous state for audit log
      const previousLocation = await getLocationById(id);
      
      const validated = insertMarinaLocationSchema.partial().parse(req.body);
      const location = await updateLocation(id, validated);
      
      // Audit log: project update
      const userId = req.user?.claims?.sub;
      if (userId && previousLocation) {
        const userOrgs = await storage.getUserOrganizations(userId);
        if (userOrgs.length > 0) {
          const auditContext: AuditLogContext = { userId, organizationId: userOrgs[0].id };
          await logProjectUpdate(auditContext, id, validated, {
            name: previousLocation.name,
            projectType: previousLocation.projectType,
          });
        }
      }
      
      res.json(location);
    } catch (error) {
      console.error("Error updating location:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to update location" });
      }
    }
  });

  // POST /api/rent-roll/locations/:id/sync-capacity - Sync project capacity from storage locations
  app.post("/api/rent-roll/locations/:id/sync-capacity", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { id } = req.params;
      
      // Get all active storage locations for this project and sum their capacities
      const storageLocationsList = await db.query.storageLocations.findMany({
        where: and(
          eq(storageLocations.projectId, id),
          eq(storageLocations.isActive, true)
        ),
      });
      
      const totalCapacity = storageLocationsList.reduce((sum, loc) => sum + (loc.capacity || 0), 0);
      
      // Update the project's capacity field
      const location = await updateLocation(id, { capacity: totalCapacity });
      
      res.json({ 
        success: true, 
        capacity: totalCapacity,
        storageLocationsCount: storageLocationsList.length,
        location 
      });
    } catch (error) {
      console.error("Error syncing capacity:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to sync capacity" });
      }
    }
  });

  // POST /api/rent-roll/locations/:id/reset - Reset/clear all data for a project
  app.post("/api/rent-roll/locations/:id/reset", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { id } = req.params;
      const { confirmationName } = req.body;
      
      // Get location to verify confirmation name
      const location = await getLocationById(id);
      if (!location) {
        return res.status(404).json({ error: "Location not found" });
      }
      
      // Verify confirmation name matches
      if (confirmationName !== location.name) {
        return res.status(400).json({ error: "Confirmation name does not match project name" });
      }
      
      const result = await resetProjectData(id);
      res.json(result);
    } catch (error) {
      console.error("Error resetting project data:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to reset project data" });
      }
    }
  });

  // DELETE /api/rent-roll/locations/:id - Delete marina location
  app.delete("/api/rent-roll/locations/:id", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { id } = req.params;
      await deleteLocation(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting location:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to delete location" });
      }
    }
  });

  // POST /api/rent-roll/locations/:id/backfill-cashflows - Backfill cash flows for incomplete leases with amounts
  app.post("/api/rent-roll/locations/:id/backfill-cashflows", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { id } = req.params;
      
      const result = await backfillCashFlowsForIncompleteLeasesWithAmounts(id);
      res.json(result);
    } catch (error) {
      console.error("Error backfilling cash flows:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to backfill cash flows" });
      }
    }
  });

  // POST /api/rent-roll/locations/:id/regenerate-cashflows - Regenerate ALL cash flows for a project
  app.post("/api/rent-roll/locations/:id/regenerate-cashflows", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { id } = req.params;
      
      const result = await regenerateAllCashFlowsForProject(id);
      res.json(result);
    } catch (error) {
      console.error("Error regenerating cash flows:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to regenerate cash flows" });
      }
    }
  });

  // POST /api/rent-roll/backfill-cashflows - Backfill cash flows for all incomplete leases with amounts (global)
  app.post("/api/rent-roll/backfill-cashflows", isAuthenticated, async (req, res) => {
    try {
      const result = await backfillCashFlowsForIncompleteLeasesWithAmounts();
      res.json(result);
    } catch (error) {
      console.error("Error backfilling cash flows:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to backfill cash flows" });
      }
    }
  });

  // GET /api/rent-roll/location-occupancy - Get occupancy stats by location
  app.get("/api/rent-roll/location-occupancy", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      const occupancy = await getLocationOccupancy(
        startDate as string,
        endDate as string
      );
      res.json(occupancy);
    } catch (error) {
      console.error("Error fetching location occupancy:", error);
      res.status(500).json({ error: "Failed to fetch location occupancy" });
    }
  });

  // ============================================================================
  // STORAGE LOCATIONS ROUTES (Physical locations within projects)
  // ============================================================================

  // GET /api/rent-roll/storage-locations?projectId=:projectId - Get all storage locations for a project
  app.get("/api/rent-roll/storage-locations", isAuthenticated, async (req, res) => {
    try {
      const { projectId } = req.query;
      
      if (!projectId || typeof projectId !== 'string') {
        return res.status(400).json({ error: "projectId is required" });
      }
      
      const locations = await getStorageLocationsByProject(projectId);
      res.json(locations);
    } catch (error) {
      console.error("Error fetching storage locations:", error);
      res.status(500).json({ error: "Failed to fetch storage locations" });
    }
  });

  // GET /api/rent-roll/storage-locations/:id - Get a single storage location by ID
  app.get("/api/rent-roll/storage-locations/:id", isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const location = await getStorageLocationById(id);
      
      if (!location) {
        return res.status(404).json({ error: "Storage location not found" });
      }
      
      res.json(location);
    } catch (error) {
      console.error("Error fetching storage location:", error);
      res.status(500).json({ error: "Failed to fetch storage location" });
    }
  });

  // POST /api/rent-roll/storage-locations - Create new storage location
  app.post("/api/rent-roll/storage-locations", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const validated = insertStorageLocationSchema.parse(req.body);
      
      // Validate user has access to the project (marina location)
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const validation = await validateLocationOwnership(validated.projectId, organizationIds);
      if (!validation.valid) {
        return res.status(403).json({ error: validation.error });
      }
      
      const location = await createStorageLocation(validated);
      res.status(201).json(location);
    } catch (error) {
      console.error("Error creating storage location:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create storage location" });
      }
    }
  });

  // PUT /api/rent-roll/storage-locations/:id - Update existing storage location
  app.put("/api/rent-roll/storage-locations/:id", isAuthenticated, requireStorageLocationAccess(storage), async (req, res) => {
    try {
      const { id } = req.params;
      const validated = insertStorageLocationSchema.partial().parse(req.body);
      const location = await updateStorageLocation(id, validated);
      
      if (!location) {
        return res.status(404).json({ error: "Storage location not found" });
      }
      
      res.json(location);
    } catch (error) {
      console.error("Error updating storage location:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to update storage location" });
      }
    }
  });

  // DELETE /api/rent-roll/storage-locations/:id - Delete storage location
  app.delete("/api/rent-roll/storage-locations/:id", isAuthenticated, requireStorageLocationAccess(storage), async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await deleteStorageLocation(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Storage location not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting storage location:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to delete storage location" });
      }
    }
  });

  // ============================================================================
  // CUSTOM STORAGE TYPES ROUTES (Protected)
  // ============================================================================

  // GET /api/rent-roll/custom-storage-types - Get all custom storage types for user's organization
  app.get("/api/rent-roll/custom-storage-types", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.json([]);
      }
      const organizationId = userOrgs[0].organizationId;
      
      const customTypes = await db.query.customStorageTypes.findMany({
        where: (customStorageTypes, { eq }) => eq(customStorageTypes.organizationId, organizationId),
        orderBy: (customStorageTypes, { asc }) => [asc(customStorageTypes.name)],
      });
      res.json(customTypes);
    } catch (error) {
      console.error("Error fetching custom storage types:", error);
      res.status(500).json({ error: "Failed to fetch custom storage types" });
    }
  });

  // POST /api/rent-roll/custom-storage-types - Create new custom storage type
  app.post("/api/rent-roll/custom-storage-types", isAuthenticated, async (req: any, res) => {
    try {
      const { name } = req.body;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      if (!name || typeof name !== "string" || name.trim() === "") {
        return res.status(400).json({ error: "Storage type name is required" });
      }
      
      // Check if already exists for this organization
      const existing = await db.query.customStorageTypes.findFirst({
        where: (customStorageTypes, { eq, and }) => and(
          eq(customStorageTypes.organizationId, organizationId),
          eq(customStorageTypes.name, name.trim())
        ),
      });
      
      if (existing) {
        return res.status(409).json({ error: "Storage type already exists" });
      }
      
      // Insert new custom storage type
      const [newType] = await db.insert(customStorageTypes).values({
        organizationId,
        name: name.trim(),
      }).returning();
      
      // Add to admin review queue for potential promotion to global defaults
      try {
        // Get organization name for display
        const org = await db.query.organizations.findFirst({
          where: (orgs, { eq }) => eq(orgs.id, organizationId),
        });
        
        await db.insert(adminTypeReviewQueue).values({
          category: "storage_type",
          name: name.trim(),
          organizationId,
          organizationName: org?.name || "Unknown Organization",
          sourceCustomTypeId: newType.id,
          status: "pending",
          usageCount: 1,
        }).onConflictDoUpdate({
          target: [adminTypeReviewQueue.category, adminTypeReviewQueue.name, adminTypeReviewQueue.organizationId],
          set: {
            usageCount: sql`${adminTypeReviewQueue.usageCount} + 1`,
            updatedAt: new Date(),
          },
        });
      } catch (reviewErr) {
        console.error("Error adding to admin review queue:", reviewErr);
        // Don't fail the main request if review queue update fails
      }
      
      res.status(201).json(newType);
    } catch (error) {
      console.error("Error creating custom storage type:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create custom storage type" });
      }
    }
  });

  // ============================================================================
  // CUSTOM CONTRACT TERMS ROUTES (Protected)
  // ============================================================================

  // GET /api/rent-roll/custom-contract-terms - Get all custom contract terms for user's organization
  app.get("/api/rent-roll/custom-contract-terms", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.json([]);
      }
      const organizationId = userOrgs[0].organizationId;
      
      const customTerms = await db.query.customContractTerms.findMany({
        where: (customContractTerms, { eq }) => eq(customContractTerms.organizationId, organizationId),
        orderBy: (customContractTerms, { asc }) => [asc(customContractTerms.name)],
      });
      res.json(customTerms);
    } catch (error) {
      console.error("Error fetching custom contract terms:", error);
      res.status(500).json({ error: "Failed to fetch custom contract terms" });
    }
  });

  // POST /api/rent-roll/custom-contract-terms - Create new custom contract term
  app.post("/api/rent-roll/custom-contract-terms", isAuthenticated, async (req: any, res) => {
    try {
      const { name } = req.body;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      if (!name || typeof name !== "string" || name.trim() === "") {
        return res.status(400).json({ error: "Contract term name is required" });
      }
      
      // Check if already exists for this organization
      const existing = await db.query.customContractTerms.findFirst({
        where: (customContractTerms, { eq, and }) => and(
          eq(customContractTerms.organizationId, organizationId),
          eq(customContractTerms.name, name.trim())
        ),
      });
      
      if (existing) {
        return res.status(409).json({ error: "Contract term already exists" });
      }
      
      // Insert new custom contract term
      const [newTerm] = await db.insert(customContractTerms).values({
        organizationId,
        name: name.trim(),
      }).returning();
      
      // Add to admin review queue for potential promotion to global defaults
      try {
        const org = await db.query.organizations.findFirst({
          where: (orgs, { eq }) => eq(orgs.id, organizationId),
        });
        
        await db.insert(adminTypeReviewQueue).values({
          category: "contract_term",
          name: name.trim(),
          organizationId,
          organizationName: org?.name || "Unknown Organization",
          sourceCustomTypeId: newTerm.id,
          status: "pending",
          usageCount: 1,
        }).onConflictDoUpdate({
          target: [adminTypeReviewQueue.category, adminTypeReviewQueue.name, adminTypeReviewQueue.organizationId],
          set: {
            usageCount: sql`${adminTypeReviewQueue.usageCount} + 1`,
            updatedAt: new Date(),
          },
        });
      } catch (reviewErr) {
        console.error("Error adding to admin review queue:", reviewErr);
      }
      
      res.status(201).json(newTerm);
    } catch (error) {
      console.error("Error creating custom contract term:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create custom contract term" });
      }
    }
  });

  // DELETE /api/rent-roll/custom-storage-types/:id - Delete custom storage type
  app.delete("/api/rent-roll/custom-storage-types/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      // Check if the item exists and belongs to user's organization
      const existing = await db.query.customStorageTypes.findFirst({
        where: (customStorageTypes, { eq, and }) => and(
          eq(customStorageTypes.id, id),
          eq(customStorageTypes.organizationId, organizationId)
        ),
      });
      
      if (!existing) {
        return res.status(404).json({ error: "Storage type not found" });
      }
      
      await db.delete(customStorageTypes).where(eq(customStorageTypes.id, id));
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting custom storage type:", error);
      res.status(500).json({ error: "Failed to delete custom storage type" });
    }
  });

  // DELETE /api/rent-roll/custom-contract-terms/:id - Delete custom contract term
  app.delete("/api/rent-roll/custom-contract-terms/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      // Check if the item exists and belongs to user's organization
      const existing = await db.query.customContractTerms.findFirst({
        where: (customContractTerms, { eq, and }) => and(
          eq(customContractTerms.id, id),
          eq(customContractTerms.organizationId, organizationId)
        ),
      });
      
      if (!existing) {
        return res.status(404).json({ error: "Contract term not found" });
      }
      
      await db.delete(customContractTerms).where(eq(customContractTerms.id, id));
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting custom contract term:", error);
      res.status(500).json({ error: "Failed to delete custom contract term" });
    }
  });

  // GET /api/rent-roll/custom-rate-types - Get all custom rate types for user's organization
  app.get("/api/rent-roll/custom-rate-types", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.json([]);
      }
      const organizationId = userOrgs[0].organizationId;
      
      const rateTypes = await db.query.customRateTypes.findMany({
        where: (customRateTypes, { eq }) => eq(customRateTypes.organizationId, organizationId),
        orderBy: (customRateTypes, { asc }) => [asc(customRateTypes.name)],
      });
      res.json(rateTypes);
    } catch (error) {
      console.error("Error fetching custom rate types:", error);
      res.status(500).json({ error: "Failed to fetch custom rate types" });
    }
  });

  // POST /api/rent-roll/custom-rate-types - Create new custom rate type
  app.post("/api/rent-roll/custom-rate-types", isAuthenticated, async (req: any, res) => {
    try {
      const { name } = req.body;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      if (!name || typeof name !== "string" || name.trim() === "") {
        return res.status(400).json({ error: "Rate type name is required" });
      }
      
      // Check if already exists for this organization
      const existing = await db.query.customRateTypes.findFirst({
        where: (customRateTypes, { eq, and }) => and(
          eq(customRateTypes.organizationId, organizationId),
          eq(customRateTypes.name, name.trim())
        ),
      });
      
      if (existing) {
        return res.status(409).json({ error: "Rate type already exists" });
      }
      
      // Insert new custom rate type
      const [newType] = await db.insert(customRateTypes).values({
        organizationId,
        name: name.trim(),
      }).returning();
      
      // Add to admin review queue for potential promotion to global defaults
      try {
        const org = await db.query.organizations.findFirst({
          where: (orgs, { eq }) => eq(orgs.id, organizationId),
        });
        
        await db.insert(adminTypeReviewQueue).values({
          category: "rate_type",
          name: name.trim(),
          organizationId,
          organizationName: org?.name || "Unknown Organization",
          sourceCustomTypeId: newType.id,
          status: "pending",
          usageCount: 1,
        }).onConflictDoUpdate({
          target: [adminTypeReviewQueue.category, adminTypeReviewQueue.name, adminTypeReviewQueue.organizationId],
          set: {
            usageCount: sql`${adminTypeReviewQueue.usageCount} + 1`,
            updatedAt: new Date(),
          },
        });
      } catch (reviewErr) {
        console.error("Error adding to admin review queue:", reviewErr);
      }
      
      res.status(201).json(newType);
    } catch (error) {
      console.error("Error creating custom rate type:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create custom rate type" });
      }
    }
  });

  // DELETE /api/rent-roll/custom-rate-types/:id - Delete custom rate type
  app.delete("/api/rent-roll/custom-rate-types/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      // Check if the item exists and belongs to user's organization
      const existing = await db.query.customRateTypes.findFirst({
        where: (customRateTypes, { eq, and }) => and(
          eq(customRateTypes.id, id),
          eq(customRateTypes.organizationId, organizationId)
        ),
      });
      
      if (!existing) {
        return res.status(404).json({ error: "Rate type not found" });
      }
      
      await db.delete(customRateTypes).where(eq(customRateTypes.id, id));
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting custom rate type:", error);
      res.status(500).json({ error: "Failed to delete custom rate type" });
    }
  });

  // GET /api/rent-roll/custom-slip-statuses - Get all custom slip statuses for user's organization
  app.get("/api/rent-roll/custom-slip-statuses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.json([]);
      }
      const organizationId = userOrgs[0].organizationId;
      
      const slipStatuses = await db.query.customSlipStatuses.findMany({
        where: (customSlipStatuses, { eq }) => eq(customSlipStatuses.organizationId, organizationId),
        orderBy: (customSlipStatuses, { asc }) => [asc(customSlipStatuses.name)],
      });
      res.json(slipStatuses);
    } catch (error) {
      console.error("Error fetching custom slip statuses:", error);
      res.status(500).json({ error: "Failed to fetch custom slip statuses" });
    }
  });

  // POST /api/rent-roll/custom-slip-statuses - Create new custom slip status
  app.post("/api/rent-roll/custom-slip-statuses", isAuthenticated, async (req: any, res) => {
    try {
      const { name } = req.body;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      if (!name || typeof name !== "string" || name.trim() === "") {
        return res.status(400).json({ error: "Slip status name is required" });
      }
      
      // Check if already exists for this organization
      const existing = await db.query.customSlipStatuses.findFirst({
        where: (customSlipStatuses, { eq, and }) => and(
          eq(customSlipStatuses.organizationId, organizationId),
          eq(customSlipStatuses.name, name.trim())
        ),
      });
      
      if (existing) {
        return res.status(409).json({ error: "Slip status already exists" });
      }
      
      // Insert new custom slip status
      const [newStatus] = await db.insert(customSlipStatuses).values({
        organizationId,
        name: name.trim(),
      }).returning();
      
      // Add to admin review queue for potential promotion to global defaults
      try {
        const org = await db.query.organizations.findFirst({
          where: (orgs, { eq }) => eq(orgs.id, organizationId),
        });
        
        await db.insert(adminTypeReviewQueue).values({
          category: "slip_status",
          name: name.trim(),
          organizationId,
          organizationName: org?.name || "Unknown Organization",
          sourceCustomTypeId: newStatus.id,
          status: "pending",
          usageCount: 1,
        }).onConflictDoUpdate({
          target: [adminTypeReviewQueue.category, adminTypeReviewQueue.name, adminTypeReviewQueue.organizationId],
          set: {
            usageCount: sql`${adminTypeReviewQueue.usageCount} + 1`,
            updatedAt: new Date(),
          },
        });
      } catch (reviewErr) {
        console.error("Error adding to admin review queue:", reviewErr);
      }
      
      res.status(201).json(newStatus);
    } catch (error) {
      console.error("Error creating custom slip status:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create custom slip status" });
      }
    }
  });

  // DELETE /api/rent-roll/custom-slip-statuses/:id - Delete custom slip status
  app.delete("/api/rent-roll/custom-slip-statuses/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "User not in any organization" });
      }
      const organizationId = userOrgs[0].organizationId;
      
      // Check if the item exists and belongs to user's organization
      const existing = await db.query.customSlipStatuses.findFirst({
        where: (customSlipStatuses, { eq, and }) => and(
          eq(customSlipStatuses.id, id),
          eq(customSlipStatuses.organizationId, organizationId)
        ),
      });
      
      if (!existing) {
        return res.status(404).json({ error: "Slip status not found" });
      }
      
      await db.delete(customSlipStatuses).where(eq(customSlipStatuses.id, id));
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting custom slip status:", error);
      res.status(500).json({ error: "Failed to delete custom slip status" });
    }
  });

  // ============================================================================
  // PROJECT DETAILS CONFIGURATION ROUTES (Protected)
  // ============================================================================

  // GET /api/rent-roll/locations/:locationId/details-config - Get project details configuration
  app.get("/api/rent-roll/locations/:locationId/details-config", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const config = await getProjectDetailsConfig(locationId);
      res.json(config);
    } catch (error) {
      console.error("Error fetching project details configuration:", error);
      res.status(500).json({ error: "Failed to fetch project details configuration" });
    }
  });

  // PUT /api/rent-roll/locations/:locationId/details-config - Update project details configuration
  app.put("/api/rent-roll/locations/:locationId/details-config", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { enabledStorageTypes, dualSeasonStorageTypes, enabledRateTypes, enabledContractTerms, enabledSlipStatuses } = req.body;
      
      const config = await upsertProjectDetailsConfig(locationId, {
        enabledStorageTypes,
        dualSeasonStorageTypes,
        enabledRateTypes,
        enabledContractTerms,
        enabledSlipStatuses,
      });
      
      res.json(config);
    } catch (error) {
      console.error("Error updating project details configuration:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to update project details configuration" });
      }
    }
  });

  // GET /api/rent-roll/project-hub-metrics - Get comprehensive metrics for all projects/locations
  app.get("/api/rent-roll/project-hub-metrics", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const metrics = await getProjectHubMetrics(organizationIds);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching project hub metrics:", error);
      res.status(500).json({ error: "Failed to fetch project hub metrics" });
    }
  });

  // GET /api/rent-roll/included-projects - Get list of projects included in executive summary
  app.get("/api/rent-roll/included-projects", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const conditions = [
        eq(marinaLocations.isActive, true),
        eq(marinaLocations.includeInExecutive, true),
      ];
      
      if (organizationIds.length > 0) {
        conditions.push(inArray(marinaLocations.organizationId, organizationIds));
      }
      
      const projects = await db.query.marinaLocations.findMany({
        where: and(...conditions),
        columns: {
          id: true,
          name: true,
          projectType: true,
        },
        orderBy: [desc(marinaLocations.projectType), desc(marinaLocations.createdAt)],
      });
      
      const result = projects.map(p => ({
        locationId: p.id,
        name: p.name,
        projectType: p.projectType,
      }));
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching included projects:", error);
      res.status(500).json({ error: "Failed to fetch included projects" });
    }
  });

  // ============================================================================
  // BULK IMPORT ROUTES
  // ============================================================================

  // Valid options for enum fields (used for value mapping during import)
  const VALID_STORAGE_TYPES = [
    "Wet Slip", "Lift Slip", "Mooring", "Jet Ski", 
    "Dry Rack - Indoor", "Dry Rack - Outdoor", "Houseboat",
    "Land Storage", "Boat on Trailer", "Trailer Only", 
    "Carport", "RV Site", "Other"
  ];
  
  const VALID_SLIP_STATUSES = [
    "Occupied", "Vacant", "Reserved", "Maintenance",
    "Occupied; Not-Paying", "Sold", "Unusable", "Pending"
  ];
  
  const VALID_CONTRACT_TERMS = [
    "Annual", "Seasonal/Summer", "6-Months", "3-Months", 
    "Winter", "Monthly", "Weekly", "Daily/Nightly"
  ];

  // POST /api/rent-roll/leases/import/detect-values - Detect unrecognized values in import data
  app.post("/api/rent-roll/leases/import/detect-values", isAuthenticated, async (req, res) => {
    try {
      const { rows, columnMapping } = req.body;
      
      if (!Array.isArray(rows)) {
        return res.status(400).json({ error: "Expected rows array" });
      }
      
      // Fields to check for unrecognized values
      const fieldsToCheck = [
        { fieldId: "storageType", label: "Storage Type", validValues: VALID_STORAGE_TYPES },
        { fieldId: "slipStatus", label: "Slip Status", validValues: VALID_SLIP_STATUSES },
        { fieldId: "contractTerm", label: "Contract Term", validValues: VALID_CONTRACT_TERMS },
      ];
      
      const unrecognizedValues: Record<string, {
        fieldLabel: string;
        values: string[];
        validOptions: string[];
        occurrences: Record<string, number>;
      }> = {};
      
      // For each field, collect unique values and check against valid options
      for (const field of fieldsToCheck) {
        const csvColumn = columnMapping?.[field.fieldId];
        if (!csvColumn) continue; // Field not mapped
        
        const valueOccurrences: Record<string, number> = {};
        
        // Collect unique values from the mapped column
        for (const row of rows) {
          const rawValue = row[csvColumn];
          if (rawValue && String(rawValue).trim()) {
            const value = String(rawValue).trim();
            valueOccurrences[value] = (valueOccurrences[value] || 0) + 1;
          }
        }
        
        // Check which values are not in the valid options (case-insensitive)
        const unrecognized: string[] = [];
        const validLower = field.validValues.map(v => v.toLowerCase());
        
        for (const value of Object.keys(valueOccurrences)) {
          if (!validLower.includes(value.toLowerCase())) {
            unrecognized.push(value);
          }
        }
        
        if (unrecognized.length > 0) {
          unrecognizedValues[field.fieldId] = {
            fieldLabel: field.label,
            values: unrecognized,
            validOptions: field.validValues,
            occurrences: Object.fromEntries(
              Object.entries(valueOccurrences).filter(([k]) => unrecognized.includes(k))
            ),
          };
        }
      }
      
      res.json({
        hasUnrecognizedValues: Object.keys(unrecognizedValues).length > 0,
        unrecognizedValues,
      });
    } catch (error) {
      console.error("Error detecting unrecognized values:", error);
      res.status(500).json({ error: "Failed to detect unrecognized values" });
    }
  });

  // POST /api/rent-roll/leases/import/suggest-mappings - Get AI suggestions for value mappings
  app.post("/api/rent-roll/leases/import/suggest-mappings", isAuthenticated, async (req, res) => {
    try {
      const { unrecognizedValues } = req.body;
      
      if (!unrecognizedValues || typeof unrecognizedValues !== 'object') {
        return res.status(400).json({ error: "Expected unrecognizedValues object" });
      }

      // Use AI to suggest mappings
      const suggestions = await suggestValueMappings(unrecognizedValues);
      
      res.json({ suggestions });
    } catch (error) {
      console.error("Error getting AI mapping suggestions:", error);
      res.status(500).json({ error: "Failed to get AI suggestions" });
    }
  });

  // POST /api/rent-roll/leases/import/suggest-column-mappings - Get AI suggestions for column header mappings
  app.post("/api/rent-roll/leases/import/suggest-column-mappings", isAuthenticated, async (req, res) => {
    try {
      const { headers, sampleRows, availableFields } = req.body;
      
      if (!headers || !Array.isArray(headers)) {
        return res.status(400).json({ error: "Expected headers array" });
      }
      if (!sampleRows || !Array.isArray(sampleRows)) {
        return res.status(400).json({ error: "Expected sampleRows array" });
      }
      if (!availableFields || !Array.isArray(availableFields)) {
        return res.status(400).json({ error: "Expected availableFields array" });
      }

      // Use AI to suggest column mappings
      const result = await suggestColumnMappings(headers, sampleRows, availableFields);
      
      res.json(result);
    } catch (error) {
      console.error("Error getting AI column mapping suggestions:", error);
      res.status(500).json({ error: "Failed to get AI column mapping suggestions" });
    }
  });

  // POST /api/rent-roll/leases/import/pdf - Parse PDF and extract lease data using AI
  app.post("/api/rent-roll/leases/import/pdf", isAuthenticated, async (req, res) => {
    try {
      const { pdfBase64 } = req.body;
      
      if (!pdfBase64 || typeof pdfBase64 !== 'string') {
        return res.status(400).json({ error: "Expected pdfBase64 string" });
      }

      // Decode base64 PDF
      const pdfBuffer = Buffer.from(pdfBase64, 'base64');
      
      // Check file size (10MB max)
      const maxSize = 10 * 1024 * 1024;
      if (pdfBuffer.length > maxSize) {
        return res.status(400).json({ error: "PDF file too large. Maximum size is 10MB." });
      }

      // Import pdf-parse dynamically - uses PDFParse class (v2 API)
      const { PDFParse } = await import('pdf-parse');
      
      // Extract text from PDF using class-based API
      let pdfText: string = '';
      let pageCount: number = 0;
      let parser: InstanceType<typeof PDFParse> | null = null;
      
      try {
        parser = new PDFParse({ data: pdfBuffer });
        const result = await parser.getText();
        pdfText = result.text || '';
        pageCount = result.total || 0;
      } catch (pdfError) {
        console.error("PDF parsing error:", pdfError);
        return res.status(400).json({ 
          error: "Could not read PDF file. It may be password-protected, corrupted, or contain only images." 
        });
      } finally {
        // Clean up parser resources
        if (parser) {
          try {
            await parser.destroy();
          } catch {
            // Ignore cleanup errors
          }
        }
      }

      if (!pdfText || pdfText.trim().length === 0) {
        return res.status(400).json({ 
          error: "PDF appears to contain no extractable text. It may be a scanned document or contain only images." 
        });
      }

      // Use AI to extract lease data from the PDF text
      const { extractLeasesFromPdfText } = await import('./aiAddressParser');
      const result = await extractLeasesFromPdfText(pdfText);
      
      // Add page count from PDF metadata
      result.pageCount = pageCount;

      res.json(result);
    } catch (error) {
      console.error("Error processing PDF:", error);
      res.status(500).json({ error: "Failed to process PDF file" });
    }
  });

  // POST /api/rent-roll/leases/import/parse - Parse and validate CSV for bulk import preview
  app.post("/api/rent-roll/leases/import/parse", isAuthenticated, async (req, res) => {
    try {
      const { rows, headers, columnMapping } = req.body;
      
      if (!Array.isArray(rows)) {
        return res.status(400).json({ error: "Expected rows array" });
      }

      let columnMap: Map<string, string>;

      // If columnMapping is provided (user-mapped columns), create identity map
      // Rows already have field IDs as keys from frontend mapping
      if (columnMapping && typeof columnMapping === 'object') {
        // Create identity mapping: fieldId -> fieldId
        // Since frontend already mapped the rows to have field IDs as keys
        columnMap = new Map();
        Object.keys(columnMapping).forEach(fieldId => {
          columnMap.set(fieldId, fieldId);
        });
      } else if (Array.isArray(headers)) {
        // Legacy automatic column mapping (for backward compatibility)
        columnMap = mapColumnHeaders(headers);
      } else {
        return res.status(400).json({ error: "Expected columnMapping object or headers array" });
      }

      // Process full addresses with AI before parsing rows
      const processedRows = await processFullAddresses(rows, columnMap);

      // Parse and validate each row
      // Skip missing column check for user-provided mappings (frontend validates required fields)
      const skipMissingColumnCheck = !!(columnMapping && typeof columnMapping === 'object');
      const parsedRows: ParsedImportRow[] = processedRows.map((row, index) => 
        parseImportRow(row, index, columnMap, skipMissingColumnCheck)
      );

      // Check for duplicates
      const rowsWithDuplicateCheck = await findDuplicateTenants(parsedRows);
      
      // Get locationId from request if provided (for validation against existing data)
      const { locationId } = req.body;
      
      // Validate slip uniqueness (within import and against existing leases)
      const rowsWithSlipCheck = await validateSlipUniqueness(rowsWithDuplicateCheck, locationId);
      
      // Validate contract date overlaps (same tenant with overlapping periods)
      const rowsWithOverlapCheck = await validateContractOverlaps(rowsWithSlipCheck, locationId);

      res.json({
        parsedRows: rowsWithOverlapCheck,
        columnMapping: Object.fromEntries(columnMap),
      });
    } catch (error) {
      console.error("Error parsing import data:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to parse import data" });
      }
    }
  });

  // POST /api/rent-roll/leases/import - Import validated leases
  app.post("/api/rent-roll/leases/import", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { 
        rows, 
        skipDuplicates, 
        locationId, 
        fileMetadata, 
        importMode, 
        rateConfiguration,
        // New import options
        defaultStorageType,
        autoApplyContractTermDates,
        projectSeasonDates,
      } = req.body;
      
      if (!Array.isArray(rows)) {
        return res.status(400).json({ error: "Expected rows array" });
      }
      
      // Validate import mode if provided
      const validImportModes = ['create', 'append', 'replace'];
      const mode = validImportModes.includes(importMode) ? importMode : 'create';
      
      // If locationId is provided, validate user has access to it
      if (locationId) {
        const userId = req.user.claims.sub;
        const userOrgs = await storage.getUserOrganizations(userId);
        const organizationIds = userOrgs.map(org => org.id);
        
        const validation = await validateLocationOwnership(locationId, organizationIds);
        if (!validation.valid) {
          return res.status(403).json({ error: validation.error });
        }
      }

      // Filter to only valid rows (no errors)
      // Handle both ParsedImportRow (from frontend with errors array) and raw row objects
      const validRows = rows.filter((row: any) => {
        // If row has errors property, check it's empty
        if (row.errors !== undefined) {
          return Array.isArray(row.errors) && row.errors.length === 0;
        }
        // Otherwise assume it's a raw row object and is valid
        return true;
      });

      if (validRows.length === 0) {
        return res.status(400).json({ error: "No valid rows to import" });
      }

      // Build import options
      const importOptions = {
        defaultStorageType,
        autoApplyContractTermDates,
        projectSeasonDates,
      };
      
      // Import leases with optional locationId for auto-assignment, import mode, rate configuration, and import options
      const result = await importLeases(validRows, skipDuplicates || false, locationId, mode, rateConfiguration, importOptions);

      // Audit log: bulk import
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length > 0 && result.imported > 0) {
        const auditContext: AuditLogContext = { userId, organizationId: userOrgs[0].id };
        await logBulkImport(auditContext, locationId, {
          rowsImported: result.imported,
          rowsSkipped: result.skipped,
          importMode: mode,
          fileName: fileMetadata?.fileName,
        });
      }

      // If file metadata is provided, store the file and track lineage
      // Store file even if all leases were skipped for auditability
      if (fileMetadata && locationId) {
        try {
          const userId = req.user.claims.sub;
          
          // Create uploaded file record
          const uploadedFile = await storage.createUploadedFile({
            projectId: locationId,
            uploaderId: userId,
            sourceFileName: fileMetadata.fileName,
            mimeType: fileMetadata.mimeType,
            byteSize: fileMetadata.byteSize,
            fileData: fileMetadata.fileData,
            parsedSheetName: fileMetadata.sheetName || null,
            importStatus: "completed",
            rowsImported: result.imported,
            uploadedAt: new Date(),
          });

          // Track data lineage for imported leases
          if (result.details && result.details.created && result.details.created.length > 0) {
            for (const createdLease of result.details.created) {
              await storage.createLeaseImport({
                uploadedFileId: uploadedFile.id,
                leaseId: createdLease.leaseId,
                tenantId: createdLease.tenantId,
              });
            }
          }
        } catch (fileError) {
          console.error("Error storing file metadata:", fileError);
          // Don't fail the import if file storage fails
        }
      }

      res.json(result);
    } catch (error) {
      console.error("Error importing leases:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to import leases" });
      }
    }
  });

  // GET /api/rent-roll/monthly-summary - Get monthly cash flow summary
  // PHASE 1: Extended with as-of date, YTD mode, and location filtering
  app.get("/api/rent-roll/monthly-summary", isAuthenticated, async (req, res) => {
    try {
      const { from, to, startDate, endDate, asOfDate, mode, locationId } = req.query;
      
      // Support both old params (from/to) and new options (startDate/endDate/asOfDate/mode)
      if (mode || asOfDate || startDate || endDate) {
        // New options interface
        const summary = await getMonthlySummary({
          startDate: startDate ? new Date(startDate as string) : undefined,
          endDate: endDate ? new Date(endDate as string) : undefined,
          asOfDate: asOfDate ? new Date(asOfDate as string) : undefined,
          mode: mode as "FULL_PERIOD" | "YTD" | undefined,
          locationId: locationId as string | undefined,
        });
        res.json(summary);
      } else {
        // Old params interface (backward compatibility)
        const summary = await getMonthlySummary({
          from: from as string | undefined,
          to: to as string | undefined,
          locationId: locationId as string | undefined,
        });
        res.json(summary);
      }
    } catch (error) {
      console.error("Error fetching monthly summary:", error);
      res.status(500).json({ error: "Failed to fetch monthly summary" });
    }
  });

  // GET /api/rent-roll/summary-drilldown/active-leases - Get active leases for drill-down modal
  app.get("/api/rent-roll/summary-drilldown/active-leases", isAuthenticated, async (req: any, res) => {
    try {
      const { month } = req.query;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Get all locations for this user's organizations
      const locations = await db.query.marinaLocations.findMany({
        where: inArray(marinaLocations.organizationId, organizationIds),
      });
      const locationIds = locations.map(l => l.id);
      
      if (locationIds.length === 0) {
        return res.json([]);
      }
      
      // Get active leases with tenant info
      const activeLeases = await db
        .select({
          id: leases.id,
          customerName: tenants.name,
          vesselName: leases.vesselName,
          unitLocation: leases.unitLocation,
          storageType: leases.storageType,
          leaseAmount: leases.leaseAmount,
          rateType: leases.rateType,
          contractTerm: leases.contractTerm,
          commencementDate: leases.commencementDate,
          expirationDate: leases.expirationDate,
          locationId: leases.locationId,
          locationName: marinaLocations.name,
        })
        .from(leases)
        .innerJoin(tenants, eq(leases.tenantId, tenants.id))
        .innerJoin(marinaLocations, eq(leases.locationId, marinaLocations.id))
        .where(
          and(
            inArray(leases.locationId, locationIds),
            eq(leases.isActive, true),
            isNull(leases.deletedAt)
          )
        )
        .orderBy(marinaLocations.name, tenants.name);
      
      res.json(activeLeases);
    } catch (error) {
      console.error("Error fetching active leases for drilldown:", error);
      res.status(500).json({ error: "Failed to fetch active leases" });
    }
  });

  // GET /api/rent-roll/summary-drilldown/revenue-by-project - Revenue breakdown by project
  app.get("/api/rent-roll/summary-drilldown/revenue-by-project", isAuthenticated, async (req: any, res) => {
    try {
      const { month } = req.query;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Get all locations for this user's organizations
      const locations = await db.query.marinaLocations.findMany({
        where: inArray(marinaLocations.organizationId, organizationIds),
      });
      const locationIds = locations.map(l => l.id);
      
      if (locationIds.length === 0) {
        return res.json([]);
      }
      
      // Parse month to get date range
      const monthDate = new Date(month + "-01");
      const startOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
      const endOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0);
      
      // Get revenue by project from cash flows
      const revenueByProject = await db
        .select({
          projectId: marinaLocations.id,
          projectName: marinaLocations.name,
          revenue: sql<number>`coalesce(sum(${leaseCashFlows.amount}), 0)`,
          leaseCount: sql<number>`count(distinct ${leases.id})`,
        })
        .from(leaseCashFlows)
        .innerJoin(leases, eq(leaseCashFlows.leaseId, leases.id))
        .innerJoin(marinaLocations, eq(leases.locationId, marinaLocations.id))
        .where(
          and(
            inArray(leases.locationId, locationIds),
            gte(leaseCashFlows.periodDate, startOfMonth),
            lte(leaseCashFlows.periodDate, endOfMonth),
            isNull(leases.deletedAt)
          )
        )
        .groupBy(marinaLocations.id, marinaLocations.name)
        .orderBy(sql`sum(${leaseCashFlows.amount}) desc`);
      
      // Calculate percentages
      const totalRevenue = revenueByProject.reduce((sum, r) => sum + Number(r.revenue), 0);
      const result = revenueByProject.map(r => ({
        ...r,
        revenue: Number(r.revenue),
        leaseCount: Number(r.leaseCount),
        percentage: totalRevenue > 0 ? (Number(r.revenue) / totalRevenue) * 100 : 0,
      }));
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching revenue by project for drilldown:", error);
      res.status(500).json({ error: "Failed to fetch revenue by project" });
    }
  });

  // GET /api/rent-roll/summary-drilldown/revenue-by-storage-type - Revenue breakdown by storage type
  app.get("/api/rent-roll/summary-drilldown/revenue-by-storage-type", isAuthenticated, async (req: any, res) => {
    try {
      const { month } = req.query;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Get all locations for this user's organizations
      const locations = await db.query.marinaLocations.findMany({
        where: inArray(marinaLocations.organizationId, organizationIds),
      });
      const locationIds = locations.map(l => l.id);
      
      if (locationIds.length === 0) {
        return res.json([]);
      }
      
      // Parse month to get date range
      const monthDate = new Date(month + "-01");
      const startOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
      const endOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0);
      
      // Get revenue by storage type from cash flows
      const revenueByStorageType = await db
        .select({
          storageType: sql<string>`coalesce(${leases.storageType}, 'Unspecified')`,
          revenue: sql<number>`coalesce(sum(${leaseCashFlows.amount}), 0)`,
          leaseCount: sql<number>`count(distinct ${leases.id})`,
        })
        .from(leaseCashFlows)
        .innerJoin(leases, eq(leaseCashFlows.leaseId, leases.id))
        .where(
          and(
            inArray(leases.locationId, locationIds),
            gte(leaseCashFlows.periodDate, startOfMonth),
            lte(leaseCashFlows.periodDate, endOfMonth),
            isNull(leases.deletedAt)
          )
        )
        .groupBy(leases.storageType)
        .orderBy(sql`sum(${leaseCashFlows.amount}) desc`);
      
      // Calculate percentages
      const totalRevenue = revenueByStorageType.reduce((sum, r) => sum + Number(r.revenue), 0);
      const result = revenueByStorageType.map(r => ({
        storageType: r.storageType || "Unspecified",
        revenue: Number(r.revenue),
        leaseCount: Number(r.leaseCount),
        percentage: totalRevenue > 0 ? (Number(r.revenue) / totalRevenue) * 100 : 0,
      }));
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching revenue by storage type for drilldown:", error);
      res.status(500).json({ error: "Failed to fetch revenue by storage type" });
    }
  });

  // GET /api/rent-roll/summary-drilldown/move-events - Move events for drill-down modal
  app.get("/api/rent-roll/summary-drilldown/move-events", isAuthenticated, async (req: any, res) => {
    try {
      const { month } = req.query;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Get all locations for this user's organizations
      const locations = await db.query.marinaLocations.findMany({
        where: inArray(marinaLocations.organizationId, organizationIds),
      });
      const locationIds = locations.map(l => l.id);
      
      if (locationIds.length === 0) {
        return res.json([]);
      }
      
      // Parse month to get date range
      const monthDate = new Date(month + "-01");
      const startOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
      const endOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0);
      
      // Get move events with lease and tenant info
      const events = await db
        .select({
          id: moveEvents.id,
          leaseId: moveEvents.leaseId,
          customerName: tenants.name,
          vesselName: leases.vesselName,
          unitLocation: leases.unitLocation,
          storageType: leases.storageType,
          leaseAmount: leases.leaseAmount,
          eventDate: moveEvents.eventDate,
          eventType: moveEvents.direction,
          locationId: leases.locationId,
          locationName: marinaLocations.name,
        })
        .from(moveEvents)
        .innerJoin(leases, eq(moveEvents.leaseId, leases.id))
        .innerJoin(tenants, eq(leases.tenantId, tenants.id))
        .innerJoin(marinaLocations, eq(leases.locationId, marinaLocations.id))
        .where(
          and(
            inArray(leases.locationId, locationIds),
            gte(moveEvents.eventDate, startOfMonth),
            lte(moveEvents.eventDate, endOfMonth),
            isNull(leases.deletedAt)
          )
        )
        .orderBy(moveEvents.eventDate);
      
      // Map direction to event type
      const result = events.map(e => ({
        ...e,
        eventType: e.eventType === "in" ? "move-in" : "move-out",
      }));
      
      res.json(result);
    } catch (error) {
      console.error("Error fetching move events for drilldown:", error);
      res.status(500).json({ error: "Failed to fetch move events" });
    }
  });

  // GET /api/rent-roll/summary-drilldown/discrepancies - Data quality issues for drill-down modal
  app.get("/api/rent-roll/summary-drilldown/discrepancies", isAuthenticated, async (req: any, res) => {
    try {
      const { month } = req.query;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Get all locations for this user's organizations
      const locations = await db.query.marinaLocations.findMany({
        where: inArray(marinaLocations.organizationId, organizationIds),
      });
      const locationMap = new Map(locations.map(l => [l.id, l.name]));
      const locationIds = locations.map(l => l.id);
      
      if (locationIds.length === 0) {
        return res.json([]);
      }
      
      // Get active leases with potential issues
      const activeLeases = await db
        .select({
          id: leases.id,
          customerName: tenants.name,
          locationId: leases.locationId,
          leaseAmount: leases.leaseAmount,
          commencementDate: leases.commencementDate,
          expirationDate: leases.expirationDate,
          unitLocation: leases.unitLocation,
        })
        .from(leases)
        .innerJoin(tenants, eq(leases.tenantId, tenants.id))
        .where(
          and(
            inArray(leases.locationId, locationIds),
            eq(leases.isActive, true),
            isNull(leases.deletedAt)
          )
        );
      
      // Get cash flow counts per lease
      const cashFlowCounts = await db
        .select({
          leaseId: leaseCashFlows.leaseId,
          count: sql<number>`count(*)`,
        })
        .from(leaseCashFlows)
        .innerJoin(leases, eq(leaseCashFlows.leaseId, leases.id))
        .where(inArray(leases.locationId, locationIds))
        .groupBy(leaseCashFlows.leaseId);
      
      const cashFlowMap = new Map(cashFlowCounts.map(c => [c.leaseId, Number(c.count)]));
      
      const issues: Array<{
        type: string;
        description: string;
        leaseId: string;
        customerName: string;
        projectName: string;
        projectId: string;
      }> = [];
      
      for (const lease of activeLeases) {
        const projectName = locationMap.get(lease.locationId) || "Unknown";
        
        // Check for missing cash flows
        const cfCount = cashFlowMap.get(lease.id) || 0;
        if (cfCount === 0 && lease.leaseAmount) {
          issues.push({
            type: "missing_cash_flow",
            description: "Active lease has amount but no cash flows generated",
            leaseId: lease.id,
            customerName: lease.customerName,
            projectName,
            projectId: lease.locationId,
          });
        }
        
        // Check for missing dates
        if (!lease.commencementDate || !lease.expirationDate) {
          issues.push({
            type: "missing_dates",
            description: `Missing ${!lease.commencementDate ? "commencement" : "expiration"} date`,
            leaseId: lease.id,
            customerName: lease.customerName,
            projectName,
            projectId: lease.locationId,
          });
        }
        
        // Check for missing amount
        if (!lease.leaseAmount || parseFloat(lease.leaseAmount) === 0) {
          issues.push({
            type: "missing_amount",
            description: "Lease has no amount specified",
            leaseId: lease.id,
            customerName: lease.customerName,
            projectName,
            projectId: lease.locationId,
          });
        }
      }
      
      // Sort by type then customer name
      issues.sort((a, b) => {
        if (a.type !== b.type) return a.type.localeCompare(b.type);
        return a.customerName.localeCompare(b.customerName);
      });
      
      res.json(issues);
    } catch (error) {
      console.error("Error fetching discrepancies for drilldown:", error);
      res.status(500).json({ error: "Failed to fetch discrepancies" });
    }
  });

  // GET /api/rent-roll/lease-matrix - Get per-lease cash flow matrix (PHASE 1)
  app.get("/api/rent-roll/lease-matrix", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, locationId } = req.query;
      
      const matrix = await getLeaseCashFlowMatrix({
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        locationId: locationId as string | undefined,
      });
      
      res.json(matrix);
    } catch (error) {
      console.error("Error fetching lease cash flow matrix:", error);
      res.status(500).json({ error: "Failed to fetch lease cash flow matrix" });
    }
  });

  // GET /api/rent-roll/data-quality - Get data quality validation summary (PHASE 1)
  app.get("/api/rent-roll/data-quality", isAuthenticated, async (req, res) => {
    try {
      const { locationId, asOfDate } = req.query;
      
      const qualitySummary = await getDataQualitySummary({
        locationId: locationId as string | undefined,
        asOfDate: asOfDate ? new Date(asOfDate as string) : undefined,
      });
      
      res.json(qualitySummary);
    } catch (error) {
      console.error("Error fetching data quality summary:", error);
      res.status(500).json({ error: "Failed to fetch data quality summary" });
    }
  });

  // POST /api/rent-roll/pnl-rack-revenue - Upsert P&L rack revenue
  app.post("/api/rent-roll/pnl-rack-revenue", isAuthenticated, async (req, res) => {
    try {
      const data = req.body; // Array of { periodDate, amount }
      
      if (!Array.isArray(data)) {
        return res.status(400).json({ error: "Expected array of revenue data" });
      }
      
      await upsertPnlRackRevenue(data);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error upserting P&L rack revenue:", error);
      res.status(500).json({ error: "Failed to upsert P&L rack revenue" });
    }
  });

  // GET /api/rent-roll/move-events - Get all move events
  app.get("/api/rent-roll/move-events", isAuthenticated, async (req, res) => {
    try {
      const { direction, year, locationId, page, pageSize } = req.query;
      
      const filters = {
        direction: direction as "IN" | "OUT" | undefined,
        year: year ? parseInt(year as string) : undefined,
        locationId: locationId as string | undefined,
        page: page ? parseInt(page as string) : undefined,
        pageSize: pageSize ? parseInt(pageSize as string) : undefined,
      };
      
      const result = await getAllMoveEvents(filters);
      res.json(result);
    } catch (error) {
      console.error("Error fetching move events:", error);
      res.status(500).json({ error: "Failed to fetch move events" });
    }
  });

  // POST /api/rent-roll/move-events - Create new move event
  app.post("/api/rent-roll/move-events", isAuthenticated, async (req, res) => {
    try {
      const validated = insertMoveEventSchema.parse(req.body);
      const event = await createMoveEvent({
        direction: validated.direction,
        customerName: validated.customerName,
        checkedAt: validated.checkedAt,
        vesselLoa: validated.vesselLoa ? parseFloat(validated.vesselLoa.toString()) : undefined,
        subtotal: validated.subtotal ? parseFloat(validated.subtotal.toString()) : undefined,
        sourceSheet: validated.sourceSheet || undefined,
      });
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating move event:", error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: "Failed to create move event" });
      }
    }
  });

  // POST /api/rent-roll/move-events/import - Import move events from CSV
  app.post("/api/rent-roll/move-events/import", isAuthenticated, async (req, res) => {
    try {
      const { events } = req.body; // Array of move event data
      
      if (!Array.isArray(events)) {
        return res.status(400).json({ error: "Expected array of events" });
      }
      
      const created = [];
      for (const eventData of events) {
        const event = await createMoveEvent(eventData);
        created.push(event);
      }
      
      res.status(201).json({ imported: created.length, events: created });
    } catch (error) {
      console.error("Error importing move events:", error);
      res.status(500).json({ error: "Failed to import move events" });
    }
  });

  // GET /api/rent-roll/address-heatmap - Get address heat map data
  app.get("/api/rent-roll/address-heatmap", isAuthenticated, async (req, res) => {
    try {
      const { group, locationId } = req.query;
      
      if (group !== "state" && group !== "city") {
        return res.status(400).json({ error: "Group must be 'state' or 'city'" });
      }
      
      const data = await getAddressHeatMap(
        group,
        locationId as string | undefined
      );
      res.json(data);
    } catch (error) {
      console.error("Error fetching address heatmap:", error);
      res.status(500).json({ error: "Failed to fetch address heatmap" });
    }
  });

  // GET /api/rent-roll/revenue-by-storage-type - Get revenue breakdown by storage type
  app.get("/api/rent-roll/revenue-by-storage-type", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, locationId, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      if (locationId && typeof locationId !== "string") {
        return res.status(400).json({ error: "locationId must be a string" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" &&
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getRevenueByStorageType(
        startDate, 
        endDate,
        locationId as string | undefined,
        filterOptions
      );
      res.json(data);
    } catch (error) {
      console.error("Error fetching revenue by storage type:", error);
      res.status(500).json({ error: "Failed to fetch revenue by storage type" });
    }
  });

  // GET /api/executive-dashboard/metrics - Get executive dashboard KPIs
  app.get("/api/executive-dashboard/metrics", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType, seasonMode, storageType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      // Add unified KPI filter parameters
      if (seasonMode && typeof seasonMode === "string") {
        const validSeasonModes = ["overall", "annual", "seasonal", "winter", "shortTerm"];
        if (validSeasonModes.includes(seasonMode)) {
          filterOptions.seasonMode = seasonMode as KpiFilterOptions["seasonMode"];
        }
      }
      
      if (storageType && typeof storageType === "string") {
        filterOptions.storageType = storageType;
      }
      
      const metrics = await getExecutiveDashboardMetrics(startDate, endDate, filterOptions);
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching executive dashboard metrics:", error);
      res.status(500).json({ error: "Failed to fetch dashboard metrics" });
    }
  });

  // GET /api/executive-dashboard/revenue-trend - Get revenue trend data for charts
  app.get("/api/executive-dashboard/revenue-trend", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const trendData = await getRevenueTrendData(startDate, endDate, filterOptions);
      res.json(trendData);
    } catch (error) {
      console.error("Error fetching revenue trend data:", error);
      res.status(500).json({ error: "Failed to fetch revenue trend" });
    }
  });

  // GET /api/executive-dashboard/revenue-trend-by-storage-type - Revenue trend with storage type breakdown
  app.get("/api/executive-dashboard/revenue-trend-by-storage-type", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType, storageTypes } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      // Parse storage types (comma-separated)
      let selectedStorageTypes: string[] | undefined;
      if (storageTypes && typeof storageTypes === "string") {
        selectedStorageTypes = storageTypes.split(",").filter(st => st.trim().length > 0);
      }
      
      const trendData = await getRevenueTrendByStorageType(
        startDate, 
        endDate, 
        selectedStorageTypes,
        filterOptions
      );
      res.json(trendData);
    } catch (error) {
      console.error("Error fetching revenue trend by storage type:", error);
      res.status(500).json({ error: "Failed to fetch revenue trend by storage type" });
    }
  });

  // GET /api/executive-dashboard/ancillary-revenue-trend - Ancillary revenue (electric, liveaboard, other)
  app.get("/api/executive-dashboard/ancillary-revenue-trend", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const { getAncillaryRevenueTrendData } = await import("./rentRollService");
      const trendData = await getAncillaryRevenueTrendData(startDate, endDate, filterOptions);
      res.json(trendData);
    } catch (error) {
      console.error("Error fetching ancillary revenue trend:", error);
      res.status(500).json({ error: "Failed to fetch ancillary revenue trend" });
    }
  });

  // GET /api/executive-dashboard/transient-revenue-trend - Transient/short-term revenue
  app.get("/api/executive-dashboard/transient-revenue-trend", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const { getTransientRevenueTrendData } = await import("./rentRollService");
      const trendData = await getTransientRevenueTrendData(startDate, endDate, filterOptions);
      res.json(trendData);
    } catch (error) {
      console.error("Error fetching transient revenue trend:", error);
      res.status(500).json({ error: "Failed to fetch transient revenue trend" });
    }
  });

  // GET /api/executive-dashboard/move-events-detail - Get detailed drill-down for move events
  app.get("/api/executive-dashboard/move-events-detail", isAuthenticated, async (req, res) => {
    try {
      const { eventType, startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!eventType || !startDate || !endDate) {
        return res.status(400).json({ error: "eventType, startDate, and endDate are required" });
      }
      
      if (eventType !== "move-in" && eventType !== "move-out") {
        return res.status(400).json({ error: "eventType must be 'move-in' or 'move-out'" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const detailData = await getMoveEventsDetail(
        eventType as MoveEventType,
        startDate,
        endDate,
        filterOptions
      );
      res.json(detailData);
    } catch (error) {
      console.error("Error fetching move events detail:", error);
      res.status(500).json({ error: "Failed to fetch move events detail" });
    }
  });

  // GET /api/executive-dashboard/revenue-by-project - Revenue breakdown by project
  app.get("/api/executive-dashboard/revenue-by-project", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getRevenueByProject(startDate, endDate, filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching revenue by project:", error);
      res.status(500).json({ error: "Failed to fetch revenue by project" });
    }
  });

  // GET /api/executive-dashboard/revenue-by-month - Revenue breakdown by month
  app.get("/api/executive-dashboard/revenue-by-month", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getRevenueByMonth(startDate, endDate, filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching revenue by month:", error);
      res.status(500).json({ error: "Failed to fetch revenue by month" });
    }
  });

  // GET /api/executive-dashboard/revenue-by-month-by-project - Revenue breakdown by month per project (for filtering)
  app.get("/api/executive-dashboard/revenue-by-month-by-project", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getRevenueByMonthByProject(startDate, endDate, filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching revenue by month by project:", error);
      res.status(500).json({ error: "Failed to fetch revenue by month by project" });
    }
  });

  // GET /api/executive-dashboard/revenue-by-storage-type - Revenue breakdown by storage type
  app.get("/api/executive-dashboard/revenue-by-storage-type", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getRevenueByStorageType(startDate, endDate, undefined, filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching revenue by storage type:", error);
      res.status(500).json({ error: "Failed to fetch revenue by storage type" });
    }
  });

  // GET /api/executive-dashboard/leases-by-project - Lease breakdown by project (current snapshot)
  app.get("/api/executive-dashboard/leases-by-project", isAuthenticated, async (req, res) => {
    try {
      const { projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse project IDs if provided (comma-separated string)
      let projectIdArray: string[] | undefined;
      if (projectIds && typeof projectIds === "string") {
        projectIdArray = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      // Parse project type if provided
      let projectTypeFilter: "OWNED" | "DEAL" | undefined;
      if (projectType === "OWNED" || projectType === "DEAL") {
        projectTypeFilter = projectType;
      }
      
      const data = await getLeasesByProject({ 
        projectIds: projectIdArray, 
        projectType: projectTypeFilter,
        organizationIds 
      });
      res.json(data);
    } catch (error) {
      console.error("Error fetching leases by project:", error);
      res.status(500).json({ error: "Failed to fetch leases by project" });
    }
  });

  // GET /api/executive-dashboard/occupancy-by-project - Occupancy breakdown by project (current snapshot)
  app.get("/api/executive-dashboard/occupancy-by-project", isAuthenticated, async (req, res) => {
    try {
      const { projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getOccupancyByProject(filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching occupancy by project:", error);
      res.status(500).json({ error: "Failed to fetch occupancy by project" });
    }
  });

  // GET /api/executive-dashboard/storage-locations/:projectId - Storage location details for a specific project
  app.get("/api/executive-dashboard/storage-locations/:projectId", isAuthenticated, async (req, res) => {
    try {
      const { projectId } = req.params;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      // Verify user has access to this project via organization
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Validate project belongs to user's organizations
      const project = await db
        .select({ organizationId: marinaLocations.organizationId })
        .from(marinaLocations)
        .where(eq(marinaLocations.id, projectId))
        .limit(1);
      
      if (project.length === 0 || !organizationIds.includes(project[0].organizationId)) {
        return res.status(403).json({ error: "Access denied to this project" });
      }
      
      const data = await getStorageLocationsOccupancy(projectId);
      res.json(data);
    } catch (error) {
      console.error("Error fetching storage locations:", error);
      res.status(500).json({ error: "Failed to fetch storage locations" });
    }
  });

  // GET /api/executive-dashboard/avg-lease-value-by-project - Avg lease value breakdown by project
  app.get("/api/executive-dashboard/avg-lease-value-by-project", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getAvgLeaseValueByProject(startDate, endDate, filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching avg lease value by project:", error);
      res.status(500).json({ error: "Failed to fetch avg lease value by project" });
    }
  });

  // GET /api/executive-dashboard/avg-lease-value-by-storage-type - Avg lease value breakdown by storage type
  app.get("/api/executive-dashboard/avg-lease-value-by-storage-type", isAuthenticated, async (req, res) => {
    try {
      const { startDate, endDate, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getAvgLeaseValueByStorageType(startDate, endDate, filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching avg lease value by storage type:", error);
      res.status(500).json({ error: "Failed to fetch avg lease value by storage type" });
    }
  });

  // GET /api/executive-dashboard/seasonal-move-events - Seasonal move events aggregated across all included projects
  app.get("/api/executive-dashboard/seasonal-move-events", isAuthenticated, async (req, res) => {
    try {
      const { year, projectIds, projectType } = req.query;
      const userId = (req.user as any)?.claims?.sub;
      
      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }
      
      const targetYear = year ? parseInt(year as string, 10) : new Date().getFullYear();
      
      // Get user's organizations for scoping
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      // Parse filter options
      const filterOptions: KpiFilterOptions = { organizationIds };
      
      if (projectIds && typeof projectIds === "string") {
        filterOptions.projectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL" || projectType === "ALL")) {
        filterOptions.projectType = projectType;
      }
      
      const data = await getExecutiveSeasonalMoveEvents(targetYear, filterOptions);
      res.json(data);
    } catch (error) {
      console.error("Error fetching executive seasonal move events:", error);
      res.status(500).json({ error: "Failed to fetch executive seasonal move events" });
    }
  });

  // GET /api/executive-dashboard/contract-term-occupancy - Contract term occupancy aggregated across all included projects
  app.get("/api/executive-dashboard/contract-term-occupancy", isAuthenticated, async (req, res) => {
    try {
      const { projectIds, projectType, storageType } = req.query;
      
      // Parse project IDs if provided
      let parsedProjectIds: string[] | undefined;
      if (projectIds && typeof projectIds === "string") {
        parsedProjectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      // Parse project type
      let parsedProjectType: "OWNED" | "DEAL" | undefined;
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL")) {
        parsedProjectType = projectType;
      }
      
      const data = await getExecutiveContractTermOccupancy(
        parsedProjectType,
        parsedProjectIds,
        storageType as string | undefined
      );
      res.json(data);
    } catch (error) {
      console.error("Error fetching executive contract term occupancy:", error);
      res.status(500).json({ error: "Failed to fetch executive contract term occupancy" });
    }
  });

  // GET /api/executive-dashboard/avg-boat-size - Average boat size across all included projects with seasonal breakdown
  app.get("/api/executive-dashboard/avg-boat-size", isAuthenticated, async (req, res) => {
    try {
      const { projectIds, projectType } = req.query;
      
      // Parse project IDs if provided
      let parsedProjectIds: string[] | undefined;
      if (projectIds && typeof projectIds === "string") {
        parsedProjectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      // Parse project type
      let parsedProjectType: "OWNED" | "DEAL" | undefined;
      if (projectType && typeof projectType === "string" && 
          (projectType === "OWNED" || projectType === "DEAL")) {
        parsedProjectType = projectType;
      }
      
      const data = await getExecutiveAvgBoatSize(
        parsedProjectType,
        parsedProjectIds
      );
      res.json(data);
    } catch (error) {
      console.error("Error fetching executive avg boat size:", error);
      res.status(500).json({ error: "Failed to fetch avg boat size" });
    }
  });

  // GET /api/executive-dashboard/available-storage-types - Get storage types across all included projects
  app.get("/api/executive-dashboard/available-storage-types", isAuthenticated, async (req, res) => {
    try {
      const { projectIds } = req.query;
      
      // Parse project IDs if provided
      let parsedProjectIds: string[] | undefined;
      if (projectIds && typeof projectIds === "string") {
        parsedProjectIds = projectIds.split(",").filter(id => id.trim().length > 0);
      }
      
      // Use includeInExecutiveOnly=true to only get storage types from included projects
      const data = await getAvailableStorageTypes(undefined, parsedProjectIds, true);
      res.json(data);
    } catch (error) {
      console.error("Error fetching executive storage types:", error);
      res.status(500).json({ error: "Failed to fetch storage types" });
    }
  });

  // ============================================================================
  // PROJECT-SCOPED ANALYTICS (LOCATION OVERVIEW)
  // ============================================================================

  // GET /api/rent-roll/:locationId/overview/metrics - Project KPIs
  app.get("/api/rent-roll/:locationId/overview/metrics", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      const data = await getProjectKPIs(locationId, startDate, endDate);
      res.json(data);
    } catch (error) {
      console.error("Error fetching project KPIs:", error);
      res.status(500).json({ error: "Failed to fetch project KPIs" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/move-events - Move events for date range
  app.get("/api/rent-roll/:locationId/overview/move-events", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      const data = await getProjectMoveEvents(locationId, startDate, endDate);
      res.json(data);
    } catch (error) {
      console.error("Error fetching project move events:", error);
      res.status(500).json({ error: "Failed to fetch project move events" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/move-event-leases - Detailed leases for move-in/move-out drill-down
  app.get("/api/rent-roll/:locationId/overview/move-event-leases", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate, eventType } = req.query;
      
      if (!startDate || !endDate || !eventType) {
        return res.status(400).json({ error: "startDate, endDate, and eventType are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      if (eventType !== "move-in" && eventType !== "move-out") {
        return res.status(400).json({ error: "eventType must be 'move-in' or 'move-out'" });
      }
      
      const data = await getProjectMoveEventLeases(locationId, startDate, endDate, eventType);
      res.json(data);
    } catch (error) {
      console.error("Error fetching move event leases:", error);
      res.status(500).json({ error: "Failed to fetch move event leases" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/revenue-trend - Monthly revenue trend
  app.get("/api/rent-roll/:locationId/overview/revenue-trend", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      const data = await getProjectRevenueTrend(locationId, startDate, endDate);
      res.json(data);
    } catch (error) {
      console.error("Error fetching project revenue trend:", error);
      res.status(500).json({ error: "Failed to fetch project revenue trend" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/revenue-by-storage - Revenue distribution by storage type
  app.get("/api/rent-roll/:locationId/overview/revenue-by-storage", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      const data = await getProjectRevenueByStorage(locationId, startDate, endDate);
      res.json(data);
    } catch (error) {
      console.error("Error fetching project revenue by storage:", error);
      res.status(500).json({ error: "Failed to fetch project revenue by storage" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/economic-vacancy - Economic vacancy metrics (Potential vs Actual revenue)
  app.get("/api/rent-roll/:locationId/overview/economic-vacancy", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      if (typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "Dates must be strings in YYYY-MM-DD format" });
      }
      
      const data = await getEconomicVacancyMetrics(locationId, startDate, endDate);
      res.json(data);
    } catch (error) {
      console.error("Error fetching economic vacancy metrics:", error);
      res.status(500).json({ error: "Failed to fetch economic vacancy metrics" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/seasonal-occupancy - Seasonal occupancy metrics
  app.get("/api/rent-roll/:locationId/overview/seasonal-occupancy", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { year } = req.query;
      
      // Default to current year if not specified
      const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      if (isNaN(targetYear)) {
        return res.status(400).json({ error: "Year must be a valid number" });
      }
      
      const data = await getSeasonalOccupancyMetrics(locationId, targetYear);
      res.json(data);
    } catch (error) {
      console.error("Error fetching seasonal occupancy metrics:", error);
      res.status(500).json({ error: "Failed to fetch seasonal occupancy metrics" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/contract-term-occupancy - Contract term-based occupancy metrics
  app.get("/api/rent-roll/:locationId/overview/contract-term-occupancy", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { storageType } = req.query;
      const data = await getContractTermOccupancy(locationId, storageType as string | undefined);
      res.json(data);
    } catch (error) {
      console.error("Error fetching contract term occupancy:", error);
      res.status(500).json({ error: "Failed to fetch contract term occupancy" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/available-storage-types - Get storage types with active leases
  app.get("/api/rent-roll/:locationId/overview/available-storage-types", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const data = await getAvailableStorageTypes(locationId);
      res.json(data);
    } catch (error) {
      console.error("Error fetching available storage types:", error);
      res.status(500).json({ error: "Failed to fetch storage types" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/leases-by-storage-location - Lease breakdown by storage location within a project
  app.get("/api/rent-roll/:locationId/overview/leases-by-storage-location", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const data = await getLeasesByStorageLocation(locationId);
      res.json(data);
    } catch (error) {
      console.error("Error fetching leases by storage location:", error);
      res.status(500).json({ error: "Failed to fetch leases by storage location" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/avg-lease-value-by-storage-type - Avg lease value breakdown by storage type for a project
  app.get("/api/rent-roll/:locationId/overview/avg-lease-value-by-storage-type", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate, contractTermFilter, storageTypeFilter } = req.query;
      
      if (!startDate || !endDate || typeof startDate !== "string" || typeof endDate !== "string") {
        return res.status(400).json({ error: "startDate and endDate are required" });
      }
      
      const options = {
        contractTermFilter: typeof contractTermFilter === "string" ? contractTermFilter : undefined,
        storageTypeFilter: typeof storageTypeFilter === "string" ? storageTypeFilter : undefined,
      };
      
      const data = await getProjectAvgLeaseValueByStorageType(locationId, startDate, endDate, options);
      res.json(data);
    } catch (error) {
      console.error("Error fetching avg lease value by storage type:", error);
      res.status(500).json({ error: "Failed to fetch avg lease value by storage type" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/seasonal-move-events - Seasonal move events metrics
  app.get("/api/rent-roll/:locationId/overview/seasonal-move-events", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { year } = req.query;
      
      const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      if (isNaN(targetYear)) {
        return res.status(400).json({ error: "Year must be a valid number" });
      }
      
      const data = await getSeasonalMoveEvents(locationId, targetYear);
      res.json(data);
    } catch (error) {
      console.error("Error fetching seasonal move events:", error);
      res.status(500).json({ error: "Failed to fetch seasonal move events" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/seasonal-revenue - Seasonal revenue metrics
  app.get("/api/rent-roll/:locationId/overview/seasonal-revenue", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { year } = req.query;
      
      const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      if (isNaN(targetYear)) {
        return res.status(400).json({ error: "Year must be a valid number" });
      }
      
      const data = await getSeasonalRevenue(locationId, targetYear);
      res.json(data);
    } catch (error) {
      console.error("Error fetching seasonal revenue:", error);
      res.status(500).json({ error: "Failed to fetch seasonal revenue" });
    }
  });

  // GET /api/rent-roll/:locationId/overview/unified-seasonal - All seasonal metrics combined
  app.get("/api/rent-roll/:locationId/overview/unified-seasonal", isAuthenticated, requireLocationAccess(storage), async (req, res) => {
    try {
      const { locationId } = req.params;
      const { year } = req.query;
      
      const targetYear = year ? parseInt(year as string) : new Date().getFullYear();
      
      if (isNaN(targetYear)) {
        return res.status(400).json({ error: "Year must be a valid number" });
      }
      
      const data = await getUnifiedSeasonalMetrics(locationId, targetYear);
      res.json(data);
    } catch (error) {
      console.error("Error fetching unified seasonal metrics:", error);
      res.status(500).json({ error: "Failed to fetch unified seasonal metrics" });
    }
  });

  // ============================================================================
  // UPLOADED FILES MANAGEMENT
  // ============================================================================

  // GET /api/rent-roll/locations/:id/uploads - List all uploaded files for a project
  app.get("/api/rent-roll/locations/:id/uploads", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Validate user has access to the location
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      const validation = await validateLocationOwnership(id, organizationIds);
      
      if (!validation.valid) {
        return res.status(403).json({ error: validation.error });
      }
      
      const files = await storage.getUploadedFiles(id);
      res.json(files);
    } catch (error) {
      console.error("Error fetching uploaded files:", error);
      res.status(500).json({ error: "Failed to fetch uploaded files" });
    }
  });

  // POST /api/rent-roll/locations/:id/uploads - Upload a new file
  app.post("/api/rent-roll/locations/:id/uploads", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const { sourceFileName, mimeType, byteSize, fileData, parsedSheetName, rowsImported } = req.body;
      
      // Validate user has access to the location
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      const validation = await validateLocationOwnership(id, organizationIds);
      
      if (!validation.valid) {
        return res.status(403).json({ error: validation.error });
      }
      
      // Create uploaded file record
      const file = await storage.createUploadedFile({
        projectId: id,
        uploaderId: userId,
        sourceFileName,
        mimeType,
        byteSize,
        fileData,
        parsedSheetName,
        importStatus: "completed",
        rowsImported: rowsImported || 0,
        uploadedAt: new Date(),
      });
      
      res.status(201).json(file);
    } catch (error) {
      console.error("Error uploading file:", error);
      res.status(500).json({ error: "Failed to upload file" });
    }
  });

  // GET /api/rent-roll/uploads/:id/download - Download a file
  app.get("/api/rent-roll/uploads/:id/download", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const file = await storage.getUploadedFileById(id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      
      // Validate user has access to the file's project
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      const validation = await validateLocationOwnership(file.projectId, organizationIds);
      
      if (!validation.valid) {
        return res.status(403).json({ error: validation.error });
      }
      
      // Decode base64 file data
      const buffer = Buffer.from(file.fileData, 'base64');
      
      // Set appropriate headers
      res.setHeader('Content-Type', file.mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${file.sourceFileName}"`);
      res.setHeader('Content-Length', buffer.length);
      
      res.send(buffer);
    } catch (error) {
      console.error("Error downloading file:", error);
      res.status(500).json({ error: "Failed to download file" });
    }
  });

  // DELETE /api/rent-roll/uploads/:id - Delete a file and all associated data
  app.delete("/api/rent-roll/uploads/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      const file = await storage.getUploadedFileById(id);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      
      // Validate user has access to the file's project
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      const validation = await validateLocationOwnership(file.projectId, organizationIds);
      
      if (!validation.valid) {
        return res.status(403).json({ error: validation.error });
      }
      
      // Delete the file and all associated leases/tenants
      await storage.deleteUploadedFile(id);
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting file:", error);
      res.status(500).json({ error: "Failed to delete file" });
    }
  });

  // ============================================================================
  // CONTRACT CHARGES & CASH FLOW API ENDPOINTS
  // ============================================================================

  // GET /api/rent-roll/leases/:leaseId/charges - Get all charges for a lease
  app.get("/api/rent-roll/leases/:leaseId/charges", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const { getChargesForLease } = await import("./marinaLeaseEngine");
      
      const charges = await getChargesForLease(leaseId);
      res.json(charges);
    } catch (error) {
      console.error("Error fetching contract charges:", error);
      res.status(500).json({ error: "Failed to fetch contract charges" });
    }
  });

  // POST /api/rent-roll/leases/:leaseId/charges - Create a new charge for a lease
  app.post("/api/rent-roll/leases/:leaseId/charges", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const { createContractCharge } = await import("./marinaLeaseEngine");
      
      const charge = await createContractCharge({
        leaseId,
        ...req.body
      });
      
      res.status(201).json(charge);
    } catch (error) {
      console.error("Error creating contract charge:", error);
      res.status(500).json({ error: "Failed to create contract charge" });
    }
  });

  // PUT /api/rent-roll/charges/:chargeId - Update a contract charge
  app.put("/api/rent-roll/charges/:chargeId", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { chargeId } = req.params;
      const { updateContractCharge } = await import("./marinaLeaseEngine");
      
      const charge = await updateContractCharge(chargeId, req.body);
      if (!charge) {
        return res.status(404).json({ error: "Charge not found" });
      }
      
      res.json(charge);
    } catch (error) {
      console.error("Error updating contract charge:", error);
      res.status(500).json({ error: "Failed to update contract charge" });
    }
  });

  // DELETE /api/rent-roll/charges/:chargeId - Delete a contract charge
  app.delete("/api/rent-roll/charges/:chargeId", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { chargeId } = req.params;
      const { deleteContractCharge } = await import("./marinaLeaseEngine");
      
      await deleteContractCharge(chargeId);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting contract charge:", error);
      res.status(500).json({ error: "Failed to delete contract charge" });
    }
  });

  // POST /api/rent-roll/charges/:chargeId/deactivate - Soft delete a charge
  app.post("/api/rent-roll/charges/:chargeId/deactivate", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { chargeId } = req.params;
      const { deactivateContractCharge } = await import("./marinaLeaseEngine");
      
      const charge = await deactivateContractCharge(chargeId);
      res.json(charge);
    } catch (error) {
      console.error("Error deactivating contract charge:", error);
      res.status(500).json({ error: "Failed to deactivate contract charge" });
    }
  });

  // GET /api/rent-roll/leases/:leaseId/cash-flow - Generate cash flow for a lease
  // Uses V2 economics engine when V2 data exists, otherwise falls back to legacy
  // V2 includes both new economics calculations AND existing contract charges for parity
  app.get("/api/rent-roll/leases/:leaseId/cash-flow", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const { startDate, endDate, includeEscalation, yearsToProject, forceV2 } = req.query;
      
      // Check if V2 data exists (or if force flag is set)
      const useV2 = forceV2 === 'true' || await hasEconomicsV2Data(leaseId);
      
      if (useV2) {
        // Parse common parameters once
        const parsedStartDate = startDate ? new Date(startDate as string) : undefined;
        const parsedEndDate = endDate ? new Date(endDate as string) : undefined;
        const parsedYearsToProject = yearsToProject ? parseInt(yearsToProject as string) : 1;
        
        // Use V2 economics engine for base rent calculations
        const v2Result = await generateLeaseEconomicsCashFlows(leaseId, {
          startDate: parsedStartDate,
          endDate: parsedEndDate,
          yearsToProject: parsedYearsToProject,
        });
        
        // Also fetch legacy contract charges for backward compatibility
        // Use the actual V2 date range to ensure period alignment
        // This ensures existing contract charge data is still included in cash flow
        const { generateLeaseCashFlow } = await import("./marinaLeaseEngine");
        
        // Determine the actual date range from V2 results to ensure alignment
        // Ensure proper Date objects (V2 periods may have Date objects or ISO strings)
        let v2Start: Date | undefined = parsedStartDate;
        let v2End: Date | undefined = parsedEndDate;
        
        if (v2Result.periods.length > 0) {
          const firstPeriod = v2Result.periods[0];
          const lastPeriod = v2Result.periods[v2Result.periods.length - 1];
          
          // Handle both Date objects and ISO strings
          v2Start = firstPeriod.periodStart instanceof Date 
            ? firstPeriod.periodStart 
            : new Date(firstPeriod.periodStart);
          v2End = lastPeriod.periodEnd instanceof Date 
            ? lastPeriod.periodEnd 
            : new Date(lastPeriod.periodEnd);
        }
        
        const legacyCashFlow = await generateLeaseCashFlow({
          leaseId,
          startDate: v2Start,
          endDate: v2End,
          includeEscalation: includeEscalation !== 'false',
          yearsToProject: parsedYearsToProject
        });
        
        // Build a lookup map from legacy periods for faster access
        // Use numeric year-month key for consistent matching
        const legacyPeriodMap = new Map<string, any>();
        for (const lp of legacyCashFlow.periods) {
          // Ensure numeric keys for both (avoid "2024-3" vs "2024-03" mismatch)
          const key = `${Number(lp.year)}-${Number(lp.month)}`;
          legacyPeriodMap.set(key, lp);
        }
        
        // Merge V2 economics with legacy charges
        // Use V2 for base rent/escalations/concessions, legacy for contract charges
        const mergedPeriods = v2Result.periods.map((p) => {
          // Find matching period from legacy using lookup map with numeric keys
          const key = `${Number(p.year)}-${Number(p.month)}`;
          const legacyPeriod = legacyPeriodMap.get(key);
          
          // Merge charges from legacy with V2 economics
          const charges = legacyPeriod?.charges || [];
          const chargesTotal = charges.reduce((sum: number, c: any) => sum + (c.calculatedAmount || 0), 0);
          
          return {
            label: p.label,
            year: p.year,
            month: p.month,
            periodId: `${p.year}-${String(p.month).padStart(2, '0')}`,
            periodStart: p.periodStart,
            periodEnd: p.periodEnd,
            totalAmount: p.totalRevenue + chargesTotal,
            baseRent: p.contractBaseRent,
            effectiveRent: p.effectiveBaseRent,
            escalationAmount: p.escalationAmount,
            concessionAmount: p.concessionsApplied,
            isPartial: p.isPartialPeriod,
            proRataFactor: p.proRataFactor,
            charges, // Include legacy contract charges for parity
          };
        });
        
        const cashFlow = {
          leaseId: v2Result.leaseId,
          tenantName: v2Result.tenantName,
          periods: mergedPeriods,
          summary: {
            totalRevenue: mergedPeriods.reduce((sum, p) => sum + p.totalAmount, 0),
            totalBaseRent: v2Result.totalAccruedRent,
            totalEffectiveRent: v2Result.totalEffectiveRent,
            totalConcessions: v2Result.totalConcessions,
            annualizedRent: v2Result.annualizedInPlaceRent,
            chargeTypeSummary: legacyCashFlow.chargeTypeSummary || {},
          },
          warnings: v2Result.warnings,
          isV2: true,
        };
        
        return res.json(cashFlow);
      }
      
      // Fall back to legacy engine
      const { generateLeaseCashFlow } = await import("./marinaLeaseEngine");
      
      const cashFlow = await generateLeaseCashFlow({
        leaseId,
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        includeEscalation: includeEscalation !== 'false',
        yearsToProject: yearsToProject ? parseInt(yearsToProject as string) : 1
      });
      
      res.json({ ...cashFlow, isV2: false });
    } catch (error) {
      console.error("Error generating lease cash flow:", error);
      res.status(500).json({ error: "Failed to generate cash flow" });
    }
  });

  // GET /api/rent-roll/:locationId/cash-flow-summary - Get aggregated cash flows for a location
  app.get("/api/rent-roll/:locationId/cash-flow-summary", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { locationId } = req.params;
      const { startDate, endDate } = req.query;
      const { getLocationMonthlySummary } = await import("./marinaLeaseEngine");
      
      const summary = await getLocationMonthlySummary(
        locationId,
        startDate ? new Date(startDate as string) : undefined,
        endDate ? new Date(endDate as string) : undefined
      );
      
      res.json(summary);
    } catch (error) {
      console.error("Error generating location cash flow summary:", error);
      res.status(500).json({ error: "Failed to generate cash flow summary" });
    }
  });

  // ============================================================================
  // REPORTS API ROUTES
  // ============================================================================

  // GET /api/reports/options - Get filter options for reports
  app.get("/api/reports/options", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;

      const { getReportOptions } = await import("./reportsService");
      const options = await getReportOptions(organizationId);
      res.json(options);
    } catch (error) {
      console.error("Error fetching report options:", error);
      res.status(500).json({ error: "Failed to fetch report options" });
    }
  });

  // POST /api/reports/generate - Generate a report with filters
  app.post("/api/reports/generate", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;

      const { filters, includeAINarrative = true } = req.body;

      const { generateReport } = await import("./reportsService");
      const report = await generateReport(organizationId, filters || {}, includeAINarrative);
      res.json(report);
    } catch (error) {
      console.error("Error generating report:", error);
      res.status(500).json({ error: "Failed to generate report" });
    }
  });

  // POST /api/reports/export/excel - Export report to Excel with professional formatting
  app.post("/api/reports/export/excel", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;

      const { filters } = req.body;

      const { generateReport } = await import("./reportsService");
      const report = await generateReport(organizationId, filters || {}, false);

      // Generate Excel file using xlsx with professional formatting
      const XLSX = await import("xlsx");
      const workbook = XLSX.utils.book_new();

      // Helper: Set column widths
      const setColumnWidths = (sheet: any, widths: number[]) => {
        sheet['!cols'] = widths.map(w => ({ wch: w }));
      };

      // Helper: Apply currency format to specific cells
      const applyCurrencyFormat = (sheet: any, cellRefs: string[]) => {
        cellRefs.forEach(ref => {
          if (sheet[ref] && typeof sheet[ref].v === 'number') {
            sheet[ref].z = '"$"#,##0.00';
          }
        });
      };

      // Helper: Apply percentage format to specific cells
      const applyPercentFormat = (sheet: any, cellRefs: string[]) => {
        cellRefs.forEach(ref => {
          if (sheet[ref] && typeof sheet[ref].v === 'number') {
            sheet[ref].z = '0.0%';
          }
        });
      };

      // ========== SUMMARY SHEET ==========
      const summaryData = [
        ["MarinaMatch Rent Roll Report"],
        [""],
        ["Report Generated:", new Date(report.generatedAt).toLocaleString()],
        [""],
        ["KEY METRICS"],
        [""],
        ["Metric", "Value"],
        ["Total Leases", report.metrics.totalLeases],
        ["Active Leases", report.metrics.activeLeases],
        ["Total Revenue", report.metrics.totalRevenue],
        ["Average Lease Value", report.metrics.averageLeaseValue],
        ["Occupancy Rate", report.metrics.occupancyRate / 100],
        ["Economic Vacancy", report.metrics.economicVacancy],
        ["Move-Ins (YTD)", report.metrics.moveIns],
        ["Move-Outs (YTD)", report.metrics.moveOuts],
        ["Net Change", report.metrics.netChange],
        ["Average LOA (ft)", report.metrics.averageLOA],
      ];
      const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
      setColumnWidths(summarySheet, [25, 20]);
      
      // Apply formatting to summary sheet
      applyCurrencyFormat(summarySheet, ['B10', 'B11', 'B13']);
      applyPercentFormat(summarySheet, ['B12']);
      
      // Merge title cell
      summarySheet['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }];
      
      XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary");

      // ========== PROJECTS SHEET ==========
      if (report.projectBreakdown.length > 0) {
        const projectHeaders = ["Project Name", "Type", "Season Type", "Capacity", "Active Leases", "Revenue", "Occupancy Rate"];
        const projectRows = report.projectBreakdown.map(p => [
          p.projectName,
          p.projectType,
          p.seasonType || 'N/A',
          p.capacity || 0,
          p.activeLeases,
          p.revenue,
          p.occupancyRate / 100,
        ]);
        
        const projectsSheet = XLSX.utils.aoa_to_sheet([projectHeaders, ...projectRows]);
        setColumnWidths(projectsSheet, [30, 12, 14, 12, 14, 18, 14]);
        
        // Apply currency format to Revenue column (F) and percent to Occupancy (G)
        for (let i = 2; i <= projectRows.length + 1; i++) {
          applyCurrencyFormat(projectsSheet, [`F${i}`]);
          applyPercentFormat(projectsSheet, [`G${i}`]);
        }
        
        // Auto-filter for header row
        projectsSheet['!autofilter'] = { ref: `A1:G${projectRows.length + 1}` };
        
        XLSX.utils.book_append_sheet(workbook, projectsSheet, "Projects");
      }

      // ========== STORAGE TYPES SHEET ==========
      if (report.storageTypeBreakdown.length > 0) {
        const storageHeaders = ["Storage Type", "Lease Count", "Revenue", "% of Total"];
        const storageRows = report.storageTypeBreakdown.map(s => [
          s.storageType,
          s.leaseCount,
          s.revenue,
          s.percentage / 100,
        ]);
        
        const storageSheet = XLSX.utils.aoa_to_sheet([storageHeaders, ...storageRows]);
        setColumnWidths(storageSheet, [25, 14, 18, 14]);
        
        // Apply currency format to Revenue column (C) and percent to % of Total (D)
        for (let i = 2; i <= storageRows.length + 1; i++) {
          applyCurrencyFormat(storageSheet, [`C${i}`]);
          applyPercentFormat(storageSheet, [`D${i}`]);
        }
        
        // Auto-filter for data rows only (excludes totals)
        storageSheet['!autofilter'] = { ref: `A1:D${storageRows.length + 1}` };
        
        // Add blank row then totals row (outside filter range)
        const blankRowNum = storageRows.length + 2;
        const totalsRowNum = storageRows.length + 3;
        XLSX.utils.sheet_add_aoa(storageSheet, [[""]], { origin: `A${blankRowNum}` });
        XLSX.utils.sheet_add_aoa(storageSheet, [["TOTAL", 
          report.storageTypeBreakdown.reduce((sum, s) => sum + s.leaseCount, 0),
          report.storageTypeBreakdown.reduce((sum, s) => sum + s.revenue, 0),
          1
        ]], { origin: `A${totalsRowNum}` });
        applyCurrencyFormat(storageSheet, [`C${totalsRowNum}`]);
        applyPercentFormat(storageSheet, [`D${totalsRowNum}`]);
        
        XLSX.utils.book_append_sheet(workbook, storageSheet, "Storage Types");
      }

      // ========== LEASE DETAILS SHEET ==========
      if (report.leaseDetails.length > 0) {
        const leaseHeaders = [
          "Tenant Name", 
          "Project", 
          "Storage Type", 
          "Location", 
          "Contract Term", 
          "Lease Amount",
          "Rate Type",
          "Commencement", 
          "Expiration", 
          "Boat Size (ft)",
          "Status"
        ];
        
        const leaseRows = report.leaseDetails.map(l => [
          l.tenantName,
          l.projectName,
          l.storageType || '',
          l.unitLocation || '',
          l.contractTerm || '',
          l.leaseAmount || 0,
          l.rateType || '',
          l.commencementDate || '',
          l.expirationDate || '',
          l.boatSize || '',
          l.isActive ? 'Active' : 'Inactive',
        ]);
        
        const leasesSheet = XLSX.utils.aoa_to_sheet([leaseHeaders, ...leaseRows]);
        setColumnWidths(leasesSheet, [25, 20, 15, 15, 14, 14, 12, 14, 14, 12, 10]);
        
        // Apply currency format to Lease Amount column (F)
        for (let i = 2; i <= leaseRows.length + 1; i++) {
          applyCurrencyFormat(leasesSheet, [`F${i}`]);
        }
        
        // Add auto-filter
        leasesSheet['!autofilter'] = { ref: `A1:K${leaseRows.length + 1}` };
        
        // Freeze header row
        leasesSheet['!freeze'] = { xSplit: 0, ySplit: 1 };
        
        XLSX.utils.book_append_sheet(workbook, leasesSheet, "Lease Details");
      }

      // ========== MOVE EVENTS SHEET (if data available) ==========
      if (report.metrics.moveIns > 0 || report.metrics.moveOuts > 0) {
        const moveEventsData = [
          ["Move Events Summary (YTD)"],
          [""],
          ["Metric", "Count"],
          ["Move-Ins", report.metrics.moveIns],
          ["Move-Outs", report.metrics.moveOuts],
          ["Net Change", report.metrics.netChange],
        ];
        
        const moveEventsSheet = XLSX.utils.aoa_to_sheet(moveEventsData);
        setColumnWidths(moveEventsSheet, [20, 12]);
        moveEventsSheet['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }];
        
        XLSX.utils.book_append_sheet(workbook, moveEventsSheet, "Move Events");
      }

      // Generate buffer with proper options
      const buffer = XLSX.write(workbook, { 
        type: "buffer", 
        bookType: "xlsx",
        cellStyles: true,
        bookSST: false,
      });

      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.setHeader("Content-Disposition", `attachment; filename=rent-roll-report-${new Date().toISOString().split('T')[0]}.xlsx`);
      res.send(buffer);
    } catch (error) {
      console.error("Error exporting report to Excel:", error);
      res.status(500).json({ error: "Failed to export report" });
    }
  });

  // POST /api/reports/export/pdf - Export report to PDF
  app.post("/api/reports/export/pdf", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;

      const { filters } = req.body;

      const { generateReport } = await import("./reportsService");
      const report = await generateReport(organizationId, filters || {}, true);

      const PDFDocument = (await import("pdfkit")).default;
      const doc = new PDFDocument({ margin: 50, size: 'LETTER' });

      const chunks: Buffer[] = [];
      doc.on('data', (chunk: Buffer) => chunks.push(chunk));
      
      const pdfPromise = new Promise<Buffer>((resolve, reject) => {
        doc.on('end', () => resolve(Buffer.concat(chunks)));
        doc.on('error', reject);
      });

      // Title
      doc.fontSize(24).font('Helvetica-Bold').text('Rent Roll Report', { align: 'center' });
      doc.moveDown(0.5);
      doc.fontSize(10).font('Helvetica').fillColor('#666666')
        .text(`Generated: ${new Date(report.generatedAt).toLocaleString()}`, { align: 'center' });
      doc.moveDown(1.5);

      // Key Metrics Section
      doc.fontSize(16).font('Helvetica-Bold').fillColor('#000000').text('Key Metrics');
      doc.moveDown(0.5);
      doc.fontSize(11).font('Helvetica');
      
      const metrics = [
        ['Active Leases', `${report.metrics.activeLeases} of ${report.metrics.totalLeases} total`],
        ['Total Revenue', `$${report.metrics.totalRevenue.toLocaleString()}`],
        ['Average Lease Value', `$${report.metrics.averageLeaseValue.toLocaleString()}`],
        ['Occupancy Rate', `${report.metrics.occupancyRate}%`],
        ['Economic Vacancy', `$${report.metrics.economicVacancy.toLocaleString()}`],
        ['Move-Ins (YTD)', `${report.metrics.moveIns}`],
        ['Move-Outs (YTD)', `${report.metrics.moveOuts}`],
        ['Net Change', `${report.metrics.netChange >= 0 ? '+' : ''}${report.metrics.netChange}`],
        ['Average LOA', `${report.metrics.averageLOA} ft`],
      ];

      metrics.forEach(([label, value]) => {
        doc.font('Helvetica-Bold').text(`${label}: `, { continued: true });
        doc.font('Helvetica').text(value);
      });
      doc.moveDown(1.5);

      // AI Summary if available
      if (report.aiNarrative) {
        doc.fontSize(16).font('Helvetica-Bold').text('Executive Summary');
        doc.moveDown(0.5);
        doc.fontSize(10).font('Helvetica').text(report.aiNarrative, { align: 'justify' });
        doc.moveDown(1.5);
      }

      // Projects Breakdown
      if (report.projectBreakdown.length > 0) {
        doc.addPage();
        doc.fontSize(16).font('Helvetica-Bold').text('Projects Breakdown');
        doc.moveDown(0.5);
        
        // Table header
        const projectCols = ['Project', 'Type', 'Leases', 'Revenue', 'Occupancy'];
        const colWidths = [150, 80, 60, 100, 80];
        let x = 50;
        
        doc.fontSize(9).font('Helvetica-Bold');
        projectCols.forEach((col, i) => {
          doc.text(col, x, doc.y, { width: colWidths[i], continued: i < projectCols.length - 1 });
          x += colWidths[i];
        });
        doc.moveDown(0.5);
        doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
        doc.moveDown(0.3);

        // Table rows
        doc.font('Helvetica').fontSize(9);
        report.projectBreakdown.forEach(p => {
          x = 50;
          const y = doc.y;
          doc.text(p.projectName.substring(0, 25), x, y, { width: colWidths[0] });
          doc.text(p.projectType, x + colWidths[0], y, { width: colWidths[1] });
          doc.text(String(p.activeLeases), x + colWidths[0] + colWidths[1], y, { width: colWidths[2] });
          doc.text(`$${p.revenue.toLocaleString()}`, x + colWidths[0] + colWidths[1] + colWidths[2], y, { width: colWidths[3] });
          doc.text(`${p.occupancyRate.toFixed(1)}%`, x + colWidths[0] + colWidths[1] + colWidths[2] + colWidths[3], y, { width: colWidths[4] });
          doc.moveDown(0.8);
        });
        doc.moveDown(1);
      }

      // Storage Type Breakdown
      if (report.storageTypeBreakdown.length > 0) {
        doc.fontSize(16).font('Helvetica-Bold').text('Revenue by Storage Type');
        doc.moveDown(0.5);
        
        doc.fontSize(9).font('Helvetica');
        report.storageTypeBreakdown.forEach(s => {
          doc.font('Helvetica-Bold').text(`${s.storageType}: `, { continued: true });
          doc.font('Helvetica').text(`${s.leaseCount} leases, $${s.revenue.toLocaleString()} (${s.percentage.toFixed(1)}%)`);
        });
        doc.moveDown(1.5);
      }

      // Top Leases (first 20)
      if (report.leaseDetails.length > 0) {
        doc.addPage();
        doc.fontSize(16).font('Helvetica-Bold').text(`Top Leases (${Math.min(20, report.leaseDetails.length)} of ${report.leaseDetails.length})`);
        doc.moveDown(0.5);
        
        doc.fontSize(9).font('Helvetica');
        report.leaseDetails.slice(0, 20).forEach((l, i) => {
          doc.font('Helvetica-Bold').text(`${i + 1}. ${l.tenantName}`, { continued: true });
          doc.font('Helvetica').text(` - ${l.projectName}, ${l.storageType || 'N/A'}, ${l.leaseAmount ? `$${l.leaseAmount.toLocaleString()}` : 'N/A'}`);
        });
      }

      // Footer
      doc.fontSize(8).fillColor('#999999')
        .text('Generated by MarinaMatch', 50, doc.page.height - 50, { align: 'center' });

      doc.end();

      const pdfBuffer = await pdfPromise;

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=rent-roll-report-${new Date().toISOString().split('T')[0]}.pdf`);
      res.send(pdfBuffer);
    } catch (error) {
      console.error("Error exporting report to PDF:", error);
      res.status(500).json({ error: "Failed to export PDF report" });
    }
  });

  // ============================================================================
  // SAVED REPORTS API ROUTES
  // ============================================================================

  // GET /api/saved-reports - Get all saved reports for the organization
  app.get("/api/saved-reports", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;

      const savedReports = await storage.getSavedReports(organizationId);
      res.json(savedReports);
    } catch (error) {
      console.error("Error fetching saved reports:", error);
      res.status(500).json({ error: "Failed to fetch saved reports" });
    }
  });

  // GET /api/saved-reports/:id - Get a single saved report by ID
  app.get("/api/saved-reports/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;
      const { id } = req.params;

      const report = await storage.getSavedReportById(id);
      if (!report) {
        return res.status(404).json({ error: "Saved report not found" });
      }
      
      // Verify organization access
      if (report.organizationId !== organizationId) {
        return res.status(403).json({ error: "Access denied" });
      }

      res.json(report);
    } catch (error) {
      console.error("Error fetching saved report:", error);
      res.status(500).json({ error: "Failed to fetch saved report" });
    }
  });

  // POST /api/saved-reports - Create a new saved report
  app.post("/api/saved-reports", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;

      const { name, description, filters, includeAiNarrative, isScheduled, scheduleFrequency, scheduleDayOfWeek, scheduleDayOfMonth, scheduleRecipients } = req.body;

      if (!name) {
        return res.status(400).json({ error: "Report name is required" });
      }

      const savedReport = await storage.createSavedReport({
        organizationId,
        createdByUserId: userId,
        name,
        description,
        filters: filters || {},
        includeAiNarrative: includeAiNarrative ?? true,
        isScheduled: isScheduled ?? false,
        scheduleFrequency,
        scheduleDayOfWeek,
        scheduleDayOfMonth,
        scheduleRecipients,
      });

      res.status(201).json(savedReport);
    } catch (error) {
      console.error("Error creating saved report:", error);
      res.status(500).json({ error: "Failed to create saved report" });
    }
  });

  // PATCH /api/saved-reports/:id - Update a saved report
  app.patch("/api/saved-reports/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;
      const { id } = req.params;

      // Verify the report exists and belongs to the organization
      const existingReport = await storage.getSavedReportById(id);
      if (!existingReport) {
        return res.status(404).json({ error: "Saved report not found" });
      }
      if (existingReport.organizationId !== organizationId) {
        return res.status(403).json({ error: "Access denied" });
      }

      const { name, description, filters, includeAiNarrative, isScheduled, scheduleFrequency, scheduleDayOfWeek, scheduleDayOfMonth, scheduleRecipients } = req.body;

      const updatedReport = await storage.updateSavedReport(id, {
        name,
        description,
        filters,
        includeAiNarrative,
        isScheduled,
        scheduleFrequency,
        scheduleDayOfWeek,
        scheduleDayOfMonth,
        scheduleRecipients,
      });

      res.json(updatedReport);
    } catch (error) {
      console.error("Error updating saved report:", error);
      res.status(500).json({ error: "Failed to update saved report" });
    }
  });

  // DELETE /api/saved-reports/:id - Delete a saved report
  app.delete("/api/saved-reports/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;
      const { id } = req.params;

      // Verify the report exists and belongs to the organization
      const existingReport = await storage.getSavedReportById(id);
      if (!existingReport) {
        return res.status(404).json({ error: "Saved report not found" });
      }
      if (existingReport.organizationId !== organizationId) {
        return res.status(403).json({ error: "Access denied" });
      }

      await storage.deleteSavedReport(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting saved report:", error);
      res.status(500).json({ error: "Failed to delete saved report" });
    }
  });

  // POST /api/saved-reports/:id/run - Run a saved report
  app.post("/api/saved-reports/:id/run", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      const organizationId = userOrgs[0].id;
      const { id } = req.params;

      // Verify the report exists and belongs to the organization
      const savedReport = await storage.getSavedReportById(id);
      if (!savedReport) {
        return res.status(404).json({ error: "Saved report not found" });
      }
      if (savedReport.organizationId !== organizationId) {
        return res.status(403).json({ error: "Access denied" });
      }

      // Generate the report using the saved filters
      const { generateReport } = await import("./reportsService");
      const report = await generateReport(
        organizationId, 
        savedReport.filters as any || {}, 
        savedReport.includeAiNarrative ?? true
      );

      // Update last run timestamp
      await storage.updateSavedReport(id, {});

      res.json(report);
    } catch (error) {
      console.error("Error running saved report:", error);
      res.status(500).json({ error: "Failed to run saved report" });
    }
  });

  // ============================================================================
  // ADMIN TYPE MANAGEMENT ENDPOINTS
  // ============================================================================

  // Helper to check if user is an admin (first user or special role)
  async function isAdminUser(userId: string): Promise<boolean> {
    try {
      // Check if user has admin role in any organization
      const userOrgs = await storage.getUserOrganizations(userId);
      const isOrgAdmin = userOrgs.some(org => org.role === 'admin');
      
      // Also check if they're the first user (system admin) - check by created_at
      const allUsers = await db.query.users.findMany({
        orderBy: (users, { asc }) => [asc(users.createdAt)],
        limit: 1,
      });
      const isFirstUser = allUsers.length > 0 && allUsers[0].id === userId;
      
      return isOrgAdmin || isFirstUser;
    } catch {
      return false;
    }
  }

  // GET /api/admin/type-review-queue - Get all pending custom types for admin review
  app.get("/api/admin/type-review-queue", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const isAdmin = await isAdminUser(userId);
      
      if (!isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      const status = req.query.status || "pending";
      const category = req.query.category;
      
      let query = db.select().from(adminTypeReviewQueue);
      
      // Build where conditions
      const conditions: any[] = [];
      if (status !== "all") {
        conditions.push(eq(adminTypeReviewQueue.status, status as any));
      }
      if (category) {
        conditions.push(eq(adminTypeReviewQueue.category, category as any));
      }
      
      if (conditions.length > 0) {
        query = query.where(and(...conditions)) as any;
      }
      
      const items = await query.orderBy(desc(adminTypeReviewQueue.createdAt));
      
      res.json(items);
    } catch (error) {
      console.error("Error fetching admin type review queue:", error);
      res.status(500).json({ error: "Failed to fetch type review queue" });
    }
  });

  // GET /api/admin/global-promoted-types - Get all globally promoted types
  app.get("/api/admin/global-promoted-types", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const isAdmin = await isAdminUser(userId);
      
      if (!isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      const category = req.query.category;
      
      let items;
      if (category) {
        items = await db.query.globalPromotedTypes.findMany({
          where: (gpt, { eq }) => eq(gpt.category, category as any),
          orderBy: (gpt, { asc }) => [asc(gpt.name)],
        });
      } else {
        items = await db.query.globalPromotedTypes.findMany({
          orderBy: (gpt, { asc }) => [asc(gpt.category), asc(gpt.name)],
        });
      }
      
      res.json(items);
    } catch (error) {
      console.error("Error fetching global promoted types:", error);
      res.status(500).json({ error: "Failed to fetch global promoted types" });
    }
  });

  // POST /api/admin/promote-type - Promote a custom type to global default
  app.post("/api/admin/promote-type", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const isAdmin = await isAdminUser(userId);
      
      if (!isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      const { reviewId, description } = req.body;
      
      if (!reviewId) {
        return res.status(400).json({ error: "Review ID is required" });
      }
      
      // Get the review queue item
      const reviewItem = await db.query.adminTypeReviewQueue.findFirst({
        where: (atrq, { eq }) => eq(atrq.id, reviewId),
      });
      
      if (!reviewItem) {
        return res.status(404).json({ error: "Review item not found" });
      }
      
      // Check if already promoted globally
      const existingGlobal = await db.query.globalPromotedTypes.findFirst({
        where: (gpt, { eq, and }) => and(
          eq(gpt.category, reviewItem.category),
          eq(gpt.name, reviewItem.name)
        ),
      });
      
      if (existingGlobal) {
        return res.status(409).json({ error: "Type already exists as a global default" });
      }
      
      // Insert into global promoted types
      const [promoted] = await db.insert(globalPromotedTypes).values({
        category: reviewItem.category,
        name: reviewItem.name,
        description: description || null,
        promotedBy: userId,
      }).returning();
      
      // Update review queue item status
      await db.update(adminTypeReviewQueue)
        .set({
          status: "promoted",
          reviewedBy: userId,
          reviewedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(adminTypeReviewQueue.id, reviewId));
      
      res.json({ success: true, promoted });
    } catch (error) {
      console.error("Error promoting type:", error);
      res.status(500).json({ error: "Failed to promote type" });
    }
  });

  // POST /api/admin/reject-type - Reject a custom type from promotion
  app.post("/api/admin/reject-type", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const isAdmin = await isAdminUser(userId);
      
      if (!isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      const { reviewId, notes } = req.body;
      
      if (!reviewId) {
        return res.status(400).json({ error: "Review ID is required" });
      }
      
      // Update review queue item status to rejected
      const [updated] = await db.update(adminTypeReviewQueue)
        .set({
          status: "rejected",
          reviewedBy: userId,
          reviewedAt: new Date(),
          reviewNotes: notes || null,
          updatedAt: new Date(),
        })
        .where(eq(adminTypeReviewQueue.id, reviewId))
        .returning();
      
      if (!updated) {
        return res.status(404).json({ error: "Review item not found" });
      }
      
      res.json({ success: true, updated });
    } catch (error) {
      console.error("Error rejecting type:", error);
      res.status(500).json({ error: "Failed to reject type" });
    }
  });

  // DELETE /api/admin/global-promoted-types/:id - Remove a globally promoted type
  app.delete("/api/admin/global-promoted-types/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const isAdmin = await isAdminUser(userId);
      
      if (!isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      const { id } = req.params;
      
      await db.delete(globalPromotedTypes).where(eq(globalPromotedTypes.id, id));
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting global promoted type:", error);
      res.status(500).json({ error: "Failed to delete global promoted type" });
    }
  });

  // GET /api/admin/type-statistics - Get statistics about custom types across all orgs
  app.get("/api/admin/type-statistics", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const isAdmin = await isAdminUser(userId);
      
      if (!isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      
      // Count pending reviews by category
      const pendingReviews = await db.select({
        category: adminTypeReviewQueue.category,
        count: sql<number>`count(*)::int`,
      })
      .from(adminTypeReviewQueue)
      .where(eq(adminTypeReviewQueue.status, "pending"))
      .groupBy(adminTypeReviewQueue.category);
      
      // Count global promoted by category
      const globalCounts = await db.select({
        category: globalPromotedTypes.category,
        count: sql<number>`count(*)::int`,
      })
      .from(globalPromotedTypes)
      .groupBy(globalPromotedTypes.category);
      
      // Total pending
      const [totalPending] = await db.select({
        count: sql<number>`count(*)::int`,
      })
      .from(adminTypeReviewQueue)
      .where(eq(adminTypeReviewQueue.status, "pending"));
      
      res.json({
        pendingByCategory: pendingReviews,
        globalByCategory: globalCounts,
        totalPending: totalPending?.count || 0,
      });
    } catch (error) {
      console.error("Error fetching type statistics:", error);
      res.status(500).json({ error: "Failed to fetch type statistics" });
    }
  });

  // ============================================================================
  // SCENARIO MODELING ROUTES (IRR/NPV Analysis)
  // ============================================================================

  const {
    getScenarios,
    getScenarioById,
    createScenario,
    updateScenario,
    deleteScenario,
    getScenarioCashFlows,
    calculateScenarioMetrics,
    calculateQuickMetrics,
  } = await import("./scenarioService");

  // GET /api/scenarios - List all scenarios for an organization
  app.get("/api/scenarios", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      
      if (userOrgs.length === 0) {
        return res.json([]);
      }
      
      const { projectId } = req.query;
      const organizationId = userOrgs[0].id;
      
      const scenarioList = await getScenarios(organizationId, projectId as string | undefined);
      res.json(scenarioList);
    } catch (error) {
      console.error("Error fetching scenarios:", error);
      res.status(500).json({ error: "Failed to fetch scenarios" });
    }
  });

  // GET /api/scenarios/:id - Get a single scenario with cash flows
  app.get("/api/scenarios/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const scenario = await getScenarioById(id);
      
      if (!scenario) {
        return res.status(404).json({ error: "Scenario not found" });
      }
      
      const cashFlows = await getScenarioCashFlows(id);
      
      res.json({ ...scenario, cashFlows });
    } catch (error) {
      console.error("Error fetching scenario:", error);
      res.status(500).json({ error: "Failed to fetch scenario" });
    }
  });

  // POST /api/scenarios - Create a new scenario
  app.post("/api/scenarios", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      
      if (userOrgs.length === 0) {
        return res.status(403).json({ error: "No organization access" });
      }
      
      const data = {
        ...req.body,
        organizationId: userOrgs[0].id,
        createdByUserId: userId,
      };
      
      const scenario = await createScenario(data);
      res.status(201).json(scenario);
    } catch (error) {
      console.error("Error creating scenario:", error);
      res.status(500).json({ error: "Failed to create scenario" });
    }
  });

  // PUT /api/scenarios/:id - Update a scenario
  app.put("/api/scenarios/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const updated = await updateScenario(id, req.body);
      
      if (!updated) {
        return res.status(404).json({ error: "Scenario not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating scenario:", error);
      res.status(500).json({ error: "Failed to update scenario" });
    }
  });

  // DELETE /api/scenarios/:id - Delete a scenario
  app.delete("/api/scenarios/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await deleteScenario(id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting scenario:", error);
      res.status(500).json({ error: "Failed to delete scenario" });
    }
  });

  // POST /api/scenarios/:id/calculate - Run IRR/NPV calculations
  app.post("/api/scenarios/:id/calculate", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const result = await calculateScenarioMetrics(id);
      res.json(result);
    } catch (error) {
      console.error("Error calculating scenario metrics:", error);
      res.status(500).json({ error: "Failed to calculate scenario metrics" });
    }
  });

  // POST /api/scenarios/quick-calculate - Run quick IRR/NPV calculation without saving
  app.post("/api/scenarios/quick-calculate", isAuthenticated, async (req: any, res) => {
    try {
      const { initialInvestment, discountRate, cashFlows, exitCapRate, finalYearNoi } = req.body;
      
      if (!initialInvestment || !discountRate || !cashFlows) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      const result = calculateQuickMetrics(
        parseFloat(initialInvestment),
        parseFloat(discountRate),
        cashFlows.map((cf: string | number) => parseFloat(String(cf))),
        exitCapRate ? parseFloat(exitCapRate) : undefined,
        finalYearNoi ? parseFloat(finalYearNoi) : undefined
      );
      
      res.json(result);
    } catch (error) {
      console.error("Error in quick calculation:", error);
      res.status(500).json({ error: "Failed to calculate metrics" });
    }
  });

  // ============================================================================
  // PORTFOLIO ROLL-UP ENDPOINTS
  // ============================================================================

  // GET /api/portfolio/summary - Get portfolio-wide aggregated metrics
  app.get("/api/portfolio/summary", isAuthenticated, async (req: any, res) => {
    try {
      const { projectType } = req.query;
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      if (organizationIds.length === 0) {
        return res.status(403).json({ error: "Organization required" });
      }

      // Get all projects for user's organizations
      const projectConditions = inArray(marinaLocations.organizationId, organizationIds);
      
      // Get projects with optional type filter
      const projects = await db
        .select()
        .from(marinaLocations)
        .where(
          projectType && projectType !== "ALL"
            ? and(projectConditions, eq(marinaLocations.projectType, projectType))
            : projectConditions
        );

      // Calculate TTM date range (trailing 12 months)
      const endDate = new Date();
      const startDate = new Date();
      startDate.setFullYear(startDate.getFullYear() - 1);
      const startDateStr = startDate.toISOString().split("T")[0];
      const endDateStr = endDate.toISOString().split("T")[0];

      // Get per-project metrics
      const projectMetrics = await Promise.all(
        projects.map(async (project) => {
          // Get revenue for this project (TTM)
          const revenueResult = await db
            .select({
              totalRevenue: sql<string>`COALESCE(SUM(${leaseCashFlows.rentAmount}), 0)`,
            })
            .from(leaseCashFlows)
            .innerJoin(leases, eq(leaseCashFlows.leaseId, leases.id))
            .innerJoin(periods, eq(leaseCashFlows.periodId, periods.id))
            .where(
              and(
                eq(leases.locationId, project.id),
                gte(periods.periodDate, startDateStr),
                lte(periods.periodDate, endDateStr)
              )
            );

          // Get active leases and capacity
          const leaseStats = await db
            .select({
              activeLeases: sql<number>`CAST(COALESCE(SUM(CASE WHEN ${leases.isActive} = true AND ${leases.slipStatus} NOT IN ('Vacant', 'Unusable') THEN 1 ELSE 0 END), 0) AS INTEGER)`,
              avgLeaseValue: sql<string>`COALESCE(AVG(CASE WHEN ${leases.isActive} = true THEN CAST(${leases.leaseAmount} AS NUMERIC) ELSE NULL END), 0)`,
            })
            .from(leases)
            .where(eq(leases.locationId, project.id));

          // Get capacity from storage locations
          const capacityResult = await db
            .select({
              totalCapacity: sql<number>`CAST(COALESCE(SUM(${storageLocations.capacity}), 0) AS INTEGER)`,
            })
            .from(storageLocations)
            .where(
              and(
                eq(storageLocations.projectId, project.id),
                eq(storageLocations.isActive, true)
              )
            );

          // Get move events for TTM
          const moveResult = await db
            .select({
              moveIns: sql<number>`CAST(COALESCE(SUM(CASE WHEN ${moveEvents.moveDirection} = 'IN' THEN 1 ELSE 0 END), 0) AS INTEGER)`,
              moveOuts: sql<number>`CAST(COALESCE(SUM(CASE WHEN ${moveEvents.moveDirection} = 'OUT' THEN 1 ELSE 0 END), 0) AS INTEGER)`,
            })
            .from(moveEvents)
            .innerJoin(leases, eq(moveEvents.leaseId, leases.id))
            .where(
              and(
                eq(leases.locationId, project.id),
                gte(moveEvents.moveDate, startDateStr),
                lte(moveEvents.moveDate, endDateStr)
              )
            );

          const totalRevenue = parseFloat(revenueResult[0]?.totalRevenue || "0");
          const activeLeases = leaseStats[0]?.activeLeases || 0;
          const totalCapacity = capacityResult[0]?.totalCapacity || 0;
          const avgLeaseValue = parseFloat(leaseStats[0]?.avgLeaseValue || "0");
          const moveIns = moveResult[0]?.moveIns || 0;
          const moveOuts = moveResult[0]?.moveOuts || 0;

          return {
            projectId: project.id,
            projectName: project.name,
            projectType: project.projectType as "OWNED" | "DEAL",
            totalRevenue,
            activeLeases,
            totalCapacity,
            occupancyRate: totalCapacity > 0 ? (activeLeases / totalCapacity) * 100 : 0,
            avgLeaseValue,
            moveIns,
            moveOuts,
            netChange: moveIns - moveOuts,
          };
        })
      );

      // Calculate portfolio totals
      const totalProjects = projectMetrics.length;
      const ownedProjects = projectMetrics.filter((p) => p.projectType === "OWNED").length;
      const dealProjects = projectMetrics.filter((p) => p.projectType === "DEAL").length;
      const totalRevenue = projectMetrics.reduce((sum, p) => sum + p.totalRevenue, 0);
      const totalActiveLeases = projectMetrics.reduce((sum, p) => sum + p.activeLeases, 0);
      const totalCapacity = projectMetrics.reduce((sum, p) => sum + p.totalCapacity, 0);
      const avgOccupancy = totalCapacity > 0 ? (totalActiveLeases / totalCapacity) * 100 : 0;
      const avgLeaseValue = totalActiveLeases > 0
        ? projectMetrics.reduce((sum, p) => sum + p.avgLeaseValue * p.activeLeases, 0) / totalActiveLeases
        : 0;
      const totalMoveIns = projectMetrics.reduce((sum, p) => sum + p.moveIns, 0);
      const totalMoveOuts = projectMetrics.reduce((sum, p) => sum + p.moveOuts, 0);

      res.json({
        totalProjects,
        ownedProjects,
        dealProjects,
        totalRevenue,
        totalActiveLeases,
        totalCapacity,
        avgOccupancy,
        avgLeaseValue,
        totalMoveIns,
        totalMoveOuts,
        netChange: totalMoveIns - totalMoveOuts,
        projectMetrics,
      });
    } catch (error) {
      console.error("Error fetching portfolio summary:", error);
      res.status(500).json({ error: "Failed to fetch portfolio summary" });
    }
  });

  // ============================================================================
  // COHORT ANALYSIS ENDPOINTS
  // ============================================================================

  // GET /api/cohort/analysis - Get tenant cohort analysis data
  app.get("/api/cohort/analysis", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);
      
      if (organizationIds.length === 0) {
        return res.status(403).json({ error: "Organization required" });
      }

      const { locationId, granularity = "quarter", startDate, endDate } = req.query;

      // Get all projects for user's organizations
      const projects = await db
        .select()
        .from(marinaLocations)
        .where(inArray(marinaLocations.organizationId, organizationIds));

      const projectIds = projects.map(p => p.id);

      if (projectIds.length === 0) {
        return res.json({
          summary: {
            totalTenants: 0, activeTenants: 0, churned: 0, overallRetention: 0, overallChurn: 0,
            avgTenureMonths: 0, cohortsCount: 0, totalRevenue: 0, avgRevenuePerCohort: 0,
            avgLeaseValue: 0, totalLTV: 0, avgLTV: 0, estimatedLTV: 0, growthRate: 0,
            retentionChange: 0, ltvChange: 0,
          },
          cohorts: [],
          retentionMatrix: [],
          retentionHeatmap: [],
          revenueTrend: [],
          availableProjects: [],
        });
      }

      // Validate locationId belongs to user's organizations if provided
      if (locationId && !projectIds.includes(locationId as string)) {
        return res.status(403).json({ error: "Access denied to this location" });
      }

      // Build the where conditions for ALL leases (to understand full tenant history)
      const allLeasesConditions = [
        inArray(leases.locationId, projectIds)
      ];
      
      if (locationId) {
        allLeasesConditions.push(eq(leases.locationId, locationId as string));
      }

      // Get ALL leases with tenant info for these projects (for proper tenant status)
      const allLeasesWithTenants = await db
        .select({
          leaseId: leases.id,
          tenantId: leases.tenantId,
          tenantName: tenants.name,
          locationId: leases.locationId,
          leaseCommencement: leases.leaseCommencement,
          leaseExpiration: leases.leaseExpiration,
          isActive: leases.isActive,
          leaseAmount: leases.leaseAmount,
        })
        .from(leases)
        .innerJoin(tenants, eq(leases.tenantId, tenants.id))
        .where(and(...allLeasesConditions));

      // Get LTV per lease using SQL aggregation with proper date filtering
      // This uses SQL to filter cash flows within lease term, which is more accurate
      const leaseIds = allLeasesWithTenants.map(l => l.leaseId);
      const cashFlowsByLease = new Map<string, number>();
      
      if (leaseIds.length > 0) {
        // LTV = sum of cash flows where period date falls within lease term
        // Use LEFT JOINs to preserve leases with missing period linkage, filter in WHERE
        const ltvResults = await db
          .select({
            leaseId: leases.id,
            totalLtv: sql<string>`COALESCE(SUM(CASE 
              WHEN ${periods.periodDate} >= ${leases.leaseCommencement} 
                AND ${periods.periodDate} <= COALESCE(${leases.leaseExpiration}, '2099-12-31') 
              THEN ${leaseCashFlows.rentAmount} 
              ELSE 0 
            END), 0)`,
          })
          .from(leases)
          .leftJoin(leaseCashFlows, eq(leaseCashFlows.leaseId, leases.id))
          .leftJoin(periods, eq(leaseCashFlows.periodId, periods.id))
          .where(inArray(leases.id, leaseIds))
          .groupBy(leases.id);
        
        // Build the map from query results
        ltvResults.forEach((row) => {
          const leaseId = row.leaseId;
          const ltv = parseFloat(row.totalLtv || "0");
          if (leaseId && ltv > 0) {
            cashFlowsByLease.set(leaseId, ltv);
          }
        });
      }

      // Build a map of all leases per tenant (for proper churn detection)
      const tenantLeaseMap = new Map<string, typeof allLeasesWithTenants>();
      allLeasesWithTenants.forEach(lease => {
        if (!tenantLeaseMap.has(lease.tenantId)) {
          tenantLeaseMap.set(lease.tenantId, []);
        }
        tenantLeaseMap.get(lease.tenantId)!.push(lease);
      });

      const now = new Date();
      const todayStr = now.toISOString().split('T')[0];

      // Helper function: Check if tenant is currently active (has any active lease)
      const isTenantActive = (tenantId: string): boolean => {
        const tenantLeases = tenantLeaseMap.get(tenantId) || [];
        return tenantLeases.some(l => {
          // A tenant is active if they have a lease that:
          // 1. Has isActive = true AND
          // 2. Either has no expiration OR expiration is in the future
          if (!l.isActive) return false;
          if (!l.leaseExpiration) return true; // No expiration means perpetual
          return l.leaseExpiration >= todayStr;
        });
      };

      // Helper function: Check if tenant has churned (had lease that ended with no renewal)
      const hasTenantChurned = (tenantId: string): boolean => {
        const tenantLeases = tenantLeaseMap.get(tenantId) || [];
        
        // If no leases, not churned (never was a tenant)
        if (tenantLeases.length === 0) return false;
        
        // If tenant is currently active, they haven't churned
        if (isTenantActive(tenantId)) return false;
        
        // Check if they had at least one lease that has ended
        const hasEndedLease = tenantLeases.some(l => {
          if (!l.leaseCommencement) return false;
          // Lease has started
          if (l.leaseCommencement > todayStr) return false;
          // And has an expiration that has passed
          if (l.leaseExpiration && l.leaseExpiration < todayStr) return true;
          // Or isActive is false (manually marked as inactive)
          if (!l.isActive) return true;
          return false;
        });
        
        return hasEndedLease;
      };

      // Calculate tenant LTV using filtered cash flows (primary) or lease amount × duration (fallback)
      const calculateTenantLTV = (tenantId: string): { ltv: number; months: number } => {
        const tenantLeases = tenantLeaseMap.get(tenantId) || [];
        let totalRevenue = 0;
        let earliestStart: Date | null = null;
        let latestEnd: Date | null = null;
        
        tenantLeases.forEach(l => {
          // Try to use filtered cash flow data first (most accurate - includes escalations, etc.)
          const cashFlowRevenue = cashFlowsByLease.get(l.leaseId);
          if (cashFlowRevenue && cashFlowRevenue > 0) {
            totalRevenue += cashFlowRevenue;
          } else {
            // Fallback: Calculate using lease amount × months in full lease term
            // Use inclusive calendar month counting (Jan 1 to Dec 31 = 12 months, not 11.96)
            const monthlyRate = parseFloat(l.leaseAmount || "0");
            if (monthlyRate > 0 && l.leaseCommencement) {
              const startDate = new Date(l.leaseCommencement);
              const endDate = l.leaseExpiration ? new Date(l.leaseExpiration) : now;
              
              // Calculate inclusive months: count from start month to end month (inclusive)
              const startYear = startDate.getFullYear();
              const startMonth = startDate.getMonth();
              const endYear = endDate.getFullYear();
              const endMonth = endDate.getMonth();
              
              // Total months = (endYear - startYear) * 12 + (endMonth - startMonth) + 1 (inclusive)
              const durationMonths = Math.max(1, (endYear - startYear) * 12 + (endMonth - startMonth) + 1);
              
              totalRevenue += monthlyRate * durationMonths;
            }
          }
          
          // Track tenure duration (earliest start to latest end)
          if (l.leaseCommencement) {
            const start = new Date(l.leaseCommencement);
            if (!earliestStart || start < earliestStart) {
              earliestStart = start;
            }
          }
          if (l.leaseExpiration) {
            const end = new Date(l.leaseExpiration);
            if (!latestEnd || end > latestEnd) {
              latestEnd = end;
            }
          } else if (l.isActive) {
            if (!latestEnd || now > latestEnd) {
              latestEnd = now;
            }
          }
        });
        
        // Calculate total tenure in months
        const months = earliestStart && latestEnd
          ? Math.max(1, Math.round((latestEnd.getTime() - earliestStart.getTime()) / (1000 * 60 * 60 * 24 * 30.44)))
          : 0;
        
        return { ltv: Math.round(totalRevenue * 100) / 100, months };
      };

      // Filter leases for cohort assignment based on date range
      let cohortLeases = allLeasesWithTenants;
      if (startDate && endDate) {
        cohortLeases = allLeasesWithTenants.filter(l => 
          l.leaseCommencement && 
          l.leaseCommencement >= (startDate as string) && 
          l.leaseCommencement <= (endDate as string)
        );
      }

      // Group leases by cohort (based on FIRST lease commencement date per tenant)
      // First, find each tenant's first lease commencement
      const tenantFirstLease = new Map<string, string>(); // tenantId -> earliest commencement
      allLeasesWithTenants.forEach(lease => {
        if (!lease.leaseCommencement) return;
        const existing = tenantFirstLease.get(lease.tenantId);
        if (!existing || lease.leaseCommencement < existing) {
          tenantFirstLease.set(lease.tenantId, lease.leaseCommencement);
        }
      });

      const cohortMap = new Map<string, {
        cohortKey: string;
        cohortLabel: string;
        cohortDate: Date;
        totalTenants: number;
        activeTenants: number;
        churned: number;
        totalRevenue: number;
        totalLTV: number;
        tenantIds: Set<string>;
        leases: typeof allLeasesWithTenants;
        tenantLTVs: Map<string, { ltv: number; months: number }>;
      }>();

      // Assign tenants to cohorts based on their first lease
      tenantFirstLease.forEach((firstCommencement, tenantId) => {
        // Apply date filter if specified
        if (startDate && endDate) {
          if (firstCommencement < (startDate as string) || firstCommencement > (endDate as string)) {
            return; // Skip tenants whose first lease is outside the date range
          }
        }

        const commDate = new Date(firstCommencement);
        let cohortKey: string;
        let cohortLabel: string;

        if (granularity === "month") {
          cohortKey = `${commDate.getFullYear()}-${String(commDate.getMonth() + 1).padStart(2, "0")}`;
          cohortLabel = commDate.toLocaleDateString("en-US", { year: "numeric", month: "short" });
        } else if (granularity === "year") {
          cohortKey = `${commDate.getFullYear()}`;
          cohortLabel = `${commDate.getFullYear()}`;
        } else {
          // Quarter (default)
          const quarter = Math.floor(commDate.getMonth() / 3) + 1;
          cohortKey = `${commDate.getFullYear()}-Q${quarter}`;
          cohortLabel = `Q${quarter} ${commDate.getFullYear()}`;
        }

        if (!cohortMap.has(cohortKey)) {
          cohortMap.set(cohortKey, {
            cohortKey,
            cohortLabel,
            cohortDate: new Date(commDate.getFullYear(), Math.floor(commDate.getMonth() / 3) * 3, 1),
            totalTenants: 0,
            activeTenants: 0,
            churned: 0,
            totalRevenue: 0,
            totalLTV: 0,
            tenantIds: new Set(),
            leases: [],
            tenantLTVs: new Map(),
          });
        }

        const cohort = cohortMap.get(cohortKey)!;
        
        // Add tenant to cohort
        if (!cohort.tenantIds.has(tenantId)) {
          cohort.tenantIds.add(tenantId);
          cohort.totalTenants++;
          
          // Check tenant's CURRENT status using proper churn detection
          if (isTenantActive(tenantId)) {
            cohort.activeTenants++;
          } else if (hasTenantChurned(tenantId)) {
            cohort.churned++;
          }
          // Note: A tenant might not be active AND not churned if they haven't started yet
          
          // Calculate and store tenant LTV
          const tenantLTV = calculateTenantLTV(tenantId);
          cohort.tenantLTVs.set(tenantId, tenantLTV);
          cohort.totalLTV += tenantLTV.ltv;
        }
        
        // Add all of this tenant's leases to the cohort for analysis
        const tenantLeases = tenantLeaseMap.get(tenantId) || [];
        tenantLeases.forEach(l => {
          cohort.totalRevenue += parseFloat(l.leaseAmount || "0");
          cohort.leases.push(l);
        });
      });

      // Convert to array and calculate retention rates
      const cohorts = Array.from(cohortMap.values())
        .map(cohort => {
          const avgLTV = cohort.totalTenants > 0 
            ? cohort.totalLTV / cohort.totalTenants 
            : 0;
          
          // Calculate average tenure in months
          let totalTenureMonths = 0;
          cohort.tenantLTVs.forEach(ltv => {
            totalTenureMonths += ltv.months;
          });
          const avgTenureMonths = cohort.totalTenants > 0 
            ? totalTenureMonths / cohort.totalTenants 
            : 0;
          
          return {
            cohortKey: cohort.cohortKey,
            cohortLabel: cohort.cohortLabel,
            totalTenants: cohort.totalTenants,
            activeTenants: cohort.activeTenants,
            churned: cohort.churned,
            retentionRate: cohort.totalTenants > 0 
              ? (cohort.activeTenants / cohort.totalTenants) * 100 
              : 0,
            churnRate: cohort.totalTenants > 0 
              ? (cohort.churned / cohort.totalTenants) * 100 
              : 0,
            totalRevenue: cohort.totalRevenue,
            totalLTV: cohort.totalLTV,
            avgLTV,
            avgTenureMonths: Math.round(avgTenureMonths),
            avgLeaseValue: cohort.leases.length > 0
              ? cohort.totalRevenue / cohort.leases.length
              : 0,
            leaseCount: cohort.leases.length,
          };
        })
        .sort((a, b) => a.cohortKey.localeCompare(b.cohortKey));

      // Calculate retention over time (cohort retention matrix)
      const retentionMatrix: {
        cohortKey: string;
        cohortLabel: string;
        monthsFromStart: number[];
        retentionRates: number[];
      }[] = [];

      cohortMap.forEach((cohort, key) => {
        const monthsFromStart: number[] = [];
        const retentionRates: number[] = [];
        
        // Calculate how many tenants were still active at each month milestone
        for (let months = 0; months <= 24; months += 3) {
          const checkDate = new Date(cohort.cohortDate);
          checkDate.setMonth(checkDate.getMonth() + months);
          
          if (checkDate > now) break;

          const checkDateStr = checkDate.toISOString().split('T')[0];

          // Count tenants who had an active lease at this point in time
          const activeAtPoint = Array.from(cohort.tenantIds).filter(tenantId => {
            const tenantLeases = tenantLeaseMap.get(tenantId) || [];
            return tenantLeases.some(l => {
              if (!l.leaseCommencement) return false;
              const startDate = l.leaseCommencement;
              const endDate = l.leaseExpiration || "2099-12-31";
              // Lease was active if: started before check date AND ended after check date
              return startDate <= checkDateStr && endDate >= checkDateStr;
            });
          }).length;

          monthsFromStart.push(months);
          retentionRates.push(
            cohort.totalTenants > 0 
              ? (activeAtPoint / cohort.totalTenants) * 100 
              : 0
          );
        }

        if (monthsFromStart.length > 0) {
          retentionMatrix.push({
            cohortKey: key,
            cohortLabel: cohort.cohortLabel,
            monthsFromStart,
            retentionRates,
          });
        }
      });

      // Calculate overall metrics
      const totalTenantsAll = cohorts.reduce((sum, c) => sum + c.totalTenants, 0);
      const activeTenantsAll = cohorts.reduce((sum, c) => sum + c.activeTenants, 0);
      const churnedAll = cohorts.reduce((sum, c) => sum + c.churned, 0);
      const overallRetention = totalTenantsAll > 0 
        ? (activeTenantsAll / totalTenantsAll) * 100 
        : 0;
      const overallChurn = totalTenantsAll > 0
        ? (churnedAll / totalTenantsAll) * 100
        : 0;
      
      // Calculate overall average tenure
      const totalTenure = cohorts.reduce((sum, c) => sum + c.avgTenureMonths * c.totalTenants, 0);
      const avgTenure = totalTenantsAll > 0 ? totalTenure / totalTenantsAll : 0;
      
      // Calculate overall LTV metrics
      const totalLTV = cohorts.reduce((sum, c) => sum + c.totalLTV, 0);
      const avgLTV = totalTenantsAll > 0 ? totalLTV / totalTenantsAll : 0;
      
      // Calculate additional revenue metrics
      const totalRevenue = cohorts.reduce((sum, c) => sum + c.totalRevenue, 0);
      const avgRevenuePerCohort = cohorts.length > 0 ? totalRevenue / cohorts.length : 0;
      const totalLeases = cohorts.reduce((sum, c) => sum + c.leaseCount, 0);
      const avgLeaseValue = totalLeases > 0
        ? cohorts.reduce((sum, c) => sum + c.avgLeaseValue * c.leaseCount, 0) / totalLeases
        : 0;
      
      // Build revenue trend data
      const revenueTrend: { period: string; revenue: number; newTenants: number; churn: number; ltv: number }[] = [];
      cohorts.forEach(c => {
        revenueTrend.push({
          period: c.cohortLabel,
          revenue: c.totalRevenue,
          newTenants: c.totalTenants,
          churn: c.churned,
          ltv: c.avgLTV,
        });
      });
      
      // Calculate cohort-by-cohort comparison (if 2+ cohorts)
      let growthRate = 0;
      let retentionChange = 0;
      let ltvChange = 0;
      if (cohorts.length >= 2) {
        const recent = cohorts[cohorts.length - 1];
        const previous = cohorts[cohorts.length - 2];
        
        if (previous.totalTenants > 0) {
          growthRate = ((recent.totalTenants - previous.totalTenants) / previous.totalTenants) * 100;
        }
        retentionChange = recent.retentionRate - previous.retentionRate;
        if (previous.avgLTV > 0) {
          ltvChange = ((recent.avgLTV - previous.avgLTV) / previous.avgLTV) * 100;
        }
      }
      
      // Build retention matrix heatmap data
      const retentionHeatmap: { cohort: string; periods: { period: number; rate: number }[] }[] = [];
      retentionMatrix.forEach(r => {
        const periods = r.monthsFromStart.map((m, idx) => ({
          period: m,
          rate: r.retentionRates[idx],
        }));
        retentionHeatmap.push({
          cohort: r.cohortLabel,
          periods,
        });
      });

      res.json({
        summary: {
          totalTenants: totalTenantsAll,
          activeTenants: activeTenantsAll,
          churnedTenants: churnedAll,
          overallRetention,
          overallChurn,
          avgTenureMonths: Math.round(avgTenure),
          cohortsCount: cohorts.length,
          totalRevenue,
          avgRevenuePerCohort,
          avgLeaseValue,
          totalLTV,
          avgLTV,
          estimatedLTV: avgLTV, // Keep for backward compatibility
          growthRate,
          retentionChange,
          ltvChange,
        },
        cohorts,
        retentionMatrix: retentionMatrix.slice(-12), // Last 12 cohorts
        retentionHeatmap,
        revenueTrend,
        availableProjects: projects.map(p => ({ id: p.id, name: p.name })),
      });
    } catch (error) {
      console.error("Error fetching cohort analysis:", error);
      res.status(500).json({ error: "Failed to fetch cohort analysis" });
    }
  });

  // GET /api/cohort/ltv-trend - Get LTV trend data over time
  app.get("/api/cohort/ltv-trend", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);

      if (organizationIds.length === 0) {
        return res.json({ trend: [], summary: { currentAvgLTV: 0, previousAvgLTV: 0, change: 0 } });
      }

      const { locationId, granularity = "monthly" } = req.query;

      // Get all projects for user's organizations
      const projects = await db
        .select()
        .from(marinaLocations)
        .where(inArray(marinaLocations.organizationId, organizationIds));

      const projectIds = projects.map(p => p.id);

      if (projectIds.length === 0) {
        return res.json({ trend: [], summary: { currentAvgLTV: 0, previousAvgLTV: 0, change: 0 } });
      }

      if (locationId && !projectIds.includes(locationId as string)) {
        return res.status(403).json({ error: "Access denied to this location" });
      }

      // Get LTV trend by period using a two-step approach:
      // 1. Get leases with LTV using Drizzle query builder
      // 2. Aggregate by period in JavaScript
      
      // First, get all leases for the user's projects with their LTV
      const targetProjectIds = locationId ? [locationId as string] : projectIds;
      
      const leasesWithCommencement = await db
        .select({
          leaseId: leases.id,
          tenantId: leases.tenantId,
          leaseCommencement: leases.leaseCommencement,
          leaseExpiration: leases.leaseExpiration,
        })
        .from(leases)
        .where(and(
          inArray(leases.locationId, targetProjectIds),
          isNotNull(leases.leaseCommencement)
        ));

      // Get LTV for each lease using filtered cash flows
      const leaseIds = leasesWithCommencement.map(l => l.leaseId);
      const cashFlowsByLease = new Map<string, number>();
      
      if (leaseIds.length > 0) {
        // LTV = sum of cash flows where period date falls within lease term
        // Use LEFT JOINs to preserve leases with missing period linkage, filter via CASE WHEN
        const ltvResults = await db
          .select({
            leaseId: leases.id,
            totalLtv: sql<string>`COALESCE(SUM(CASE 
              WHEN ${periods.periodDate} >= ${leases.leaseCommencement} 
                AND ${periods.periodDate} <= COALESCE(${leases.leaseExpiration}, '2099-12-31') 
              THEN ${leaseCashFlows.rentAmount} 
              ELSE 0 
            END), 0)`,
          })
          .from(leases)
          .leftJoin(leaseCashFlows, eq(leaseCashFlows.leaseId, leases.id))
          .leftJoin(periods, eq(leaseCashFlows.periodId, periods.id))
          .where(inArray(leases.id, leaseIds))
          .groupBy(leases.id);
        
        ltvResults.forEach((row) => {
          cashFlowsByLease.set(row.leaseId, parseFloat(row.totalLtv) || 0);
        });
      }

      // Aggregate by period in JavaScript
      const periodMap = new Map<string, { tenants: Set<string>; totalLTV: number }>();
      
      for (const lease of leasesWithCommencement) {
        if (!lease.leaseCommencement) continue;
        
        const ltv = cashFlowsByLease.get(lease.leaseId) || 0;
        if (ltv <= 0) continue;
        
        // Determine the period key based on granularity
        const date = new Date(lease.leaseCommencement);
        let periodKey: string;
        
        if (granularity === 'quarterly') {
          const quarter = Math.floor(date.getMonth() / 3);
          periodKey = `${date.getFullYear()}-Q${quarter + 1}`;
        } else if (granularity === 'yearly') {
          periodKey = `${date.getFullYear()}`;
        } else {
          // monthly
          periodKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        }
        
        if (!periodMap.has(periodKey)) {
          periodMap.set(periodKey, { tenants: new Set(), totalLTV: 0 });
        }
        
        const periodData = periodMap.get(periodKey)!;
        periodData.tenants.add(lease.tenantId);
        periodData.totalLTV += ltv;
      }

      // Convert to array and calculate averages
      const trend = Array.from(periodMap.entries())
        .map(([period, data]) => {
          // Convert period key to date for sorting
          let periodDate: Date;
          if (granularity === 'quarterly') {
            const [year, q] = period.split('-Q');
            periodDate = new Date(parseInt(year), (parseInt(q) - 1) * 3, 1);
          } else if (granularity === 'yearly') {
            periodDate = new Date(parseInt(period), 0, 1);
          } else {
            const [year, month] = period.split('-');
            periodDate = new Date(parseInt(year), parseInt(month) - 1, 1);
          }
          
          return {
            period: periodDate.toISOString(),
            tenantCount: data.tenants.size,
            avgLTV: Math.round((data.totalLTV / data.tenants.size) * 100) / 100,
            totalLTV: Math.round(data.totalLTV * 100) / 100,
          };
        })
        .sort((a, b) => new Date(a.period).getTime() - new Date(b.period).getTime());

      // Calculate summary with current vs previous period comparison
      let currentAvgLTV = 0;
      let previousAvgLTV = 0;
      let change = 0;

      if (trend.length >= 1) {
        currentAvgLTV = trend[trend.length - 1].avgLTV;
      }
      if (trend.length >= 2) {
        previousAvgLTV = trend[trend.length - 2].avgLTV;
        if (previousAvgLTV > 0) {
          change = ((currentAvgLTV - previousAvgLTV) / previousAvgLTV) * 100;
        }
      }

      res.json({
        trend,
        summary: {
          currentAvgLTV,
          previousAvgLTV,
          change: Math.round(change * 100) / 100,
        }
      });
    } catch (error) {
      console.error("Error fetching LTV trend:", error);
      res.status(500).json({ error: "Failed to fetch LTV trend" });
    }
  });

  // ============================================================================
  // COMMENTS/NOTES API
  // ============================================================================

  // Get comments for an entity (lease, tenant, project)
  app.get("/api/comments/:entityType/:entityId", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { entityType, entityId } = req.params;
      const organizationId = req.user?.organizationId;

      if (!organizationId) {
        return res.status(403).json({ error: "Organization required" });
      }

      const entityComments = await db
        .select({
          id: comments.id,
          content: comments.content,
          isPinned: comments.isPinned,
          createdAt: comments.createdAt,
          updatedAt: comments.updatedAt,
          userId: comments.userId,
          userName: sql<string>`COALESCE(${users.firstName} || ' ' || ${users.lastName}, ${users.email})`,
        })
        .from(comments)
        .leftJoin(users, eq(comments.userId, users.id))
        .where(
          and(
            eq(comments.organizationId, organizationId),
            eq(comments.entityType, entityType as any),
            eq(comments.entityId, entityId)
          )
        )
        .orderBy(desc(comments.isPinned), desc(comments.createdAt));

      res.json(entityComments);
    } catch (error) {
      console.error("Error fetching comments:", error);
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  // Create a new comment
  app.post("/api/comments", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user?.id;
      const organizationId = req.user?.organizationId;

      if (!userId || !organizationId) {
        return res.status(403).json({ error: "Authentication required" });
      }

      const parsed = insertCommentSchema.safeParse({
        ...req.body,
        userId,
        organizationId,
      });

      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid comment data", details: parsed.error.errors });
      }

      const [newComment] = await db
        .insert(comments)
        .values(parsed.data)
        .returning();

      res.json(newComment);
    } catch (error) {
      console.error("Error creating comment:", error);
      res.status(500).json({ error: "Failed to create comment" });
    }
  });

  // Update a comment
  app.patch("/api/comments/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user?.id;
      const organizationId = req.user?.organizationId;

      if (!userId || !organizationId) {
        return res.status(403).json({ error: "Authentication required" });
      }

      // Check ownership
      const [existing] = await db
        .select()
        .from(comments)
        .where(and(eq(comments.id, id), eq(comments.organizationId, organizationId)));

      if (!existing) {
        return res.status(404).json({ error: "Comment not found" });
      }

      // Only allow editing own comments or if admin
      if (existing.userId !== userId) {
        const userRole = req.user?.organizationRole;
        if (!hasPermission(userRole, "canDeleteData")) {
          return res.status(403).json({ error: "Not authorized to edit this comment" });
        }
      }

      const { content, isPinned } = req.body;
      const updates: any = { updatedAt: new Date() };
      if (content !== undefined) updates.content = content;
      if (isPinned !== undefined) updates.isPinned = isPinned;

      const [updated] = await db
        .update(comments)
        .set(updates)
        .where(eq(comments.id, id))
        .returning();

      res.json(updated);
    } catch (error) {
      console.error("Error updating comment:", error);
      res.status(500).json({ error: "Failed to update comment" });
    }
  });

  // Delete a comment
  app.delete("/api/comments/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user?.id;
      const organizationId = req.user?.organizationId;

      if (!userId || !organizationId) {
        return res.status(403).json({ error: "Authentication required" });
      }

      // Check ownership
      const [existing] = await db
        .select()
        .from(comments)
        .where(and(eq(comments.id, id), eq(comments.organizationId, organizationId)));

      if (!existing) {
        return res.status(404).json({ error: "Comment not found" });
      }

      // Only allow deleting own comments or if admin
      if (existing.userId !== userId) {
        const userRole = req.user?.organizationRole;
        if (!hasPermission(userRole, "canDeleteData")) {
          return res.status(403).json({ error: "Not authorized to delete this comment" });
        }
      }

      await db.delete(comments).where(eq(comments.id, id));

      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting comment:", error);
      res.status(500).json({ error: "Failed to delete comment" });
    }
  });

  // ============================================================================
  // LEASE ECONOMICS V2 ROUTES
  // ============================================================================

  // Feature Flags
  app.get("/api/feature-flags", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const organizationId = req.user?.organizationId;
      if (!organizationId) {
        return res.status(403).json({ error: "Organization required" });
      }

      const flags = await db
        .select()
        .from(orgFeatureFlags)
        .where(eq(orgFeatureFlags.organizationId, organizationId));

      // Return as a map of key -> enabled
      const flagMap: Record<string, boolean> = {};
      for (const flag of flags) {
        flagMap[flag.key] = flag.enabled;
      }
      
      // Include all keys with defaults
      for (const key of FEATURE_FLAG_KEYS) {
        if (!(key in flagMap)) {
          flagMap[key] = false;
        }
      }

      res.json(flagMap);
    } catch (error) {
      console.error("Error fetching feature flags:", error);
      res.status(500).json({ error: "Failed to fetch feature flags" });
    }
  });

  app.put("/api/feature-flags/:key", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const organizationId = req.user?.organizationId;
      const userRole = req.user?.organizationRole;
      
      if (!organizationId) {
        return res.status(403).json({ error: "Organization required" });
      }
      
      if (!hasPermission(userRole, "canManageSettings")) {
        return res.status(403).json({ error: "Not authorized to manage feature flags" });
      }

      const { key } = req.params;
      const { enabled } = req.body;

      if (!FEATURE_FLAG_KEYS.includes(key as any)) {
        return res.status(400).json({ error: "Invalid feature flag key" });
      }

      // Upsert the flag
      const existing = await db
        .select()
        .from(orgFeatureFlags)
        .where(and(
          eq(orgFeatureFlags.organizationId, organizationId),
          eq(orgFeatureFlags.key, key)
        ));

      if (existing.length > 0) {
        await db
          .update(orgFeatureFlags)
          .set({ enabled, updatedAt: new Date() })
          .where(eq(orgFeatureFlags.id, existing[0].id));
      } else {
        await db.insert(orgFeatureFlags).values({
          organizationId,
          key,
          enabled,
        });
      }

      res.json({ key, enabled });
    } catch (error) {
      console.error("Error updating feature flag:", error);
      res.status(500).json({ error: "Failed to update feature flag" });
    }
  });

  // Lease Terms CRUD
  app.get("/api/leases/:leaseId/terms", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const terms = await db
        .select()
        .from(leaseTerms)
        .where(eq(leaseTerms.leaseId, leaseId))
        .orderBy(desc(leaseTerms.startDate));
      res.json(terms);
    } catch (error) {
      console.error("Error fetching lease terms:", error);
      res.status(500).json({ error: "Failed to fetch lease terms" });
    }
  });

  app.post("/api/leases/:leaseId/terms", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const parsed = insertLeaseTermSchema.safeParse({ ...req.body, leaseId });
      
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid lease term data", details: parsed.error });
      }

      const [term] = await db.insert(leaseTerms).values(parsed.data).returning();
      res.json(term);
    } catch (error) {
      console.error("Error creating lease term:", error);
      res.status(500).json({ error: "Failed to create lease term" });
    }
  });

  app.put("/api/lease-terms/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseTerms, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      const [updated] = await db
        .update(leaseTerms)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(leaseTerms.id, id))
        .returning();
      res.json(updated);
    } catch (error) {
      console.error("Error updating lease term:", error);
      res.status(500).json({ error: "Failed to update lease term" });
    }
  });

  app.delete("/api/lease-terms/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseTerms, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      await db.delete(leaseTerms).where(eq(leaseTerms.id, id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting lease term:", error);
      res.status(500).json({ error: "Failed to delete lease term" });
    }
  });

  // Rent Steps CRUD
  app.get("/api/leases/:leaseId/rent-steps", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const steps = await db
        .select()
        .from(leaseRentSteps)
        .where(eq(leaseRentSteps.leaseId, leaseId))
        .orderBy(asc(leaseRentSteps.effectiveDate));
      res.json(steps);
    } catch (error) {
      console.error("Error fetching rent steps:", error);
      res.status(500).json({ error: "Failed to fetch rent steps" });
    }
  });

  app.post("/api/leases/:leaseId/rent-steps", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const parsed = insertLeaseRentStepSchema.safeParse({ ...req.body, leaseId });
      
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid rent step data", details: parsed.error });
      }

      const [step] = await db.insert(leaseRentSteps).values(parsed.data).returning();
      res.json(step);
    } catch (error) {
      console.error("Error creating rent step:", error);
      res.status(500).json({ error: "Failed to create rent step" });
    }
  });

  app.put("/api/rent-steps/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseRentSteps, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      const [updated] = await db
        .update(leaseRentSteps)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(leaseRentSteps.id, id))
        .returning();
      res.json(updated);
    } catch (error) {
      console.error("Error updating rent step:", error);
      res.status(500).json({ error: "Failed to update rent step" });
    }
  });

  app.delete("/api/rent-steps/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseRentSteps, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      await db.delete(leaseRentSteps).where(eq(leaseRentSteps.id, id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting rent step:", error);
      res.status(500).json({ error: "Failed to delete rent step" });
    }
  });

  // Escalations CRUD
  app.get("/api/leases/:leaseId/escalations", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const escalations = await db
        .select()
        .from(leaseEscalations)
        .where(eq(leaseEscalations.leaseId, leaseId))
        .orderBy(asc(leaseEscalations.effectiveDate));
      res.json(escalations);
    } catch (error) {
      console.error("Error fetching escalations:", error);
      res.status(500).json({ error: "Failed to fetch escalations" });
    }
  });

  app.post("/api/leases/:leaseId/escalations", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const parsed = insertLeaseEscalationSchema.safeParse({ ...req.body, leaseId });
      
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid escalation data", details: parsed.error });
      }

      const [escalation] = await db.insert(leaseEscalations).values(parsed.data).returning();
      res.json(escalation);
    } catch (error) {
      console.error("Error creating escalation:", error);
      res.status(500).json({ error: "Failed to create escalation" });
    }
  });

  app.put("/api/escalations/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseEscalations, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      const [updated] = await db
        .update(leaseEscalations)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(leaseEscalations.id, id))
        .returning();
      res.json(updated);
    } catch (error) {
      console.error("Error updating escalation:", error);
      res.status(500).json({ error: "Failed to update escalation" });
    }
  });

  app.delete("/api/escalations/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseEscalations, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      await db.delete(leaseEscalations).where(eq(leaseEscalations.id, id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting escalation:", error);
      res.status(500).json({ error: "Failed to delete escalation" });
    }
  });

  // Concessions CRUD
  app.get("/api/leases/:leaseId/concessions", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const concessions = await db
        .select()
        .from(leaseConcessions)
        .where(eq(leaseConcessions.leaseId, leaseId))
        .orderBy(asc(leaseConcessions.startDate));
      res.json(concessions);
    } catch (error) {
      console.error("Error fetching concessions:", error);
      res.status(500).json({ error: "Failed to fetch concessions" });
    }
  });

  app.post("/api/leases/:leaseId/concessions", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const parsed = insertLeaseConcessionSchema.safeParse({ ...req.body, leaseId });
      
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid concession data", details: parsed.error });
      }

      const [concession] = await db.insert(leaseConcessions).values(parsed.data).returning();
      res.json(concession);
    } catch (error) {
      console.error("Error creating concession:", error);
      res.status(500).json({ error: "Failed to create concession" });
    }
  });

  app.put("/api/concessions/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseConcessions, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      const [updated] = await db
        .update(leaseConcessions)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(leaseConcessions.id, id))
        .returning();
      res.json(updated);
    } catch (error) {
      console.error("Error updating concession:", error);
      res.status(500).json({ error: "Failed to update concession" });
    }
  });

  app.delete("/api/concessions/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseConcessions, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      await db.delete(leaseConcessions).where(eq(leaseConcessions.id, id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting concession:", error);
      res.status(500).json({ error: "Failed to delete concession" });
    }
  });

  // Billing Rules CRUD
  app.get("/api/leases/:leaseId/billing-rules", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const rules = await db
        .select()
        .from(leaseBillingRules)
        .where(eq(leaseBillingRules.leaseId, leaseId));
      res.json(rules);
    } catch (error) {
      console.error("Error fetching billing rules:", error);
      res.status(500).json({ error: "Failed to fetch billing rules" });
    }
  });

  app.post("/api/leases/:leaseId/billing-rules", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const parsed = insertLeaseBillingRuleSchema.safeParse({ ...req.body, leaseId });
      
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid billing rule data", details: parsed.error });
      }

      const [rule] = await db.insert(leaseBillingRules).values(parsed.data).returning();
      res.json(rule);
    } catch (error) {
      console.error("Error creating billing rule:", error);
      res.status(500).json({ error: "Failed to create billing rule" });
    }
  });

  app.put("/api/billing-rules/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseBillingRules, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      const [updated] = await db
        .update(leaseBillingRules)
        .set({ ...req.body, updatedAt: new Date() })
        .where(eq(leaseBillingRules.id, id))
        .returning();
      res.json(updated);
    } catch (error) {
      console.error("Error updating billing rule:", error);
      res.status(500).json({ error: "Failed to update billing rule" });
    }
  });

  app.delete("/api/billing-rules/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      
      // Verify access via parent lease
      const access = await verifyV2ResourceAccess(leaseBillingRules, id, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }
      
      await db.delete(leaseBillingRules).where(eq(leaseBillingRules.id, id));
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting billing rule:", error);
      res.status(500).json({ error: "Failed to delete billing rule" });
    }
  });

  // Generate V2 Cash Flows
  app.get("/api/leases/:leaseId/economics-cashflows", isAuthenticated, requireLeaseAccess(storage), async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const { startDate, endDate, yearsToProject } = req.query;

      const options: any = {};
      if (startDate) options.startDate = new Date(startDate as string);
      if (endDate) options.endDate = new Date(endDate as string);
      if (yearsToProject) options.yearsToProject = parseInt(yearsToProject as string);

      const result = await generateLeaseEconomicsCashFlows(leaseId, options);
      res.json(result);
    } catch (error) {
      console.error("Error generating economics cash flows:", error);
      res.status(500).json({ error: "Failed to generate cash flows" });
    }
  });

  // Check if lease has V2 economics data
  app.get("/api/leases/:leaseId/has-economics-v2", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { leaseId } = req.params;
      const hasV2 = await hasEconomicsV2Data(leaseId);
      res.json({ hasV2 });
    } catch (error) {
      console.error("Error checking V2 data:", error);
      res.status(500).json({ error: "Failed to check V2 data" });
    }
  });

  // ============================================================================
  // SNAPSHOT VERSIONING ROUTES
  // ============================================================================

  // Helper to check if a feature flag is enabled for an organization
  async function isFeatureFlagEnabled(organizationId: string, flagKey: string): Promise<boolean> {
    try {
      const [flag] = await db
        .select()
        .from(orgFeatureFlags)
        .where(and(
          eq(orgFeatureFlags.organizationId, organizationId),
          eq(orgFeatureFlags.key, flagKey)
        ))
        .limit(1);
      return flag?.enabled ?? false;
    } catch (error) {
      console.error("Error checking feature flag:", error);
      return false;
    }
  }

  // Helper to verify project access for snapshot routes
  async function verifyProjectAccessWithFlag(projectId: string, userId: string): Promise<{ valid: boolean; error?: string; status?: number; organizationId?: string }> {
    try {
      const userOrgs = await storage.getUserOrganizations(userId);
      const organizationIds = userOrgs.map(org => org.id);

      if (organizationIds.length === 0) {
        return { valid: false, error: "Access denied: You are not a member of any organization", status: 403 };
      }

      const [project] = await db
        .select({ organizationId: marinaLocations.organizationId })
        .from(marinaLocations)
        .where(eq(marinaLocations.id, projectId))
        .limit(1);

      if (!project) {
        return { valid: false, error: "Project not found", status: 404 };
      }

      if (!organizationIds.includes(project.organizationId)) {
        return { valid: false, error: "Access denied: This project belongs to a different organization", status: 403 };
      }

      // Check if RENTROLL_SNAPSHOTS feature flag is enabled
      const isEnabled = await isFeatureFlagEnabled(project.organizationId, 'RENTROLL_SNAPSHOTS');
      if (!isEnabled) {
        return { valid: false, error: "Snapshot versioning feature is not enabled for your organization", status: 403 };
      }

      return { valid: true, organizationId: project.organizationId };
    } catch (error) {
      console.error("Error verifying project access:", error);
      return { valid: false, error: "Failed to verify project access", status: 500 };
    }
  }

  // Get all snapshots for a project
  app.get("/api/projects/:projectId/snapshots", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { projectId } = req.params;
      const userId = req.user.claims.sub;

      // Verify project access and feature flag
      const access = await verifyProjectAccessWithFlag(projectId, userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const snapshots = await getProjectSnapshots(projectId);
      res.json(snapshots);
    } catch (error) {
      console.error("Error fetching snapshots:", error);
      res.status(500).json({ error: "Failed to fetch snapshots" });
    }
  });

  // Create a new snapshot
  app.post("/api/projects/:projectId/snapshots", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { projectId } = req.params;
      const { name, description, asOfDate, yearsToProject } = req.body;
      const userId = req.user.claims.sub;

      // Verify project access and feature flag
      const access = await verifyProjectAccessWithFlag(projectId, userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      if (!name || !asOfDate) {
        return res.status(400).json({ error: "Name and as-of date are required" });
      }

      const snapshot = await createSnapshot({
        projectId,
        name,
        description,
        asOfDate: new Date(asOfDate),
        yearsToProject: yearsToProject || 5,
        createdBy: userId,
      });

      res.json(snapshot);
    } catch (error) {
      console.error("Error creating snapshot:", error);
      res.status(500).json({ error: "Failed to create snapshot" });
    }
  });

  // Get snapshot details
  app.get("/api/snapshots/:snapshotId", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { snapshotId } = req.params;
      const userId = req.user.claims.sub;

      // Verify access to snapshot via organization
      const access = await verifySnapshotAccess(snapshotId, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const snapshot = await getSnapshotDetails(snapshotId);

      if (!snapshot) {
        return res.status(404).json({ error: "Snapshot not found" });
      }

      res.json(snapshot);
    } catch (error) {
      console.error("Error fetching snapshot:", error);
      res.status(500).json({ error: "Failed to fetch snapshot" });
    }
  });

  // Get snapshot cash flows
  app.get("/api/snapshots/:snapshotId/cashflows", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { snapshotId } = req.params;
      const userId = req.user.claims.sub;

      // Verify access to snapshot via organization
      const access = await verifySnapshotAccess(snapshotId, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const cashFlows = await getSnapshotCashFlows(snapshotId);
      res.json(cashFlows);
    } catch (error) {
      console.error("Error fetching snapshot cash flows:", error);
      res.status(500).json({ error: "Failed to fetch snapshot cash flows" });
    }
  });

  // Finalize snapshot
  app.post("/api/snapshots/:snapshotId/finalize", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { snapshotId } = req.params;
      const userId = req.user.claims.sub;

      // Verify access to snapshot via organization
      const access = await verifySnapshotAccess(snapshotId, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      // Only allow finalizing draft snapshots
      if (access.snapshot?.status !== 'draft') {
        return res.status(409).json({ error: "Only draft snapshots can be finalized" });
      }

      const snapshot = await finalizeSnapshot(snapshotId, userId);

      if (!snapshot) {
        return res.status(404).json({ error: "Snapshot not found" });
      }

      res.json(snapshot);
    } catch (error) {
      console.error("Error finalizing snapshot:", error);
      res.status(500).json({ error: "Failed to finalize snapshot" });
    }
  });

  // Compare two snapshots
  app.get("/api/snapshots/:baseSnapshotId/compare/:compareSnapshotId", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { baseSnapshotId, compareSnapshotId } = req.params;
      const userId = req.user.claims.sub;

      // Verify access to both snapshots
      const [baseAccess, compareAccess] = await Promise.all([
        verifySnapshotAccess(baseSnapshotId, userId, storage),
        verifySnapshotAccess(compareSnapshotId, userId, storage),
      ]);

      if (!baseAccess.valid) {
        return res.status(baseAccess.status || 403).json({ error: baseAccess.error });
      }
      if (!compareAccess.valid) {
        return res.status(compareAccess.status || 403).json({ error: compareAccess.error });
      }

      const comparison = await compareSnapshots(baseSnapshotId, compareSnapshotId);
      res.json(comparison);
    } catch (error) {
      console.error("Error comparing snapshots:", error);
      res.status(500).json({ error: "Failed to compare snapshots" });
    }
  });

  // Delete draft snapshot
  app.delete("/api/snapshots/:snapshotId", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { snapshotId } = req.params;
      const userId = req.user.claims.sub;

      // Verify access to snapshot via organization
      const access = await verifySnapshotAccess(snapshotId, userId, storage);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      // Only allow deleting draft snapshots
      if (access.snapshot?.status !== 'draft') {
        return res.status(409).json({ error: "Only draft snapshots can be deleted" });
      }

      const deleted = await deleteSnapshot(snapshotId);

      if (!deleted) {
        return res.status(400).json({ error: "Cannot delete snapshot. It may be finalized or not found." });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting snapshot:", error);
      res.status(500).json({ error: "Failed to delete snapshot" });
    }
  });

  // ============================================================================
  // GL RECONCILIATION ROUTES (Feature-flagged: RENTROLL_RECONCILIATION)
  // ============================================================================

  // Helper to verify GL reconciliation access
  async function verifyGlReconciliationAccess(userId: string): Promise<{ valid: boolean; error?: string; status?: number; organizationId?: string }> {
    const orgMembership = await storage.getUserOrganization(userId);
    if (!orgMembership) {
      return { valid: false, error: "User is not a member of any organization", status: 403 };
    }

    const featureEnabled = await storage.isFeatureFlagEnabled(orgMembership.organizationId, 'RENTROLL_RECONCILIATION');
    if (!featureEnabled) {
      return { valid: false, error: "GL Reconciliation feature is not enabled for this organization", status: 403 };
    }

    return { valid: true, organizationId: orgMembership.organizationId };
  }

  // GET /api/gl-accounts - Get all GL accounts for organization
  app.get("/api/gl-accounts", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const accounts = await reconciliationService.getGlAccounts(access.organizationId!);
      res.json(accounts);
    } catch (error) {
      console.error("Error fetching GL accounts:", error);
      res.status(500).json({ error: "Failed to fetch GL accounts" });
    }
  });

  // POST /api/gl-accounts - Create a new GL account
  app.post("/api/gl-accounts", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const account = await reconciliationService.createGlAccount({
        ...req.body,
        organizationId: access.organizationId!,
      });
      res.status(201).json(account);
    } catch (error) {
      console.error("Error creating GL account:", error);
      res.status(500).json({ error: "Failed to create GL account" });
    }
  });

  // PUT /api/gl-accounts/:id - Update a GL account
  app.put("/api/gl-accounts/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const account = await reconciliationService.updateGlAccount(id, access.organizationId!, req.body);
      if (!account) {
        return res.status(404).json({ error: "GL account not found" });
      }
      res.json(account);
    } catch (error) {
      console.error("Error updating GL account:", error);
      res.status(500).json({ error: "Failed to update GL account" });
    }
  });

  // DELETE /api/gl-accounts/:id - Delete a GL account
  app.delete("/api/gl-accounts/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      await reconciliationService.deleteGlAccount(id, access.organizationId!);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting GL account:", error);
      res.status(500).json({ error: "Failed to delete GL account" });
    }
  });

  // GET /api/gl-mappings - Get all GL mappings for organization
  app.get("/api/gl-mappings", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const mappings = await reconciliationService.getGlMappings(access.organizationId!);
      res.json(mappings);
    } catch (error) {
      console.error("Error fetching GL mappings:", error);
      res.status(500).json({ error: "Failed to fetch GL mappings" });
    }
  });

  // POST /api/gl-mappings - Create a new GL mapping
  app.post("/api/gl-mappings", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const mapping = await reconciliationService.createGlMapping({
        ...req.body,
        organizationId: access.organizationId!,
      });
      res.status(201).json(mapping);
    } catch (error) {
      console.error("Error creating GL mapping:", error);
      res.status(500).json({ error: "Failed to create GL mapping" });
    }
  });

  // PUT /api/gl-mappings/:id - Update a GL mapping
  app.put("/api/gl-mappings/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const mapping = await reconciliationService.updateGlMapping(id, access.organizationId!, req.body);
      if (!mapping) {
        return res.status(404).json({ error: "GL mapping not found" });
      }
      res.json(mapping);
    } catch (error) {
      console.error("Error updating GL mapping:", error);
      res.status(500).json({ error: "Failed to update GL mapping" });
    }
  });

  // DELETE /api/gl-mappings/:id - Delete a GL mapping
  app.delete("/api/gl-mappings/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      await reconciliationService.deleteGlMapping(id, access.organizationId!);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting GL mapping:", error);
      res.status(500).json({ error: "Failed to delete GL mapping" });
    }
  });

  // GET /api/reconciliation-records - Get all reconciliation records for organization
  app.get("/api/reconciliation-records", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const projectId = req.query.projectId as string | undefined;
      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const records = await reconciliationService.getReconciliationRecords(access.organizationId!, projectId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching reconciliation records:", error);
      res.status(500).json({ error: "Failed to fetch reconciliation records" });
    }
  });

  // POST /api/reconciliation-records - Create or get a reconciliation record for a period
  app.post("/api/reconciliation-records", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { projectId, year, month } = req.body;
      if (!year || !month) {
        return res.status(400).json({ error: "Year and month are required" });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const record = await reconciliationService.getOrCreateReconciliationRecord(
        access.organizationId!,
        projectId || null,
        year,
        month
      );
      res.json(record);
    } catch (error) {
      console.error("Error creating reconciliation record:", error);
      res.status(500).json({ error: "Failed to create reconciliation record" });
    }
  });

  // GET /api/reconciliation-records/:id/breakdown - Get detailed breakdown for a reconciliation record
  app.get("/api/reconciliation-records/:id/breakdown", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const breakdown = await reconciliationService.getReconciliationBreakdown(access.organizationId!, id);
      res.json(breakdown);
    } catch (error) {
      console.error("Error fetching reconciliation breakdown:", error);
      res.status(500).json({ error: "Failed to fetch reconciliation breakdown" });
    }
  });

  // POST /api/reconciliation-records/:id/run - Run reconciliation for a record
  app.post("/api/reconciliation-records/:id/run", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { glTotals } = req.body;
      const glTotalsMap = new Map<string, number>(Object.entries(glTotals || {}));

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const record = await reconciliationService.runReconciliation(access.organizationId!, id, glTotalsMap);
      res.json(record);
    } catch (error) {
      console.error("Error running reconciliation:", error);
      res.status(500).json({ error: "Failed to run reconciliation" });
    }
  });

  // PUT /api/reconciliation-records/:id/status - Update reconciliation status
  app.put("/api/reconciliation-records/:id/status", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyGlReconciliationAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ error: "Status is required" });
      }

      const { reconciliationService } = await import("./services/glReconciliation/reconciliationService");
      const record = await reconciliationService.updateReconciliationStatus(access.organizationId!, id, status, userId);
      if (!record) {
        return res.status(404).json({ error: "Reconciliation record not found" });
      }
      res.json(record);
    } catch (error) {
      console.error("Error updating reconciliation status:", error);
      res.status(500).json({ error: "Failed to update reconciliation status" });
    }
  });

  // ============================================================================
  // INVESTOR REPORT PACKAGES ROUTES (Feature-flagged: RENTROLL_REPORT_PACKAGE)
  // ============================================================================

  // Helper to verify report package access
  async function verifyReportPackageAccess(userId: string): Promise<{ valid: boolean; error?: string; status?: number; organizationId?: string }> {
    const orgMembership = await storage.getUserOrganization(userId);
    if (!orgMembership) {
      return { valid: false, error: "User is not a member of any organization", status: 403 };
    }

    const featureEnabled = await storage.isFeatureFlagEnabled(orgMembership.organizationId, 'RENTROLL_REPORT_PACKAGE');
    if (!featureEnabled) {
      return { valid: false, error: "Report Package feature is not enabled for this organization", status: 403 };
    }

    return { valid: true, organizationId: orgMembership.organizationId };
  }

  // GET /api/report-packages - Get all report packages for organization
  app.get("/api/report-packages", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const projectId = req.query.projectId as string | undefined;
      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      const packages = await reportPackageService.getReportPackages(access.organizationId!, projectId);
      res.json(packages);
    } catch (error) {
      console.error("Error fetching report packages:", error);
      res.status(500).json({ error: "Failed to fetch report packages" });
    }
  });

  // POST /api/report-packages - Create a new report package
  app.post("/api/report-packages", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      const pkg = await reportPackageService.createReportPackage({
        ...req.body,
        organizationId: access.organizationId!,
      }, userId);
      res.status(201).json(pkg);
    } catch (error) {
      console.error("Error creating report package:", error);
      res.status(500).json({ error: "Failed to create report package" });
    }
  });

  // GET /api/report-packages/:id - Get a report package by ID
  app.get("/api/report-packages/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      const pkg = await reportPackageService.getReportPackageById(id, access.organizationId!);
      if (!pkg) {
        return res.status(404).json({ error: "Report package not found" });
      }
      res.json(pkg);
    } catch (error) {
      console.error("Error fetching report package:", error);
      res.status(500).json({ error: "Failed to fetch report package" });
    }
  });

  // PUT /api/report-packages/:id - Update a report package
  app.put("/api/report-packages/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      const pkg = await reportPackageService.updateReportPackage(id, access.organizationId!, req.body);
      if (!pkg) {
        return res.status(404).json({ error: "Report package not found" });
      }
      res.json(pkg);
    } catch (error) {
      console.error("Error updating report package:", error);
      res.status(500).json({ error: "Failed to update report package" });
    }
  });

  // DELETE /api/report-packages/:id - Delete a draft report package
  app.delete("/api/report-packages/:id", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      await reportPackageService.deleteReportPackage(id, access.organizationId!);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting report package:", error);
      if (error.message === "Only draft report packages can be deleted") {
        return res.status(409).json({ error: error.message });
      }
      res.status(500).json({ error: "Failed to delete report package" });
    }
  });

  // PUT /api/report-packages/:id/sections/:sectionId - Update a report section
  app.put("/api/report-packages/:id/sections/:sectionId", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id, sectionId } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      const section = await reportPackageService.updateSection(sectionId, id, access.organizationId!, req.body);
      if (!section) {
        return res.status(404).json({ error: "Section not found" });
      }
      res.json(section);
    } catch (error) {
      console.error("Error updating report section:", error);
      res.status(500).json({ error: "Failed to update report section" });
    }
  });

  // POST /api/report-packages/:id/generate - Generate the report
  app.post("/api/report-packages/:id/generate", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      const pkg = await reportPackageService.generateReport(id, access.organizationId!);
      if (!pkg) {
        return res.status(404).json({ error: "Report package not found" });
      }
      res.json(pkg);
    } catch (error) {
      console.error("Error generating report:", error);
      res.status(500).json({ error: "Failed to generate report" });
    }
  });

  // POST /api/report-packages/:id/archive - Archive a report package
  app.post("/api/report-packages/:id/archive", isAuthenticated, async (req: AuthorizedRequest, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const access = await verifyReportPackageAccess(userId);
      if (!access.valid) {
        return res.status(access.status || 403).json({ error: access.error });
      }

      const { reportPackageService } = await import("./services/reportPackages/reportPackageService");
      const pkg = await reportPackageService.archiveReportPackage(id, access.organizationId!);
      if (!pkg) {
        return res.status(404).json({ error: "Report package not found" });
      }
      res.json(pkg);
    } catch (error) {
      console.error("Error archiving report package:", error);
      res.status(500).json({ error: "Failed to archive report package" });
    }
  });

  // ============================================================================
  // INTEGRATION ROUTES (CRM <-> MarinaMatch Sync)
  // ============================================================================
  
  const { registerIntegrationRoutes } = await import("./integrations");
  registerIntegrationRoutes(app);

  const httpServer = createServer(app);

  return httpServer;
}
