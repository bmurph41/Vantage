import { 
  users, 
  organizations, 
  organizationUsers, 
  uploadedFiles,
  leaseImports,
  leases,
  tenants,
  auditLogs,
  projectBudgets,
  savedReports,
  comments,
  type User, 
  type UpsertUser, 
  type Organization, 
  type OrganizationUser, 
  type InsertOrganization, 
  type InsertOrganizationUser, 
  type OrganizationRole,
  type UploadedFile,
  type InsertUploadedFile,
  type InsertLeaseImport,
  type InsertAuditLog,
  type AuditLog,
  type InsertProjectBudget,
  type ProjectBudget,
  type InsertSavedReport,
  type SavedReport,
  type InsertComment,
  type Comment,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, gte, lte, sql } from "drizzle-orm";

// Storage interface for user and organization operations
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Organization operations
  getOrganization(id: string): Promise<Organization | undefined>;
  getUserOrganizations(userId: string): Promise<Array<Organization & { role: OrganizationRole }>>;
  getUserOrganization(userId: string): Promise<{ organizationId: string; role: OrganizationRole } | null>;
  createOrganization(data: InsertOrganization, ownerId: string): Promise<Organization>;
  
  // Feature flag operations
  isFeatureFlagEnabled(organizationId: string, flagName: string): Promise<boolean>;
  updateOrganization(id: string, data: Partial<InsertOrganization>): Promise<Organization | undefined>;
  deleteOrganization(id: string): Promise<boolean>;
  
  // Organization membership operations
  addUserToOrganization(organizationId: string, userId: string, role: OrganizationRole): Promise<OrganizationUser>;
  removeUserFromOrganization(organizationId: string, userId: string): Promise<boolean>;
  updateUserRole(organizationId: string, userId: string, role: OrganizationRole): Promise<OrganizationUser | undefined>;
  getOrganizationMembers(organizationId: string): Promise<Array<User & { role: OrganizationRole }>>;
  getUserOrganizationRole(userId: string, organizationId: string): Promise<OrganizationRole | undefined>;
  
  // Uploaded files operations
  getUploadedFiles(projectId: string): Promise<UploadedFile[]>;
  getUploadedFileById(id: string): Promise<UploadedFile | undefined>;
  createUploadedFile(data: InsertUploadedFile): Promise<UploadedFile>;
  deleteUploadedFile(id: string): Promise<boolean>;
  createLeaseImport(data: InsertLeaseImport): Promise<void>;
  
  // Audit log operations
  createAuditLog(data: InsertAuditLog): Promise<AuditLog>;
  getAuditLogs(organizationId: string, filters?: {
    entityType?: string;
    entityId?: string;
    userId?: string;
    action?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<{ logs: AuditLog[]; total: number }>;
  
  // Budget operations
  getProjectBudgets(projectId: string, year?: number): Promise<ProjectBudget[]>;
  upsertProjectBudget(data: InsertProjectBudget): Promise<ProjectBudget>;
  deleteProjectBudget(id: string): Promise<boolean>;
  
  // Saved reports operations
  getSavedReports(organizationId: string): Promise<SavedReport[]>;
  getSavedReportById(id: string): Promise<SavedReport | undefined>;
  createSavedReport(data: InsertSavedReport): Promise<SavedReport>;
  updateSavedReport(id: string, data: Partial<InsertSavedReport>): Promise<SavedReport | undefined>;
  deleteSavedReport(id: string): Promise<boolean>;
  
  // Comments operations
  getComments(entityType: string, entityId: string): Promise<Comment[]>;
  createComment(data: InsertComment): Promise<Comment>;
  updateComment(id: string, data: Partial<InsertComment>): Promise<Comment | undefined>;
  deleteComment(id: string): Promise<boolean>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const { id, ...updateData } = userData;
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.email,
        set: {
          ...updateData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Organization operations
  async getOrganization(id: string): Promise<Organization | undefined> {
    const [org] = await db.select().from(organizations).where(eq(organizations.id, id));
    return org || undefined;
  }

  async getUserOrganizations(userId: string): Promise<Array<Organization & { role: OrganizationRole }>> {
    const results = await db
      .select({
        id: organizations.id,
        name: organizations.name,
        description: organizations.description,
        createdAt: organizations.createdAt,
        updatedAt: organizations.updatedAt,
        role: organizationUsers.role,
      })
      .from(organizationUsers)
      .innerJoin(organizations, eq(organizationUsers.organizationId, organizations.id))
      .where(eq(organizationUsers.userId, userId));
    
    return results;
  }

  async getUserOrganization(userId: string): Promise<{ organizationId: string; role: OrganizationRole } | null> {
    const [result] = await db
      .select({
        organizationId: organizationUsers.organizationId,
        role: organizationUsers.role,
      })
      .from(organizationUsers)
      .where(eq(organizationUsers.userId, userId))
      .limit(1);
    
    return result || null;
  }

  async isFeatureFlagEnabled(organizationId: string, flagName: string): Promise<boolean> {
    // For now, enable all V2 features for all organizations
    // TODO: Implement proper feature flag storage and lookup
    const enabledFlags = [
      'RENTROLL_ECONOMICS_V2',
      'RENTROLL_RECONCILIATION',
      'RENTROLL_REPORT_PACKAGE',
      'RENTROLL_SNAPSHOTS',
    ];
    return enabledFlags.includes(flagName);
  }

  async createOrganization(data: InsertOrganization, ownerId: string): Promise<Organization> {
    return await db.transaction(async (tx) => {
      const [org] = await tx.insert(organizations).values(data).returning();
      
      await tx.insert(organizationUsers).values({
        organizationId: org.id,
        userId: ownerId,
        role: "owner",
      });
      
      return org;
    });
  }

  async updateOrganization(id: string, data: Partial<InsertOrganization>): Promise<Organization | undefined> {
    const [updated] = await db
      .update(organizations)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(organizations.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteOrganization(id: string): Promise<boolean> {
    const result = await db.delete(organizations).where(eq(organizations.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Organization membership operations
  async addUserToOrganization(organizationId: string, userId: string, role: OrganizationRole): Promise<OrganizationUser> {
    const [member] = await db
      .insert(organizationUsers)
      .values({
        organizationId,
        userId,
        role,
      })
      .returning();
    return member;
  }

  async removeUserFromOrganization(organizationId: string, userId: string): Promise<boolean> {
    // Use a transaction to prevent race conditions
    const result = await db.transaction(async (tx) => {
      // Check if this is the last owner within the transaction
      const owners = await tx
        .select({ id: organizationUsers.id })
        .from(organizationUsers)
        .where(
          and(
            eq(organizationUsers.organizationId, organizationId),
            eq(organizationUsers.role, "owner")
          )
        );
      
      const targetUser = await tx
        .select({ role: organizationUsers.role })
        .from(organizationUsers)
        .where(
          and(
            eq(organizationUsers.organizationId, organizationId),
            eq(organizationUsers.userId, userId)
          )
        );
      
      if (targetUser[0]?.role === "owner" && owners.length <= 1) {
        throw new Error("Cannot remove the last owner from the organization");
      }
      
      const deleteResult = await tx
        .delete(organizationUsers)
        .where(
          and(
            eq(organizationUsers.organizationId, organizationId),
            eq(organizationUsers.userId, userId)
          )
        );
      
      return deleteResult.rowCount ? deleteResult.rowCount > 0 : false;
    });
    
    return result;
  }

  async updateUserRole(organizationId: string, userId: string, role: OrganizationRole): Promise<OrganizationUser | undefined> {
    // Use a transaction to prevent race conditions when demoting the last owner
    const updated = await db.transaction(async (tx) => {
      // If demoting from owner to another role, check if this is the last owner
      if (role !== "owner") {
        const targetUser = await tx
          .select({ role: organizationUsers.role })
          .from(organizationUsers)
          .where(
            and(
              eq(organizationUsers.organizationId, organizationId),
              eq(organizationUsers.userId, userId)
            )
          );
        
        if (targetUser[0]?.role === "owner") {
          const owners = await tx
            .select({ id: organizationUsers.id })
            .from(organizationUsers)
            .where(
              and(
                eq(organizationUsers.organizationId, organizationId),
                eq(organizationUsers.role, "owner")
              )
            );
          
          if (owners.length <= 1) {
            throw new Error("Cannot demote the last owner. Promote another user to owner first.");
          }
        }
      }
      
      const [updatedUser] = await tx
        .update(organizationUsers)
        .set({ role, updatedAt: new Date() })
        .where(
          and(
            eq(organizationUsers.organizationId, organizationId),
            eq(organizationUsers.userId, userId)
          )
        )
        .returning();
      
      return updatedUser || undefined;
    });
    
    return updated;
  }

  async getOrganizationMembers(organizationId: string): Promise<Array<User & { role: OrganizationRole }>> {
    const results = await db
      .select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        profileImageUrl: users.profileImageUrl,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        role: organizationUsers.role,
      })
      .from(organizationUsers)
      .innerJoin(users, eq(organizationUsers.userId, users.id))
      .where(eq(organizationUsers.organizationId, organizationId));
    
    return results;
  }

  async getUserOrganizationRole(userId: string, organizationId: string): Promise<OrganizationRole | undefined> {
    const [result] = await db
      .select({ role: organizationUsers.role })
      .from(organizationUsers)
      .where(
        and(
          eq(organizationUsers.userId, userId),
          eq(organizationUsers.organizationId, organizationId)
        )
      );
    return result?.role;
  }

  // Uploaded files operations
  async getUploadedFiles(projectId: string): Promise<UploadedFile[]> {
    const files = await db
      .select()
      .from(uploadedFiles)
      .where(eq(uploadedFiles.projectId, projectId))
      .orderBy(uploadedFiles.uploadedAt);
    return files;
  }

  async getUploadedFileById(id: string): Promise<UploadedFile | undefined> {
    const [file] = await db
      .select()
      .from(uploadedFiles)
      .where(eq(uploadedFiles.id, id));
    return file || undefined;
  }

  async createUploadedFile(data: InsertUploadedFile): Promise<UploadedFile> {
    const [file] = await db
      .insert(uploadedFiles)
      .values(data)
      .returning();
    return file;
  }

  async deleteUploadedFile(id: string): Promise<boolean> {
    // Use transaction to ensure data integrity
    return await db.transaction(async (tx) => {
      // Get all lease imports for this file
      const imports = await tx
        .select()
        .from(leaseImports)
        .where(eq(leaseImports.uploadedFileId, id));
      
      // Get all unique lease and tenant IDs from these imports
      const leaseIds = Array.from(new Set(imports.map(i => i.leaseId)));
      const tenantIds = Array.from(new Set(imports.map(i => i.tenantId)));
      
      // Delete all leases (cascade will handle lease_cash_flows and lease_imports)
      if (leaseIds.length > 0) {
        await tx
          .delete(leases)
          .where(eq(leases.id, leaseIds[0]) || leaseIds.length === 1 ? eq(leases.id, leaseIds[0]) : eq(leases.id, leaseIds[0]));
        
        // Delete each lease individually
        for (const leaseId of leaseIds) {
          await tx.delete(leases).where(eq(leases.id, leaseId));
        }
      }
      
      // Delete all tenants that have no remaining leases
      if (tenantIds.length > 0) {
        for (const tenantId of tenantIds) {
          // Check if tenant has any other leases
          const remainingLeases = await tx
            .select({ id: leases.id })
            .from(leases)
            .where(eq(leases.tenantId, tenantId));
          
          // If no remaining leases, delete the tenant
          if (remainingLeases.length === 0) {
            await tx.delete(tenants).where(eq(tenants.id, tenantId));
          }
        }
      }
      
      // Delete the uploaded file record (cascade will handle lease_imports)
      const result = await tx
        .delete(uploadedFiles)
        .where(eq(uploadedFiles.id, id));
      
      return result.rowCount ? result.rowCount > 0 : false;
    });
  }

  async createLeaseImport(data: InsertLeaseImport): Promise<void> {
    await db.insert(leaseImports).values(data);
  }

  // Audit log operations
  async createAuditLog(data: InsertAuditLog): Promise<AuditLog> {
    const [log] = await db.insert(auditLogs).values(data).returning();
    return log;
  }

  async getAuditLogs(organizationId: string, filters?: {
    entityType?: string;
    entityId?: string;
    userId?: string;
    action?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<{ logs: AuditLog[]; total: number }> {
    const conditions = [eq(auditLogs.organizationId, organizationId)];
    
    if (filters?.entityType) {
      conditions.push(eq(auditLogs.entityType, filters.entityType as any));
    }
    if (filters?.entityId) {
      conditions.push(eq(auditLogs.entityId, filters.entityId));
    }
    if (filters?.userId) {
      conditions.push(eq(auditLogs.userId, filters.userId));
    }
    if (filters?.action) {
      conditions.push(eq(auditLogs.action, filters.action as any));
    }
    if (filters?.startDate) {
      conditions.push(gte(auditLogs.createdAt, filters.startDate));
    }
    if (filters?.endDate) {
      conditions.push(lte(auditLogs.createdAt, filters.endDate));
    }

    const whereClause = conditions.length > 1 ? and(...conditions) : conditions[0];
    
    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(auditLogs)
      .where(whereClause);
    
    const logs = await db
      .select()
      .from(auditLogs)
      .where(whereClause)
      .orderBy(desc(auditLogs.createdAt))
      .limit(filters?.limit ?? 50)
      .offset(filters?.offset ?? 0);

    return { logs, total: countResult?.count ?? 0 };
  }

  // Budget operations
  async getProjectBudgets(projectId: string, year?: number): Promise<ProjectBudget[]> {
    const conditions = [eq(projectBudgets.projectId, projectId)];
    if (year) {
      conditions.push(eq(projectBudgets.year, year));
    }
    return await db
      .select()
      .from(projectBudgets)
      .where(conditions.length > 1 ? and(...conditions) : conditions[0]);
  }

  async upsertProjectBudget(data: InsertProjectBudget): Promise<ProjectBudget> {
    const [budget] = await db
      .insert(projectBudgets)
      .values(data)
      .onConflictDoUpdate({
        target: [projectBudgets.projectId, projectBudgets.year, projectBudgets.month],
        set: {
          budgetedRevenue: data.budgetedRevenue,
          budgetedOccupancy: data.budgetedOccupancy,
          budgetedLeaseCount: data.budgetedLeaseCount,
          notes: data.notes,
          updatedAt: new Date(),
        },
      })
      .returning();
    return budget;
  }

  async deleteProjectBudget(id: string): Promise<boolean> {
    const result = await db.delete(projectBudgets).where(eq(projectBudgets.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Saved reports operations
  async getSavedReports(organizationId: string): Promise<SavedReport[]> {
    return await db
      .select()
      .from(savedReports)
      .where(eq(savedReports.organizationId, organizationId))
      .orderBy(desc(savedReports.createdAt));
  }

  async getSavedReportById(id: string): Promise<SavedReport | undefined> {
    const [report] = await db
      .select()
      .from(savedReports)
      .where(eq(savedReports.id, id));
    return report || undefined;
  }

  async createSavedReport(data: InsertSavedReport): Promise<SavedReport> {
    const [report] = await db.insert(savedReports).values(data).returning();
    return report;
  }

  async updateSavedReport(id: string, data: Partial<InsertSavedReport>): Promise<SavedReport | undefined> {
    const [updated] = await db
      .update(savedReports)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(savedReports.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteSavedReport(id: string): Promise<boolean> {
    const result = await db.delete(savedReports).where(eq(savedReports.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }

  // Comments operations
  async getComments(entityType: string, entityId: string): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(and(
        eq(comments.entityType, entityType as any),
        eq(comments.entityId, entityId)
      ))
      .orderBy(desc(comments.createdAt));
  }

  async createComment(data: InsertComment): Promise<Comment> {
    const [comment] = await db.insert(comments).values(data).returning();
    return comment;
  }

  async updateComment(id: string, data: Partial<InsertComment>): Promise<Comment | undefined> {
    const [updated] = await db
      .update(comments)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(comments.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteComment(id: string): Promise<boolean> {
    const result = await db.delete(comments).where(eq(comments.id, id));
    return result.rowCount ? result.rowCount > 0 : false;
  }
}

export const storage = new DatabaseStorage();
