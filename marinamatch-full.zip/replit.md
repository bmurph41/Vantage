# MarinaMatch - Rent Roll Analysis Module

## Overview

MarinaMatch is a marina lease management and financial analysis platform designed to replace spreadsheet-based workflows for marina operators and private equity firms. It offers comprehensive tools for managing tenant leases, tracking cash flows, recording move events, and analyzing customer distribution. Key capabilities include an executive dashboard with KPIs, revenue visualizations, interactive lease data drill-downs, hierarchical project organization, and Excel-parity rent roll analysis with "as-of" date and YTD modes. The platform also features a robust bulk import system and aims to provide a scalable, web-based solution that enhances data quality and accessibility while maintaining familiar financial analysis patterns. It differentiates between actively managed "OWNED" marinas and "DEAL" pipeline projects under evaluation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### UI/UX Decisions

The frontend utilizes React 18, TypeScript, Vite, Wouter, `shadcn/ui` (Radix UI), and Tailwind CSS, adhering to Carbon Design System principles. The design emphasizes data clarity, a "New York" style variant, tabular numbers, and a 12-column grid. TanStack Query is used for server state management and caching.

### Technical Implementations

*   **Frontend:** React 18, TypeScript, Vite, Wouter, `shadcn/ui` (Radix UI), Tailwind CSS, TanStack Query.
*   **Backend:** Node.js with Express.js and TypeScript, using Drizzle ORM for Neon serverless PostgreSQL. A service layer handles business logic for lease key generation, date calculations, cash flow aggregation, data quality validation, and revenue discrepancy calculations.
*   **Data Storage:** Neon serverless PostgreSQL. The schema includes tables for `marina_locations`, `storage_locations`, `tenants`, `leases`, `periods`, `leaseCashFlows`, `pnlRackRevenue`, `moveEvents`, and `users`. Key design principles include UUID primary keys, timestamp columns, nullable lease expiration dates, separate tables for computed vs. user-entered data, and enums for move direction and storage types. A three-tier data hierarchy (Projects, Storage Locations, Leases) ensures data isolation via project/location scoping.
*   **Bulk Import System:** A 4-step workflow (Upload → Mapping → Preview → Import) with validation, duplicate detection, and incremental import modes. Includes AI-powered PDF import using GPT-4o-mini for data extraction, dynamic rate configuration with seasonal assignments, and robust line item support.
*   **Lease Line Items System:** Stores individual fee components per lease (`winter_slip`, `summer_slip`, `seasonal`, `liveaboard`, `electric`, etc.) with amounts, slip assignments, and date ranges.
*   **Date Management:** Automatic application of project season dates for leases missing commencement/expiration.
*   **KPIs & Analytics:** Includes Total Storage Revenue, Average Boat Size, Move Events Analytics, Economic Vacancy Analysis, Seasonal Occupancy Metrics, and enhanced Tenant Cohort Analysis with:
    - **KPI Drill-Down Modals:** All summary cards are clickable and open detailed drill-down modals:
      - Active Leases: Shows table of all active leases grouped by project
      - Monthly Revenue: Tabs for breakdown by Project, Month, and Storage Type
      - Net Moves MTD: Tabs for move-ins and move-outs with lease details
      - Discrepancy: Shows data quality issues grouped by type (missing_cash_flow, missing_dates, missing_amount)
      - **Date Synchronization:** Modals inherit dashboard's exact startDate/endDate and use them until user explicitly changes time period within the modal. Project/storage filter changes do not affect date range.
    - **Drill-Down API Endpoints:** `/api/rent-roll/summary-drilldown/active-leases`, `/api/rent-roll/summary-drilldown/revenue-by-project`, `/api/rent-roll/summary-drilldown/revenue-by-storage-type`, `/api/rent-roll/summary-drilldown/move-events`, `/api/rent-roll/summary-drilldown/discrepancies`
    - **Revenue Analysis Tab:** LTV estimates, revenue per cohort, cohort revenue trends
    - **LTV Trend Modal:** Clickable Avg LTV card opens modal with interactive chart showing LTV trends over time. Supports Monthly/Quarterly/Yearly granularity. Uses SQL aggregation with proper date filtering (cash flows within lease term dates only). Endpoint: `/api/cohort/ltv-trend`
    - **Retention Matrix Heatmap:** Visual month-by-month retention percentages
    - **Project/Location Filtering:** Scope analysis to specific marinas
    - **Period-over-Period Comparisons:** Growth rate and retention change indicators
    - Time-period filtering (TTM, Year, Month, Quarter) with Monthly/Quarterly/Yearly granularity
*   **Configurable Options:** Project-level configurable storage types, rate types, slip statuses, and boat classifications.
*   **Dual-Season Capacity Calculation:** For seasonal marinas that rent the same slips twice per year (summer and winter), the `dualSeasonStorageTypes` array in `projectDetailsConfig` specifies which storage types should be counted twice. The reports service calculates effective capacity by summing storage location capacities with a 2× multiplier for dual-season types (e.g., 239 physical slips → 478 effective capacity). This affects occupancy rate calculations and capacity reporting in the Reports module.
*   **Posted Rate System:** Allows storage locations to have a Posted Rate and Rate Type for calculating Potential Revenue, with leases tracking discounts.
*   **Contract Charges & Cash Flow System:** Flexible pricing infrastructure with a `contract_charges` table supporting various basis types, escalation, and seasonal settings. A cash flow engine generates monthly projections with proper rate type handling:
    - **Rate Type Handling:** For seasonal/annual rates ($/season, $/yr), `leaseAmount` stores the PERIOD TOTAL. Cash flow generation divides by `numMonths` to get monthly rate before generating flows.
    - **Monthly Rates:** For monthly rates ($/mo), `leaseAmount` is already monthly and used directly.
*   **Reports Module:** Comprehensive rent roll reporting with filters, key metrics, project and storage type breakdowns, lease details, AI Executive Summary, and Excel/PDF export. Supports V2 Economics integration for advanced revenue calculations.
    - **Enhanced AI Executive Summary (December 2025):** The AI-generated narrative now includes:
      - **Contract Expiration Analysis:** Non-overlapping buckets (Next 30 days, 31-60 days, 61-90 days, 91-180 days) showing count and revenue at risk for upcoming renewals
      - **Tenant Lifetime Value (LTV):** Average and median LTV, distribution buckets, and top 5 tenants by cumulative revenue
      - **Repeat Customer Analysis:** Retention rate, revenue from repeat customers (2+ leases), and top repeat customers
    - Implementation: `server/reportsService.ts` calculates metrics, `server/aiReportNarratives.ts` generates the narrative with enhanced prompt
*   **Institutional Lease Economics Engine (V2):** Feature-flagged system supporting rent steps, escalations (fixed percent, fixed amount, CPI-linked), concessions (free rent, one-time credits, amortized), proration, and configurable billing rules.
*   **Snapshot Versioning System (V2):** Feature-flagged point-in-time snapshot capability for institutional reporting, including full lease capture and cash flow preservation, with comparison engine.
*   **GL Reconciliation Module (V2):** Feature-flagged system for managing GL accounts, mapping lease charges to accounts, and performing monthly reconciliation between rent roll and GL.
*   **Investor Report Packages (V2):** Feature-flagged system for generating investor report bundles (Quarterly, Annual, Acquisition, etc.) with customizable sections, snapshot integration, and branding.

### CRM Integration System (December 2025)

A complete bidirectional integration system for syncing data with external CRM applications:

*   **Database Tables:** `integration_mappings` (entity relationships), `integration_webhook_logs` (delivery tracking), `integration_api_keys` (org-scoped authentication), `integration_webhook_endpoints` (outbound configuration)
*   **Inbound API:** Service-to-service authenticated endpoints for syncing projects, tenants, and leases from CRM (`/api/integrations/projects`, `/api/integrations/tenants`, `/api/integrations/leases`)
*   **Outbound Webhooks:** Event publishing for `lease.created`, `lease.updated`, `lease.deleted`, `tenant.created`, `tenant.updated`, `tenant.deleted` with HMAC-SHA256 signatures, exponential backoff retry, and configurable endpoints
*   **Security:** All integration endpoints are organization-scoped; API keys require non-null organizationId
*   **Dashboard:** Integration status page at `/integrations` with stats, entity mappings, webhook logs, API key management, and endpoint configuration
*   **Documentation:** Comprehensive API docs at `docs/CRM_INTEGRATION_API.md` with payload formats, retry semantics, and signature verification examples

Key files: `server/integrations.ts`, `server/webhookPublisher.ts`, `client/src/pages/integrations.tsx`

### V2 Management UIs (December 2025)

Three new management UIs have been built for the V2 institutional features:

1. **GL Reconciliation Page** (`/gl-reconciliation`)
   - Tabs: GL Accounts, Mappings, Reconciliation Records
   - Create/edit GL accounts with code, name, category, description
   - Map charge types to GL accounts
   - View and manage monthly reconciliation records

2. **Report Packages Page** (`/report-packages`)
   - Create investor report packages (Quarterly, Annual, Acquisition, Custom)
   - Configure report sections and snapshot selection
   - Track generation status

3. **Snapshots Page** (`/snapshots`)
   - View point-in-time rent roll snapshots
   - Create new snapshots from current data
   - Project-level snapshot organization

All UIs use proper shadcn Form patterns with react-hook-form and zod validation.

### System Design Choices

The architecture supports point-in-time financial snapshots ("as-of date") and year-to-date analysis (YTD mode). It incorporates institutional-grade data quality validation and a comprehensive bulk import system. All leases are displayed on a single page for efficient bulk operations. Data is scopable by project and location.

## External Dependencies

*   **Database:** Neon Serverless PostgreSQL
*   **UI Component Libraries:** Radix UI, shadcn/ui, Lucide React, react-day-picker
*   **Date/Time Processing:** date-fns
*   **Validation & Type Safety:** Zod, drizzle-zod, react-hook-form, @hookform/resolvers
*   **CSV Parsing:** Papaparse
*   **Excel Parsing:** XLSX
*   **Image Export:** html2canvas
*   **Artificial Intelligence:** OpenAI (for AI-powered address parsing and PDF extraction)