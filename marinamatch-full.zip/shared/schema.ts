import { sql } from "drizzle-orm";
import { 
  pgTable, 
  text, 
  varchar, 
  uuid, 
  timestamp, 
  date, 
  integer, 
  numeric, 
  boolean, 
  pgEnum,
  uniqueIndex,
  index,
  jsonb
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================================================
// AUTHENTICATION & USER MANAGEMENT (Replit Auth Integration)
// ============================================================================

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// ============================================================================
// MULTI-TENANCY ORGANIZATION SCHEMA
// ============================================================================

// Role enum for organization users
export const organizationRoleEnum = pgEnum("organization_role", ["owner", "admin", "analyst", "viewer"]);

// Organizations table (represents PE firms)
export const organizations = pgTable("organizations", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// Organization users junction table with roles
export const organizationUsers = pgTable("organization_users", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  role: organizationRoleEnum("role").default("analyst").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgUserIdx: uniqueIndex("org_user_idx").on(table.organizationId, table.userId),
}));

// Schema for organization operations
export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOrganizationUserSchema = createInsertSchema(organizationUsers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;
export type Organization = typeof organizations.$inferSelect;
export type InsertOrganizationUser = z.infer<typeof insertOrganizationUserSchema>;
export type OrganizationUser = typeof organizationUsers.$inferSelect;
export type OrganizationRole = OrganizationUser["role"];

// ============================================================================
// FEATURE FLAGS (Org-scoped)
// ============================================================================

// Feature flag keys for institutional features
export const FEATURE_FLAG_KEYS = [
  "RENTROLL_ECONOMICS_V2",     // Advanced lease economics engine
  "RENTROLL_SNAPSHOTS",        // Snapshot versioning
  "RENTROLL_RECONCILIATION",   // GL reconciliation
  "RENTROLL_REPORT_PACKAGE",   // Investor report export
  "STORAGE_OBJECT",            // Object storage for files
] as const;

export type FeatureFlagKey = typeof FEATURE_FLAG_KEYS[number];

export const orgFeatureFlags = pgTable("org_feature_flags", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  key: text("key").notNull(),
  enabled: boolean("enabled").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgKeyIdx: uniqueIndex("org_feature_flag_idx").on(table.organizationId, table.key),
}));

export const insertOrgFeatureFlagSchema = createInsertSchema(orgFeatureFlags).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type OrgFeatureFlag = typeof orgFeatureFlags.$inferSelect;
export type InsertOrgFeatureFlag = z.infer<typeof insertOrgFeatureFlagSchema>;

// ============================================================================
// RENT ROLL ANALYSIS SCHEMA
// ============================================================================

// Enum for move event direction
export const moveDirectionEnum = pgEnum("move_direction", ["IN", "OUT"]);

// Enum for storage types
export const storageTypeEnum = pgEnum("storage_type", [
  "Wet Slip",
  "Lift Slip",
  "Mooring",
  "Jet Ski",
  "Dry Rack - Indoor",
  "Dry Rack - Outdoor",
  "Houseboat",
  "Land Storage",
  "Boat on Trailer",
  "Trailer Only",
  "Carport",
  "RV Site",
  "Other"
]);

// Enum for project types
export const projectTypeEnum = pgEnum("project_type", ["OWNED", "DEAL"]);

// Enum for season types (affects occupancy calculation)
export const seasonTypeEnum = pgEnum("season_type", ["ANNUAL", "SEASONAL"]);

// Enum for discount types on leases
export const discountTypeEnum = pgEnum("discount_type", ["PERCENT_OFF", "FLAT_RATE", "AMOUNT_OFF"]);

// Enum for lease line item types (seasonal fees, add-ons, etc.)
export const lineItemTypeEnum = pgEnum("line_item_type", [
  "winter_slip",
  "summer_slip", 
  "seasonal_slip",
  "annual_slip",
  "liveaboard",
  "electric",
  "other"
]);

// 1. MARINA LOCATIONS TABLE
export const marinaLocations = pgTable("marina_locations", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  code: text("code"), // Optional short label (e.g., "A", "B", "C1")
  description: text("description"),
  capacity: integer("capacity"), // Total number of slips/spaces available
  isActive: boolean("is_active").default(true).notNull(),
  projectType: projectTypeEnum("project_type").default("OWNED").notNull(), // OWNED = owned marina, DEAL = under evaluation
  seasonType: seasonTypeEnum("season_type").default("ANNUAL"), // ANNUAL = year-round operation, SEASONAL = summer/winter seasons
  status: text("status"), // e.g., "Under LOI", "Due Diligence", "Operating"
  targetNOI: numeric("target_noi", { precision: 14, scale: 2 }), // Target net operating income for deals
  includeInExecutive: boolean("include_in_executive").default(true).notNull(), // Include in executive summary/dashboard
  // Custom labels for base rent columns (project-specific)
  baseRent1Label: text("base_rent_1_label").default("Base Rent 1"),
  baseRent2Label: text("base_rent_2_label").default("Base Rent 2"),
  baseRent3Label: text("base_rent_3_label").default("Base Rent 3"),
  // Custom labels for additional charges (project-specific)
  charge1Label: text("charge_1_label").default("Charge 1"),
  charge2Label: text("charge_2_label").default("Charge 2"),
  charge3Label: text("charge_3_label").default("Charge 3"),
  // Season date configuration for contract term calculations (stored as MM/DD format)
  seasonStartDate: text("season_start_date"), // Start of regular season (e.g., "05/01" for May 1)
  seasonEndDate: text("season_end_date"), // End of regular season (e.g., "10/31" for October 31)
  winterStartDate: text("winter_start_date"), // Start of winter season (e.g., "11/01" for November 1)
  winterEndDate: text("winter_end_date"), // End of winter season (e.g., "04/30" for April 30)
  // Budget tracking fields for variance analysis
  budgetedRevenue: numeric("budgeted_revenue", { precision: 14, scale: 2 }), // Annual budgeted revenue target
  budgetedOccupancy: numeric("budgeted_occupancy", { precision: 5, scale: 2 }), // Target occupancy percentage (0-100)
  budgetedExpenses: numeric("budgeted_expenses", { precision: 14, scale: 2 }), // Annual budgeted expenses
  budgetYear: integer("budget_year"), // Year for which budget applies
  // Seasonal capacity configuration - storage types that are double-counted (slips rented twice: summer + winter)
  seasonalStorageTypes: text("seasonal_storage_types").array(), // Array of storage type names that count 2x for capacity
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  nameOrgIdx: uniqueIndex("location_name_org_idx").on(table.name, table.organizationId),
}));

// 2. STORAGE LOCATIONS TABLE (Physical locations within projects: docks, slips, etc.)
export const storageLocations = pgTable("storage_locations", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => marinaLocations.id, { onDelete: "cascade" }),
  name: text("name").notNull(), // e.g., "A Dock", "B Dock", "Slip 23"
  code: text("code"), // Optional short label (e.g., "A", "B", "S23")
  description: text("description"),
  storageType: text("storage_type"), // Storage type for this location (e.g., "Wet Slip", "Lift Slip")
  capacity: integer("capacity"), // Number of vessels this location can hold
  postedRate: numeric("posted_rate", { precision: 14, scale: 2 }), // Rack rate / list price for this location
  postedRateType: text("posted_rate_type"), // Rate type: "$/ft./mo.", "$/mo.", "$/season", etc.
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// 3. CUSTOM STORAGE TYPES TABLE (organization-scoped)
export const customStorageTypes = pgTable("custom_storage_types", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgNameIdx: uniqueIndex("custom_storage_org_name_idx").on(table.organizationId, table.name),
}));

// 3B. CUSTOM CONTRACT TERMS TABLE (organization-scoped)
export const customContractTerms = pgTable("custom_contract_terms", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgNameIdx: uniqueIndex("custom_contract_org_name_idx").on(table.organizationId, table.name),
}));

// 3C. CUSTOM RATE TYPES TABLE (organization-scoped)
export const customRateTypes = pgTable("custom_rate_types", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgNameIdx: uniqueIndex("custom_rate_org_name_idx").on(table.organizationId, table.name),
}));

// 3D. CUSTOM SLIP STATUSES TABLE (organization-scoped)
export const customSlipStatuses = pgTable("custom_slip_statuses", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgNameIdx: uniqueIndex("custom_slip_org_name_idx").on(table.organizationId, table.name),
}));

// 3E. ADMIN TYPE REVIEW STATUS ENUM
export const adminTypeReviewStatusEnum = pgEnum("admin_type_review_status", [
  "pending",
  "approved",
  "rejected",
  "promoted"
]);

// 3F. CUSTOM TYPE CATEGORY ENUM
export const customTypeCategoryEnum = pgEnum("custom_type_category", [
  "storage_type",
  "contract_term",
  "rate_type",
  "slip_status"
]);

// 3G. GLOBAL PROMOTED TYPES TABLE (admin-approved defaults available to all orgs)
export const globalPromotedTypes = pgTable("global_promoted_types", {
  id: uuid("id").primaryKey().defaultRandom(),
  category: customTypeCategoryEnum("category").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  promotedBy: varchar("promoted_by").references(() => users.id, { onDelete: "set null" }),
  promotedAt: timestamp("promoted_at", { withTimezone: true }).defaultNow().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  categoryNameIdx: uniqueIndex("global_promoted_category_name_idx").on(table.category, table.name),
}));

// 3H. ADMIN TYPE REVIEW QUEUE (tracks all custom types for admin review)
export const adminTypeReviewQueue = pgTable("admin_type_review_queue", {
  id: uuid("id").primaryKey().defaultRandom(),
  category: customTypeCategoryEnum("category").notNull(),
  name: text("name").notNull(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  organizationName: text("organization_name"), // Denormalized for easy display
  sourceCustomTypeId: uuid("source_custom_type_id"), // Reference to original custom type
  status: adminTypeReviewStatusEnum("status").default("pending").notNull(),
  usageCount: integer("usage_count").default(1).notNull(), // Track how often this type is used
  reviewedBy: varchar("reviewed_by").references(() => users.id, { onDelete: "set null" }),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  reviewNotes: text("review_notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  categoryNameOrgIdx: uniqueIndex("admin_review_category_name_org_idx").on(table.category, table.name, table.organizationId),
}));

// 3A. PROJECT DETAILS CONFIGURATION TABLE
// Stores which options are enabled for each project (shown on Project Setup tab)
export const projectDetailsConfig = pgTable("project_details_config", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => marinaLocations.id, { onDelete: "cascade" }).unique(),
  // Enabled storage types (array of strings)
  enabledStorageTypes: text("enabled_storage_types").array().default(sql`ARRAY['Wet Slip', 'Lift Slip', 'Mooring', 'Jet Ski', 'Dry Rack - Indoor', 'Dry Rack - Outdoor', 'Houseboat', 'Land Storage', 'Boat on Trailer', 'Trailer Only', 'Carport', 'RV Site']::text[]`),
  // Dual-season storage types (used in both summer AND winter seasons, counts as 2x annual capacity)
  // Only applicable for seasonal projects - these storage types are rented twice per year
  dualSeasonStorageTypes: text("dual_season_storage_types").array().default(sql`ARRAY[]::text[]`),
  // Enabled rate types (array of strings)
  enabledRateTypes: text("enabled_rate_types").array().default(sql`ARRAY['Standard', 'Seasonal', 'Transient', 'Live-Aboard']::text[]`),
  // Enabled contract terms (array of strings)
  enabledContractTerms: text("enabled_contract_terms").array().default(sql`ARRAY['Annual', 'Seasonal/Summer', '6-Months', '3-Months', 'Winter', 'Monthly', 'Weekly', 'Daily/Nightly']::text[]`),
  // Enabled slip statuses (array of strings)
  enabledSlipStatuses: text("enabled_slip_statuses").array().default(sql`ARRAY['Occupied', 'Vacant', 'Unusable', 'Liveaboard', 'Service', 'Sales', 'Occupied; Not-Paying', 'Small Boat/Dinghy', 'Commercial', 'Rental Boat', 'Boat Club', 'Transient']::text[]`),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// 4. TENANTS TABLE
export const tenants = pgTable("tenants", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  boatMake: text("boat_make"),
  boatYear: integer("boat_year"),
  boatSize: numeric("boat_size", { precision: 10, scale: 2 }), // Deprecated - kept for backward compatibility
  boatLength: numeric("boat_length", { precision: 10, scale: 2 }), // Boat length in feet
  boatWidth: numeric("boat_width", { precision: 10, scale: 2 }), // Boat width/beam in feet
  address1: text("address1"),
  address2: text("address2"),
  city: text("city"),
  state: text("state"),
  zip: text("zip"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// 5. LEASES TABLE
export const leases = pgTable("leases", {
  id: uuid("id").primaryKey().defaultRandom(),
  tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
  locationId: uuid("location_id").references(() => marinaLocations.id, { onDelete: "set null" }),
  storageLocationId: uuid("storage_location_id").references(() => storageLocations.id, { onDelete: "set null" }), // Physical dock/slip assignment
  leaseCommencement: date("lease_commencement"), // Optional - can be filled in later
  leaseExpiration: date("lease_expiration"), // NULL means 2099-12-31
  leaseAmount: numeric("lease_amount", { precision: 14, scale: 2 }), // Base Rent 1 (primary rate) - optional
  baseRent2: numeric("base_rent_2", { precision: 14, scale: 2 }), // Base Rent 2 (e.g., Summer Rate, Winter Rate)
  baseRent3: numeric("base_rent_3", { precision: 14, scale: 2 }), // Base Rent 3 (e.g., Annual Rate, Seasonal Rate)
  rateType: text("rate_type"), // e.g., "Standard", "Seasonal", "Transient", "Live-Aboard"
  contractTerm: text("contract_term"), // e.g., "Monthly", "Annual"
  storageType: storageTypeEnum("storage_type").default("Wet Slip").notNull(),
  boatType: text("boat_type"), // e.g., "Power", "Sail", "Liveaboard", "Jet Ski", "Catamaran", "Houseboat", "Dinghy"
  unitLocation: text("unit_location"), // Physical location at marina: "A Dock", "B Dock", "Slip 23", etc.
  unitNumber: text("unit_number"), // Unit/slip number (e.g., "A-12", "23")
  boatDimensions: text("boat_dimensions"), // Boat dimensions (e.g., "35' x 12'")
  slipLength: numeric("slip_length", { precision: 10, scale: 2 }), // Slip length in feet
  slipWidth: numeric("slip_width", { precision: 10, scale: 2 }), // Slip width in feet
  leaseOnFile: boolean("lease_on_file"),
  coiOnFile: boolean("coi_on_file"),
  coiExpiration: date("coi_expiration"),
  // Additional monthly charges (utilities, maintenance, parking, etc.)
  additionalCharge1: numeric("additional_charge_1", { precision: 14, scale: 2 }).default("0"),
  additionalCharge2: numeric("additional_charge_2", { precision: 14, scale: 2 }).default("0"),
  additionalCharge3: numeric("additional_charge_3", { precision: 14, scale: 2 }).default("0"),
  leaseKey: text("lease_key").notNull().unique(), // "TenantName|LocationId|UUID" for incomplete leases
  numDays: integer("num_days"), // Computed - null if no dates
  numMonths: integer("num_months"), // Computed - null if no dates
  totalContractValue: numeric("total_contract_value", { precision: 14, scale: 2 }), // Computed - null if no amount/dates
  slipStatus: text("slip_status").default("Occupied"), // Slip status: "Occupied", "Vacant", "Unusable", "Occupied; Not-Paying", etc.
  // Discount tracking for economic vacancy analysis
  hasDiscount: boolean("has_discount").default(false), // Whether this lease has a discount applied
  discountType: discountTypeEnum("discount_type"), // Type of discount: PERCENT_OFF, FLAT_RATE, AMOUNT_OFF
  discountValue: numeric("discount_value", { precision: 14, scale: 2 }), // Discount value (percentage or dollar amount)
  isActive: boolean("is_active").default(true).notNull(),
  isIncomplete: boolean("is_incomplete").default(false).notNull(), // True if missing required fields (lease commencement or amount)
  usesDefaultDates: boolean("uses_default_dates").default(false).notNull(), // True if using Jan 1-Dec 31 fallback for cash flows
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseKeyIdx: uniqueIndex("lease_key_idx").on(table.leaseKey),
  // Performance indexes for frequent queries
  locationIdx: index("leases_location_idx").on(table.locationId),
  activeLocationIdx: index("leases_active_location_idx").on(table.locationId, table.isActive),
  storageTypeIdx: index("leases_storage_type_idx").on(table.storageType),
  commencementIdx: index("leases_commencement_idx").on(table.leaseCommencement),
  expirationIdx: index("leases_expiration_idx").on(table.leaseExpiration),
  contractTermIdx: index("leases_contract_term_idx").on(table.contractTerm),
}));

// 5B. LEASE LINE ITEMS TABLE (multiple fee components per lease: winter slip, summer slip, liveaboard, etc.)
export const leaseLineItems = pgTable("lease_line_items", {
  id: uuid("id").primaryKey().defaultRandom(),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  lineType: lineItemTypeEnum("line_type").notNull(), // Type of fee: winter_slip, summer_slip, liveaboard, electric, etc.
  slipAssignment: text("slip_assignment"), // Physical slip for this line item (e.g., "C05" for winter, "G29" for summer)
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(), // Dollar amount for this line item
  startDate: date("start_date"), // When this fee period starts
  endDate: date("end_date"), // When this fee period ends
  notes: text("notes"), // Optional notes about this line item
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseLineItemIdx: index("lease_line_item_idx").on(table.leaseId),
}));

// 5C. CONTRACT CHARGES TABLE (flexible pricing model for cash flow generation)
// Supports various rate bases (per ft, per month, per year, per season) and escalation patterns
export const chargeTypeEnum = pgEnum("charge_type", [
  "slip_rent",
  "rack_rent", 
  "storage_rent",
  "liveaboard_fee",
  "electric",
  "water",
  "parking",
  "wifi",
  "pump_out",
  "transient_fee",
  "other"
]);

export const basisTypeEnum = pgEnum("basis_type", [
  "per_ft_per_month",
  "per_ft_per_year",
  "per_month",
  "per_year",
  "per_day",
  "per_season"
]);

export const chargeFrequencyEnum = pgEnum("charge_frequency", [
  "monthly",
  "annual",
  "seasonal",
  "daily",
  "one_time"
]);

export const escalationMethodEnum = pgEnum("escalation_method", [
  "none",
  "fixed_step",     // e.g., +3% per year
  "index_linked"    // CPI or other index (future support)
]);

export const contractCharges = pgTable("contract_charges", {
  id: uuid("id").primaryKey().defaultRandom(),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  chargeType: chargeTypeEnum("charge_type").notNull().default("slip_rent"), // Type of charge
  chargeName: text("charge_name"), // Optional custom name for "other" charges
  basisType: basisTypeEnum("basis_type").notNull().default("per_month"), // How rate is calculated
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(), // Rate amount (e.g., $25/ft or $500/mo)
  frequency: chargeFrequencyEnum("frequency").notNull().default("monthly"), // How often charged
  // Seasonal support
  seasonStartMonth: integer("season_start_month"), // 1-12 for seasonal charges
  seasonEndMonth: integer("season_end_month"), // 1-12 for seasonal charges
  // Override dates (null = use lease dates)
  chargeStartDate: date("charge_start_date"), // Defaults to lease.leaseCommencement
  chargeEndDate: date("charge_end_date"), // Defaults to lease.leaseExpiration
  // Escalation
  escalationMethod: escalationMethodEnum("escalation_method").default("none"),
  escalationValue: numeric("escalation_value", { precision: 5, scale: 2 }), // e.g., 3.00 for 3% annual
  escalationStartDate: date("escalation_start_date"), // When escalations begin
  // Metadata
  isActive: boolean("is_active").default(true).notNull(),
  notes: text("notes"),
  metadata: jsonb("metadata"), // For any additional custom fields
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseChargeIdx: index("contract_charge_lease_idx").on(table.leaseId),
}));

// ============================================================================
// LEASE ECONOMICS TABLES (Institutional-Grade)
// These tables support advanced lease economics: rent steps, escalations,
// concessions, and billing rules for institutional underwriting.
// ============================================================================

// Billing frequency options
export const billingFrequencyEnum = pgEnum("billing_frequency", [
  "monthly",
  "quarterly", 
  "annual",
  "weekly",
  "daily",
  "other"
]);

// Billing timing: when payment is due relative to service period
export const billingTimingEnum = pgEnum("billing_timing", [
  "in_advance",   // Payment due at start of period
  "arrears"       // Payment due at end of period
]);

// Day count convention for proration
export const dayCountConventionEnum = pgEnum("day_count_convention", [
  "actual_30",      // Days / 30 (most common in RE)
  "actual_actual",  // Days / actual days in period
  "actual_365"      // Days / 365
]);

// Term status
export const termStatusEnum = pgEnum("term_status", [
  "active",
  "superseded",
  "draft"
]);

// Rent period basis
export const rentPeriodEnum = pgEnum("rent_period", [
  "month",
  "year",
  "week",
  "day",
  "season"
]);

// Escalation type
export const escalationTypeEnum = pgEnum("escalation_type", [
  "fixed_percent",   // e.g., +3% annually
  "fixed_amount",    // e.g., +$50/month
  "cpi_linked"       // Future: index-linked
]);

// Escalation frequency
export const escalationFrequencyEnum = pgEnum("escalation_frequency", [
  "annual",
  "monthly",
  "on_date"          // Specific date trigger
]);

// Concession type
export const concessionTypeEnum = pgEnum("concession_type", [
  "free_rent",              // No rent for period
  "one_time_credit",        // Single credit applied
  "amortized_concession"    // Spread over lease term
]);

// LEASE TERMS: Billing and accrual configuration
export const leaseTerms = pgTable("lease_terms", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  billingFrequency: billingFrequencyEnum("billing_frequency").notNull().default("monthly"),
  billingTiming: billingTimingEnum("billing_timing").notNull().default("in_advance"),
  accrualFrequency: billingFrequencyEnum("accrual_frequency").notNull().default("monthly"),
  dayCountConvention: dayCountConventionEnum("day_count_convention").notNull().default("actual_30"),
  currency: text("currency").notNull().default("USD"),
  status: termStatusEnum("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseTermIdx: index("lease_term_lease_idx").on(table.leaseId),
  orgTermIdx: index("lease_term_org_idx").on(table.organizationId),
}));

// LEASE RENT STEPS: Base rent changes over time
export const leaseRentSteps = pgTable("lease_rent_steps", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  effectiveDate: date("effective_date").notNull(),
  baseRentAmount: numeric("base_rent_amount", { precision: 14, scale: 2 }).notNull(),
  baseRentPeriod: rentPeriodEnum("base_rent_period").notNull().default("month"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseStepIdx: index("lease_rent_step_lease_idx").on(table.leaseId),
  effectiveDateIdx: index("lease_rent_step_date_idx").on(table.effectiveDate),
}));

// LEASE ESCALATIONS: Automatic rent increases
export const leaseEscalations = pgTable("lease_escalations", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  escalationType: escalationTypeEnum("escalation_type").notNull(),
  frequency: escalationFrequencyEnum("frequency").notNull().default("annual"),
  effectiveDate: date("effective_date"), // For ON_DATE frequency
  value: numeric("value", { precision: 10, scale: 4 }).notNull(), // Percent as decimal (0.03 = 3%) or dollar amount
  cap: numeric("cap", { precision: 10, scale: 4 }), // Maximum escalation (optional)
  floor: numeric("floor", { precision: 10, scale: 4 }), // Minimum escalation (optional)
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseEscalationIdx: index("lease_escalation_lease_idx").on(table.leaseId),
}));

// LEASE CONCESSIONS: Free rent, credits, amortized incentives
export const leaseConcessions = pgTable("lease_concessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  concessionType: concessionTypeEnum("concession_type").notNull(),
  startDate: date("start_date"),
  endDate: date("end_date"),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  amortizeOverMonths: integer("amortize_over_months"), // For amortized concessions
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseConcessionIdx: index("lease_concession_lease_idx").on(table.leaseId),
}));

// LEASE BILLING RULES: Invoice timing configuration
export const leaseBillingRules = pgTable("lease_billing_rules", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  invoiceDayOfMonth: integer("invoice_day_of_month"), // 1-28 (or null for end of month)
  gracePeriodDays: integer("grace_period_days").default(0),
  lateFeePercent: numeric("late_fee_percent", { precision: 5, scale: 2 }),
  lateFeeAmount: numeric("late_fee_amount", { precision: 10, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  leaseBillingIdx: index("lease_billing_rules_lease_idx").on(table.leaseId),
}));

// ============================================================================
// END LEASE ECONOMICS TABLES
// ============================================================================

// 6. UPLOADED FILES TABLE (stores rent roll files for each project)
export const uploadedFiles = pgTable("uploaded_files", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => marinaLocations.id, { onDelete: "cascade" }),
  uploaderId: varchar("uploader_id").notNull().references(() => users.id, { onDelete: "set null" }),
  sourceFileName: text("source_file_name").notNull(), // Original filename
  mimeType: text("mime_type").notNull(), // e.g., "text/csv", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
  byteSize: integer("byte_size").notNull(), // File size in bytes
  fileData: text("file_data").notNull(), // Base64 encoded file content
  parsedSheetName: text("parsed_sheet_name"), // Sheet name if Excel file
  importStatus: text("import_status").default("completed").notNull(), // "completed", "failed", "partial"
  rowsImported: integer("rows_imported").default(0), // Number of rows successfully imported
  uploadedAt: timestamp("uploaded_at", { withTimezone: true }).defaultNow().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// 7. LEASE IMPORTS TABLE (tracks which leases/tenants came from which uploaded file)
export const leaseImports = pgTable("lease_imports", {
  id: uuid("id").primaryKey().defaultRandom(),
  uploadedFileId: uuid("uploaded_file_id").notNull().references(() => uploadedFiles.id, { onDelete: "cascade" }),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  tenantId: uuid("tenant_id").notNull().references(() => tenants.id, { onDelete: "cascade" }),
  locationId: uuid("location_id").references(() => marinaLocations.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  uploadLeaseIdx: uniqueIndex("upload_lease_idx").on(table.uploadedFileId, table.leaseId),
}));

// 8. PERIODS TABLE (monthly EOM calendar)
export const periods = pgTable("periods", {
  id: uuid("id").primaryKey().defaultRandom(),
  periodDate: date("period_date").notNull().unique(), // Last day of month
  label: text("label").notNull(), // e.g., "Jan 2024"
  year: integer("year").notNull(),
  month: integer("month").notNull(), // 1-12
}, (table) => ({
  periodDateIdx: uniqueIndex("period_date_idx").on(table.periodDate),
}));

// 5. LEASE CASH FLOWS TABLE
export const leaseCashFlows = pgTable("lease_cash_flows", {
  id: uuid("id").primaryKey().defaultRandom(),
  leaseId: uuid("lease_id").notNull().references(() => leases.id, { onDelete: "cascade" }),
  periodId: uuid("period_id").notNull().references(() => periods.id, { onDelete: "cascade" }),
  rentAmount: numeric("rent_amount", { precision: 14, scale: 2 }).notNull(),
  isActiveInPeriod: boolean("is_active_in_period").notNull(),
}, (table) => ({
  leasePeriodIdx: uniqueIndex("lease_period_idx").on(table.leaseId, table.periodId),
}));

// 6. P&L RACK REVENUE TABLE
export const pnlRackRevenue = pgTable("pnl_rack_revenue", {
  id: uuid("id").primaryKey().defaultRandom(),
  periodId: uuid("period_id").notNull().references(() => periods.id, { onDelete: "cascade" }).unique(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
}, (table) => ({
  periodIdIdx: uniqueIndex("pnl_period_idx").on(table.periodId),
}));

// 7. MOVE EVENTS TABLE
export const moveEvents = pgTable("move_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  locationId: uuid("location_id").references(() => marinaLocations.id, { onDelete: "set null" }),
  direction: moveDirectionEnum("direction").notNull(),
  customerName: text("customer_name").notNull(),
  checkedAt: date("checked_at").notNull(),
  vesselLoa: numeric("vessel_loa", { precision: 10, scale: 2 }),
  subtotal: numeric("subtotal", { precision: 14, scale: 2 }),
  sourceYear: integer("source_year"),
  sourceSheet: text("source_sheet"),
  periodId: uuid("period_id").references(() => periods.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// 8. RENT ROLL SNAPSHOTS TABLE (optional pre-aggregated metrics)
export const rentRollSnapshots = pgTable("rent_roll_snapshots", {
  id: uuid("id").primaryKey().defaultRandom(),
  periodId: uuid("period_id").notNull().references(() => periods.id, { onDelete: "cascade" }).unique(),
  totalContractedRevenue: numeric("total_contracted_revenue", { precision: 14, scale: 2 }),
  pnlRackRevenue: numeric("pnl_rack_revenue", { precision: 14, scale: 2 }),
  delta: numeric("delta", { precision: 14, scale: 2 }),
  rentRollCount: integer("rent_roll_count"),
  moveIns: integer("move_ins"),
  moveOuts: integer("move_outs"),
  netMoves: integer("net_moves"),
  rentRollCountByNetMoves: integer("rent_roll_count_by_net_moves"),
  discrepancy: integer("discrepancy"),
}, (table) => ({
  snapshotPeriodIdx: uniqueIndex("snapshot_period_idx").on(table.periodId),
}));

// ============================================================================
// 9. SNAPSHOT VERSIONING SYSTEM (Institutional-Grade Point-in-Time Snapshots)
// ============================================================================

// Snapshot status enum
export const snapshotStatusEnum = pgEnum("snapshot_status", [
  "draft",           // In progress, not finalized
  "finalized",       // Complete and locked for audit trail
  "superseded",      // Replaced by newer snapshot
  "archived"         // Retained but no longer active
]);

// Snapshot trigger type
export const snapshotTriggerEnum = pgEnum("snapshot_trigger", [
  "manual",          // User-initiated snapshot
  "scheduled",       // Automatic periodic snapshot
  "event",           // Triggered by significant event (e.g., lease change)
  "report"           // Created for report package generation
]);

// 9A. SNAPSHOT VERSIONS TABLE - Main tracking table for snapshots
export const snapshotVersions = pgTable("snapshot_versions", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => marinaLocations.id, { onDelete: "cascade" }),
  versionNumber: integer("version_number").notNull(),
  name: text("name").notNull(), // User-friendly name: "Q4 2024 Final", "Monthly Close - Dec 2024"
  description: text("description"),
  asOfDate: date("as_of_date").notNull(), // Point-in-time date for this snapshot
  status: snapshotStatusEnum("status").default("draft").notNull(),
  trigger: snapshotTriggerEnum("trigger").default("manual").notNull(),
  
  // Summary metrics (denormalized for quick access)
  totalActiveLeases: integer("total_active_leases"),
  totalMonthlyRevenue: numeric("total_monthly_revenue", { precision: 14, scale: 2 }),
  totalAnnualRevenue: numeric("total_annual_revenue", { precision: 14, scale: 2 }),
  occupancyRate: numeric("occupancy_rate", { precision: 5, scale: 2 }),
  averageBoatSize: numeric("average_boat_size", { precision: 10, scale: 2 }),
  
  // Cash flow projection horizon
  projectionStartDate: date("projection_start_date"),
  projectionEndDate: date("projection_end_date"),
  yearsProjected: integer("years_projected").default(5),
  
  // Audit trail
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  finalizedBy: varchar("finalized_by").references(() => users.id, { onDelete: "set null" }),
  finalizedAt: timestamp("finalized_at", { withTimezone: true }),
  
  // Additional metadata
  metadata: jsonb("metadata"), // Flexible storage for additional context
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  projectVersionIdx: uniqueIndex("snapshot_project_version_idx").on(table.projectId, table.versionNumber),
  projectAsOfIdx: index("snapshot_project_asof_idx").on(table.projectId, table.asOfDate),
  statusIdx: index("snapshot_status_idx").on(table.status),
}));

// 9B. LEASE SNAPSHOTS TABLE - Stores full lease state at point in time
export const leaseSnapshots = pgTable("lease_snapshots", {
  id: uuid("id").primaryKey().defaultRandom(),
  snapshotVersionId: uuid("snapshot_version_id").notNull().references(() => snapshotVersions.id, { onDelete: "cascade" }),
  originalLeaseId: uuid("original_lease_id").notNull(), // Reference to source lease (not FK to preserve even if lease deleted)
  
  // Full lease data copied at snapshot time
  tenantName: text("tenant_name").notNull(),
  tenantBoatMake: text("tenant_boat_make"),
  tenantBoatYear: integer("tenant_boat_year"),
  tenantBoatLength: numeric("tenant_boat_length", { precision: 10, scale: 2 }),
  tenantBoatWidth: numeric("tenant_boat_width", { precision: 10, scale: 2 }),
  
  leaseCommencement: date("lease_commencement"),
  leaseExpiration: date("lease_expiration"),
  leaseAmount: numeric("lease_amount", { precision: 14, scale: 2 }),
  baseRent2: numeric("base_rent_2", { precision: 14, scale: 2 }),
  baseRent3: numeric("base_rent_3", { precision: 14, scale: 2 }),
  rateType: text("rate_type"),
  contractTerm: text("contract_term"),
  storageType: text("storage_type"),
  unitLocation: text("unit_location"),
  unitNumber: text("unit_number"),
  slipLength: numeric("slip_length", { precision: 10, scale: 2 }),
  slipWidth: numeric("slip_width", { precision: 10, scale: 2 }),
  slipStatus: text("slip_status"),
  
  // Financial metrics at snapshot time
  monthlyRent: numeric("monthly_rent", { precision: 14, scale: 2 }),
  totalContractValue: numeric("total_contract_value", { precision: 14, scale: 2 }),
  
  // Discount info
  hasDiscount: boolean("has_discount").default(false),
  discountType: text("discount_type"),
  discountValue: numeric("discount_value", { precision: 14, scale: 2 }),
  
  // Status flags
  isActive: boolean("is_active").default(true).notNull(),
  isIncomplete: boolean("is_incomplete").default(false).notNull(),
  usesDefaultDates: boolean("uses_default_dates").default(false).notNull(),
  
  // V2 economics indicator
  hasV2Economics: boolean("has_v2_economics").default(false),
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  snapshotVersionIdx: index("lease_snapshot_version_idx").on(table.snapshotVersionId),
  originalLeaseIdx: index("lease_snapshot_original_idx").on(table.originalLeaseId),
}));

// 9C. CASH FLOW SNAPSHOTS TABLE - Stores projected cash flows at snapshot time
export const cashFlowSnapshots = pgTable("cash_flow_snapshots", {
  id: uuid("id").primaryKey().defaultRandom(),
  snapshotVersionId: uuid("snapshot_version_id").notNull().references(() => snapshotVersions.id, { onDelete: "cascade" }),
  leaseSnapshotId: uuid("lease_snapshot_id").notNull().references(() => leaseSnapshots.id, { onDelete: "cascade" }),
  
  // Cash flow period
  year: integer("year").notNull(),
  month: integer("month").notNull(),
  
  // Amounts by category
  baseRent: numeric("base_rent", { precision: 14, scale: 2 }).default("0"),
  escalationAmount: numeric("escalation_amount", { precision: 14, scale: 2 }).default("0"),
  concessionAmount: numeric("concession_amount", { precision: 14, scale: 2 }).default("0"),
  additionalCharges: numeric("additional_charges", { precision: 14, scale: 2 }).default("0"),
  totalAmount: numeric("total_amount", { precision: 14, scale: 2 }).notNull(),
  
  // Source tracking
  source: text("source").default("legacy"), // "legacy" or "v2_economics"
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  snapshotPeriodIdx: index("cash_flow_snapshot_period_idx").on(table.snapshotVersionId, table.year, table.month),
  leaseSnapshotIdx: index("cash_flow_lease_snapshot_idx").on(table.leaseSnapshotId),
}));

// 9D. SNAPSHOT COMPARISON RESULTS TABLE - Stores results of snapshot comparisons
export const snapshotComparisons = pgTable("snapshot_comparisons", {
  id: uuid("id").primaryKey().defaultRandom(),
  baseSnapshotId: uuid("base_snapshot_id").notNull().references(() => snapshotVersions.id, { onDelete: "cascade" }),
  compareSnapshotId: uuid("compare_snapshot_id").notNull().references(() => snapshotVersions.id, { onDelete: "cascade" }),
  
  // Summary changes
  leasesAdded: integer("leases_added").default(0),
  leasesRemoved: integer("leases_removed").default(0),
  leasesModified: integer("leases_modified").default(0),
  
  // Financial changes
  revenueChange: numeric("revenue_change", { precision: 14, scale: 2 }),
  revenueChangePercent: numeric("revenue_change_percent", { precision: 7, scale: 4 }),
  
  // Detailed comparison data (JSONB for flexibility)
  details: jsonb("details"), // Array of individual lease changes
  
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  baseCompareIdx: uniqueIndex("snapshot_comparison_idx").on(table.baseSnapshotId, table.compareSnapshotId),
}));

// ============================================================================
// RELATIONS
// ============================================================================

// Organization and user relations
export const organizationsRelations = relations(organizations, ({ many }) => ({
  organizationUsers: many(organizationUsers),
  marinaLocations: many(marinaLocations),
}));

export const organizationUsersRelations = relations(organizationUsers, ({ one }) => ({
  organization: one(organizations, {
    fields: [organizationUsers.organizationId],
    references: [organizations.id],
  }),
  user: one(users, {
    fields: [organizationUsers.userId],
    references: [users.id],
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  organizationUsers: many(organizationUsers),
}));

// Rent roll relations
export const tenantsRelations = relations(tenants, ({ many }) => ({
  leases: many(leases),
}));

export const marinaLocationsRelations = relations(marinaLocations, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [marinaLocations.organizationId],
    references: [organizations.id],
  }),
  leases: many(leases),
}));

export const leasesRelations = relations(leases, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [leases.tenantId],
    references: [tenants.id],
  }),
  location: one(marinaLocations, {
    fields: [leases.locationId],
    references: [marinaLocations.id],
  }),
  cashFlows: many(leaseCashFlows),
  leaseImports: many(leaseImports),
  lineItems: many(leaseLineItems),
  charges: many(contractCharges),
}));

export const leaseLineItemsRelations = relations(leaseLineItems, ({ one }) => ({
  lease: one(leases, {
    fields: [leaseLineItems.leaseId],
    references: [leases.id],
  }),
}));

export const contractChargesRelations = relations(contractCharges, ({ one }) => ({
  lease: one(leases, {
    fields: [contractCharges.leaseId],
    references: [leases.id],
  }),
}));

export const uploadedFilesRelations = relations(uploadedFiles, ({ one, many }) => ({
  project: one(marinaLocations, {
    fields: [uploadedFiles.projectId],
    references: [marinaLocations.id],
  }),
  uploader: one(users, {
    fields: [uploadedFiles.uploaderId],
    references: [users.id],
  }),
  leaseImports: many(leaseImports),
}));

export const leaseImportsRelations = relations(leaseImports, ({ one }) => ({
  uploadedFile: one(uploadedFiles, {
    fields: [leaseImports.uploadedFileId],
    references: [uploadedFiles.id],
  }),
  lease: one(leases, {
    fields: [leaseImports.leaseId],
    references: [leases.id],
  }),
  tenant: one(tenants, {
    fields: [leaseImports.tenantId],
    references: [tenants.id],
  }),
  location: one(marinaLocations, {
    fields: [leaseImports.locationId],
    references: [marinaLocations.id],
  }),
}));

export const periodsRelations = relations(periods, ({ many }) => ({
  cashFlows: many(leaseCashFlows),
  pnlRevenue: many(pnlRackRevenue),
  moveEvents: many(moveEvents),
  snapshots: many(rentRollSnapshots),
}));

export const leaseCashFlowsRelations = relations(leaseCashFlows, ({ one }) => ({
  lease: one(leases, {
    fields: [leaseCashFlows.leaseId],
    references: [leases.id],
  }),
  period: one(periods, {
    fields: [leaseCashFlows.periodId],
    references: [periods.id],
  }),
}));

export const pnlRackRevenueRelations = relations(pnlRackRevenue, ({ one }) => ({
  period: one(periods, {
    fields: [pnlRackRevenue.periodId],
    references: [periods.id],
  }),
}));

export const moveEventsRelations = relations(moveEvents, ({ one }) => ({
  period: one(periods, {
    fields: [moveEvents.periodId],
    references: [periods.id],
  }),
}));

export const rentRollSnapshotsRelations = relations(rentRollSnapshots, ({ one }) => ({
  period: one(periods, {
    fields: [rentRollSnapshots.periodId],
    references: [periods.id],
  }),
}));

// Snapshot versioning relations
export const snapshotVersionsRelations = relations(snapshotVersions, ({ one, many }) => ({
  project: one(marinaLocations, {
    fields: [snapshotVersions.projectId],
    references: [marinaLocations.id],
  }),
  createdByUser: one(users, {
    fields: [snapshotVersions.createdBy],
    references: [users.id],
    relationName: "snapshotCreator",
  }),
  finalizedByUser: one(users, {
    fields: [snapshotVersions.finalizedBy],
    references: [users.id],
    relationName: "snapshotFinalizer",
  }),
  leaseSnapshots: many(leaseSnapshots),
  cashFlowSnapshots: many(cashFlowSnapshots),
  baseComparisons: many(snapshotComparisons, { relationName: "baseSnapshot" }),
  compareComparisons: many(snapshotComparisons, { relationName: "compareSnapshot" }),
}));

export const leaseSnapshotsRelations = relations(leaseSnapshots, ({ one, many }) => ({
  snapshotVersion: one(snapshotVersions, {
    fields: [leaseSnapshots.snapshotVersionId],
    references: [snapshotVersions.id],
  }),
  cashFlows: many(cashFlowSnapshots),
}));

export const cashFlowSnapshotsRelations = relations(cashFlowSnapshots, ({ one }) => ({
  snapshotVersion: one(snapshotVersions, {
    fields: [cashFlowSnapshots.snapshotVersionId],
    references: [snapshotVersions.id],
  }),
  leaseSnapshot: one(leaseSnapshots, {
    fields: [cashFlowSnapshots.leaseSnapshotId],
    references: [leaseSnapshots.id],
  }),
}));

export const snapshotComparisonsRelations = relations(snapshotComparisons, ({ one }) => ({
  baseSnapshot: one(snapshotVersions, {
    fields: [snapshotComparisons.baseSnapshotId],
    references: [snapshotVersions.id],
    relationName: "baseSnapshot",
  }),
  compareSnapshot: one(snapshotVersions, {
    fields: [snapshotComparisons.compareSnapshotId],
    references: [snapshotVersions.id],
    relationName: "compareSnapshot",
  }),
  createdByUser: one(users, {
    fields: [snapshotComparisons.createdBy],
    references: [users.id],
  }),
}));

// ============================================================================
// ZOD SCHEMAS FOR VALIDATION
// ============================================================================

// Marina Locations
export const insertMarinaLocationSchema = createInsertSchema(marinaLocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectMarinaLocationSchema = createSelectSchema(marinaLocations);

export type InsertMarinaLocation = z.infer<typeof insertMarinaLocationSchema>;
export type MarinaLocation = typeof marinaLocations.$inferSelect;

// Storage Locations
export const insertStorageLocationSchema = createInsertSchema(storageLocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectStorageLocationSchema = createSelectSchema(storageLocations);

export type InsertStorageLocation = z.infer<typeof insertStorageLocationSchema>;
export type StorageLocation = typeof storageLocations.$inferSelect;

// Custom Storage Types
export const insertCustomStorageTypeSchema = createInsertSchema(customStorageTypes).omit({
  id: true,
  createdAt: true,
});

export const selectCustomStorageTypeSchema = createSelectSchema(customStorageTypes);

// Custom Contract Terms
export const insertCustomContractTermSchema = createInsertSchema(customContractTerms).omit({
  id: true,
  createdAt: true,
});

export const selectCustomContractTermSchema = createSelectSchema(customContractTerms);

// Custom Rate Types
export const insertCustomRateTypeSchema = createInsertSchema(customRateTypes).omit({
  id: true,
  createdAt: true,
});

export const selectCustomRateTypeSchema = createSelectSchema(customRateTypes);

// Custom Slip Statuses
export const insertCustomSlipStatusSchema = createInsertSchema(customSlipStatuses).omit({
  id: true,
  createdAt: true,
});

export const selectCustomSlipStatusSchema = createSelectSchema(customSlipStatuses);

// Global Promoted Types
export const insertGlobalPromotedTypeSchema = createInsertSchema(globalPromotedTypes).omit({
  id: true,
  promotedAt: true,
  createdAt: true,
});

export const selectGlobalPromotedTypeSchema = createSelectSchema(globalPromotedTypes);

// Admin Type Review Queue
export const insertAdminTypeReviewSchema = createInsertSchema(adminTypeReviewQueue).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectAdminTypeReviewSchema = createSelectSchema(adminTypeReviewQueue);

// Project Details Configuration
export const insertProjectDetailsConfigSchema = createInsertSchema(projectDetailsConfig).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectProjectDetailsConfigSchema = createSelectSchema(projectDetailsConfig);

// Tenants
export const insertTenantSchema = createInsertSchema(tenants).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectTenantSchema = createSelectSchema(tenants);

// Leases
export const insertLeaseSchema = createInsertSchema(leases).omit({
  id: true,
  leaseKey: true,
  numDays: true,
  numMonths: true,
  totalContractValue: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
});

export const selectLeaseSchema = createSelectSchema(leases);

// Lease Line Items
export const insertLeaseLineItemSchema = createInsertSchema(leaseLineItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectLeaseLineItemSchema = createSelectSchema(leaseLineItems);

// Contract Charges (flexible pricing model)
export const insertContractChargeSchema = createInsertSchema(contractCharges).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectContractChargeSchema = createSelectSchema(contractCharges);

// Lease Terms (institutional economics)
export const insertLeaseTermSchema = createInsertSchema(leaseTerms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const selectLeaseTermSchema = createSelectSchema(leaseTerms);

// Lease Rent Steps
export const insertLeaseRentStepSchema = createInsertSchema(leaseRentSteps).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const selectLeaseRentStepSchema = createSelectSchema(leaseRentSteps);

// Lease Escalations
export const insertLeaseEscalationSchema = createInsertSchema(leaseEscalations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const selectLeaseEscalationSchema = createSelectSchema(leaseEscalations);

// Lease Concessions
export const insertLeaseConcessionSchema = createInsertSchema(leaseConcessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const selectLeaseConcessionSchema = createSelectSchema(leaseConcessions);

// Lease Billing Rules
export const insertLeaseBillingRuleSchema = createInsertSchema(leaseBillingRules).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const selectLeaseBillingRuleSchema = createSelectSchema(leaseBillingRules);

// Uploaded Files
export const insertUploadedFileSchema = createInsertSchema(uploadedFiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectUploadedFileSchema = createSelectSchema(uploadedFiles);

// Lease Imports
export const insertLeaseImportSchema = createInsertSchema(leaseImports).omit({
  id: true,
  createdAt: true,
});

export const selectLeaseImportSchema = createSelectSchema(leaseImports);

// Periods
export const insertPeriodSchema = createInsertSchema(periods).omit({
  id: true,
});

export const selectPeriodSchema = createSelectSchema(periods);

// Lease Cash Flows
export const insertLeaseCashFlowSchema = createInsertSchema(leaseCashFlows).omit({
  id: true,
});

export const selectLeaseCashFlowSchema = createSelectSchema(leaseCashFlows);

// P&L Rack Revenue
export const insertPnlRackRevenueSchema = createInsertSchema(pnlRackRevenue).omit({
  id: true,
});

export const selectPnlRackRevenueSchema = createSelectSchema(pnlRackRevenue);

// Move Events
export const insertMoveEventSchema = createInsertSchema(moveEvents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectMoveEventSchema = createSelectSchema(moveEvents);

// Rent Roll Snapshots
export const insertRentRollSnapshotSchema = createInsertSchema(rentRollSnapshots).omit({
  id: true,
});

export const selectRentRollSnapshotSchema = createSelectSchema(rentRollSnapshots);

// Snapshot Versions
export const insertSnapshotVersionSchema = createInsertSchema(snapshotVersions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectSnapshotVersionSchema = createSelectSchema(snapshotVersions);

// Lease Snapshots
export const insertLeaseSnapshotSchema = createInsertSchema(leaseSnapshots).omit({
  id: true,
  createdAt: true,
});

export const selectLeaseSnapshotSchema = createSelectSchema(leaseSnapshots);

// Cash Flow Snapshots
export const insertCashFlowSnapshotSchema = createInsertSchema(cashFlowSnapshots).omit({
  id: true,
  createdAt: true,
});

export const selectCashFlowSnapshotSchema = createSelectSchema(cashFlowSnapshots);

// Snapshot Comparisons
export const insertSnapshotComparisonSchema = createInsertSchema(snapshotComparisons).omit({
  id: true,
  createdAt: true,
});

export const selectSnapshotComparisonSchema = createSelectSchema(snapshotComparisons);

// ============================================================================
// TYPESCRIPT TYPES
// ============================================================================

export type CustomStorageType = typeof customStorageTypes.$inferSelect;
export type InsertCustomStorageType = z.infer<typeof insertCustomStorageTypeSchema>;

export type CustomContractTerm = typeof customContractTerms.$inferSelect;
export type InsertCustomContractTerm = z.infer<typeof insertCustomContractTermSchema>;

export type CustomRateType = typeof customRateTypes.$inferSelect;
export type InsertCustomRateType = z.infer<typeof insertCustomRateTypeSchema>;

export type CustomSlipStatus = typeof customSlipStatuses.$inferSelect;
export type InsertCustomSlipStatus = z.infer<typeof insertCustomSlipStatusSchema>;

export type GlobalPromotedType = typeof globalPromotedTypes.$inferSelect;
export type InsertGlobalPromotedType = z.infer<typeof insertGlobalPromotedTypeSchema>;

export type AdminTypeReview = typeof adminTypeReviewQueue.$inferSelect;
export type InsertAdminTypeReview = z.infer<typeof insertAdminTypeReviewSchema>;

export type ProjectDetailsConfig = typeof projectDetailsConfig.$inferSelect;
export type InsertProjectDetailsConfig = z.infer<typeof insertProjectDetailsConfigSchema>;

export type Tenant = typeof tenants.$inferSelect;
export type InsertTenant = z.infer<typeof insertTenantSchema>;

export type Lease = typeof leases.$inferSelect;
export type InsertLease = z.infer<typeof insertLeaseSchema>;

export type LeaseLineItem = typeof leaseLineItems.$inferSelect;
export type InsertLeaseLineItem = z.infer<typeof insertLeaseLineItemSchema>;
export type LineItemType = LeaseLineItem["lineType"];

export type ContractCharge = typeof contractCharges.$inferSelect;
export type InsertContractCharge = z.infer<typeof insertContractChargeSchema>;
export type ChargeType = ContractCharge["chargeType"];
export type BasisType = ContractCharge["basisType"];
export type ChargeFrequency = ContractCharge["frequency"];
export type EscalationMethod = ContractCharge["escalationMethod"];

// Lease Economics Types (Institutional-Grade)
export type LeaseTerm = typeof leaseTerms.$inferSelect;
export type InsertLeaseTerm = z.infer<typeof insertLeaseTermSchema>;
export type BillingFrequency = LeaseTerm["billingFrequency"];
export type BillingTiming = LeaseTerm["billingTiming"];
export type DayCountConvention = LeaseTerm["dayCountConvention"];
export type TermStatus = LeaseTerm["status"];

export type LeaseRentStep = typeof leaseRentSteps.$inferSelect;
export type InsertLeaseRentStep = z.infer<typeof insertLeaseRentStepSchema>;
export type RentPeriod = LeaseRentStep["baseRentPeriod"];

export type LeaseEscalation = typeof leaseEscalations.$inferSelect;
export type InsertLeaseEscalation = z.infer<typeof insertLeaseEscalationSchema>;
export type EscalationType = LeaseEscalation["escalationType"];
export type EscalationFrequency = LeaseEscalation["frequency"];

export type LeaseConcession = typeof leaseConcessions.$inferSelect;
export type InsertLeaseConcession = z.infer<typeof insertLeaseConcessionSchema>;
export type ConcessionType = LeaseConcession["concessionType"];

export type LeaseBillingRule = typeof leaseBillingRules.$inferSelect;
export type InsertLeaseBillingRule = z.infer<typeof insertLeaseBillingRuleSchema>;

export type UploadedFile = typeof uploadedFiles.$inferSelect;
export type InsertUploadedFile = z.infer<typeof insertUploadedFileSchema>;

export type LeaseImport = typeof leaseImports.$inferSelect;
export type InsertLeaseImport = z.infer<typeof insertLeaseImportSchema>;

export type Period = typeof periods.$inferSelect;
export type InsertPeriod = z.infer<typeof insertPeriodSchema>;

export type LeaseCashFlow = typeof leaseCashFlows.$inferSelect;
export type InsertLeaseCashFlow = z.infer<typeof insertLeaseCashFlowSchema>;

export type PnlRackRevenue = typeof pnlRackRevenue.$inferSelect;
export type InsertPnlRackRevenue = z.infer<typeof insertPnlRackRevenueSchema>;

export type MoveEvent = typeof moveEvents.$inferSelect;
export type InsertMoveEvent = z.infer<typeof insertMoveEventSchema>;

export type RentRollSnapshot = typeof rentRollSnapshots.$inferSelect;
export type InsertRentRollSnapshot = z.infer<typeof insertRentRollSnapshotSchema>;

// Snapshot versioning types
export type SnapshotVersion = typeof snapshotVersions.$inferSelect;
export type InsertSnapshotVersion = z.infer<typeof insertSnapshotVersionSchema>;

export type LeaseSnapshot = typeof leaseSnapshots.$inferSelect;
export type InsertLeaseSnapshot = z.infer<typeof insertLeaseSnapshotSchema>;

export type CashFlowSnapshot = typeof cashFlowSnapshots.$inferSelect;
export type InsertCashFlowSnapshot = z.infer<typeof insertCashFlowSnapshotSchema>;

export type SnapshotComparison = typeof snapshotComparisons.$inferSelect;
export type InsertSnapshotComparison = z.infer<typeof insertSnapshotComparisonSchema>;

// ============================================================================
// COMBINED SCHEMAS FOR API REQUESTS
// ============================================================================

// Create lease with tenant info (single request)
export const createLeaseWithTenantSchema = z.object({
  tenant: insertTenantSchema,
  lease: insertLeaseSchema.omit({ tenantId: true }),
});

export type CreateLeaseWithTenant = z.infer<typeof createLeaseWithTenantSchema>;

// Monthly summary response
export const monthlySummarySchema = z.object({
  periodId: z.string(),
  periodDate: z.string(),
  label: z.string(),
  year: z.number(),
  month: z.number(),
  totalContractedRevenue: z.string(),
  pnlRackRevenue: z.string().nullable(),
  delta: z.string().nullable(),
  rentRollCount: z.number(),
  moveIns: z.number(),
  moveOuts: z.number(),
  netMoves: z.number(),
  rentRollCountByNetMoves: z.number(),
  discrepancy: z.number(),
});

export type MonthlySummary = z.infer<typeof monthlySummarySchema>;

// Address heat map response
export const addressHeatMapItemSchema = z.object({
  label: z.string(),
  count: z.number(),
});

export type AddressHeatMapItem = z.infer<typeof addressHeatMapItemSchema>;

// ============================================================================
// COLUMN CONFIGURATION FOR RENT ROLL TABLE
// ============================================================================

export interface RentRollColumnConfig {
  id: string;  // Unique identifier (matches data field name)
  label: string;  // Display name in table header
  visible: boolean;  // Whether column is shown
  order: number;  // Sort order (0-indexed)
  sortable: boolean;  // Whether column can be sorted
  align?: 'left' | 'center' | 'right';  // Text alignment
  width?: number;  // Optional fixed width in pixels
}

export interface RentRollColumnSort {
  columnId: string | null;  // Which column is being sorted
  direction: 'asc' | 'desc' | null;  // Sort direction
}

export interface RentRollTableConfig {
  columns: RentRollColumnConfig[];
  sort: RentRollColumnSort;
  version?: number;  // Configuration version for migration tracking
}

// Current configuration version - increment when adding new columns or changing sortability
// Version 11: Fix boatLength/boatWidth rendering (was accessing lease instead of tenant)
export const RENT_ROLL_CONFIG_VERSION = 11;

// Default column configuration for rent roll table
export const DEFAULT_RENT_ROLL_COLUMNS: RentRollColumnConfig[] = [
  { id: 'tenant', label: 'Tenant', visible: true, order: 0, sortable: true, align: 'left' },
  { id: 'commencement', label: 'Commencement', visible: true, order: 1, sortable: true, align: 'left' },
  { id: 'expiration', label: 'Expiration', visible: true, order: 2, sortable: true, align: 'left' },
  { id: 'daysUntilExpiration', label: 'Days to Expire', visible: true, order: 3, sortable: true, align: 'right' },
  { id: 'monthlyRent', label: 'Monthly Rent', visible: true, order: 4, sortable: true, align: 'right' },
  { id: 'ratePerFtMo', label: '$/ft./mo.', visible: false, order: 5, sortable: true, align: 'right' },
  { id: 'ratePerFtYr', label: '$/ft./yr.', visible: false, order: 6, sortable: true, align: 'right' },
  { id: 'ratePerFtSeason', label: '$/ft/season', visible: false, order: 7, sortable: true, align: 'right' },
  { id: 'baseRent2', label: 'Base Rent 2', visible: false, order: 8, sortable: true, align: 'right' },
  { id: 'baseRent3', label: 'Base Rent 3', visible: false, order: 9, sortable: true, align: 'right' },
  { id: 'customerTotal', label: 'Customer Total', visible: false, order: 10, sortable: true, align: 'right' },
  { id: 'seasonSummary', label: 'Season Summary', visible: false, order: 11, sortable: false, align: 'left' },
  { id: 'lineItems', label: 'Fee Breakdown', visible: false, order: 12, sortable: false, align: 'left' },
  { id: 'term', label: 'Term', visible: true, order: 13, sortable: true, align: 'center' },
  { id: 'location', label: 'Location', visible: true, order: 14, sortable: true, align: 'left' },
  { id: 'unitNumber', label: 'Unit/Slip #', visible: false, order: 15, sortable: true, align: 'left' },
  { id: 'storageType', label: 'Storage Type', visible: false, order: 16, sortable: true, align: 'left' },
  { id: 'slipStatus', label: 'Slip Status', visible: false, order: 17, sortable: true, align: 'center' },
  { id: 'rateType', label: 'Rate Type', visible: false, order: 18, sortable: true, align: 'left' },
  { id: 'contractTerm', label: 'Contract Term', visible: false, order: 19, sortable: true, align: 'left' },
  { id: 'boatType', label: 'Boat Type', visible: false, order: 20, sortable: true, align: 'left' },
  { id: 'boatLength', label: 'Boat Length', visible: true, order: 21, sortable: true, align: 'right' },
  { id: 'boatWidth', label: 'Boat Width', visible: false, order: 22, sortable: true, align: 'right' },
  { id: 'slipLength', label: 'Slip Length', visible: true, order: 23, sortable: true, align: 'right' },
  { id: 'slipWidth', label: 'Slip Width', visible: true, order: 24, sortable: true, align: 'right' },
  { id: 'slipUtilization', label: 'Slip Utilization', visible: true, order: 25, sortable: true, align: 'right' },
  { id: 'boat', label: 'Boat', visible: true, order: 26, sortable: true, align: 'left' },
  { id: 'numMonths', label: '# Months', visible: true, order: 27, sortable: true, align: 'right' },
  { id: 'totalStorageRevenue', label: 'Total Storage Revenue', visible: true, order: 28, sortable: true, align: 'right' },
  { id: 'totalContractValue', label: 'Total Contract Value', visible: true, order: 29, sortable: true, align: 'right' },
  { id: 'leaseOnFile', label: 'Lease On File', visible: false, order: 30, sortable: true, align: 'center' },
  { id: 'coiOnFile', label: 'COI On File', visible: false, order: 31, sortable: true, align: 'center' },
  { id: 'coiExpiration', label: 'COI Expiration', visible: false, order: 32, sortable: true, align: 'left' },
  { id: 'additionalCharge1', label: 'Add\'l Charge 1', visible: false, order: 33, sortable: true, align: 'right' },
  { id: 'additionalCharge2', label: 'Add\'l Charge 2', visible: false, order: 34, sortable: true, align: 'right' },
  { id: 'additionalCharge3', label: 'Add\'l Charge 3', visible: false, order: 35, sortable: true, align: 'right' },
  { id: 'liveaboard', label: 'Liveaboard', visible: false, order: 36, sortable: true, align: 'right' },
  { id: 'electric', label: 'Electric', visible: false, order: 37, sortable: true, align: 'right' },
  { id: 'discount', label: 'Discount', visible: false, order: 38, sortable: true, align: 'right' },
  { id: 'status', label: 'Status', visible: true, order: 39, sortable: true, align: 'center' },
  { id: 'actions', label: 'Actions', visible: true, order: 40, sortable: false, align: 'right' },
];

// Lease with tenant data (for display)
export const leaseWithTenantSchema = selectLeaseSchema.extend({
  tenant: selectTenantSchema,
  lineItems: z.array(selectLeaseLineItemSchema).optional(),
});

export type LeaseWithTenant = z.infer<typeof leaseWithTenantSchema>;

// ============================================================================
// BULK LEASE IMPORT METADATA & VALIDATION
// ============================================================================

export type ImportFieldType = "text" | "number" | "date" | "boolean";

export interface ImportFieldMetadata {
  id: string;
  label: string;
  required: boolean;
  type: ImportFieldType;
  aliases: string[];  // Flexible column names that map to this field
  validator?: (value: any) => { valid: boolean; error?: string };
  transformer?: (value: any) => any;
}

// Validation helpers for import fields
const validateDate = (value: any): { valid: boolean; error?: string } => {
  if (!value) return { valid: true }; // Nullable fields handled by required check
  
  // Check if it's an Excel serial number (positive number less than 200000)
  const numValue = Number(value);
  if (!isNaN(numValue) && numValue > 0 && numValue < 200000) {
    return { valid: true }; // Valid Excel serial date
  }
  
  // Try parsing string date formats
  const parsed = new Date(value);
  if (isNaN(parsed.getTime())) {
    return { valid: false, error: "Invalid date format" };
  }
  return { valid: true };
};

/**
 * Cleans a numeric string by removing currency symbols, commas, and whitespace
 * Handles formats like: $1,500.00, 1,500, €500, -$1,234.56
 */
const cleanNumericString = (value: any): string => {
  if (typeof value === 'number') return String(value);
  if (!value) return '';
  
  // Remove currency symbols, commas, spaces, and other non-numeric chars except . and -
  return String(value)
    .replace(/[$€£¥₹,\s]/g, '')  // Remove currency symbols, commas, spaces
    .replace(/^[^\d.-]+/, '')     // Remove leading non-numeric chars (except - for negative)
    .replace(/[^\d.-]+$/, '')     // Remove trailing non-numeric chars
    .trim();
};

const validateNumber = (value: any): { valid: boolean; error?: string } => {
  if (!value && value !== 0) return { valid: true }; // Nullable
  
  const cleaned = cleanNumericString(value);
  if (!cleaned) return { valid: true }; // Empty after cleaning
  
  const num = Number(cleaned);
  if (isNaN(num)) {
    return { valid: false, error: "Must be a number" };
  }
  return { valid: true };
};

const validateBoolean = (value: any): { valid: boolean; error?: string } => {
  if (!value) return { valid: true }; // Nullable
  
  const normalized = String(value).toLowerCase().trim();
  if (!["true", "false", "yes", "no", "1", "0", "y", "n"].includes(normalized)) {
    return { valid: false, error: "Must be true/false, yes/no, or 1/0" };
  }
  return { valid: true };
};

// Transform helpers
const transformBoolean = (value: any): boolean | null => {
  if (!value) return null;
  const normalized = String(value).toLowerCase().trim();
  return ["true", "yes", "1", "y"].includes(normalized);
};

const transformNumber = (value: any): number | null => {
  if (!value && value !== 0) return null;
  
  const cleaned = cleanNumericString(value);
  if (!cleaned) return null;
  
  const num = Number(cleaned);
  return isNaN(num) ? null : num;
};

const transformDate = (value: any): string | null => {
  if (!value) return null;
  
  // Handle Excel serial date numbers (days since 1/1/1900)
  // Excel dates are typically numbers between 1 and ~100000
  const numValue = Number(value);
  if (!isNaN(numValue) && numValue > 0 && numValue < 200000) {
    // Convert Excel serial number to JavaScript Date
    // Excel's epoch is 1/1/1900, but it has a leap year bug (treats 1900 as leap year)
    // Days from 1/1/1900 to 1/1/1970 (JavaScript epoch) = 25569
    const excelEpoch = 25569;
    const msPerDay = 86400000; // milliseconds in a day
    const jsTimestamp = (numValue - excelEpoch) * msPerDay;
    const parsed = new Date(jsTimestamp);
    
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0];
    }
  }
  
  // Handle string date formats (MM/DD/YYYY, YYYY-MM-DD, etc.)
  const parsed = new Date(value);
  if (!isNaN(parsed.getTime())) {
    return parsed.toISOString().split('T')[0];
  }
  
  // If all parsing fails, return null
  return null;
};

// Import field metadata for tenant fields
export const TENANT_IMPORT_FIELDS: ImportFieldMetadata[] = [
  {
    id: "name",
    label: "Tenant Name",
    required: false,
    type: "text",
    aliases: ["name", "tenant_name", "tenantname", "tenant name", "customer", "customer_name", "customername"],
  },
  {
    id: "boatMake",
    label: "Boat Make",
    required: false,
    type: "text",
    aliases: ["boat_make", "boatmake", "boat make", "make", "vessel_make", "vesselmake"],
  },
  {
    id: "boatYear",
    label: "Boat Year",
    required: false,
    type: "number",
    aliases: ["boat_year", "boatyear", "boat year", "year", "vessel_year"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "boatSize",
    label: "Boat Size (ft)",
    required: false,
    type: "number",
    aliases: ["boat_size", "boatsize", "boat size", "size", "vessel_size", "loa", "vessel_loa"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "boatLength",
    label: "Boat Length (ft)",
    required: false,
    type: "number",
    aliases: ["boat_length", "boatlength", "boat length", "length", "vessel_length", "loa_length"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "boatWidth",
    label: "Boat Width/Beam (ft)",
    required: false,
    type: "number",
    aliases: ["boat_width", "boatwidth", "boat width", "beam", "width", "vessel_beam", "vessel_width"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "address1",
    label: "Address Line 1",
    required: false,
    type: "text",
    aliases: ["address1", "address_1", "address line 1", "street", "street_address", "address"],
  },
  {
    id: "address2",
    label: "Address Line 2",
    required: false,
    type: "text",
    aliases: ["address2", "address_2", "address line 2", "suite", "apt", "apartment"],
  },
  {
    id: "city",
    label: "City",
    required: false,
    type: "text",
    aliases: ["city"],
  },
  {
    id: "state",
    label: "State",
    required: false,
    type: "text",
    aliases: ["state", "st", "province"],
  },
  {
    id: "zip",
    label: "ZIP Code",
    required: false,
    type: "text",
    aliases: ["zip", "zipcode", "zip_code", "postal", "postal_code", "postalcode"],
  },
  {
    id: "fullAddress",
    label: "Full Address (AI will split)",
    required: false,
    type: "text",
    aliases: ["full_address", "fulladdress", "full address", "complete_address", "completeaddress", "mailing_address", "mailingaddress"],
  },
];

// Import field metadata for lease fields
export const LEASE_IMPORT_FIELDS: ImportFieldMetadata[] = [
  {
    id: "leaseCommencement",
    label: "Lease Commencement",
    required: false,
    type: "date",
    aliases: ["lease_commencement", "leasecommencement", "lease commencement", "start_date", "startdate", "commencement", "begin_date"],
    validator: validateDate,
    transformer: transformDate,
  },
  {
    id: "leaseExpiration",
    label: "Lease Expiration",
    required: false,
    type: "date",
    aliases: ["lease_expiration", "leaseexpiration", "lease expiration", "end_date", "enddate", "expiration", "expire_date"],
    validator: validateDate,
    transformer: transformDate,
  },
  {
    id: "leaseAmount",
    label: "Lease Amount (Base Rent 1)",
    required: false,
    type: "number",
    aliases: ["lease_amount", "leaseamount", "lease amount", "amount", "rent", "monthly_rent", "rent_amount", "price", "base_rent", "base_rent_1", "baserent1"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "baseRent2",
    label: "Base Rent 2",
    required: false,
    type: "number",
    aliases: ["base_rent_2", "baserent2", "base rent 2", "rent_2", "rent2", "summer_rate", "summerrate", "summer rate", "winter_rate", "winterrate", "winter rate", "rate_2", "rate2", "seasonal_rate"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "baseRent3",
    label: "Base Rent 3",
    required: false,
    type: "number",
    aliases: ["base_rent_3", "baserent3", "base rent 3", "rent_3", "rent3", "annual_rate", "annualrate", "annual rate", "yearly_rate", "yearlyrate", "rate_3", "rate3", "transient_rate"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "contractTerm",
    label: "Contract Term",
    required: false,
    type: "text",
    aliases: ["contract_term", "contractterm", "contract term", "term", "lease_term", "leaseterm"],
  },
  {
    id: "storageType",
    label: "Storage Type",
    required: false,
    type: "text",
    aliases: ["storage_type", "storagetype", "storage type", "type", "slip_type", "sliptype"],
  },
  {
    id: "unitLocation",
    label: "Location",
    required: false,
    type: "text",
    aliases: ["unit_location", "unitlocation", "location", "dock", "slip", "slip_number", "unit", "unit_number", "berth"],
  },
  {
    id: "slipStatus",
    label: "Slip Status",
    required: false,
    type: "text",
    aliases: ["slip_status", "slipstatus", "slip status", "status", "occupancy_status", "lease_status", "unit_status"],
  },
  {
    id: "boatDimensions",
    label: "Boat Dimensions",
    required: false,
    type: "text",
    aliases: ["boat_dimensions", "boatdimensions", "boat dimensions", "boat_size", "vessel_dimensions", "dimensions"],
  },
  {
    id: "slipLength",
    label: "Slip Length",
    required: false,
    type: "number",
    aliases: ["slip_length", "sliplength", "slip length", "length", "slip_len", "dock_length"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "slipWidth",
    label: "Slip Width",
    required: false,
    type: "number",
    aliases: ["slip_width", "slipwidth", "slip width", "width", "slip_wid", "dock_width", "beam"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "additionalCharge1",
    label: "Additional Charge 1",
    required: false,
    type: "number",
    aliases: ["additional_charge_1", "additionalcharge1", "additional charge 1", "charge_1", "charge1", "extra_charge_1"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "additionalCharge2",
    label: "Additional Charge 2",
    required: false,
    type: "number",
    aliases: ["additional_charge_2", "additionalcharge2", "additional charge 2", "charge_2", "charge2", "extra_charge_2"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "additionalCharge3",
    label: "Additional Charge 3",
    required: false,
    type: "number",
    aliases: ["additional_charge_3", "additionalcharge3", "additional charge 3", "charge_3", "charge3", "extra_charge_3"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "leaseOnFile",
    label: "Lease on File",
    required: false,
    type: "boolean",
    aliases: ["lease_on_file", "leaseonfile", "lease on file", "has_lease", "lease_document"],
    validator: validateBoolean,
    transformer: transformBoolean,
  },
  {
    id: "coiOnFile",
    label: "COI on File",
    required: false,
    type: "boolean",
    aliases: ["coi_on_file", "coionfile", "coi on file", "has_coi", "insurance", "insurance_on_file"],
    validator: validateBoolean,
    transformer: transformBoolean,
  },
  {
    id: "coiExpiration",
    label: "COI Expiration",
    required: false,
    type: "date",
    aliases: ["coi_expiration", "coiexpiration", "coi expiration", "insurance_expiration", "coi_expires"],
    validator: validateDate,
    transformer: transformDate,
  },
];

// Line Item import fields (for multi-fee rent rolls with separate winter/summer/liveaboard columns)
export const LINE_ITEM_IMPORT_FIELDS: ImportFieldMetadata[] = [
  {
    id: "winterAmount",
    label: "Winter Slip Amount",
    required: false,
    type: "number",
    aliases: ["winter", "winter_amount", "winteramount", "winter amount", "winter_slip_amount", "winter_rate", "winter rate"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "summerAmount",
    label: "Summer Slip Amount",
    required: false,
    type: "number",
    aliases: ["summer", "summer_amount", "summeramount", "summer amount", "summer_slip_amount", "summer_rate", "summer rate"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "seasonalAmount",
    label: "Seasonal Slip Amount",
    required: false,
    type: "number",
    aliases: ["seasonal", "seasonal_amount", "seasonalamount", "seasonal amount", "seasonal_slip_amount", "seasonal_rate"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "liveaboardAmount",
    label: "Liveaboard Fee",
    required: false,
    type: "number",
    aliases: ["liveaboard", "liveaboard_amount", "liveaboardamount", "liveaboard amount", "liveaboard_fee", "live_aboard", "live aboard"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "electricAmount",
    label: "Electric Fee",
    required: false,
    type: "number",
    aliases: ["electric", "electric_amount", "electricamount", "electric amount", "electric_fee", "electricity", "power"],
    validator: validateNumber,
    transformer: transformNumber,
  },
  {
    id: "winterSlip",
    label: "Winter Slip Assignment",
    required: false,
    type: "text",
    aliases: ["winter_slip", "winterslip", "winter slip", "winter_slips", "winterslips", "winter slips", "winter_dock"],
  },
  {
    id: "summerSlip",
    label: "Summer Slip Assignment",
    required: false,
    type: "text",
    aliases: ["summer_slip", "summerslip", "summer slip", "summer_slips", "summerslips", "summer slips", "summer_dock"],
  },
];

// Combined import field metadata
export const ALL_IMPORT_FIELDS = [...TENANT_IMPORT_FIELDS, ...LEASE_IMPORT_FIELDS, ...LINE_ITEM_IMPORT_FIELDS];

// Line item data structure for import
export interface ParsedLineItemData {
  winterAmount?: number | null;
  summerAmount?: number | null;
  seasonalAmount?: number | null;
  liveaboardAmount?: number | null;
  electricAmount?: number | null;
  winterSlip?: string;
  summerSlip?: string;
}

// Parsed import row with validation errors
export interface ParsedImportRow {
  rowIndex: number;
  tenantData: Partial<InsertTenant>;
  leaseData: Partial<Omit<InsertLease, "tenantId">>;
  lineItemData?: ParsedLineItemData; // Optional line item data for multi-fee imports
  errors: string[];
  warnings: string[];
  isDuplicate?: boolean;
  duplicateMatchReason?: string;
  existingLeaseId?: string; // If tenant matches existing record, store lease ID for consolidation
}

// Bulk import request schema
export const bulkLeaseImportSchema = z.object({
  rows: z.array(z.object({
    tenantData: insertTenantSchema.partial(),
    leaseData: insertLeaseSchema.omit({ tenantId: true }).partial(),
  })),
  skipDuplicates: z.boolean().default(false),
});

export type BulkLeaseImportRequest = z.infer<typeof bulkLeaseImportSchema>;

// Bulk import response
export interface BulkLeaseImportResponse {
  imported: number;
  skipped: number;
  errors: number;
  updated?: number; // Count of existing records that were updated
  details: {
    created: Array<{ tenantName: string; leaseKey: string; tenantId: string; leaseId: string }>;
    duplicates: Array<{ tenantName: string; reason: string }>;
    failed: Array<{ tenantName: string; error: string }>;
    updated?: Array<{ tenantName: string; tenantId: string; leaseId?: string; reason: string }>;
  };
}

// ============================================================================
// REPORTS MODULE TYPES
// ============================================================================

// Report request filters
export interface ReportFilters {
  projectIds?: string[];
  storageTypes?: string[];
  storageLocationIds?: string[];
  contractTerms?: string[];
  startDate?: string;
  endDate?: string;
  year?: number;
}

// Contract expiration bucket for tracking upcoming renewals
export interface ContractExpirationBucket {
  window: string; // "30 days", "60 days", "90 days", "180 days"
  count: number;
  revenueAtRisk: number;
  leases: Array<{
    tenantName: string;
    projectName: string;
    expirationDate: string;
    leaseAmount: number;
  }>;
}

// Tenant LTV (Lifetime Value) statistics
export interface TenantLTVStats {
  averageLTV: number;
  medianLTV: number;
  totalLTV: number;
  topTenants: Array<{
    tenantName: string;
    totalRevenue: number;
    leaseCount: number;
    tenureMonths: number;
  }>;
  ltvDistribution: Array<{
    bucket: string; // "$0-$5k", "$5k-$25k", "$25k-$100k", "$100k+"
    count: number;
    totalRevenue: number;
  }>;
}

// Repeat customer analysis
export interface RepeatCustomerStats {
  repeatCustomerCount: number;
  totalCustomerCount: number;
  repeatRate: number; // percentage
  repeatCustomerRevenue: number;
  repeatRevenuePercentage: number;
  repeatCustomers: Array<{
    tenantName: string;
    leaseCount: number;
    totalRevenue: number;
    projects: string[];
  }>;
}

// Report metrics summary
export interface ReportMetrics {
  totalLeases: number;
  activeLeases: number;
  totalRevenue: number;
  averageLeaseValue: number;
  occupancyRate: number;
  occupancyNumerator: number;
  occupancyDenominator: number;
  economicVacancy: number;
  potentialRevenue: number;
  moveIns: number;
  moveOuts: number;
  netChange: number;
  averageLOA: number;
  contractExpirations?: ContractExpirationBucket[];
  tenantLTV?: TenantLTVStats;
  repeatCustomers?: RepeatCustomerStats;
}

// Report project breakdown
export interface ReportProjectBreakdown {
  projectId: string;
  projectName: string;
  projectType: string;
  seasonType: string;
  capacity: number | null;
  activeLeases: number;
  revenue: number;
  occupancyRate: number;
}

// Report storage type breakdown
export interface ReportStorageTypeBreakdown {
  storageType: string;
  leaseCount: number;
  revenue: number;
  percentage: number;
}

// Report lease detail row
export interface ReportLeaseDetail {
  tenantName: string;
  projectName: string;
  storageType: string | null;
  unitLocation: string | null;
  contractTerm: string | null;
  leaseAmount: number | null;
  rateType: string | null;
  commencementDate: string | null;
  expirationDate: string | null;
  boatSize: number | null;
  isActive: boolean;
}

// Full report response
export interface ReportData {
  generatedAt: string;
  filters: ReportFilters;
  metrics: ReportMetrics;
  projectBreakdown: ReportProjectBreakdown[];
  storageTypeBreakdown: ReportStorageTypeBreakdown[];
  leaseDetails: ReportLeaseDetail[];
  aiNarrative?: string;
}

// Report options for filter dropdowns
export interface ReportOptions {
  projects: Array<{ id: string; name: string; type: string }>;
  storageTypes: string[];
  storageLocations: Array<{ id: string; name: string; projectId: string }>;
  contractTerms: string[];
  years: number[];
}

// ============================================================================
// AUDIT LOGGING SYSTEM
// ============================================================================

// Enum for audit log action types
export const auditActionEnum = pgEnum("audit_action", [
  "CREATE",
  "UPDATE", 
  "DELETE",
  "IMPORT",
  "EXPORT",
  "LOGIN",
  "LOGOUT",
  "ROLE_CHANGE",
  "BULK_EDIT"
]);

// Enum for audit log entity types
export const auditEntityEnum = pgEnum("audit_entity", [
  "lease",
  "tenant",
  "project",
  "storage_location",
  "line_item",
  "move_event",
  "user",
  "organization",
  "report",
  "budget"
]);

// Audit log table - tracks all data changes for compliance
export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "set null" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "set null" }),
  action: auditActionEnum("action").notNull(),
  entityType: auditEntityEnum("entity_type").notNull(),
  entityId: text("entity_id"), // UUID or ID of the affected entity
  entityName: text("entity_name"), // Human-readable name for display
  previousValue: jsonb("previous_value"), // State before change (for UPDATE/DELETE)
  newValue: jsonb("new_value"), // State after change (for CREATE/UPDATE)
  metadata: jsonb("metadata"), // Additional context (IP, user agent, etc.)
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("audit_logs_org_idx").on(table.organizationId),
  userIdx: index("audit_logs_user_idx").on(table.userId),
  entityIdx: index("audit_logs_entity_idx").on(table.entityType, table.entityId),
  createdAtIdx: index("audit_logs_created_at_idx").on(table.createdAt),
}));

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;

// ============================================================================
// BUDGET TRACKING SYSTEM
// ============================================================================

// Budget periods for projects (annual/monthly budget targets)
export const projectBudgets = pgTable("project_budgets", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull().references(() => marinaLocations.id, { onDelete: "cascade" }),
  year: integer("year").notNull(),
  month: integer("month"), // 1-12 for monthly, null for annual
  budgetedRevenue: numeric("budgeted_revenue", { precision: 14, scale: 2 }),
  budgetedOccupancy: numeric("budgeted_occupancy", { precision: 5, scale: 2 }), // Percentage
  budgetedLeaseCount: integer("budgeted_lease_count"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  projectYearMonthIdx: uniqueIndex("budget_project_year_month_idx").on(table.projectId, table.year, table.month),
}));

export const insertProjectBudgetSchema = createInsertSchema(projectBudgets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertProjectBudget = z.infer<typeof insertProjectBudgetSchema>;
export type ProjectBudget = typeof projectBudgets.$inferSelect;

// ============================================================================
// SAVED REPORTS & SCHEDULING
// ============================================================================

// Saved report configurations
export const savedReports = pgTable("saved_reports", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  createdByUserId: varchar("created_by_user_id").references(() => users.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  description: text("description"),
  filters: jsonb("filters").notNull(), // ReportFilters JSON
  includeAiNarrative: boolean("include_ai_narrative").default(true),
  isScheduled: boolean("is_scheduled").default(false),
  scheduleFrequency: text("schedule_frequency"), // "daily", "weekly", "monthly"
  scheduleDayOfWeek: integer("schedule_day_of_week"), // 0-6 for weekly
  scheduleDayOfMonth: integer("schedule_day_of_month"), // 1-31 for monthly
  scheduleRecipients: text("schedule_recipients").array(), // Email addresses
  lastRunAt: timestamp("last_run_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertSavedReportSchema = createInsertSchema(savedReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastRunAt: true,
});

export type InsertSavedReport = z.infer<typeof insertSavedReportSchema>;
export type SavedReport = typeof savedReports.$inferSelect;

// ============================================================================
// SCENARIO MODELING SYSTEM
// ============================================================================

// Scenarios for IRR/NPV financial analysis
export const scenarios = pgTable("scenarios", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  projectId: uuid("project_id").references(() => marinaLocations.id, { onDelete: "cascade" }), // null = portfolio-level
  createdByUserId: varchar("created_by_user_id").references(() => users.id, { onDelete: "set null" }),
  name: text("name").notNull(),
  description: text("description"),
  // Investment assumptions
  initialInvestment: numeric("initial_investment", { precision: 14, scale: 2 }), // Acquisition cost
  discountRate: numeric("discount_rate", { precision: 5, scale: 4 }).default("0.08"), // e.g., 0.08 = 8%
  // Growth assumptions
  revenueGrowthRate: numeric("revenue_growth_rate", { precision: 5, scale: 4 }).default("0.03"), // Annual revenue growth
  expenseGrowthRate: numeric("expense_growth_rate", { precision: 5, scale: 4 }).default("0.02"), // Annual expense growth
  // Exit assumptions
  holdingPeriodYears: integer("holding_period_years").default(5), // Investment horizon
  exitCapRate: numeric("exit_cap_rate", { precision: 5, scale: 4 }).default("0.07"), // Terminal cap rate
  // Override cash flows (if user wants to model custom projections)
  customCashFlows: jsonb("custom_cash_flows"), // Array of { year: number, cashFlow: number }
  // Calculated results (cached for display)
  calculatedNpv: numeric("calculated_npv", { precision: 14, scale: 2 }),
  calculatedIrr: numeric("calculated_irr", { precision: 6, scale: 4 }), // e.g., 0.1234 = 12.34%
  calculatedPaybackYears: numeric("calculated_payback_years", { precision: 4, scale: 2 }),
  lastCalculatedAt: timestamp("last_calculated_at", { withTimezone: true }),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("scenarios_org_idx").on(table.organizationId),
  projectIdx: index("scenarios_project_idx").on(table.projectId),
}));

export const insertScenarioSchema = createInsertSchema(scenarios).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  calculatedNpv: true,
  calculatedIrr: true,
  calculatedPaybackYears: true,
  lastCalculatedAt: true,
});

export type InsertScenario = z.infer<typeof insertScenarioSchema>;
export type Scenario = typeof scenarios.$inferSelect;

// Scenario cash flow projections (year-by-year breakdown)
export const scenarioCashFlows = pgTable("scenario_cash_flows", {
  id: uuid("id").primaryKey().defaultRandom(),
  scenarioId: uuid("scenario_id").notNull().references(() => scenarios.id, { onDelete: "cascade" }),
  year: integer("year").notNull(), // Year number (1, 2, 3, etc.) or calendar year
  calendarYear: integer("calendar_year"), // Actual calendar year (e.g., 2025)
  revenue: numeric("revenue", { precision: 14, scale: 2 }),
  expenses: numeric("expenses", { precision: 14, scale: 2 }),
  noi: numeric("noi", { precision: 14, scale: 2 }), // Net Operating Income
  cashFlow: numeric("cash_flow", { precision: 14, scale: 2 }), // Net cash flow (may include cap ex, debt service)
  terminalValue: numeric("terminal_value", { precision: 14, scale: 2 }), // Exit value in final year
  isProjection: boolean("is_projection").default(true), // true = projected, false = actual
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  scenarioYearIdx: uniqueIndex("scenario_year_idx").on(table.scenarioId, table.year),
}));

export const insertScenarioCashFlowSchema = createInsertSchema(scenarioCashFlows).omit({
  id: true,
  createdAt: true,
});

export type InsertScenarioCashFlow = z.infer<typeof insertScenarioCashFlowSchema>;
export type ScenarioCashFlow = typeof scenarioCashFlows.$inferSelect;

// ============================================================================
// COMMENTS/NOTES SYSTEM
// ============================================================================

// Comments on entities (leases, tenants, projects)
export const comments = pgTable("comments", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  entityType: auditEntityEnum("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  content: text("content").notNull(),
  isPinned: boolean("is_pinned").default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  entityIdx: index("comments_entity_idx").on(table.entityType, table.entityId),
  orgIdx: index("comments_org_idx").on(table.organizationId),
}));

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

// ============================================================================
// GL RECONCILIATION SYSTEM (Feature-flagged: RENTROLL_RECONCILIATION)
// ============================================================================

// GL Account categories for mapping
export const glAccountCategoryEnum = pgEnum("gl_account_category", [
  "revenue",
  "expense",
  "asset",
  "liability",
  "equity",
]);

// Reconciliation status
export const reconciliationStatusEnum = pgEnum("reconciliation_status", [
  "pending",
  "in_progress",
  "reconciled",
  "variance_identified",
  "closed",
]);

// GL Accounts - Chart of accounts for the organization
export const glAccounts = pgTable("gl_accounts", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  accountCode: text("account_code").notNull(),
  accountName: text("account_name").notNull(),
  category: glAccountCategoryEnum("category").notNull(),
  parentAccountId: uuid("parent_account_id").references((): any => glAccounts.id, { onDelete: "set null" }),
  description: text("description"),
  isActive: boolean("is_active").default(true).notNull(),
  externalSystemId: text("external_system_id"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgCodeIdx: uniqueIndex("gl_account_org_code_idx").on(table.organizationId, table.accountCode),
  categoryIdx: index("gl_account_category_idx").on(table.category),
}));

export const insertGlAccountSchema = createInsertSchema(glAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertGlAccount = z.infer<typeof insertGlAccountSchema>;
export type GlAccount = typeof glAccounts.$inferSelect;

// GL Mappings - Maps lease charge types to GL accounts
export const glMappings = pgTable("gl_mappings", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  glAccountId: uuid("gl_account_id").notNull().references(() => glAccounts.id, { onDelete: "cascade" }),
  chargeType: chargeTypeEnum("charge_type"),
  storageType: storageTypeEnum("storage_type"),
  projectId: uuid("project_id").references(() => marinaLocations.id, { onDelete: "set null" }),
  description: text("description"),
  priority: integer("priority").default(0),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgMappingIdx: index("gl_mapping_org_idx").on(table.organizationId),
  accountIdx: index("gl_mapping_account_idx").on(table.glAccountId),
}));

export const insertGlMappingSchema = createInsertSchema(glMappings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertGlMapping = z.infer<typeof insertGlMappingSchema>;
export type GlMapping = typeof glMappings.$inferSelect;

// Reconciliation Records - Monthly reconciliation between rent roll and GL
export const reconciliationRecords = pgTable("reconciliation_records", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  projectId: uuid("project_id").references(() => marinaLocations.id, { onDelete: "set null" }),
  periodYear: integer("period_year").notNull(),
  periodMonth: integer("period_month").notNull(),
  status: reconciliationStatusEnum("status").default("pending").notNull(),
  
  rentRollTotal: numeric("rent_roll_total", { precision: 14, scale: 2 }),
  glTotal: numeric("gl_total", { precision: 14, scale: 2 }),
  varianceAmount: numeric("variance_amount", { precision: 14, scale: 2 }),
  variancePercent: numeric("variance_percent", { precision: 5, scale: 2 }),
  
  reconciledBy: varchar("reconciled_by").references(() => users.id, { onDelete: "set null" }),
  reconciledAt: timestamp("reconciled_at", { withTimezone: true }),
  notes: text("notes"),
  
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgPeriodIdx: uniqueIndex("recon_org_period_idx").on(table.organizationId, table.projectId, table.periodYear, table.periodMonth),
  statusIdx: index("recon_status_idx").on(table.status),
}));

export const insertReconciliationRecordSchema = createInsertSchema(reconciliationRecords).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertReconciliationRecord = z.infer<typeof insertReconciliationRecordSchema>;
export type ReconciliationRecord = typeof reconciliationRecords.$inferSelect;

// Reconciliation Line Items - Detailed breakdown of reconciliation
export const reconciliationLineItems = pgTable("reconciliation_line_items", {
  id: uuid("id").primaryKey().defaultRandom(),
  reconciliationRecordId: uuid("reconciliation_record_id").notNull().references(() => reconciliationRecords.id, { onDelete: "cascade" }),
  glAccountId: uuid("gl_account_id").references(() => glAccounts.id, { onDelete: "set null" }),
  
  description: text("description"),
  rentRollAmount: numeric("rent_roll_amount", { precision: 14, scale: 2 }),
  glAmount: numeric("gl_amount", { precision: 14, scale: 2 }),
  varianceAmount: numeric("variance_amount", { precision: 14, scale: 2 }),
  
  leaseId: uuid("lease_id").references(() => leases.id, { onDelete: "set null" }),
  chargeType: chargeTypeEnum("charge_type"),
  
  isReconciled: boolean("is_reconciled").default(false),
  notes: text("notes"),
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  recordIdx: index("recon_line_record_idx").on(table.reconciliationRecordId),
  accountIdx: index("recon_line_account_idx").on(table.glAccountId),
}));

export const insertReconciliationLineItemSchema = createInsertSchema(reconciliationLineItems).omit({
  id: true,
  createdAt: true,
});

export type InsertReconciliationLineItem = z.infer<typeof insertReconciliationLineItemSchema>;
export type ReconciliationLineItem = typeof reconciliationLineItems.$inferSelect;

// ============================================================================
// INVESTOR REPORT PACKAGES (Feature-flagged: RENTROLL_REPORT_PACKAGE)
// ============================================================================

// Report package status
export const reportPackageStatusEnum = pgEnum("report_package_status", [
  "draft",
  "generating",
  "ready",
  "failed",
  "archived",
]);

// Report package type
export const reportPackageTypeEnum = pgEnum("report_package_type", [
  "quarterly",
  "annual",
  "acquisition",
  "disposition",
  "custom",
]);

// Report Packages - Investor-ready report bundles
export const reportPackages = pgTable("report_packages", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  projectId: uuid("project_id").references(() => marinaLocations.id, { onDelete: "set null" }),
  
  name: text("name").notNull(),
  description: text("description"),
  packageType: reportPackageTypeEnum("package_type").default("quarterly").notNull(),
  status: reportPackageStatusEnum("status").default("draft").notNull(),
  
  // Reporting period
  periodStartDate: date("period_start_date").notNull(),
  periodEndDate: date("period_end_date").notNull(),
  asOfDate: date("as_of_date"),
  
  // Linked snapshot for point-in-time accuracy
  snapshotId: uuid("snapshot_id").references(() => snapshotVersions.id, { onDelete: "set null" }),
  
  // Report configuration
  includeSections: jsonb("include_sections"), // Array of section names to include
  customBranding: jsonb("custom_branding"), // Logo URL, colors, fonts
  
  // Generated content cache
  executiveSummary: text("executive_summary"),
  generatedAt: timestamp("generated_at", { withTimezone: true }),
  excelFilePath: text("excel_file_path"),
  pdfFilePath: text("pdf_file_path"),
  
  // Audit trail
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("report_pkg_org_idx").on(table.organizationId),
  projectIdx: index("report_pkg_project_idx").on(table.projectId),
  statusIdx: index("report_pkg_status_idx").on(table.status),
}));

export const insertReportPackageSchema = createInsertSchema(reportPackages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  generatedAt: true,
  excelFilePath: true,
  pdfFilePath: true,
});

export type InsertReportPackage = z.infer<typeof insertReportPackageSchema>;
export type ReportPackage = typeof reportPackages.$inferSelect;

// Report Package Sections - Individual sections within a report package
export const reportPackageSections = pgTable("report_package_sections", {
  id: uuid("id").primaryKey().defaultRandom(),
  reportPackageId: uuid("report_package_id").notNull().references(() => reportPackages.id, { onDelete: "cascade" }),
  
  sectionType: text("section_type").notNull(), // "executive_summary", "rent_roll", "cash_flow", "occupancy", etc.
  sectionOrder: integer("section_order").notNull(),
  title: text("title"),
  content: text("content"), // Rendered content or markdown
  chartData: jsonb("chart_data"), // Data for charts/visualizations
  tableData: jsonb("table_data"), // Data for tables
  
  isIncluded: boolean("is_included").default(true).notNull(),
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  packageIdx: index("report_section_pkg_idx").on(table.reportPackageId),
  orderIdx: index("report_section_order_idx").on(table.reportPackageId, table.sectionOrder),
}));

export const insertReportPackageSectionSchema = createInsertSchema(reportPackageSections).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertReportPackageSection = z.infer<typeof insertReportPackageSectionSchema>;
export type ReportPackageSection = typeof reportPackageSections.$inferSelect;

// ============================================================================
// ROLE-BASED PERMISSIONS HELPER TYPES
// ============================================================================

// Permission definitions for role-based access
export const ROLE_PERMISSIONS = {
  owner: {
    canManageOrganization: true,
    canManageUsers: true,
    canManageProjects: true,
    canEditData: true,
    canImportData: true,
    canExportData: true,
    canViewReports: true,
    canDeleteData: true,
    canViewAuditLogs: true,
    canManageBudgets: true,
  },
  admin: {
    canManageOrganization: false,
    canManageUsers: true,
    canManageProjects: true,
    canEditData: true,
    canImportData: true,
    canExportData: true,
    canViewReports: true,
    canDeleteData: true,
    canViewAuditLogs: true,
    canManageBudgets: true,
  },
  analyst: {
    canManageOrganization: false,
    canManageUsers: false,
    canManageProjects: false,
    canEditData: true,
    canImportData: true,
    canExportData: true,
    canViewReports: true,
    canDeleteData: false,
    canViewAuditLogs: false,
    canManageBudgets: false,
  },
  viewer: {
    canManageOrganization: false,
    canManageUsers: false,
    canManageProjects: false,
    canEditData: false,
    canImportData: false,
    canExportData: true,
    canViewReports: true,
    canDeleteData: false,
    canViewAuditLogs: false,
    canManageBudgets: false,
  },
} as const;

export type Permission = keyof typeof ROLE_PERMISSIONS.owner;

// Helper to check if a role has a permission
export function hasPermission(role: OrganizationRole | null | undefined, permission: Permission): boolean {
  if (!role) return false;
  return ROLE_PERMISSIONS[role]?.[permission] ?? false;
}

// ============================================================================
// INTEGRATION MAPPINGS (CRM <-> MarinaMatch Sync)
// ============================================================================

// Entity types that can be synced between systems
export const integrationEntityTypeEnum = pgEnum("integration_entity_type", [
  "project",      // CRM Property <-> MarinaMatch Project
  "tenant",       // CRM Company/Contact <-> MarinaMatch Tenant
  "lease",        // CRM Deal <-> MarinaMatch Lease
  "contact",      // CRM Contact <-> MarinaMatch Tenant Contact
]);

// Sync status for tracking integration health
export const integrationSyncStatusEnum = pgEnum("integration_sync_status", [
  "synced",
  "pending",
  "error",
  "conflict",
]);

// Integration mappings table - tracks entity relationships between systems
export const integrationMappings = pgTable("integration_mappings", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  
  // Entity type and IDs
  entityType: integrationEntityTypeEnum("entity_type").notNull(),
  marinaMatchId: uuid("marina_match_id").notNull(), // ID in MarinaMatch
  externalId: text("external_id").notNull(), // ID in external CRM system
  externalSystem: text("external_system").notNull().default("crm"), // e.g., "crm", "salesforce", etc.
  
  // Sync metadata
  syncStatus: integrationSyncStatusEnum("sync_status").default("pending").notNull(),
  syncHash: text("sync_hash"), // Hash of last synced data for change detection
  lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }),
  lastSyncError: text("last_sync_error"),
  
  // Conflict resolution
  lastExternalUpdate: timestamp("last_external_update", { withTimezone: true }),
  lastMarinaMatchUpdate: timestamp("last_marina_match_update", { withTimezone: true }),
  
  // Additional metadata from external system
  externalData: jsonb("external_data"), // Cache of external system data
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgEntityIdx: index("int_mapping_org_entity_idx").on(table.organizationId, table.entityType),
  marinaIdIdx: uniqueIndex("int_mapping_marina_id_idx").on(table.entityType, table.marinaMatchId),
  externalIdIdx: uniqueIndex("int_mapping_external_id_idx").on(table.externalSystem, table.entityType, table.externalId),
  syncStatusIdx: index("int_mapping_sync_status_idx").on(table.syncStatus),
}));

export const insertIntegrationMappingSchema = createInsertSchema(integrationMappings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertIntegrationMapping = z.infer<typeof insertIntegrationMappingSchema>;
export type IntegrationMapping = typeof integrationMappings.$inferSelect;

// Integration webhook logs - tracks all incoming/outgoing webhook events
export const integrationWebhookLogs = pgTable("integration_webhook_logs", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").references(() => organizations.id, { onDelete: "cascade" }),
  
  // Event details
  direction: text("direction").notNull(), // "inbound" or "outbound"
  eventType: text("event_type").notNull(), // e.g., "project.created", "tenant.updated"
  externalSystem: text("external_system").notNull(),
  
  // Request/Response data
  requestPayload: jsonb("request_payload"),
  responsePayload: jsonb("response_payload"),
  statusCode: integer("status_code"),
  
  // Related entity
  entityType: integrationEntityTypeEnum("entity_type"),
  entityId: uuid("entity_id"),
  externalId: text("external_id"),
  
  // Processing status
  processedAt: timestamp("processed_at", { withTimezone: true }),
  errorMessage: text("error_message"),
  retryCount: integer("retry_count").default(0).notNull(),
  
  // Idempotency
  idempotencyKey: text("idempotency_key"),
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("webhook_log_org_idx").on(table.organizationId),
  eventTypeIdx: index("webhook_log_event_idx").on(table.eventType),
  directionIdx: index("webhook_log_direction_idx").on(table.direction),
  idempotencyIdx: uniqueIndex("webhook_log_idempotency_idx").on(table.idempotencyKey),
}));

export const insertIntegrationWebhookLogSchema = createInsertSchema(integrationWebhookLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertIntegrationWebhookLog = z.infer<typeof insertIntegrationWebhookLogSchema>;
export type IntegrationWebhookLog = typeof integrationWebhookLogs.$inferSelect;

// Integration API keys - service-to-service authentication
export const integrationApiKeys = pgTable("integration_api_keys", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  
  name: text("name").notNull(),
  keyHash: text("key_hash").notNull(),
  keyPrefix: text("key_prefix").notNull(),
  
  externalSystem: text("external_system").default("crm"),
  scopes: jsonb("scopes").$type<string[]>(),
  permissions: jsonb("permissions"),
  
  isActive: boolean("is_active").default(true).notNull(),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  
  createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("api_key_org_idx").on(table.organizationId),
  prefixIdx: index("api_key_prefix_idx").on(table.keyPrefix),
}));

export const insertIntegrationApiKeySchema = createInsertSchema(integrationApiKeys).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastUsedAt: true,
});

export type InsertIntegrationApiKey = z.infer<typeof insertIntegrationApiKeySchema>;
export type IntegrationApiKey = typeof integrationApiKeys.$inferSelect;

// Integration webhook endpoints - where to send outbound webhook events
export const integrationWebhookEndpoints = pgTable("integration_webhook_endpoints", {
  id: uuid("id").primaryKey().defaultRandom(),
  organizationId: uuid("organization_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  
  name: text("name").notNull(),
  url: text("url").notNull(),
  secret: text("secret"), // Shared secret for HMAC signature verification
  
  // Event filtering
  eventTypes: jsonb("event_types").$type<string[]>(), // null = all events, e.g. ["lease.created", "lease.updated"]
  entityTypes: jsonb("entity_types").$type<string[]>(), // null = all entities, e.g. ["lease", "tenant"]
  
  // Configuration
  isActive: boolean("is_active").default(true).notNull(),
  retryPolicy: jsonb("retry_policy").$type<{
    maxRetries: number;
    initialDelayMs: number;
    maxDelayMs: number;
    backoffMultiplier: number;
  }>().default({
    maxRetries: 3,
    initialDelayMs: 1000,
    maxDelayMs: 30000,
    backoffMultiplier: 2,
  }),
  
  // Stats
  successCount: integer("success_count").default(0).notNull(),
  failureCount: integer("failure_count").default(0).notNull(),
  lastSuccessAt: timestamp("last_success_at", { withTimezone: true }),
  lastFailureAt: timestamp("last_failure_at", { withTimezone: true }),
  lastError: text("last_error"),
  
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("webhook_endpoint_org_idx").on(table.organizationId),
  activeIdx: index("webhook_endpoint_active_idx").on(table.isActive),
}));

export const insertIntegrationWebhookEndpointSchema = createInsertSchema(integrationWebhookEndpoints).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  successCount: true,
  failureCount: true,
  lastSuccessAt: true,
  lastFailureAt: true,
  lastError: true,
});

export type InsertIntegrationWebhookEndpoint = z.infer<typeof insertIntegrationWebhookEndpointSchema>;
export type IntegrationWebhookEndpoint = typeof integrationWebhookEndpoints.$inferSelect;

