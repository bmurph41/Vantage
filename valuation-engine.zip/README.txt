Valuation Engine Export - MarinaMatch
=====================================

Contents:
- services/ - Backend valuation engine services
  - pro-forma-engine-service.ts - Multi-year projections, NOI, IRR, equity multiple
  - capital-stack-service.ts - Debt/equity modeling, LP/GP waterfall, DSCR
  - debt-scenario-service.ts - LTV, amortization, debt yield calculations
  - sensitivity-matrix-service.ts - Two-variable sensitivity analysis

- valuator-pages/ - Valuator workspace pages
- components/modeling/ - Supporting UI components (Growth Rates, Year/Case selectors)
