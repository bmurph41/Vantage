# Exit Scenario Engine — Surgical Fix Tasks

> Generated from full static analysis of `shared/exit/` engine suite.
> Priority order: Critical tax/math bugs → Inconsistent rate sourcing → Edge-case guards → Code dedup.

---

## CRITICAL (Materially Incorrect Outputs)

### T-1: 1031 Exchange Deferral Not Applied to After-Tax Proceeds
**File:** `shared/exit/exit-scenario-engine.ts` lines 219–225
**Bug:** The orchestrator calls `runTaxEngine()` which computes full tax liability on the entire gain, then subtracts it via `afterTaxEquityProceeds = beforeTaxEquityProceeds - taxResult.totalTaxLiability`. For a 1031 exchange, the deferred gain should NOT be taxed — only the boot/recognized gain should flow through the tax engine. The `exchange1031Result` is computed but never used to adjust the tax.
**Acceptance Criteria:**
- When `scenarioType === 'exchange_1031'`, tax is computed ONLY on `recognizedGain` (boot), not on the full gain.
- `afterTaxEquityProceeds` reflects deferral; `comparisonMetrics.deferredGain` matches `exchange1031Result.totalDeferredGain`.
- `effectiveTaxRate` is based on recognized gain only for 1031 scenarios.
- GOLDEN_VECTORS test `1031_full_deferral` must show $0 recognized gain → $0 tax.

### T-2: Installment Sale Depreciation Recapture Timing (IRS §453(d)(1))
**File:** `shared/exit/tax-engine.ts` lines 499–508; `shared/exit/seller-financing-engine.ts` lines 220–223
**Bug:** Both installment tax schedules recognize §1250/§1245 recapture ONLY in Year 0 (proportional to down payment). Per IRS §453(d)(1), ALL depreciation recapture must be recognized in the year of sale regardless of installment treatment. The recapture is NOT spread over installment payments — it's frontloaded in full.
**Acceptance Criteria:**
- In tax-engine `calculateInstallmentTaxSchedule()`: Year 0 recognizes ALL §1250 + §1245 recapture in full (not capped by `gainRecognized` from down payment).
- In seller-financing-engine: Same fix — full recapture in year 0.
- Remaining installment gain in subsequent years is pure LTCG (no recapture remaining).
- GOLDEN_VECTORS test `installment_recapture` must show Year 0 recapture ≥ accumulated depreciation.

### T-3: IRR Uses Only 2 Cash Flows (Ignores Interim Distributions & Refi)
**File:** `shared/exit/exit-scenario-engine.ts` lines 314–318
**Bug:** The orchestrator builds a 2-point IRR: `[{period:0, amount: totalEquityInvested}, {period:N, amount: totalCashReturned}]`. This ignores refinance cash-out proceeds (which occur mid-holding), any interim distributions, and time-weighting.
**Acceptance Criteria:**
- When refinance events exist, each `netCashOut` is added as an intermediate cash flow at its respective year.
- IRR reflects the time-weighted value of mid-holding cash flows.
- MOIC denominator accounts for changed equity base after refi.
- GOLDEN_VECTORS test `refi_irr` must show IRR > naive 2-point IRR when mid-holding cash-out exists.

### T-4: totalEquityInvested Ignores Refinance
**File:** `shared/exit/exit-scenario-engine.ts` line 305
**Bug:** `totalEquityInvested = purchasePrice + acquisitionCosts - debt.outstandingBalance` uses the ORIGINAL debt balance. After a cash-out refi, the investor has received cash back, reducing effective equity at risk. This overstates equity invested and understates MOIC.
**Acceptance Criteria:**
- `totalEquityInvested` remains the initial equity outlay (correct for MOIC denominator).
- But `totalCashReturned` must include refi cash-out proceeds (it does on line 306, confirmed OK).
- Clarify: the issue is that IRR doesn't include refi cash-outs as interim flows (see T-3).

---

## HIGH (Tax Rate Inconsistencies Across Engines)

### T-5: 1031 Boot Tax Uses Hardcoded 23.8% Instead of Tax Engine
**File:** `shared/exit/exchange-1031-engine.ts` line 117
**Bug:** Boot tax = `recognizedGain * 0.238`. This ignores filing status, income brackets, state tax, and NIIT eligibility. A married filer with low income could pay 15% LTCG + 0% NIIT, not 23.8%.
**Acceptance Criteria:**
- Boot tax estimate uses the actual LTCG bracket from tax-engine's `getLtcgRate()` + NIIT + state rate.
- OR: Remove `taxOnBoot` from the 1031 result and let the orchestrator compute it (preferred, avoids duplication).
- If keeping `taxOnBoot`, it must accept a `TaxProfileInput` parameter.

### T-6: Seller Financing Uses Hardcoded LTCG Rate + Incomplete State Table
**File:** `shared/exit/seller-financing-engine.ts` lines 186–190, 227–229
**Bug:** Uses flat 20% LTCG rate (line 227) and only has 12 states in its internal table. A filer in the 15% bracket overpays; a filer in VA/CO/etc. gets a default 5% instead of the correct rate.
**Acceptance Criteria:**
- Seller financing installment tax schedule uses `STATE_CAPITAL_GAINS_RATES` from tax-engine.ts (import it).
- LTCG rate uses `getLtcgRate()` from tax-engine.ts based on filing status + income.
- OR: Accept a `TaxProfileInput` and route through the central tax functions.

### T-7: Earnout Uses Hardcoded Combined Tax Rates
**File:** `shared/exit/earnout-engine.ts` lines 78–83
**Bug:** Uses hardcoded `{ capital_gain: 0.238, ordinary_income: 0.407, mixed: 0.32 }`. These embed assumptions about LTCG bracket (20%), NIIT (3.8%), and top ordinary rate (37%) + NIIT that don't apply to all filers.
**Acceptance Criteria:**
- Earnout engine accepts optional `TaxProfileInput` and computes rates from tax-engine if provided.
- Falls back to current hardcoded rates when no profile is given (backward compatible).

---

## MEDIUM (Edge-Case Guards)

### T-8: Division by Zero in Basis Ledger
**File:** `shared/exit/basis-ledger.ts` lines 66–67
**Bug:** `improvementBasis / depreciationScheduleYears` and `personalPropertyValue / 5` — if `depreciationScheduleYears === 0`, this produces `Infinity`/`NaN` that propagates through all downstream engines.
**Acceptance Criteria:**
- Guard: if `depreciationScheduleYears <= 0`, set annual depreciation to 0 and push a warning.
- Guard: if `personalPropertyValue` is provided but is 0, skip personal property depreciation.

### T-9: Empty replacementProperties in 1031 Engine
**File:** `shared/exit/exchange-1031-engine.ts` lines 96, 130–132
**Bug:** If `replacementProperties` is empty, `totalReplacementValue = 0`, and in `replacementResults.map()` the `shareOfRelinquished = 1 / 0 = Infinity`.
**Acceptance Criteria:**
- If `replacementProperties.length === 0`, return early with a warning and all-boot-recognized result.
- No NaN/Infinity in any output field.

### T-10: 100% Down Payment in Seller Financing
**File:** `shared/exit/seller-financing-engine.ts` line 132
**Bug:** If `downPaymentPercent === 1.0`, `faceValue = 0`. The amortization loop runs with `balance = 0`, `monthlyPayment` could be 0 or NaN, and the installment tax schedule still computes meaningless entries.
**Acceptance Criteria:**
- If `faceValue <= 0`, skip amortization and installment tax entirely; return a simplified cash-sale-equivalent result with warning.

### T-11: Empty Capital Calls / Distributions in Waterfall
**File:** `shared/exit/waterfall-engine-v2.ts` lines 93–94, 99
**Bug:** `totalCapitalCalled = 0` → `gpCapital = 0`, `lpCapital = 0`, and `holdingYears` from `calculateHoldingYears` with 0 events returns 1 (safe) but downstream `paidInCapital = 0` → `grossMoic = 0/0`.
**Acceptance Criteria:**
- If no capital calls or no distributions, return early with warning and zeroed-out metrics.
- No NaN in any fund metric.

### T-12: holdingPeriodYears = 0
**File:** `shared/exit/exit-scenario-engine.ts` line 310
**Bug:** `annualizedReturn = Math.pow(moic, 1/0) - 1 = Infinity`.
**Acceptance Criteria:**
- Guard: if `holdingPeriodYears <= 0`, set annualizedReturn to 0 with a warning.

### T-13: Negative Gain (Loss) Scenarios
**File:** Multiple engines
**Bug:** Tax engine's `effectiveTaxRate = totalTaxLiability / totalGain` produces negative rate when totalGain < 0. The 1031 engine clamps recognized gain to >=0 but doesn't surface a warning for exchanging at a loss.
**Acceptance Criteria:**
- Tax engine: when totalGain <= 0, effectiveTaxRate = 0 and push warning about loss.
- 1031 engine: when realizedGain <= 0, push warning "No gain to defer — 1031 exchange provides no tax benefit."

---

## LOW (Code Quality / Deduplication)

### T-14: Duplicate IRR Implementations
**Files:** `dst-engine.ts`, `seller-financing-engine.ts`, `cashflow-synthesizer.ts` each contain `bisectionIRR()`. `waterfall-engine-v2.ts` contains `dateBasedXIRR()`.
**Bug:** 4 separate IRR functions that could diverge in behavior from the canonical `irr-calculator.ts`.
**Acceptance Criteria:**
- Replace all local `bisectionIRR()` calls with `import { calculateIRR } from './irr-calculator'`.
- Replace `dateBasedXIRR()` with `import { calculateXIRR } from './irr-calculator'` (adapting the input format).
- Remove the local function definitions.

### T-15: Duplicate formatCurrency
**Files:** `exit-scenario-engine.ts`, `exchange-1031-engine.ts`, `waterfall-engine-v2.ts`, `tax-engine.ts`
**Acceptance Criteria:**
- Extract `formatCurrency` to a shared utility (e.g., `shared/exit/format-utils.ts`) and import everywhere.

### T-16: Duplicate Gain Allocation Logic
**Files:** `shared/exit/basis-ledger.ts` (`calculateCapitalGainBreakdown`) vs `shared/exit/tax-engine.ts` (`allocateGains`)
**Bug:** Two separate implementations of gain allocation with slightly different handling of suspended losses and §1231 lookback.
**Acceptance Criteria:**
- Designate `tax-engine.ts` `allocateGains()` as the canonical implementation.
- Have `calculateCapitalGainBreakdown()` delegate to `allocateGains()` or be deprecated.

### T-17: Dead Code in Tax Engine
**File:** `shared/exit/tax-engine.ts` line 456
**Bug:** `const salePrice = allocation.netSalePrice + (allocation.netSalePrice - allocation.adjustedBasis < allocation.totalGain ? 0 : 0)` — ternary always evaluates to 0.
**Acceptance Criteria:**
- Remove or fix the dead expression. Use `allocation.netSalePrice` directly.

### T-18: Static Risk Score in Comparison Engine
**File:** `shared/exit/exit-scenario-engine.ts` lines 333–338
**Bug:** Risk scores are hardcoded (cash=2, 1031=4, seller_financing=5, dst=6, hybrid=7) rather than derived from actual sub-engine risk analysis.
**Acceptance Criteria:**
- Derive risk score from sub-engine outputs (e.g., buyer risk score from seller financing, DST risk flags count, 1031 boot amount).
- Fall back to static scoring if sub-engine results unavailable.

### T-19: Dual-State Tax Credit Assumes All States Allow It
**File:** `shared/exit/tax-engine.ts` line 437
**Bug:** `creditForPropertyStateTax = Math.min(propertyState.tax, residenceState.tax)` — some states don't allow credit for taxes paid to other states.
**Acceptance Criteria:**
- Add a `stateAllowsCredit` flag to `STATE_CAPITAL_GAINS_RATES` (default `true`).
- Only apply credit when both states allow it.
