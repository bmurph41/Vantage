  // Exit Strategy Suite - Exit Scenarios
  getExitScenarios(modelingProjectId: string, orgId: string): Promise<ExitScenario[]>;
  getExitScenario(id: string, orgId: string): Promise<ExitScenario | undefined>;
  createExitScenario(data: InsertExitScenario & { orgId: string; createdBy?: string }): Promise<ExitScenario>;
  updateExitScenario(id: string, data: UpdateExitScenario & { updatedBy?: string }, orgId: string): Promise<ExitScenario | undefined>;
  deleteExitScenario(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Tax Calculations
  getExitTaxCalculations(exitScenarioId: string, orgId: string): Promise<ExitTaxCalculation[]>;
  getExitTaxCalculation(id: string, orgId: string): Promise<ExitTaxCalculation | undefined>;
  createExitTaxCalculation(data: InsertExitTaxCalculation & { orgId: string }): Promise<ExitTaxCalculation>;
  updateExitTaxCalculation(id: string, data: UpdateExitTaxCalculation, orgId: string): Promise<ExitTaxCalculation | undefined>;
  deleteExitTaxCalculation(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Seller Financing
  getExitSellerFinancing(exitScenarioId: string, orgId: string): Promise<ExitSellerFinancing[]>;
  getExitSellerFinancingById(id: string, orgId: string): Promise<ExitSellerFinancing | undefined>;
  createExitSellerFinancing(data: InsertExitSellerFinancing & { orgId: string }): Promise<ExitSellerFinancing>;
  updateExitSellerFinancing(id: string, data: UpdateExitSellerFinancing, orgId: string): Promise<ExitSellerFinancing | undefined>;
  deleteExitSellerFinancing(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Earnouts
  getExitEarnouts(exitScenarioId: string, orgId: string): Promise<ExitEarnout[]>;
  getExitEarnout(id: string, orgId: string): Promise<ExitEarnout | undefined>;
  createExitEarnout(data: InsertExitEarnout & { orgId: string }): Promise<ExitEarnout>;
  updateExitEarnout(id: string, data: UpdateExitEarnout, orgId: string): Promise<ExitEarnout | undefined>;
  deleteExitEarnout(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - 1031 Exchanges
  getExit1031Exchanges(exitScenarioId: string, orgId: string): Promise<Exit1031Exchange[]>;
  getExit1031Exchange(id: string, orgId: string): Promise<Exit1031Exchange | undefined>;
  createExit1031Exchange(data: InsertExit1031Exchange & { orgId: string }): Promise<Exit1031Exchange>;
  updateExit1031Exchange(id: string, data: UpdateExit1031Exchange, orgId: string): Promise<Exit1031Exchange | undefined>;
  deleteExit1031Exchange(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - DST Analyses
  getExitDstAnalyses(exitScenarioId: string, orgId: string): Promise<ExitDstAnalysis[]>;
  getExitDstAnalysis(id: string, orgId: string): Promise<ExitDstAnalysis | undefined>;
  createExitDstAnalysis(data: InsertExitDstAnalysis & { orgId: string }): Promise<ExitDstAnalysis>;
  updateExitDstAnalysis(id: string, data: UpdateExitDstAnalysis, orgId: string): Promise<ExitDstAnalysis | undefined>;
  deleteExitDstAnalysis(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Funds
  getExitFunds(orgId: string): Promise<ExitFund[]>;
  getExitFund(id: string, orgId: string): Promise<ExitFund | undefined>;
  createExitFund(data: InsertExitFund & { orgId: string }): Promise<ExitFund>;
  updateExitFund(id: string, data: UpdateExitFund, orgId: string): Promise<ExitFund | undefined>;
  deleteExitFund(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Waterfall Structures
  getExitWaterfallStructures(exitScenarioId: string, orgId: string): Promise<ExitWaterfallStructure[]>;
  getExitWaterfallStructure(id: string, orgId: string): Promise<ExitWaterfallStructure | undefined>;
  createExitWaterfallStructure(data: InsertExitWaterfallStructure & { orgId: string }): Promise<ExitWaterfallStructure>;
  updateExitWaterfallStructure(id: string, data: UpdateExitWaterfallStructure, orgId: string): Promise<ExitWaterfallStructure | undefined>;
  deleteExitWaterfallStructure(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Investors
  getExitInvestors(fundId: string, orgId: string): Promise<ExitInvestor[]>;
  getExitInvestor(id: string, orgId: string): Promise<ExitInvestor | undefined>;
  createExitInvestor(data: InsertExitInvestor & { orgId: string }): Promise<ExitInvestor>;
  updateExitInvestor(id: string, data: UpdateExitInvestor, orgId: string): Promise<ExitInvestor | undefined>;
  deleteExitInvestor(id: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Cash Flows
  getExitCashFlows(exitScenarioId: string, orgId: string): Promise<ExitCashFlow[]>;
  createExitCashFlow(data: InsertExitCashFlow & { orgId: string }): Promise<ExitCashFlow>;
  deleteExitCashFlows(exitScenarioId: string, orgId: string): Promise<boolean>;

  // Exit Strategy Suite - Activities
  getExitActivities(exitScenarioId: string | null, modelingProjectId: string | null, orgId: string): Promise<ExitActivity[]>;
  createExitActivity(data: InsertExitActivity & { orgId: string }): Promise<ExitActivity>;

  // Virtual Data Room - Composed VDR storage access
  vdr: import("./vdr-storage").IVdrStorage;
