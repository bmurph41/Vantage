// Exit Storage Implementation (from server/storage.ts)
  // EXIT STRATEGY SUITE - Implementation Methods
  // ============================================================================

  // Exit Scenarios
  async getExitScenarios(modelingProjectId: string, orgId: string): Promise<ExitScenario[]> {
    return await db.select()
      .from(exitScenarios)
      .where(and(
        eq(exitScenarios.modelingProjectId, modelingProjectId),
        eq(exitScenarios.orgId, orgId)
      ))
      .orderBy(desc(exitScenarios.createdAt));
  }

  async getExitScenario(id: string, orgId: string): Promise<ExitScenario | undefined> {
    const [scenario] = await db.select()
      .from(exitScenarios)
      .where(and(
        eq(exitScenarios.id, id),
        eq(exitScenarios.orgId, orgId)
      ));
    return scenario || undefined;
  }

  async createExitScenario(data: InsertExitScenario & { orgId: string; createdBy?: string }): Promise<ExitScenario> {
    const [created] = await db.insert(exitScenarios)
      .values(data as any)
      .returning();
    return created;
  }

  async updateExitScenario(id: string, data: UpdateExitScenario & { updatedBy?: string }, orgId: string): Promise<ExitScenario | undefined> {
    const updateData = { ...data, updatedAt: new Date() };
    const [updated] = await db.update(exitScenarios)
      .set(updateData as any)
      .where(and(
        eq(exitScenarios.id, id),
        eq(exitScenarios.orgId, orgId)
      ))
      .returning();
    return updated || undefined;
  }

  async deleteExitScenario(id: string, orgId: string): Promise<boolean> {
    const result = await db.delete(exitScenarios)
      .where(and(
        eq(exitScenarios.id, id),
        eq(exitScenarios.orgId, orgId)
      ))
      .returning();
    return result.length > 0;
  }

  // Tax Calculations
  async getExitTaxCalculations(exitScenarioId: string, orgId: string): Promise<ExitTaxCalculation[]> {
    return await db.select()
      .from(exitTaxCalculations)
      .where(and(
        eq(exitTaxCalculations.exitScenarioId, exitScenarioId),
        eq(exitTaxCalculations.orgId, orgId)
      ))
      .orderBy(desc(exitTaxCalculations.createdAt));
  }

  async getExitTaxCalculation(id: string, orgId: string): Promise<ExitTaxCalculation | undefined> {
    const [calc] = await db.select()
      .from(exitTaxCalculations)
      .where(and(
        eq(exitTaxCalculations.id, id),
        eq(exitTaxCalculations.orgId, orgId)
      ));
    return calc || undefined;
  }

  async createExitTaxCalculation(data: InsertExitTaxCalculation & { orgId: string }): Promise<ExitTaxCalculation> {
    const [created] = await db.insert(exitTaxCalculations)
      .values(data as any)
      .returning();
    return created;
  }

  async updateExitTaxCalculation(id: string, data: UpdateExitTaxCalculation, orgId: string): Promise<ExitTaxCalculation | undefined> {
    const updateData = { ...data, updatedAt: new Date() };
    const [updated] = await db.update(exitTaxCalculations)
      .set(updateData as any)
      .where(and(
        eq(exitTaxCalculations.id, id),
        eq(exitTaxCalculations.orgId, orgId)
      ))
      .returning();
    return updated || undefined;
  }

  async deleteExitTaxCalculation(id: string, orgId: string): Promise<boolean> {
    const result = await db.delete(exitTaxCalculations)
      .where(and(
        eq(exitTaxCalculations.id, id),
        eq(exitTaxCalculations.orgId, orgId)
      ))
      .returning();
    return result.length > 0;
  }

  // Seller Financing
  async getExitSellerFinancing(exitScenarioId: string, orgId: string): Promise<ExitSellerFinancing[]> {
    return await db.select()
      .from(exitSellerFinancing)
      .where(and(
        eq(exitSellerFinancing.exitScenarioId, exitScenarioId),
        eq(exitSellerFinancing.orgId, orgId)
      ))
      .orderBy(desc(exitSellerFinancing.createdAt));
  }

  async getExitSellerFinancingById(id: string, orgId: string): Promise<ExitSellerFinancing | undefined> {
    const [sf] = await db.select()
      .from(exitSellerFinancing)
      .where(and(
        eq(exitSellerFinancing.id, id),
        eq(exitSellerFinancing.orgId, orgId)
      ));
    return sf || undefined;
  }

  async createExitSellerFinancing(data: InsertExitSellerFinancing & { orgId: string }): Promise<ExitSellerFinancing> {
    const [created] = await db.insert(exitSellerFinancing)
      .values(data as any)
      .returning();
    return created;
  }

  async updateExitSellerFinancing(id: string, data: UpdateExitSellerFinancing, orgId: string): Promise<ExitSellerFinancing | undefined> {
    const updateData = { ...data, updatedAt: new Date() };
    const [updated] = await db.update(exitSellerFinancing)
      .set(updateData as any)
      .where(and(
        eq(exitSellerFinancing.id, id),
        eq(exitSellerFinancing.orgId, orgId)
      ))
      .returning();
    return updated || undefined;
  }

  async deleteExitSellerFinancing(id: string, orgId: string): Promise<boolean> {
    const result = await db.delete(exitSellerFinancing)
      .where(and(
        eq(exitSellerFinancing.id, id),
        eq(exitSellerFinancing.orgId, orgId)
      ))
      .returning();
    return result.length > 0;
  }

  // Earnouts
  async getExitEarnouts(exitScenarioId: string, orgId: string): Promise<ExitEarnout[]> {
    return await db.select()
      .from(exitEarnouts)
      .where(and(
        eq(exitEarnouts.exitScenarioId, exitScenarioId),
        eq(exitEarnouts.orgId, orgId)
      ))
      .orderBy(asc(exitEarnouts.sortOrder));
  }

  async getExitEarnout(id: string, orgId: string): Promise<ExitEarnout | undefined> {
    const [earnout] = await db.select()
      .from(exitEarnouts)
      .where(and(
        eq(exitEarnouts.id, id),
        eq(exitEarnouts.orgId, orgId)
      ));
    return earnout || undefined;
  }

  async createExitEarnout(data: InsertExitEarnout & { orgId: string }): Promise<ExitEarnout> {
    const [created] = await db.insert(exitEarnouts)
      .values(data as any)
      .returning();
    return created;
  }

  async updateExitEarnout(id: string, data: UpdateExitEarnout, orgId: string): Promise<ExitEarnout | undefined> {
    const updateData = { ...data, updatedAt: new Date() };
    const [updated] = await db.update(exitEarnouts)
      .set(updateData as any)
      .where(and(
        eq(exitEarnouts.id, id),
        eq(exitEarnouts.orgId, orgId)
      ))
      .returning();
    return updated || undefined;
  }

  async deleteExitEarnout(id: string, orgId: string): Promise<boolean> {
    const result = await db.delete(exitEarnouts)
      .where(and(
        eq(exitEarnouts.id, id),
        eq(exitEarnouts.orgId, orgId)
      ))
      .returning();
    return result.length > 0;
  }

  // 1031 Exchanges
  async getExit1031Exchanges(exitScenarioId: string, orgId: string): Promise<Exit1031Exchange[]> {
    return await db.select()
      .from(exit1031Exchanges)
      .where(and(
        eq(exit1031Exchanges.exitScenarioId, exitScenarioId),
        eq(exit1031Exchanges.orgId, orgId)
      ))
      .orderBy(desc(exit1031Exchanges.createdAt));
  }

  async getExit1031Exchange(id: string, orgId: string): Promise<Exit1031Exchange | undefined> {
    const [exchange] = await db.select()
      .from(exit1031Exchanges)
      .where(and(
        eq(exit1031Exchanges.id, id),
        eq(exit1031Exchanges.orgId, orgId)
      ));
    return exchange || undefined;
  }

  async createExit1031Exchange(data: InsertExit1031Exchange & { orgId: string }): Promise<Exit1031Exchange> {
    const [created] = await db.insert(exit1031Exchanges)
      .values(data as any)
      .returning();
    return created;
  }

  async updateExit1031Exchange(id: string, data: UpdateExit1031Exchange, orgId: string): Promise<Exit1031Exchange | undefined> {
    const updateData = { ...data, updatedAt: new Date() };
    const [updated] = await db.update(exit1031Exchanges)
      .set(updateData as any)
      .where(and(
        eq(exit1031Exchanges.id, id),
        eq(exit1031Exchanges.orgId, orgId)
      ))
      .returning();
    return updated || undefined;
  }

  async deleteExit1031Exchange(id: string, orgId: string): Promise<boolean> {
    const result = await db.delete(exit1031Exchanges)
      .where(and(
        eq(exit1031Exchanges.id, id),
        eq(exit1031Exchanges.orgId, orgId)
      ))
      .returning();
    return result.length > 0;
  }

  // DST Analyses
  async getExitDstAnalyses(exitScenarioId: string, orgId: string): Promise<ExitDstAnalysis[]> {
    return await db.select()
      .from(exitDstAnalyses)
      .where(and(
        eq(exitDstAnalyses.exitScenarioId, exitScenarioId),
        eq(exitDstAnalyses.orgId, orgId)
      ))
