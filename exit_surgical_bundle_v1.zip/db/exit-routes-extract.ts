// Exit API Routes (from server/routes.ts)
  });

  // --- FUNDS ---

  // Get all funds for organization
  app.get('/api/exit/funds', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const funds = await storage.getExitFunds(orgId);
      res.json(funds);
    } catch (error: any) {
      console.error('Failed to fetch funds:', error);
      res.status(500).json({ error: 'Failed to fetch funds' });
    }
  });

  // Get single fund
  app.get('/api/exit/funds/:fundId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { fundId } = req.params;
      
      const fund = await storage.getExitFund(fundId, orgId);
      if (!fund) {
        return res.status(404).json({ error: 'Fund not found' });
      }
      
      res.json(fund);
    } catch (error: any) {
      console.error('Failed to fetch fund:', error);
      res.status(500).json({ error: 'Failed to fetch fund' });
    }
  });

  // Create fund
  app.post('/api/exit/funds', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      const fund = await storage.createExitFund({
        ...req.body,
        orgId
      });
      
      res.status(201).json(fund);
    } catch (error: any) {
      console.error('Failed to create fund:', error);
      res.status(500).json({ error: 'Failed to create fund' });
    }
  });

  // Update fund
  app.patch('/api/exit/funds/:fundId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { fundId } = req.params;
      
      const fund = await storage.updateExitFund(fundId, req.body, orgId);
      if (!fund) {
        return res.status(404).json({ error: 'Fund not found' });
      }
      
      res.json(fund);
    } catch (error: any) {
      console.error('Failed to update fund:', error);
      res.status(500).json({ error: 'Failed to update fund' });
    }
  });

  // Delete fund
  app.delete('/api/exit/funds/:fundId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { fundId } = req.params;
      
      const success = await storage.deleteExitFund(fundId, orgId);
      if (!success) {
        return res.status(404).json({ error: 'Fund not found' });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete fund:', error);
      res.status(500).json({ error: 'Failed to delete fund' });
    }
  });

  // --- WATERFALL STRUCTURES ---

  // Get waterfall structures for a scenario
  app.get('/api/modeling/projects/:projectId/exit/scenarios/:scenarioId/waterfall', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { scenarioId } = req.params;
      
      const waterfalls = await storage.getExitWaterfallStructures(scenarioId, orgId);
      res.json(waterfalls);
    } catch (error: any) {
      console.error('Failed to fetch waterfall structures:', error);
      res.status(500).json({ error: 'Failed to fetch waterfall structures' });
    }
  });

  // Create waterfall structure
  app.post('/api/modeling/projects/:projectId/exit/scenarios/:scenarioId/waterfall', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { scenarioId } = req.params;
      
      const scenario = await storage.getExitScenario(scenarioId, orgId);
      if (!scenario) {
        return res.status(404).json({ error: 'Exit scenario not found' });
      }
      
      const waterfall = await storage.createExitWaterfallStructure({
        ...req.body,
        exitScenarioId: scenarioId,
        orgId
      });
      
      res.status(201).json(waterfall);
    } catch (error: any) {
      console.error('Failed to create waterfall structure:', error);
      res.status(500).json({ error: 'Failed to create waterfall structure' });
    }
  });

  // Update waterfall structure
  app.patch('/api/modeling/projects/:projectId/exit/scenarios/:scenarioId/waterfall/:waterfallId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { waterfallId } = req.params;
      
      const waterfall = await storage.updateExitWaterfallStructure(waterfallId, req.body, orgId);
      if (!waterfall) {
        return res.status(404).json({ error: 'Waterfall structure not found' });
      }
      
      res.json(waterfall);
    } catch (error: any) {
      console.error('Failed to update waterfall structure:', error);
      res.status(500).json({ error: 'Failed to update waterfall structure' });
    }
  });

  // Delete waterfall structure
  app.delete('/api/modeling/projects/:projectId/exit/scenarios/:scenarioId/waterfall/:waterfallId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { waterfallId } = req.params;
      
      const success = await storage.deleteExitWaterfallStructure(waterfallId, orgId);
      if (!success) {
        return res.status(404).json({ error: 'Waterfall structure not found' });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete waterfall structure:', error);
      res.status(500).json({ error: 'Failed to delete waterfall structure' });
    }
  });

  // --- INVESTORS ---

  // Get investors for a fund
  app.get('/api/exit/funds/:fundId/investors', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { fundId } = req.params;
      
      const fund = await storage.getExitFund(fundId, orgId);
      if (!fund) {
        return res.status(404).json({ error: 'Fund not found' });
      }
      
      const investors = await storage.getExitInvestors(fundId, orgId);
      res.json(investors);
    } catch (error: any) {
      console.error('Failed to fetch investors:', error);
      res.status(500).json({ error: 'Failed to fetch investors' });
    }
  });

  // Create investor
  app.post('/api/exit/funds/:fundId/investors', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { fundId } = req.params;
      
      const fund = await storage.getExitFund(fundId, orgId);
      if (!fund) {
        return res.status(404).json({ error: 'Fund not found' });
      }
      
      const investor = await storage.createExitInvestor({
        ...req.body,
        fundId,
        orgId
      });
      
      res.status(201).json(investor);
    } catch (error: any) {
      console.error('Failed to create investor:', error);
      res.status(500).json({ error: 'Failed to create investor' });
    }
  });

  // Update investor
  app.patch('/api/exit/funds/:fundId/investors/:investorId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { investorId } = req.params;
      
      const investor = await storage.updateExitInvestor(investorId, req.body, orgId);
      if (!investor) {
        return res.status(404).json({ error: 'Investor not found' });
      }
      
      res.json(investor);
    } catch (error: any) {
      console.error('Failed to update investor:', error);
      res.status(500).json({ error: 'Failed to update investor' });
    }
  });

  // Delete investor
  app.delete('/api/exit/funds/:fundId/investors/:investorId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { investorId } = req.params;
      
      const success = await storage.deleteExitInvestor(investorId, orgId);
      if (!success) {
        return res.status(404).json({ error: 'Investor not found' });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete investor:', error);
      res.status(500).json({ error: 'Failed to delete investor' });
    }
  });

  // --- CASH FLOWS ---

  // Get cash flows for a scenario
  app.get('/api/modeling/projects/:projectId/exit/scenarios/:scenarioId/cash-flows', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { scenarioId } = req.params;
      
      const cashFlows = await storage.getExitCashFlows(scenarioId, orgId);
      res.json(cashFlows);
    } catch (error: any) {
      console.error('Failed to fetch cash flows:', error);
      res.status(500).json({ error: 'Failed to fetch cash flows' });
    }
  });

  // Save cash flows for a scenario (replaces existing)
