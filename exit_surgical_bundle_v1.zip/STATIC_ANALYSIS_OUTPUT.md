# Exit Scenario Engine — Full Static Analysis Output

> Generated: 2026-02-13
> Analyst: MarinaMatch development team
> Scope: All files in `shared/exit/` — 10 engine files, 1 barrel export

---

## CRITICAL ISSUES (Will Produce Wrong Numbers)

### 1. 1031 Exchange Tax Deferral Ignored in Proceeds

**Files:** `shared/exit/exit-scenario-engine.ts` lines 219–225

The orchestrator runs the full tax engine (computing full tax liability on the entire gain), then subtracts it from equity proceeds:

```typescript
const taxResult = runTaxEngine(gainInput, input.taxProfile);
const afterTaxEquityProceeds = beforeTaxEquityProceeds - taxResult.totalTaxLiability;
```

For a 1031 exchange, the deferred gain should NOT be taxed — only the boot/recognized gain should flow through the tax engine. The `exchange1031Result` is computed (line 246) but never used to adjust the tax. This means a 1031 scenario shows the same tax bill as a cash sale, completely defeating the purpose of the analysis.

### 2. Installment Sale Depreciation Recapture Timing Is Wrong (IRS §453(d)(1))

**Files:** `shared/exit/tax-engine.ts` lines 499–508; `shared/exit/seller-financing-engine.ts` lines 220–223

Both installment tax schedules recognize §1250/§1245 recapture ONLY in Year 0 proportional to the down payment:

```typescript
// tax-engine.ts
if (year === 0 && remainingRecapture1250 > 0) {
  section1250RecapturedThisYear = Math.min(remainingRecapture1250, gainRecognized);
  // gainRecognized = downPayment * grossProfitRatio ← WRONG cap
}
```

Per IRS §453(d)(1), ALL depreciation recapture must be recognized in the year of sale regardless of installment method. The recapture amount is NOT spread over installment payments and is NOT limited by the gross profit ratio of the down payment — it is frontloaded in full. This understates Year 0 tax and overstates the NPV benefit of installment treatment.

### 3. IRR Uses Only 2 Cash Flows (Ignores Interim Distributions & Refinance)

**File:** `shared/exit/exit-scenario-engine.ts` lines 314–318

```typescript
const investmentCashFlows = [
  { period: 0, amount: totalEquityInvested, type: 'investment' },
  { period: holdingPeriodYears, amount: totalCashReturned, type: 'distribution' },
];
const irr = calculateIRR(investmentCashFlows);
```

This 2-point IRR ignores:
- Refinance cash-out proceeds (which occur mid-holding at `evt.year`)
- Any interim operating distributions
- Time-weighting of cash flows

The result is a materially incorrect IRR that doesn't reflect the actual timing of cash inflows.

### 4. totalEquityInvested Ignores Refinance Impact

**File:** `shared/exit/exit-scenario-engine.ts` line 305

```typescript
const totalEquityInvested = input.property.purchasePrice + input.property.acquisitionCosts - input.debt.outstandingBalance;
```

Uses the ORIGINAL debt balance, not the post-refinance balance. While `totalCashReturned` does include refi cash-out (line 306), the IRR calculation doesn't properly model the refi as a mid-period cash flow, making the return metrics misleading.

---

## TAX RATE INCONSISTENCIES (Multiple Engines Contradict Each Other)

### 5. 1031 Boot Tax Uses Hardcoded 23.8% Instead of Tax Engine

**File:** `shared/exit/exchange-1031-engine.ts` line 117

```typescript
const estimatedCapGainsRate = 0.238;
const taxOnBoot = recognizedGain * estimatedCapGainsRate;
```

This ignores filing status, income brackets, state tax, and NIIT eligibility. A married filer with low income could pay 15% LTCG + 0% NIIT, not 23.8%. A CA filer would owe an additional 13.3% state tax.

### 6. Seller Financing Uses Hardcoded LTCG Rate + Incomplete State Table

**File:** `shared/exit/seller-financing-engine.ts` lines 186–190, 227–229

```typescript
// Only 12 states hardcoded:
const stateRates: Record<string, number> = {
  CA: 0.133, NY: 0.109, NJ: 0.1075, FL: 0, TX: 0, WA: 0.07, MA: 0.09,
  IL: 0.0495, PA: 0.0307, OH: 0.04, GA: 0.0549, NC: 0.0525,
};
const stateRate = stateRates[...] || 0.05; // ← Default 5% for 39 unlisted states

// Hardcoded LTCG:
const ltcgRate = 0.20;
```

Meanwhile, `tax-engine.ts` has a comprehensive 51-jurisdiction `STATE_CAPITAL_GAINS_RATES` table and bracket-based LTCG calculation. A user in Virginia gets 5% default in seller financing but 5.75% from the tax engine. A filer in the 15% LTCG bracket overpays by 5 percentage points.

### 7. Earnout Uses Hardcoded Combined Tax Rates

**File:** `shared/exit/earnout-engine.ts` lines 78–83

```typescript
const taxRates: Record<string, number> = {
  capital_gain: 0.238,       // Assumes 20% + 3.8% NIIT — not all filers
  ordinary_income: 0.407,    // Assumes 37% + 3.8% NIIT — not all filers
  mixed: 0.32,               // Arbitrary blend
};
```

These embed max-bracket assumptions that don't apply to filers in lower brackets or states with no income tax.

---

## DUPLICATE CODE PATHS (Maintenance Risk + Divergence Risk)

### 8. Four Separate IRR Implementations

| File | Function | Notes |
|------|----------|-------|
| `irr-calculator.ts` | `calculateIRR()` | Canonical. Bisection method. |
| `irr-calculator.ts` | `calculateXIRR()` | Canonical. Newton-Raphson. |
| `dst-engine.ts` line 322 | `bisectionIRR()` | Copy-paste of bisection. |
| `seller-financing-engine.ts` line 488 | `bisectionIRR()` | Copy-paste of bisection. |
| `cashflow-synthesizer.ts` line 227 | `calculateIRR()` | Yet another copy. |
| `waterfall-engine-v2.ts` line 500 | `dateBasedXIRR()` | Duplicates `calculateXIRR`. |

All 4 copies use the same algorithm but could diverge if one is patched and others aren't.

### 9. Duplicate Gain Allocation Logic

- `shared/exit/basis-ledger.ts` → `calculateCapitalGainBreakdown()` (lines 215–269)
- `shared/exit/tax-engine.ts` → `allocateGains()` (lines 255–360)

Both compute §1250/§1245 recapture buckets, but `allocateGains()` additionally handles §1231 lookback and passive loss offsets. Using the wrong one produces different recapture amounts.

### 10. `formatCurrency()` Duplicated in 4+ Files

Present in: `exit-scenario-engine.ts`, `exchange-1031-engine.ts`, `waterfall-engine-v2.ts`, `tax-engine.ts`. Identical implementations.

---

## EDGE-CASE GAPS (Will Crash or Produce NaN)

### 11. Division by Zero in Basis Ledger

**File:** `shared/exit/basis-ledger.ts` lines 66–67

```typescript
const improvementAnnualDepreciation = improvementBasis / input.depreciationScheduleYears;
```

If `depreciationScheduleYears === 0`, this produces `Infinity` which propagates through all downstream engines, corrupting basis, gain, and tax calculations.

### 12. Empty replacementProperties in 1031 Engine

**File:** `shared/exit/exchange-1031-engine.ts` lines 96, 130–132

If `replacementProperties` is empty:
- `totalReplacementValue = 0`
- In the map: `shareOfRelinquished = 1 / input.replacementProperties.length = 1 / 0 = Infinity`

### 13. 100% Down Payment in Seller Financing

If `downPaymentPercent === 1.0`, `faceValue = 0`. The amortization loop runs with `balance = 0`, `monthlyPayment` could be 0 or NaN, and the installment tax schedule still computes meaningless entries.

### 14. Empty Capital Calls / Distributions in Waterfall

No capital calls → `totalCapitalCalled = 0` → `gpCapital = 0`, `lpCapital = 0` → `grossMoic = 0/0 = NaN`. The `Math.min/max` on empty arrays returns `Infinity/-Infinity`.

### 15. holdingPeriodYears = 0

`annualizedReturn = Math.pow(moic, 1/0) - 1 = Infinity`.

### 16. Negative Gain (Loss) Scenarios

Tax engine: `effectiveTaxRate = totalTaxLiability / totalGain` produces a negative rate when `totalGain < 0`. The 1031 engine clamps recognized gain to >= 0 but doesn't warn about exchanging at a loss (which provides no deferral benefit).

---

## MINOR / DEAD CODE

### 17. Dead Code in Tax Engine

**File:** `shared/exit/tax-engine.ts` line 456

```typescript
const salePrice = allocation.netSalePrice + (allocation.netSalePrice - allocation.adjustedBasis < allocation.totalGain ? 0 : 0);
```

The ternary always evaluates to 0 regardless of condition. Dead code.

### 18. Static Risk Score in Comparison Engine

**File:** `shared/exit/exit-scenario-engine.ts` lines 333–338

```typescript
let riskScore = 2;
if (input.scenarioType === 'exchange_1031') riskScore = 4;
if (input.scenarioType === 'seller_financing') riskScore = 5;
// ...
```

Hardcoded static numbers rather than being derived from actual sub-engine risk analysis (e.g., DST risk flags, buyer credit score, boot amount).

### 19. Dual-State Tax Credit Assumes All States Allow It

**File:** `shared/exit/tax-engine.ts` line 437

```typescript
creditForPropertyStateTax = Math.min(propertyState.tax, residenceState.tax);
```

Some states (e.g., states with no income tax being the property state) don't allow credit for taxes paid to other states. The engine always applies the credit.

### 20. Earnout Scenario Probabilities Don't Sum to 1.0

**File:** `shared/exit/earnout-engine.ts` lines 86–111

The sub-scenarios for each tranche use:
- Full Achievement: `prob * 0.60`
- Partial 75%: `prob * 0.25`
- Partial 50%: `prob * 0.10`
- Not Achieved: `1 - prob`

Sum = `prob * 0.95 + (1 - prob)` = `1 - 0.05 * prob`. This never sums to 1.0 unless `prob = 0`. Missing 5% of probability mass.

---

## SUMMARY TABLE

| # | Severity | Category | Engine | Issue |
|---|----------|----------|--------|-------|
| 1 | CRITICAL | Logic | exit-scenario-engine | 1031 deferral not applied to after-tax proceeds |
| 2 | CRITICAL | Tax | tax-engine, seller-financing | Installment recapture timing violates §453(d)(1) |
| 3 | CRITICAL | Math | exit-scenario-engine | IRR uses only 2 cash flows |
| 4 | CRITICAL | Math | exit-scenario-engine | Equity invested ignores refi |
| 5 | HIGH | Tax | exchange-1031-engine | Boot tax hardcoded at 23.8% |
| 6 | HIGH | Tax | seller-financing-engine | Hardcoded LTCG rate + 12-state table |
| 7 | HIGH | Tax | earnout-engine | Hardcoded combined tax rates |
| 8 | MEDIUM | Dedup | Multiple | 4 separate IRR implementations |
| 9 | MEDIUM | Dedup | basis-ledger, tax-engine | Duplicate gain allocation |
| 10 | LOW | Dedup | Multiple | formatCurrency duplicated 4x |
| 11 | MEDIUM | Edge | basis-ledger | Div/0 on depreciationScheduleYears=0 |
| 12 | MEDIUM | Edge | exchange-1031-engine | Empty replacementProperties → Infinity |
| 13 | MEDIUM | Edge | seller-financing-engine | 100% down → zero face value |
| 14 | MEDIUM | Edge | waterfall-engine-v2 | Empty capital calls/distributions → NaN |
| 15 | MEDIUM | Edge | exit-scenario-engine | holdingPeriodYears=0 → Infinity |
| 16 | MEDIUM | Edge | tax-engine, 1031 | Negative gain not handled |
| 17 | LOW | Dead Code | tax-engine | Always-zero ternary |
| 18 | LOW | Quality | exit-scenario-engine | Static risk scores |
| 19 | LOW | Tax | tax-engine | Dual-state credit always applied |
| 20 | LOW | Math | earnout-engine | Scenario probabilities don't sum to 1.0 |
