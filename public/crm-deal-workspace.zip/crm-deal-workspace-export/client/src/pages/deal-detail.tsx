import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  ArrowLeft, 
  DollarSign, 
  Calendar, 
  User, 
  Building, 
  Target,
  Clock,
  Edit,
  Trash2,
  Anchor,
  MapPin,
  FileText,
  FolderOpen,
  FileSpreadsheet,
  CheckCircle,
  ListChecks,
  TrendingUp,
  Files,
  Activity,
  ExternalLink,
  Calculator
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import type { Deal, Contact, Company } from "@shared/schema";
import ConvertToProjectModal from "@/components/modals/convert-to-project-modal";
import CompSetSelector from "@/components/comp-set-selector";
import { formatCurrency } from "@/lib/utils";

interface WorkspaceData {
  deal: Deal;
  ddProject: {
    id: string;
    name: string;
    status: string;
    createdAt: string;
  } | null;
  ddTaskSummary: {
    total: number;
    completed: number;
    inProgress: number;
    pending: number;
    percentComplete: number;
  } | null;
  modelingProject: {
    id: string;
    name: string;
    askingPrice?: string;
    currentValuation?: string;
  } | null;
  latestValuation: {
    id: string;
    snapshotDate: string;
    totalValue?: string;
    capRate?: string;
    noiEstimate?: string;
  } | null;
  vdrFolder: {
    id: string;
    name: string;
  } | null;
  recentActivities: Array<{
    id: string;
    type: string;
    subject?: string;
    createdAt: string;
  }>;
}

// Deal with relations type
type DealWithRelations = Deal & { 
  contact?: Contact | null; 
  company?: Company | null; 
};

function getStageColor(stage: string): string {
  const stageColors: Record<string, string> = {
    'lead': 'bg-gray-100 text-gray-800',
    'qualified': 'bg-blue-100 text-blue-800',
    'proposal': 'bg-yellow-100 text-yellow-800',
    'negotiation': 'bg-orange-100 text-orange-800',
    'closed_won': 'bg-green-100 text-green-800',
    'closed_lost': 'bg-red-100 text-red-800',
    'Under Contract': 'bg-purple-100 text-purple-800',
    'Closed': 'bg-green-100 text-green-800',
  };
  
  return stageColors[stage] || 'bg-gray-100 text-gray-800';
}

function getPriorityColor(priority: string): string {
  const priorityColors: Record<string, string> = {
    'low': 'bg-gray-100 text-gray-800',
    'medium': 'bg-yellow-100 text-yellow-800',
    'high': 'bg-orange-100 text-orange-800',
    'critical': 'bg-red-100 text-red-800',
  };
  
  return priorityColors[priority] || 'bg-gray-100 text-gray-800';
}

export default function DealDetail() {
  const params = useParams();
  const [, setLocation] = useLocation();
  const dealId = params.dealId;
  const [isConvertModalOpen, setIsConvertModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");
  const queryClient = useQueryClient();

  const { data: deal, isLoading, error } = useQuery<DealWithRelations>({
    queryKey: ['/api/deals', dealId],
    enabled: !!dealId,
  });

  const { data: workspaceData } = useQuery<WorkspaceData>({
    queryKey: ['/api/deals', dealId, 'workspace'],
    enabled: !!dealId,
  });

  const createOmMutation = useMutation({
    mutationFn: (data: { projectId: string; name: string; status: string; dealId: string }) =>
      apiRequest('/api/om/oms', { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: (newOm: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/om/oms'] });
      toast({ title: "OM Created", description: "Offering Memorandum created successfully." });
      setLocation(`/om/builder/${newOm.id}`);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create OM.", variant: "destructive" });
    }
  });

  const handleCreateOm = () => {
    if (!deal) return;
    createOmMutation.mutate({
      projectId: `deal-${dealId}`,
      name: `${deal.title} - Offering Memorandum`,
      status: 'draft',
      dealId: dealId!,
    });
  };

  const handleBack = () => {
    setLocation('/deals');
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={handleBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Deals
          </Button>
        </div>
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (error || !deal) {
    return (
      <div className="p-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={handleBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Deals
          </Button>
        </div>
        <div className="text-center py-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Deal Not Found</h2>
          <p className="text-gray-600">The deal you're looking for doesn't exist or you don't have permission to view it.</p>
        </div>
      </div>
    );
  }

  const dealValue = Number(deal.amount || deal.value) || 0;
  const commission = dealValue * 0.03; // 3% commission rate

  return (
    <div className="p-6 max-w-6xl mx-auto" data-testid="deal-detail-page">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={handleBack} data-testid="button-back">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Deals
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900" data-testid="text-deal-title">
              {deal.title}
            </h1>
            <p className="text-gray-600">Deal Details</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {deal.ddProjectId ? (
            <Button 
              variant="default" 
              size="sm" 
              onClick={() => setLocation(`/dd/projects/${deal.ddProjectId}`)}
              data-testid="button-view-dd-project"
            >
              <FolderOpen className="w-4 h-4 mr-2" />
              View DD Project
            </Button>
          ) : (
            <Button 
              variant="default" 
              size="sm" 
              onClick={() => setIsConvertModalOpen(true)}
              data-testid="button-convert-to-project"
            >
              <FolderOpen className="w-4 h-4 mr-2" />
              Convert to DD Project
            </Button>
          )}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleCreateOm}
            disabled={createOmMutation.isPending}
            data-testid="button-create-om"
          >
            <FileSpreadsheet className="w-4 h-4 mr-2" />
            {createOmMutation.isPending ? 'Creating...' : 'Create OM'}
          </Button>
          <Button variant="outline" size="sm" data-testid="button-edit">
            <Edit className="w-4 h-4 mr-2" />
            Edit Deal
          </Button>
          <Button variant="outline" size="sm" data-testid="button-delete">
            <Trash2 className="w-4 h-4 mr-2" />
            Delete
          </Button>
        </div>
      </div>

      <ConvertToProjectModal
        isOpen={isConvertModalOpen}
        onClose={() => setIsConvertModalOpen(false)}
        deal={deal}
      />

      {(workspaceData?.ddProject || workspaceData?.modelingProject) && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {workspaceData?.ddProject && (
            <Card className="border-l-4 border-l-blue-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <ListChecks className="w-5 h-5 text-blue-500" />
                    <span className="font-semibold">Due Diligence</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setLocation(`/dd/projects/${workspaceData.ddProject?.id}`)}
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-sm text-gray-600 mb-2">{workspaceData.ddProject.name}</p>
                {workspaceData?.ddTaskSummary && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Task Progress</span>
                      <span className="font-medium">{workspaceData.ddTaskSummary.completed}/{workspaceData.ddTaskSummary.total}</span>
                    </div>
                    <Progress value={workspaceData.ddTaskSummary.percentComplete} className="h-2" />
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {workspaceData?.modelingProject && (
            <Card className="border-l-4 border-l-green-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-5 h-5 text-green-500" />
                    <span className="font-semibold">Modeling</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setLocation(`/modeling/${workspaceData.modelingProject?.id}`)}
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-sm text-gray-600 mb-2">{workspaceData.modelingProject.name}</p>
                {workspaceData?.latestValuation && (
                  <div className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Latest Valuation</span>
                      <span className="font-medium text-green-600">
                        {workspaceData.latestValuation.totalValue 
                          ? formatCurrency(Number(workspaceData.latestValuation.totalValue))
                          : 'N/A'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400">
                      {new Date(workspaceData.latestValuation.snapshotDate).toLocaleDateString()}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {workspaceData?.vdrFolder && (
            <Card className="border-l-4 border-l-purple-500">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Files className="w-5 h-5 text-purple-500" />
                    <span className="font-semibold">Data Room</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setLocation(`/vdr/folders/${workspaceData.vdrFolder?.id}`)}
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-sm text-gray-600">{workspaceData.vdrFolder.name}</p>
              </CardContent>
            </Card>
          )}

          {workspaceData?.recentActivities && workspaceData.recentActivities.length > 0 && (
            <Card className="border-l-4 border-l-orange-500 md:col-span-3">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Activity className="w-5 h-5 text-orange-500" />
                  <span className="font-semibold">Recent Activity</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {workspaceData.recentActivities.slice(0, 5).map((activity) => (
                    <Badge key={activity.id} variant="secondary" className="text-xs">
                      {activity.type}: {activity.subject || 'Activity'} - {new Date(activity.createdAt).toLocaleDateString()}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Deal Information */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                Deal Overview
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Stage</label>
                  <div className="mt-1">
                    <Badge className={getStageColor(deal.stage)} data-testid="text-stage">
                      {deal.stage}
                    </Badge>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Priority</label>
                  <div className="mt-1">
                    <Badge className={getPriorityColor(deal.priority)} data-testid="text-priority">
                      {deal.priority}
                    </Badge>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Probability</label>
                  <p className="text-lg font-semibold text-gray-900" data-testid="text-probability">
                    {deal.probability}%
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-600">Days in Stage</label>
                  <p className="text-lg font-semibold text-gray-900" data-testid="text-days-in-stage">
                    {deal.daysInCurrentStage || 0} days
                  </p>
                </div>
              </div>
              
              {deal.description && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Description</label>
                  <p className="mt-1 text-gray-900" data-testid="text-description">
                    {deal.description}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Financial Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Financial Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600">Deal Value</p>
                  <p className="text-2xl font-bold text-blue-600" data-testid="text-deal-value">
                    {formatCurrency(dealValue)}
                  </p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-gray-600">Commission (3%)</p>
                  <p className="text-2xl font-bold text-green-600" data-testid="text-commission">
                    {formatCurrency(commission)}
                  </p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <p className="text-sm text-gray-600">Forecast Category</p>
                  <p className="text-lg font-semibold text-purple-600" data-testid="text-forecast-category">
                    {deal.forecastCategory || 'Not Set'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Comp Set Selector */}
          <CompSetSelector dealId={dealId!} />

          {/* Property Details - Show if any property details exist */}
          {deal.propertyDetails && Object.keys(deal.propertyDetails as any).length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Anchor className="w-5 h-5" />
                  Marina Property Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {(() => {
                  const pd = deal.propertyDetails as any;
                  const hasCapacity = pd.slipsTotal || pd.linearFeet || pd.maxBoatLength || pd.highDryCapacity || pd.winterStorageCapacity || pd.occupancyRate;
                  const hasProperty = pd.acreage || pd.ownershipType || pd.expansionApproved || pd.buildingSize;
                  const hasFacilities = pd.fuelCapacity || pd.equipment || pd.amenities || pd.servicesOffered;
                  const hasLocation = pd.locationDetails || pd.marketPosition;
                  const hasFinancials = pd.grossRevenue || pd.noi || pd.revenueBreakdown;

                  return (
                    <>
                      {hasCapacity && (
                        <div>
                          <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                            <Anchor className="w-4 h-4" />
                            Physical Capacity
                          </h4>
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            {pd.slipsTotal && (
                              <div>
                                <span className="text-gray-600">Total Wet Slips:</span>
                                <span className="ml-2 font-medium">{pd.slipsTotal}</span>
                              </div>
                            )}
                            {pd.linearFeet && (
                              <div>
                                <span className="text-gray-600">Linear Feet:</span>
                                <span className="ml-2 font-medium">{pd.linearFeet} ft</span>
                              </div>
                            )}
                            {pd.maxBoatLength && (
                              <div>
                                <span className="text-gray-600">Max Boat Length:</span>
                                <span className="ml-2 font-medium">{pd.maxBoatLength} ft</span>
                              </div>
                            )}
                            {pd.highDryCapacity && (
                              <div>
                                <span className="text-gray-600">High & Dry:</span>
                                <span className="ml-2 font-medium">{pd.highDryCapacity} spots</span>
                              </div>
                            )}
                            {pd.winterStorageCapacity && (
                              <div>
                                <span className="text-gray-600">Winter Storage:</span>
                                <span className="ml-2 font-medium">{pd.winterStorageCapacity} spots</span>
                              </div>
                            )}
                            {pd.occupancyRate && (
                              <div>
                                <span className="text-gray-600">Occupancy Rate:</span>
                                <span className="ml-2 font-medium">{pd.occupancyRate}%</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {hasProperty && (
                        <div className="pt-4 border-t">
                          <h4 className="font-semibold text-sm mb-3">Property Details</h4>
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            {pd.acreage && (
                              <div>
                                <span className="text-gray-600">Total Acreage:</span>
                                <span className="ml-2 font-medium">{pd.acreage} acres</span>
                              </div>
                            )}
                            {pd.ownershipType && (
                              <div>
                                <span className="text-gray-600">Ownership:</span>
                                <span className="ml-2 font-medium capitalize">{pd.ownershipType.replace('_', ' ')}</span>
                              </div>
                            )}
                            {pd.expansionApproved && (
                              <div>
                                <span className="text-gray-600">Approved Expansion:</span>
                                <span className="ml-2 font-medium">{pd.expansionApproved} slips</span>
                              </div>
                            )}
                            {pd.buildingSize && (
                              <div>
                                <span className="text-gray-600">Building Size:</span>
                                <span className="ml-2 font-medium">{pd.buildingSize} sq ft</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {hasFacilities && (
                        <div className="pt-4 border-t">
                          <h4 className="font-semibold text-sm mb-3">Facilities & Equipment</h4>
                          <div className="space-y-2 text-sm">
                            {pd.fuelCapacity && (
                              <div>
                                <span className="text-gray-600">Fuel Storage:</span>
                                <span className="ml-2 font-medium">{pd.fuelCapacity} gallons</span>
                              </div>
                            )}
                            {pd.equipment && (
                              <div>
                                <span className="text-gray-600 block mb-1">Major Equipment:</span>
                                <p className="text-gray-900 whitespace-pre-wrap">{pd.equipment}</p>
                              </div>
                            )}
                            {pd.amenities && (
                              <div>
                                <span className="text-gray-600 block mb-1">Amenities:</span>
                                <p className="text-gray-900 whitespace-pre-wrap">{pd.amenities}</p>
                              </div>
                            )}
                            {pd.servicesOffered && (
                              <div>
                                <span className="text-gray-600 block mb-1">Services Offered:</span>
                                <p className="text-gray-900 whitespace-pre-wrap">{pd.servicesOffered}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {pd.recentImprovements && (
                        <div className="pt-4 border-t">
                          <h4 className="font-semibold text-sm mb-3">Recent Improvements</h4>
                          <p className="text-sm text-gray-900 whitespace-pre-wrap">{pd.recentImprovements}</p>
                        </div>
                      )}

                      {hasLocation && (
                        <div className="pt-4 border-t">
                          <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            Location & Market
                          </h4>
                          <div className="space-y-2 text-sm">
                            {pd.locationDetails && (
                              <div>
                                <span className="text-gray-600 block mb-1">Location Details:</span>
                                <p className="text-gray-900 whitespace-pre-wrap">{pd.locationDetails}</p>
                              </div>
                            )}
                            {pd.marketPosition && (
                              <div>
                                <span className="text-gray-600 block mb-1">Market Position:</span>
                                <p className="text-gray-900 whitespace-pre-wrap">{pd.marketPosition}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {hasFinancials && (
                        <div className="pt-4 border-t">
                          <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                            <DollarSign className="w-4 h-4" />
                            Financial Performance
                          </h4>
                          <div className="space-y-2 text-sm">
                            {pd.grossRevenue && (
                              <div>
                                <span className="text-gray-600">Gross Revenue:</span>
                                <span className="ml-2 font-medium">{formatCurrency(pd.grossRevenue)}</span>
                              </div>
                            )}
                            {pd.noi && (
                              <div>
                                <span className="text-gray-600">NOI:</span>
                                <span className="ml-2 font-medium">{formatCurrency(pd.noi)}</span>
                              </div>
                            )}
                            {pd.revenueBreakdown && (
                              <div>
                                <span className="text-gray-600 block mb-1">Revenue Breakdown:</span>
                                <p className="text-gray-900 whitespace-pre-wrap">{pd.revenueBreakdown}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {pd.additionalNotes && (
                        <div className="pt-4 border-t">
                          <h4 className="font-semibold text-sm mb-3">Additional Notes</h4>
                          <p className="text-sm text-gray-900 whitespace-pre-wrap">{pd.additionalNotes}</p>
                        </div>
                      )}
                    </>
                  );
                })()}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar Information */}
        <div className="space-y-6">
          {/* Contact Information */}
          {deal.contact && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Primary Contact
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="font-semibold text-gray-900" data-testid="text-contact-name">
                    {deal.contact.firstName} {deal.contact.lastName}
                  </p>
                  {deal.contact.email && (
                    <p className="text-sm text-gray-600" data-testid="text-contact-email">
                      {deal.contact.email}
                    </p>
                  )}
                  {deal.contact.phone && (
                    <p className="text-sm text-gray-600" data-testid="text-contact-phone">
                      {deal.contact.phone}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Company Information */}
          {deal.company && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="w-5 h-5" />
                  Company
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="font-semibold text-gray-900" data-testid="text-company-name">
                    {deal.company.name}
                  </p>
                  {deal.company.industry && (
                    <p className="text-sm text-gray-600" data-testid="text-company-industry">
                      {deal.company.industry}
                    </p>
                  )}
                  {deal.company.website && (
                    <p className="text-sm text-gray-600" data-testid="text-company-website">
                      {deal.company.website}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Timeline Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Timeline
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Expected Close Date</label>
                <p className="text-sm text-gray-900" data-testid="text-close-date">
                  {deal.expectedCloseDate 
                    ? new Date(deal.expectedCloseDate).toLocaleDateString()
                    : 'Not set'
                  }
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Created</label>
                <p className="text-sm text-gray-900" data-testid="text-created-date">
                  {new Date(deal.createdAt).toLocaleDateString()}
                </p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Last Updated</label>
                <p className="text-sm text-gray-900" data-testid="text-updated-date">
                  {new Date(deal.updatedAt).toLocaleDateString()}
                </p>
              </div>
              {deal.lastActivityDate && (
                <div>
                  <label className="text-sm font-medium text-gray-600">Last Activity</label>
                  <p className="text-sm text-gray-900" data-testid="text-last-activity">
                    {new Date(deal.lastActivityDate).toLocaleDateString()}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}