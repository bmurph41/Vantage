export const omTemplates = pgTable("om_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  ownerType: omTemplateOwnerTypeEnum("owner_type").notNull(),
  ownerId: varchar("owner_id"),
  name: text("name").notNull(),
  scope: omTemplateScopeEnum("scope").notNull(),
  category: text("category"),
  templateData: jsonb("template_data").notNull(),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  ownerIdx: index("om_templates_owner_idx").on(table.ownerType, table.ownerId),
  scopeIdx: index("om_templates_scope_idx").on(table.scope),
}));

export const omDatasets = pgTable("om_datasets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  projectId: varchar("project_id").notNull(),
  organizationId: varchar("organization_id"),
  name: text("name").notNull(),
  type: omDatasetTypeEnum("type").notNull(),
  sourceFileName: text("source_file_name"),
  data: jsonb("data").notNull(),
  sheetNames: text("sheet_names").array(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  projectIdx: index("om_datasets_project_idx").on(table.projectId),
  orgIdx: index("om_datasets_org_idx").on(table.organizationId),
}));

// ============================================================================
// OM Builder - Brand Kits
// ============================================================================
export const omBrandKits = pgTable("om_brand_kits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  organizationId: varchar("organization_id"),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  tokens: jsonb("tokens").notNull().default({}),
  primaryColors: jsonb("primary_colors").$type<string[]>().default([]),
  secondaryColors: jsonb("secondary_colors").$type<string[]>().default([]),
  accentColors: jsonb("accent_colors").$type<string[]>().default([]),
  fontFamilies: jsonb("font_families").$type<{ heading: string; body: string; alt?: string }>(),
  logoAssetId: varchar("logo_asset_id"),
  markAssetId: varchar("mark_asset_id"),
  guidelines: text("guidelines"),
  autoImportedFromUrl: varchar("auto_imported_from_url"),
  sourceScanData: jsonb("source_scan_data"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("om_brand_kits_org_idx").on(table.organizationId),
  userIdx: index("om_brand_kits_user_idx").on(table.userId),
}));

// ============================================================================
// OM Builder - Document Versions
// ============================================================================
export const omDocumentVersions = pgTable("om_document_versions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  omId: varchar("om_id").notNull().references(() => oms.id, { onDelete: 'cascade' }),
  versionNumber: integer("version_number").notNull(),
  snapshotJson: jsonb("snapshot_json").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  changeSummary: text("change_summary"),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  omIdx: index("om_document_versions_om_idx").on(table.omId),
  versionIdx: index("om_document_versions_version_idx").on(table.omId, table.versionNumber),
}));

// ============================================================================
// OM Builder - Generated Documents (Deal-specific OM documents)
// ============================================================================
export const omDocumentStatusEnum = pgEnum("om_document_status", ["draft", "generating", "completed", "failed"]);

export const omDocuments = pgTable("om_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  dealId: varchar("deal_id").notNull().references(() => crmDeals.id, { onDelete: 'cascade' }),
  templateId: varchar("template_id").references(() => omTemplates.id, { onDelete: 'set null' }),
  title: text("title").notNull(),
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
  pdfUrl: text("pdf_url"),
  status: omDocumentStatusEnum("status").notNull().default('draft'),
  metadata: jsonb("metadata").$type<{
    propertyOverview?: Record<string, any>;
    financialSummary?: Record<string, any>;
    rentRoll?: Record<string, any>;
    operations?: Record<string, any>;
    generationOptions?: Record<string, any>;
  }>().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  dealIdx: index("om_documents_deal_idx").on(table.dealId),
  templateIdx: index("om_documents_template_idx").on(table.templateId),
  statusIdx: index("om_documents_status_idx").on(table.status),
}));

export const insertOmDocumentSchema = createInsertSchema(omDocuments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmDocumentSchema = insertOmDocumentSchema.partial();
export type InsertOmDocument = z.infer<typeof insertOmDocumentSchema>;
export type OmDocument = typeof omDocuments.$inferSelect;

// ============================================================================
// OM Builder - Assets
// ============================================================================
export const omAssets = pgTable("om_assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  userId: varchar("user_id").notNull(),
  organizationId: varchar("organization_id"),
  fileUrl: text("file_url").notNull(),
  mimeType: text("mime_type").notNull(),
  fileName: text("file_name").notNull(),
  sha256: text("sha256"),
  folder: varchar("folder", { length: 100 }),
  width: integer("width"),
  height: integer("height"),
  byteSize: integer("byte_size"),
  tags: jsonb("tags"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdx: index("om_assets_user_idx").on(table.userId),
  orgIdx: index("om_assets_org_idx").on(table.organizationId),
  sha256Idx: index("om_assets_sha256_idx").on(table.sha256),
  folderIdx: index("om_assets_folder_idx").on(table.folder),
}));

export const omPageThumbnails = pgTable("om_page_thumbnails", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  documentVersionId: varchar("document_version_id").notNull().references(() => omDocumentVersions.id, { onDelete: 'cascade' }),
  pageIndex: integer("page_index").notNull(),
  imageUrl: text("image_url").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  versionIdx: index("om_page_thumbnails_version_idx").on(table.documentVersionId),
}));

// ============================================================================
// OM Builder - Themes (Institutional-grade theme system)
// ============================================================================
export const omThemes = pgTable("om_themes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  name: text("name").notNull(),
  description: text("description"),
  organizationId: varchar("organization_id"),
  userId: varchar("user_id"),
  isDefault: boolean("is_default").notNull().default(false),
  isSystemDefault: boolean("is_system_default").notNull().default(false),
  baseThemeKey: varchar("base_theme_key", { length: 50 }),
  colors: jsonb("colors").$type<{
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textMuted: string;
    headerBackground: string;
    footerBackground: string;
    metricTileBackground: string;
    chartSeries: string[];
    mapOverlay: string;
  }>().notNull(),
  typography: jsonb("typography").$type<{
    fontFamilyDisplay: string;
    fontFamilyHeading: string;
    fontFamilyBody: string;
    fontSizes: {
      title: string;
      section: string;
      h1: string;
      h2: string;
      h3: string;
      body: string;
      disclaimer: string;
      metricValue: string;
      metricLabel: string;
    };
    fontWeights: {
      title: number;
      heading: number;
      body: number;
      bold: number;
    };
  }>().notNull(),
  branding: jsonb("branding").$type<{
    logoUrl?: string;
    watermarkUrl?: string;
    footerTextTemplate?: string;
    coverOverlayStyle?: 'solid' | 'gradient' | 'none';
    headerStyle?: 'minimal' | 'branded' | 'none';
  }>(),
  spacing: jsonb("spacing").$type<{
    defaultSpacingScale: number;
    defaultBorderRadius: string;
    cardShadow: 'none' | 'sm' | 'md' | 'lg';
    pageMargins: { top: number; right: number; bottom: number; left: number };
  }>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("om_themes_org_idx").on(table.organizationId),
  userIdx: index("om_themes_user_idx").on(table.userId),
  defaultIdx: index("om_themes_default_idx").on(table.isDefault),
}));

// ============================================================================
// OM Builder - Page Layouts (Reusable page layout templates)
// ============================================================================
export const omLayoutTypeEnum = pgEnum("om_layout_type", [
  'cover',
  'sectionDivider', 
  'execSummary',
  'financials',
  'market',
  'photos',
  'portfolio',
  'team',
  'disclaimer',
  'custom'
]);

export const omPageLayouts = pgTable("om_page_layouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  name: text("name").notNull(),
  description: text("description"),
  layoutType: omLayoutTypeEnum("layout_type").notNull(),
  themeId: varchar("theme_id").references(() => omThemes.id, { onDelete: 'set null' }),
  organizationId: varchar("organization_id"),
  userId: varchar("user_id"),
  isSystemDefault: boolean("is_system_default").notNull().default(false),
  thumbnail: text("thumbnail"),
  structure: jsonb("structure").$type<{
    gridColumns: number;
    gridRows?: number;
    gridGap: string;
    backgroundColor?: string;
    backgroundImageUrl?: string;
    placeholders: Array<{
      id: string;
      blockType: string;
      x: number;
      y: number;
      width: number;
      height: number;
      label?: string;
      styleHints?: Record<string, any>;
    }>;
  }>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  typeIdx: index("om_page_layouts_type_idx").on(table.layoutType),
  orgIdx: index("om_page_layouts_org_idx").on(table.organizationId),
  themeIdx: index("om_page_layouts_theme_idx").on(table.themeId),
}));

export const insertOmSchema = createInsertSchema(oms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmSchema = insertOmSchema.partial();
export type Om = typeof oms.$inferSelect;
export type InsertOm = z.infer<typeof insertOmSchema>;

export const insertOmPageSchema = createInsertSchema(omPages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmPageSchema = insertOmPageSchema.partial();
export type OmPage = typeof omPages.$inferSelect;
export type InsertOmPage = z.infer<typeof insertOmPageSchema>;

export const insertOmBlockSchema = createInsertSchema(omBlocks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmBlockSchema = insertOmBlockSchema.partial();
export type OmBlock = typeof omBlocks.$inferSelect;
export type InsertOmBlock = z.infer<typeof insertOmBlockSchema>;

export const insertOmTemplateSchema = createInsertSchema(omTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmTemplateSchema = insertOmTemplateSchema.partial();
export type OmTemplate = typeof omTemplates.$inferSelect;
export type InsertOmTemplate = z.infer<typeof insertOmTemplateSchema>;

export const insertOmDatasetSchema = createInsertSchema(omDatasets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmDatasetSchema = insertOmDatasetSchema.partial();
export type OmDataset = typeof omDatasets.$inferSelect;
export type InsertOmDataset = z.infer<typeof insertOmDatasetSchema>;

export const insertOmBrandKitSchema = createInsertSchema(omBrandKits).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
