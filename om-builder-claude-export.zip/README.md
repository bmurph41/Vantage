# OM Builder - MarinaMatch Offering Memorandum Builder

## Overview
The OM Builder is a professional offering memorandum creation tool with data binding, template management, and PDF export capabilities. It allows users to create beautiful OMs for marina acquisition deals.

## File Structure

### Frontend Components (`client/src/`)

**Pages:**
- `pages/om-builder-editor.tsx` - Main editor page with full canvas interface
- `pages/om-builder/OMBuilder.tsx` - OM Builder entry component
- `modules/om-builder/pages/om-builder.tsx` - Module-based OM builder page
- `modules/om-builder/hooks/useAutosave.ts` - Autosave hook for documents
- `modules/om-builder/index.ts` - Module exports

**Components (`components/om-builder/`):**
- `OmCanvas.tsx` - Main canvas for visual editing
- `OmEditorToolbar.tsx` - Editor toolbar with actions
- `OmDataBindingsPanel.tsx` - Data binding configuration panel
- `OmAssetLibraryPanel.tsx` - Asset library for images/media
- `OmBrandKitPanel.tsx` - Brand kit management (colors, fonts, logos)
- `OmInspectorPanel.tsx` - Element inspector/properties panel
- `OmLayersPanel.tsx` - Layer management panel
- `OmPagesPanel.tsx` - Multi-page document management
- `index.ts` - Component exports

**API Client:**
- `lib/om-builder-api.ts` - API client for OM Builder endpoints

### Backend (`server/`)

**Routes:**
- `routes/om-builder-routes.ts` - REST API endpoints for OM Builder

**Services:**
- `services/om-builder-service.ts` - Business logic and data management
- `services/pdf-generator-service.ts` - PDF export functionality
- `om/ai-service.ts` - AI integration for content generation

### Schema (`shared/`)
- `om-schema-excerpt.ts` - Database table definitions for OM Builder

## Key Features
1. **Visual Editor** - Drag-and-drop canvas for creating OMs
2. **Data Bindings** - Connect dynamic data from deals, properties, financials
3. **Templates** - Save and reuse OM templates
4. **Asset Library** - Manage images, logos, and media
5. **Brand Kit** - Consistent branding across documents
6. **PDF Export** - Generate professional PDF output
7. **AI Integration** - AI-powered content suggestions

## API Endpoints
- `GET /api/om-builder/templates` - List templates
- `POST /api/om-builder/templates` - Create template
- `GET /api/om-builder/projects` - List OM projects
- `POST /api/om-builder/projects` - Create project
- `GET /api/om-builder/projects/:id` - Get project details
- `PUT /api/om-builder/projects/:id` - Update project
- `POST /api/om-builder/projects/:id/export-pdf` - Export to PDF
