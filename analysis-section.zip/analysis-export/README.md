# MarinaMatch — Analysis Section Source Files

## Structure

### Frontend Pages (`client_pages_analysis/`)
All page components for the Analysis section:
- `AnalysisHub.tsx` — Hub landing page
- `sales-comps/` — Sales Comparables module
- `rate-comps/` — Rate Comparables module
- `analytics/` — Unified analytics dashboard
- `benchmarks/` — Benchmarking tools
- `capital-markets/` — Capital markets data
- `demographics/` — Demographics & market intelligence
- `docket/` — Industry intelligence feed
- `financial-analysis/` — Financial analysis tools
- `marina-comps/` — Marina comps comparison
- `projects/` — SC Projects module
- `valuation-timeline/` — Valuation timeline
- `IndustryStandards.tsx` — Industry standards reference

### Frontend Components
- `client_components_salescomps/` — All Sales Comps UI components
- `client_components_ratecomps/` — All Rate Comps UI components
- `client_pages_analytics/` — Unified analytics page
- `comp-set-selector.tsx` — Shared comp set picker
- `analytics.tsx` — Analytics routing page

### Server Routes (`server_routes/`)
- `analytics-routes.ts` — Analytics API routes
- `deal-analytics-routes.ts` — Deal analytics API
- `legal-benchmarking-routes.ts` — Benchmarking API
- `pipeline-analytics-routes.ts` — Pipeline analytics
- `valuation-timeline-routes.ts` — Valuation timeline API
- `marina-comp-routes.ts` — Marina comp comparison API
- `routes_ts_analysis_excerpt.ts` — Sales comps & rate comps API handlers extracted from main routes.ts

### Server Services (`server_services/`)
- `analytics/` — Analytics computation services
- `salescomps/analyticsService.ts` — Sales comps analytics engine
- `ratecomps/analyticsService.ts` — Rate comps analytics engine
- `capital-markets/` — Capital markets data services
- `benchmark-comparison-service.ts` — Benchmark comparison logic
- `benchmarking-guardrails.ts` — Data privacy guardrails
- `customer-analytics-service.ts` — Customer analytics
- `demographics-service.ts` — Census/FRED data integration
- `valuation-timeline-service.ts` — Valuation timeline engine
