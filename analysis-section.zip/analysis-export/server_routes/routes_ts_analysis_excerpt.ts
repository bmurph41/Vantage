  app.get("/api/analysis/hub-stats", authenticateUser, enforceTenant, async (req: any, res) => {
    try {
      const orgId = req.user?.organizationId || '';
      const [salesResult, rateResult, dealsResult] = await Promise.all([
        db.execute(sql`SELECT COUNT(*)::int as count FROM sales_comps WHERE org_id = ${orgId}`),
        db.execute(sql`SELECT COUNT(*)::int as count FROM rate_comps WHERE org_id = ${orgId}`),
        db.execute(sql`SELECT COUNT(*)::int as count FROM docket_deals`),
      ]);


// Sales Comps API Routes (from server/routes.ts)
  app.get('/api/sales-comps', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const includeGlobal = req.query.includeGlobal === 'true';
      const scopeFilter = req.query.scope as string | undefined; // 'all' | 'org' | 'global'

      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.set('Pragma', 'no-cache');
      res.set('Expires', '0');

      const filters = compFiltersSchema.parse(req.query);
      const sqlFilters = filterBuilder.buildFilters(filters);
      
      // Fetch org-specific comps (unless filtering to global only)
      let comps: any[] = [];
      let total = 0;
      
      if (scopeFilter !== 'global') {
        const orgResult = await storage.getComps({
          orgId,
          filters: sqlFilters,
          sortBy: filters.sortBy,
          sortDir: filters.sortDir,
          page: filters.page,
          pageSize: filters.pageSize,
        });
        comps = orgResult.comps.map((c: any) => ({ ...c, _source: 'org' }));
        total = orgResult.total;
      }
      
      // Include global curated comps if requested (users with Analysis pack)
      if (includeGlobal || scopeFilter === 'all' || scopeFilter === 'global') {
        try {
          const globalComps = await db
            .select()
            .from(salesComps)
            .where(eq(salesComps.scope, "global"))
            .limit(filters.pageSize || 50);
          
          // Add source tag and merge
          const taggedGlobal = globalComps.map((c: any) => ({ ...c, _source: 'global' }));
          
          if (scopeFilter === 'global') {
            comps = taggedGlobal;
            total = taggedGlobal.length;
          } else {
            comps = [...comps, ...taggedGlobal];
            total += taggedGlobal.length;
          }
        } catch (globalErr) {
          console.warn("Could not fetch global comps:", globalErr);
        }
      }

      res.json({ comps, total, page: filters.page, pageSize: filters.pageSize });
    } catch (error: any) {
      console.error("Error fetching comps:", error);
      res.status(500).json({ message: "Failed to fetch comps" });
    }
  });
  app.get('/api/sales-comps/ids', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const ids = await storage.getAllCompIds(orgId);
      res.json({ ids });
    } catch (error: any) {
      console.error('Error getting comp IDs:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/sales-comps/column-values/:column', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { column } = req.params;
      const values = await storage.getColumnUniqueValues(orgId, column);
      res.json({ values });
    } catch (error: any) {
      console.error('Error getting column values:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Custom Storage Types routes (must be before /:id route)
  app.get('/api/sales-comps/custom-storage-types', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const types = await storage.getScCustomStorageTypes(orgId);
      res.json(types);
    } catch (error: any) {
      console.error("Error fetching custom storage types:", error);
      res.status(500).json({ message: "Failed to fetch custom storage types" });
    }
  });

  app.post('/api/sales-comps/custom-storage-types', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { name } = req.body;

      if (!name || typeof name !== 'string' || name.trim() === '') {
        return res.status(400).json({ message: "Storage type name is required" });
      }

      // Check for duplicates (case-insensitive)
      const existing = await storage.getScCustomStorageTypes(orgId);
      if (existing.some(t => t.name.toLowerCase() === name.trim().toLowerCase())) {
        return res.status(400).json({ message: "Storage type already exists" });
      }

      const type = await storage.createScCustomStorageType({
        orgId,
        name: name.trim(),
        createdBy: userId,
      });

      res.status(201).json(type);
    } catch (error: any) {
      console.error("Error creating custom storage type:", error);
      res.status(500).json({ message: "Failed to create custom storage type" });
    }
  });

  app.delete('/api/sales-comps/custom-storage-types/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const success = await storage.deleteScCustomStorageType(req.params.id, orgId);

      if (!success) return res.status(404).json({ message: "Storage type not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting custom storage type:", error);
      res.status(500).json({ message: "Failed to delete custom storage type" });
    }
  });

  // Custom Column Management routes (must be before /:id route)
  app.get('/api/sales-comps/columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const columns = await storage.getCompColumns(orgId);
      res.json(columns);
    } catch (error: any) {
      console.error("Error fetching custom columns:", error);
      res.status(500).json({ message: "Failed to fetch custom columns" });
    }
  });

  app.post('/api/sales-comps/columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { key, label, type, options, required, visible, orderIndex } = req.body;

      if (!key || !label || !type) {
        return res.status(400).json({ message: "Field key, label, and type are required" });
      }

      // Check for duplicate key
      const existing = await storage.getCompColumns(orgId);
      if (existing.some(c => c.key === key)) {
        return res.status(400).json({ message: "Column with this key already exists" });
      }

      const column = await storage.createCompColumn({
        orgId,
        key,
        label,
        type,
        options: options || null,
        required: required || false,
        visible: visible !== false,
        orderIndex: orderIndex || 0,
      });

      res.status(201).json(column);
    } catch (error: any) {
      console.error("Error creating custom column:", error);
      res.status(500).json({ message: "Failed to create custom column" });
    }
  });

  app.delete('/api/sales-comps/columns/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const success = await storage.deleteCompColumn(req.params.id, orgId);

      if (!success) return res.status(404).json({ message: "Column not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting custom column:", error);
      res.status(500).json({ message: "Failed to delete custom column" });
    }
  });

  // Pending Property Profiles routes (must be before /:id route)
  app.get('/api/sales-comps/pending-property-profiles', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const status = req.query.status as string | undefined;
      const profiles = await storage.getPendingPropertyProfiles(orgId, status);
      res.json(profiles);
    } catch (error: any) {
      console.error("Error fetching pending property profiles:", error);
      res.status(500).json({ message: "Failed to fetch pending property profiles" });
    }
  });

  app.post('/api/sales-comps/pending-property-profiles', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { compId, status } = req.body;

      if (!compId) {
        return res.status(400).json({ message: "compId is required" });
      }

      const profile = await storage.createPendingPropertyProfile({
        compId,
        orgId,
        status: status || 'pending',
      });

      res.status(201).json(profile);
    } catch (error: any) {
      console.error("Error creating pending property profile:", error);
      res.status(500).json({ message: "Failed to create pending property profile" });
    }
  });

  app.patch('/api/sales-comps/pending-property-profiles/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { status } = req.body;
      
      // Verify ownership before updating
      const existing = await storage.getPendingPropertyProfiles(orgId);
      const profile = existing.find(p => p.id === req.params.id);
      if (!profile) {
        return res.status(404).json({ message: "Pending property profile not found" });
      }
      
      const updated = await storage.updatePendingPropertyProfile(req.params.id, { status });
      res.json(updated);
    } catch (error: any) {
      console.error("Error updating pending property profile:", error);
      res.status(500).json({ message: "Failed to update pending property profile" });
    }
  });

  app.delete('/api/sales-comps/pending-property-profiles/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      // Verify ownership before deleting
      const existing = await storage.getPendingPropertyProfiles(orgId);
      const profile = existing.find(p => p.id === req.params.id);
      if (!profile) {
        return res.status(404).json({ message: "Pending property profile not found" });
      }
      
      const success = await storage.deletePendingPropertyProfile(req.params.id);
      if (!success) return res.status(404).json({ message: "Pending property profile not found" });
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting pending property profile:", error);
      res.status(500).json({ message: "Failed to delete pending property profile" });
    }
  });

  app.get('/api/sales-comps/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const comp = await storage.getComp(req.params.id, orgId);
      if (!comp) return res.status(404).json({ message: "Comp not found" });
      res.json(comp);
    } catch (error: any) {
      console.error("Error fetching comp:", error);
      res.status(500).json({ message: "Failed to fetch comp" });
    }
  });

  app.post('/api/sales-comps/backfill-properties', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      
      
      const result = await storage.getComps({ orgId, pageSize: 10000 });
      const comps = result.comps;
      const compsWithoutProperty = comps.filter(comp => !comp.propertyId && comp.marina);
      
      
      let created = 0;
      let matched = 0;
      let failed = 0;
      
      for (const comp of compsWithoutProperty) {
        try {
          let propertyId = null;
          
          const matchedProperty = await storage.findPropertyByLocation(
            orgId,
            comp.marina!,
            comp.city || undefined,
            comp.state || undefined
          );
          
          if (matchedProperty) {
            propertyId = matchedProperty.id;
            matched++;
          } else {
            const address = [
              comp.address,
              comp.city && comp.state ? `${comp.city}, ${comp.state}` : comp.city || comp.state
            ].filter(Boolean).join(', ');
            
            const newProperty = await storage.createCrmProperty({
              title: comp.marina!,
              type: 'marina',
              status: 'available',
              address: address || undefined,
              ownerId: orgId,
              listingPrice: comp.salePrice ? String(comp.salePrice) : undefined,
              description: `Auto-created from sales comp backfill`,
            });
            
            propertyId = newProperty.id;
            created++;
          }
          
          if (propertyId) {
            await storage.updateComp(comp.id, { propertyId }, orgId);
          }
        } catch (error: any) {
          failed++;
          console.error(`❌ Failed to process comp ${comp.id}:`, error);
        }
      }
      
      const summary = {
        total: compsWithoutProperty.length,
        propertiesCreated: created,
        propertiesMatched: matched,
        failed,
      };
      
      
      res.json(summary);
    } catch (error: any) {
      console.error("Error during property backfill:", error);
      res.status(500).json({ message: "Failed to backfill properties" });
    }
  });

  app.post('/api/sales-comps', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const compData = salesCompCreateSchema.parse(req.body);

      // Map user-friendly field names to database column names
      const mappedData = {
        ...compData,
        // Map sellerCompany -> seller (Seller Company in the form)
        seller: compData.sellerCompany || compData.seller,
        // Map sellerPrincipal -> owner (Seller Principal in the form)
        owner: compData.sellerPrincipal || compData.owner,
        // Map buyerCompany -> company (Buyer Company in the form)
        company: compData.buyerCompany || compData.company,
        orgId: req.user.orgId,
        // Map buyerPrincipal -> buyer (Buyer Principal in the form)
        buyer: compData.buyerPrincipal || compData.buyer,
      };

      const comp = await compService.createComp({
        ...mappedData,
        orgId,
        createdBy: userId,
      }, userId);

      // Auto-create pending company if buyerCompany was provided
      if (compData.buyerCompany) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: comp.id,
            orgId,
            userId,
            companyName: compData.buyerCompany,
            role: 'buyer',
            city: compData.city,
            state: compData.state,
          });
        } catch (companyError) {
          console.error('Error auto-creating pending buyer company:', companyError);
        }
      }

      // Auto-create pending company if sellerCompany was provided
      if (compData.sellerCompany) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: comp.id,
            orgId,
            userId,
            companyName: compData.sellerCompany,
            role: 'seller',
            city: compData.city,
            state: compData.state,
          });
        } catch (companyError) {
          console.error('Error auto-creating pending seller company:', companyError);
        }
      }

      // Auto-create pending company for brokerage if brokerage name was provided but no brokerageCompanyId linked
      if (compData.brokerage && !compData.brokerageCompanyId) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: comp.id,
            orgId,
            userId,
            companyName: compData.brokerage,
            role: 'brokerage',
            city: compData.city,
            state: compData.state,
          });
        } catch (companyError) {
          console.error('Error auto-creating pending brokerage company:', companyError);
        }
      }

      // Auto-create pending contact if agent info was provided
      if (compData.agentFirstName || compData.agentLastName) {
        try {
          await storage.autoCreatePendingContactFromSalesComp({
            salesCompId: comp.id,
            orgId,
            userId,
            agentFirstName: compData.agentFirstName,
            agentLastName: compData.agentLastName,
            brokerage: compData.brokerage,
          });
        } catch (contactError) {
          console.error('Error auto-creating pending contact:', contactError);
        }
      }

      // Auto-create pending contacts for Seller Principal and Buyer Principal
      const principalEntries = [
        { name: (compData.sellerPrincipal || '').trim(), role: 'seller_principal' },
        { name: (compData.buyerPrincipal || '').trim(), role: 'buyer_principal' },
      ];
      for (const entry of principalEntries) {
        if (entry.name) {
          try {
            const parts = entry.name.split(' ');
            const firstName = parts[0] || '';
            const lastName = parts.slice(1).join(' ') || '';
            const fullName = entry.name;

            const similarContacts = await storage.findSimilarContacts(orgId, fullName);

            await storage.createPendingContact({
              orgId,
              sourceType: 'sales_comp',
              sourceId: comp.id,
              firstName: firstName || undefined,
              lastName: lastName || undefined,
              fullName,
              status: 'pending',
              suggestedDuplicates: similarContacts.map((c: any) => c.id),
              sourceMetadata: { salesCompId: comp.id, marina: compData.marina, role: entry.role },
              createdBy: userId,
            });
          } catch (principalError) {
            console.error('Error auto-creating pending ' + entry.role + ' contact:', principalError);
          }
        }
      }

      // Auto-create pending property if marina/property data is provided but not linked to existing property
      if (!compData.propertyId && compData.marina) {
        try {
          // Check if a pending property already exists for this sales comp
          const existingPending = await storage.getPendingProperties(orgId, 'pending');
          const alreadyExists = existingPending.some((p: any) => 
            p.sourceType === 'sales_comp' && p.compId === comp.id
          );
          
          if (!alreadyExists) {
            // Find similar properties to suggest as duplicates
            const similarProperties = await storage.findSimilarProperties(
              orgId, 
              compData.marina, 
              compData.city, 
              compData.state
            );
            
            await storage.createPendingProperty({
              orgId,
              sourceType: 'sales_comp',
              compId: comp.id,
              marinaName: compData.marina,
              city: compData.city || null,
              state: compData.state || null,
              address: compData.address || null,
              salePrice: compData.salePrice ? Number(compData.salePrice) : null,
              status: 'pending',
              suggestedDuplicates: similarProperties.map((p: any) => p.id),
              compMetadata: {
                wetSlips: compData.wetSlips,
                drySlips: compData.drySlips,
                buyer: compData.buyerCompany,
                seller: compData.sellerCompany,
                saleDate: compData.saleDate,
              },
              createdBy: userId,
            });
            console.log('[SalesComps] Created pending property for "' + compData.marina + '"');
          }
        } catch (propertyError) {
          console.error('Error auto-creating pending property:', propertyError);
        }
      }

      // Auto-create pending brokerage company if brokerage name is provided but not linked
      if (!compData.brokerageCompanyId && compData.brokerage && compData.brokerage.trim()) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: comp.id,
            orgId,
            userId,
            companyName: compData.brokerage.trim(),
            role: 'brokerage' as any,
            city: compData.city,
            state: compData.state,
          });
          console.log('[SalesComps] Created pending brokerage company "' + compData.brokerage + '"');
        } catch (brokerageError) {
          console.error('Error auto-creating pending brokerage company:', brokerageError);
        }
      }

      // Auto-create pending contacts for additional agents
      if (compData.additionalAgents && Array.isArray(compData.additionalAgents)) {
        for (let i = 0; i < compData.additionalAgents.length; i++) {
          const agent = compData.additionalAgents[i];
          // Only create pending contact if agent has a name but no linked contactId
          if (agent && agent.name && agent.name.trim() && !agent.contactId) {
            try {
              // Parse the name into first and last name
              const nameParts = agent.name.trim().split(' ');
              const firstName = nameParts[0] || '';
              const lastName = nameParts.slice(1).join(' ') || '';
              
              // Use a unique sourceId for each additional agent
              const agentSourceId = comp.id + ':agent:' + i;
              
              // Check if pending contact already exists for this agent
              const existingPending = await storage.getPendingContacts(orgId, 'pending');
              const alreadyExists = existingPending.some((c: any) => 
                c.sourceType === 'sales_comp' && c.sourceId === agentSourceId
              );
              
              if (!alreadyExists) {
                const similarContacts = await storage.findSimilarContacts(orgId, firstName, lastName);
                
                await storage.createPendingContact({
                  orgId,
                  sourceType: 'sales_comp',
                  sourceId: agentSourceId,
                  fullName: agent.name.trim(),
                  status: 'pending',
                  suggestedDuplicates: similarContacts.map((c: any) => c.id),
                  sourceMetadata: {
                    salesCompId: comp.id,
                    agentFirstName: firstName,
                    agentLastName: lastName,
                    brokerage: compData.brokerage,
                    isAdditionalAgent: true,
                    agentIndex: i,
                  },
                  createdBy: userId,
                });
                console.log('[SalesComps] Created pending contact for additional agent "' + agent.name + '"');
              }
            } catch (agentError) {
              console.error('Error auto-creating pending contact for additional agent "' + agent.name + '":', agentError);
            }
          }
        }
      }
      res.status(201).json(comp);
    } catch (error: any) {
      console.error("Error creating comp:", error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      const errorMessage = error.message || "Failed to create comp";
      res.status(500).json({ message: errorMessage, details: error.code || error.name });
    }
  });

  app.patch('/api/sales-comps/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const updates = salesCompUpdateSchema.parse(req.body);

      // Map user-friendly field names to database column names
      const mappedUpdates = {
        ...updates,
        // Map sellerCompany -> seller (Seller Company in the form)
        seller: updates.sellerCompany || updates.seller,
        // Map sellerPrincipal -> owner (Seller Principal in the form)
        owner: updates.sellerPrincipal || updates.owner,
        // Map buyerCompany -> company (Buyer Company in the form)
        company: updates.buyerCompany || updates.company,
        orgId: req.user.orgId,
        // Map buyerPrincipal -> buyer (Buyer Principal in the form)
        buyer: updates.buyerPrincipal || updates.buyer,
      };

      const comp = await compService.updateComp(
        req.params.id,
        { ...mappedUpdates, updatedBy: userId },
        orgId,
        userId
      );

      if (!comp) return res.status(404).json({ message: "Comp not found" });

      // Auto-create pending company if buyerCompany was provided
      if (updates.buyerCompany) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: req.params.id,
            orgId,
            userId,
            companyName: updates.buyerCompany,
            role: 'buyer',
            city: updates.city,
            state: updates.state,
          });
        } catch (companyError) {
          console.error('Error auto-creating pending buyer company:', companyError);
        }
      }

      // Auto-create pending company if sellerCompany was provided
      if (updates.sellerCompany) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: req.params.id,
            orgId,
            userId,
            companyName: updates.sellerCompany,
            role: 'seller',
            city: updates.city,
            state: updates.state,
          });
        } catch (companyError) {
          console.error('Error auto-creating pending seller company:', companyError);
        }
      }

      // Auto-create pending company for brokerage if brokerage name was provided but no brokerageCompanyId linked
      if (updates.brokerage && !updates.brokerageCompanyId) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: req.params.id,
            orgId,
            userId,
            companyName: updates.brokerage,
            role: 'brokerage',
            city: updates.city,
            state: updates.state,
          });
        } catch (companyError) {
          console.error('Error auto-creating pending brokerage company:', companyError);
        }
      }

      // Auto-create pending contact if agent info was provided
      if (updates.agentFirstName || updates.agentLastName) {
        try {
          await storage.autoCreatePendingContactFromSalesComp({
            salesCompId: req.params.id,
            orgId,
            userId,
            agentFirstName: updates.agentFirstName,
            agentLastName: updates.agentLastName,
            brokerage: updates.brokerage,
          });
        } catch (contactError) {
          console.error('Error auto-creating pending contact:', contactError);
        }
      }

      // Auto-create pending contacts for Seller Principal and Buyer Principal
      const principalEntries = [
        { name: (updates.sellerPrincipal || '').trim(), role: 'seller_principal' },
        { name: (updates.buyerPrincipal || '').trim(), role: 'buyer_principal' },
      ];
      for (const entry of principalEntries) {
        if (entry.name) {
          try {
            const parts = entry.name.split(' ');
            const firstName = parts[0] || '';
            const lastName = parts.slice(1).join(' ') || '';
            const fullName = entry.name;

            const similarContacts = await storage.findSimilarContacts(orgId, fullName);

            await storage.createPendingContact({
              orgId,
              sourceType: 'sales_comp',
              sourceId: req.params.id,
              firstName: firstName || undefined,
              lastName: lastName || undefined,
              fullName,
              status: 'pending',
              suggestedDuplicates: similarContacts.map((c: any) => c.id),
              sourceMetadata: { salesCompId: req.params.id, marina: updates.marina, role: entry.role },
              createdBy: userId,
            });
          } catch (principalError) {
            console.error('Error auto-creating pending ' + entry.role + ' contact:', principalError);
          }
        }
      }

      // Auto-create pending property if marina/property data is updated but not linked to existing property
      if (!updates.propertyId && updates.marina) {
        try {
          const existingPending = await storage.getPendingProperties(orgId, 'pending');
          const alreadyExists = existingPending.some((p: any) => 
            p.sourceType === 'sales_comp' && p.compId === req.params.id
          );
          
          if (!alreadyExists) {
            const similarProperties = await storage.findSimilarProperties(
              orgId, 
              updates.marina, 
              updates.city, 
              updates.state
            );
            
            await storage.createPendingProperty({
              orgId,
              sourceType: 'sales_comp',
              compId: req.params.id,
              marinaName: updates.marina,
              city: updates.city || null,
              state: updates.state || null,
              address: updates.address || null,
              salePrice: updates.salePrice ? Number(updates.salePrice) : null,
              status: 'pending',
              suggestedDuplicates: similarProperties.map((p: any) => p.id),
              compMetadata: {
                wetSlips: updates.wetSlips,
                drySlips: updates.drySlips,
                buyer: updates.buyerCompany,
                seller: updates.sellerCompany,
                saleDate: updates.saleDate,
              },
              createdBy: userId,
            });
          }
        } catch (propertyError) {
          console.error('Error auto-creating pending property on update:', propertyError);
        }
      }

      // Auto-create pending brokerage company if brokerage name is updated but not linked
      if (!updates.brokerageCompanyId && updates.brokerage && updates.brokerage.trim()) {
        try {
          await storage.autoCreatePendingCompanyFromSalesComp({
            salesCompId: req.params.id,
            orgId,
            userId,
            companyName: updates.brokerage.trim(),
            role: 'brokerage' as any,
            city: updates.city,
            state: updates.state,
          });
        } catch (brokerageError) {
          console.error('Error auto-creating pending brokerage company on update:', brokerageError);
        }
      }

      // Auto-create pending contacts for additional agents on update
      if (updates.additionalAgents && Array.isArray(updates.additionalAgents)) {
        for (let i = 0; i < updates.additionalAgents.length; i++) {
          const agent = updates.additionalAgents[i];
          if (agent && agent.name && agent.name.trim() && !agent.contactId) {
            try {
              const nameParts = agent.name.trim().split(' ');
              const firstName = nameParts[0] || '';
              const lastName = nameParts.slice(1).join(' ') || '';
              const agentSourceId = req.params.id + ':agent:' + i;
              
              const existingPending = await storage.getPendingContacts(orgId, 'pending');
              const alreadyExists = existingPending.some((c: any) => 
                c.sourceType === 'sales_comp' && c.sourceId === agentSourceId
              );
              
              if (!alreadyExists) {
                const similarContacts = await storage.findSimilarContacts(orgId, firstName, lastName);
                
                await storage.createPendingContact({
                  orgId,
                  sourceType: 'sales_comp',
                  sourceId: agentSourceId,
                  fullName: agent.name.trim(),
                  status: 'pending',
                  suggestedDuplicates: similarContacts.map((c: any) => c.id),
                  sourceMetadata: {
                    salesCompId: req.params.id,
                    agentFirstName: firstName,
                    agentLastName: lastName,
                    brokerage: updates.brokerage,
                    isAdditionalAgent: true,
                    agentIndex: i,
                  },
                  createdBy: userId,
                });
              }
            } catch (agentError) {
              console.error('Error auto-creating pending contact for additional agent on update:', agentError);
            }
          }
        }
      }

      res.json(comp);
    } catch (error: any) {
      console.error("Error updating comp:", error);
      res.status(500).json({ message: "Failed to update comp" });
    }
  });

  app.delete('/api/sales-comps/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const success = await compService.deleteComp(req.params.id, orgId, userId);
      if (!success) return res.status(404).json({ message: "Comp not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting comp:", error);
      res.status(500).json({ message: "Failed to delete comp" });
    }
  });

  app.post('/api/sales-comps/:id/duplicate', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { id } = req.params;

      const originalComp = await storage.getCompById(id, orgId);
      if (!originalComp) {
        return res.status(404).json({ message: "Comp not found" });
      }

      const duplicatedComp = await compService.duplicateComp(id, orgId, userId);
      res.status(201).json(duplicatedComp);
    } catch (error: any) {
      console.error("Error duplicating comp:", error);
      res.status(500).json({ message: "Failed to duplicate comp" });
    }
  });

  app.post('/api/sales-comps/bulk-update', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const { ids, updates } = bulkUpdateSchema.parse(req.body);
      const count = await compService.bulkUpdateComps(ids, updates, orgId, userId);

      res.json({ updated: count });
    } catch (error: any) {
      console.error("Error bulk updating comps:", error);
      res.status(500).json({ message: "Failed to bulk update comps" });
    }
  });

  app.post('/api/sales-comps/bulk-delete', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const { ids } = req.body;
      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ message: "Invalid or empty IDs array" });
      }

      const count = await compService.bulkDeleteComps(ids, orgId, userId);
      res.json({ deleted: count });
    } catch (error: any) {
      console.error("Error bulk deleting comps:", error);
      res.status(500).json({ message: "Failed to bulk delete comps" });
    }
  });

  // Geocoding endpoint
  app.post('/api/sales-comps/:id/geocode', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { id } = req.params;

      const comp = await storage.getCompById(id, orgId);
      if (!comp) {
        return res.status(404).json({ message: "Comp not found" });
      }

      const addressString = geocodingService.buildAddressString({
        marina: comp.marina,
        address: comp.address || undefined,
        city: comp.city || undefined,
        state: comp.state || undefined,
        zip: comp.zip || undefined,
      });

      if (!addressString) {
        return res.status(400).json({ message: "No address information available to geocode" });
      }

      const result = await geocodingService.geocodeAddress(addressString);

      if ('error' in result) {
        return res.status(400).json(result);
      }

      await compService.updateComp(
        id,
        { 
          lat: result.lat.toString(),
          lng: result.lng.toString(),
          updatedBy: userId 
        },
        orgId,
        userId
      );

      res.json(result);
    } catch (error: any) {
      console.error("Error geocoding comp:", error);
      res.status(500).json({ message: "Failed to geocode comp" });
    }
  });

  // Upload and Import routes
  app.post('/api/sales-comps/upload', uploadSalesComps.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const analysis = await parserService.analyzeFile(req.file);
      const fullData = await parserService.parseFullFile(req.file);
      
      
      const importRecord = await storage.createImport({
        orgId,
        createdBy: userId,
        filename: req.file.originalname,
        status: 'mapping',
        parsedData: fullData,
        summary: {
          totalRows: fullData.length,
          successCount: 0,
          errorCount: 0,
          warningCount: 0,
          errors: []
        }
      });

      res.json({
        importId: importRecord.id,
        analysis,
      });
    } catch (error: any) {
      console.error("Error uploading file:", error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  app.post('/api/sales-comps/import/:importId/detect-duplicates', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { mapping, normalization } = req.body;
      
      const result = await compService.detectDuplicates(
        req.params.importId,
        orgId,
        mapping,
        normalization
      );

      res.json(result);
    } catch (error: any) {
      console.error("Error detecting duplicates:", error);
      res.status(500).json({ message: "Failed to detect duplicates" });
    }
  });

  app.post('/api/sales-comps/import/:importId/preview', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { mapping, normalization, importMode = 'upsert', updateBlankValues = false } = req.body;
      
      const result = await compService.previewImport(
        req.params.importId,
        orgId,
        mapping,
        normalization,
        importMode,
        updateBlankValues
      );

      res.json(result);
    } catch (error: any) {
      console.error("Error previewing import:", error);
      res.status(500).json({ message: "Failed to preview import" });
    }
  });

  app.post('/api/sales-comps/import/:importId/commit', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const { mapping, normalization, excludedRows = [], parentPortfolioId, importMode = 'upsert', updateBlankValues = false } = req.body;
      
      
      const result = await compService.processImport(
        req.params.importId,
        orgId,
        userId,
        mapping,
        normalization,
        excludedRows,
        parentPortfolioId,
        importMode,
        updateBlankValues
      );
      

      res.json(result);
    } catch (error: any) {
      console.error("Error processing import:", error);
      res.status(500).json({ message: "Failed to process import" });
    }
  });

  app.get('/api/sales-comps/import/:importId/status', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const importRecord = await storage.getImport(req.params.importId, orgId);
      if (!importRecord) return res.status(404).json({ message: "Import not found" });

      res.json(importRecord);
    } catch (error: any) {
      console.error("Error fetching import status:", error);
      res.status(500).json({ message: "Failed to fetch import status" });
    }
  });
  app.post('/api/sales-comps/import/:importId/submit-reviewed', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { reviewedRows, parentPortfolioId } = req.body;

      if (!reviewedRows || !Array.isArray(reviewedRows)) {
        return res.status(400).json({ message: "reviewedRows array is required" });
      }

      const results = {
        successCount: 0,
        errorCount: 0,
        errors: [] as Array<{ row: number; message: string }>,
      };

      for (let i = 0; i < reviewedRows.length; i++) {
        const row = reviewedRows[i];
        try {
          if (!row.marina || !String(row.marina).trim()) {
            results.errors.push({ row: i + 1, message: 'Marina name is still missing' });
            results.errorCount++;
            continue;
          }

          const insertData: any = {
            orgId,
            createdBy: userId,
            updatedBy: userId,
            marina: row.marina,
            salePrice: row.salePrice || undefined,
            isPriceDisclosed: Boolean(row.salePrice),
            capRate: row.capRate || undefined,
            isCapRateDisclosed: Boolean(row.capRate),
            noi: row.noi || undefined,
            isNoiDisclosed: Boolean(row.noi),
            saleMonth: row.saleMonth || undefined,
            saleYear: row.saleYear || undefined,
            state: row.state || undefined,
            city: row.city || undefined,
            region: row.region || undefined,
            wetSlips: row.wetSlips || undefined,
            dryRacks: row.dryRacks || undefined,
            ioBoth: row.ioBoth || undefined,
            bodyOfWater: row.bodyOfWater || undefined,
            waterfront: row.waterfront || undefined,
            saleCondition: row.saleCondition || undefined,
            daysOnMarket: row.daysOnMarket || undefined,
            broker: row.broker || undefined,
            agentFirstName: row.agentFirstName || undefined,
            agentLastName: row.agentLastName || undefined,
            brokerage: row.brokerage || undefined,
            address: row.address || undefined,
            zip: row.zip || undefined,
            seller: row.seller || undefined,
            company: row.company || undefined,
            owner: row.owner || undefined,
            listPrice: row.listPrice || undefined,
            acres: row.acres || undefined,
            occupancy: row.occupancy || undefined,
            yearBuilt: row.yearBuilt || undefined,
            notes: row.notes || undefined,
            articleUrls: row.articleUrls || [],
            parentPortfolioId: parentPortfolioId || undefined,
          };

          const createdComp = await storage.createComp(insertData);
          results.successCount++;

          // Create pending entities from reviewed rows
          if (createdComp) {
            // Pending Property - only when no existing property match found
            const matchedProperty = await storage.findPropertyByLocation(orgId, String(row.marina).trim(), row.city, row.state).catch(() => null);
            if (row.marina && String(row.marina).trim() && !matchedProperty) {
              try {
                const propDuplicates = await DuplicateDetectionService.findPropertyDuplicates({
                  title: String(row.marina).trim(),
                  city: row.city,
                  state: row.state,
                  address: row.address,
                }, orgId);
                await storage.createPendingProperty({
                  orgId,
                  sourceType: 'sales_comp',
                  compId: createdComp.id,
                  marinaName: String(row.marina).trim(),
                  city: row.city || undefined,
                  state: row.state || undefined,
                  address: row.address || undefined,
                  salePrice: row.salePrice ? parseInt(row.salePrice) : undefined,
                  status: 'pending',
                  suggestedDuplicates: propDuplicates.matches.map((m: any) => m.existingEntity.id),
                  compMetadata: { salesCompId: createdComp.id },
                  createdBy: userId,
                });
              } catch (err) { console.error('Error creating pending property from review:', err); }
            }

            // Pending Companies: Seller Company, Buyer Company, Brokerage
            const companyEntries = [
              { name: (row.sellerCompany || row.seller || '').trim(), role: 'seller' },
              { name: (row.buyerCompany || row.company || '').trim(), role: 'buyer' },
              { name: (row.brokerage || '').trim(), role: 'brokerage' },
            ];
            for (const entry of companyEntries) {
              if (entry.name) {
                try {
                  const dupes = await DuplicateDetectionService.findCompanyDuplicates({ name: entry.name }, orgId);
                  await storage.createPendingCompany({
                    orgId,
                    name: entry.name,
                    city: row.city || undefined,
                    state: row.state || undefined,
                    status: 'pending',
                    suggestedDuplicates: dupes.matches.map((m: any) => m.existingEntity.id),
                    sourceMetadata: { salesCompId: createdComp.id, role: entry.role },
                    createdBy: userId,
                  });
                } catch (err) { console.error('Error creating pending ' + entry.role + ' company from review:', err); }
              }
            }

            // Pending Contacts: Seller Principal, Buyer Principal, Agent
            const contactEntries: Array<{name: string; role: string}> = [
              { name: (row.sellerPrincipal || '').trim(), role: 'seller_principal' },
              { name: (row.buyerPrincipal || '').trim(), role: 'buyer_principal' },
            ];
            const agentName = (row.agentFirstName && row.agentLastName)
              ? (row.agentFirstName.trim() + ' ' + row.agentLastName.trim())
              : (row.broker || '').trim();
            if (agentName) contactEntries.push({ name: agentName, role: 'agent' });

            for (const entry of contactEntries) {
              if (entry.name) {
                try {
                  const parts = entry.name.split(' ');
                  const firstName = parts[0] || '';
                  const lastName = parts.slice(1).join(' ') || '';
                  const dupes = await DuplicateDetectionService.findContactDuplicates({ firstName, lastName, fullName: entry.name }, orgId);
                  await storage.createPendingContact({
                    orgId,
                    sourceType: 'sales_comp',
                    sourceId: createdComp.id,
                    firstName: firstName || undefined,
                    lastName: lastName || undefined,
                    fullName: entry.name,
                    status: 'pending',
                    suggestedDuplicates: dupes.matches.map((m: any) => m.existingEntity.id),
                    sourceMetadata: { compId: createdComp.id, marina: row.marina, role: entry.role },
                    createdBy: userId,
                  });
                } catch (err) { console.error('Error creating pending ' + entry.role + ' contact from review:', err); }
              }
            }
          }
        } catch (error) {
          results.errors.push({ row: i + 1, message: (error as Error).message });
          results.errorCount++;
        }
      }

      res.json(results);
    } catch (error: any) {
      console.error("Error submitting reviewed records:", error);
      res.status(500).json({ message: "Failed to submit reviewed records" });
    }
  });

  // Comp Columns management routes
  app.get('/api/comp-columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const columns = await storage.getCompColumns(orgId);
      res.json(columns);
    } catch (error: any) {
      console.error("Error fetching columns:", error);
      res.status(500).json({ message: "Failed to fetch columns" });
    }
  });

  app.post('/api/comp-columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const columnData = compColumnCreateSchema.parse(req.body);
      const column = await storage.createCompColumn({
        ...columnData,
        orgId,
      });

      res.status(201).json(column);
    } catch (error: any) {
      console.error("Error creating column:", error);
      res.status(500).json({ message: "Failed to create column" });
    }
  });

  app.patch('/api/comp-columns/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const updates = compColumnUpdateSchema.parse(req.body);
      const column = await storage.updateCompColumn(req.params.id, updates, orgId);

      if (!column) return res.status(404).json({ message: "Column not found" });
      res.json(column);
    } catch (error: any) {
      console.error("Error updating column:", error);
      res.status(500).json({ message: "Failed to update column" });
    }
  });

  app.delete('/api/comp-columns/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const success = await storage.deleteCompColumn(req.params.id, orgId);
      if (!success) return res.status(404).json({ message: "Column not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting column:", error);
      res.status(500).json({ message: "Failed to delete column" });
    }
  });

  // Analytics endpoint
  app.post('/api/sales-comps/analytics', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters: AnalyticsFilters = req.body;

      const metrics = await calculateMetrics(orgId, filters);
      
      // Use AI-powered insights with fallback to basic insights
      let insights;
      try {
        insights = await generateAIInsights(metrics, filters);
      } catch (aiError) {
        console.error("AI insights failed, using fallback:", aiError);
        const basicInsights = await generateInsights(metrics, filters);
        // Convert basic string insights to AIInsight format
        insights = basicInsights.map(text => ({
          category: 'trend',
          title: text.substring(0, 50),
          description: text,
          confidence: 'medium',
          priority: 3,
        }));
      }

      res.json({ metrics, insights });
    } catch (error: any) {
      console.error("Error calculating analytics:", error);
      res.status(500).json({ message: "Failed to calculate analytics" });
    }
  });

  // Correlation analysis endpoint
  app.post('/api/sales-comps/analytics/correlation', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters: AnalyticsFilters = req.body;

      const correlationData = await calculateCorrelationData(orgId, filters);
      res.json(correlationData);
    } catch (error: any) {
      console.error("Error calculating correlation data:", error);
      res.status(500).json({ message: "Failed to calculate correlation data" });
    }
  });

  // Valuation models endpoint
  app.post('/api/sales-comps/analytics/valuation', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters: AnalyticsFilters = req.body;

      const valuationModels = await calculateValuationModels(orgId, filters);
      res.json(valuationModels);
    } catch (error: any) {
      console.error("Error calculating valuation models:", error);
      res.status(500).json({ message: "Failed to calculate valuation models" });
    }
  });

  // Matched comps endpoint
  app.post('/api/sales-comps/analytics/matched-comps', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters: AnalyticsFilters = req.body;

      const result = await getMatchedComps(orgId, filters);
      res.json(result);
    } catch (error: any) {
      console.error("Error fetching matched comps:", error);
      res.status(500).json({ message: "Failed to fetch matched comps" });
    }
  });

  // Market Trends endpoint
  app.post('/api/sales-comps/analytics/trends', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters: TrendsFilters = req.body || {};

      const trendsData = await getMarketTrends(orgId, filters);
      const insights = await generateTrendsInsights(trendsData);

      res.json({
        ...trendsData,
        insights,
      });
    } catch (error: any) {
      console.error("Error fetching market trends:", error);
      res.status(500).json({ message: "Failed to fetch market trends" });
    }
  });

  // Analytics Filter Presets routes
  app.get('/api/sales-comps/analytics/filter-presets', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const presets = await storage.getAnalyticsFilterPresets(orgId, userId);
      res.json(presets);
    } catch (error: any) {
      console.error("Error fetching analytics filter presets:", error);
      res.status(500).json({ message: "Failed to fetch analytics filter presets" });
    }
  });

  app.post('/api/sales-comps/analytics/filter-presets', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const presetData = insertScAnalyticsFilterPresetSchema.parse(req.body);
      const preset = await storage.createAnalyticsFilterPreset({
        ...presetData,
        orgId,
        userId,
      });

      res.status(201).json(preset);
    } catch (error: any) {
      console.error("Error creating analytics filter preset:", error);
      res.status(500).json({ message: "Failed to create analytics filter preset" });
    }
  });

  app.patch('/api/sales-comps/analytics/filter-presets/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const presetData = updateScAnalyticsFilterPresetSchema.parse(req.body);
      const preset = await storage.updateAnalyticsFilterPreset(req.params.id, presetData, orgId, userId);

      if (!preset) return res.status(404).json({ message: "Analytics filter preset not found" });

      res.json(preset);
    } catch (error: any) {
      console.error("Error updating analytics filter preset:", error);
      res.status(500).json({ message: "Failed to update analytics filter preset" });
    }
  });

  app.delete('/api/sales-comps/analytics/filter-presets/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;

      const success = await storage.deleteAnalyticsFilterPreset(req.params.id, orgId, userId);

      if (!success) return res.status(404).json({ message: "Analytics filter preset not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting analytics filter preset:", error);
      res.status(500).json({ message: "Failed to delete analytics filter preset" });
    }
  });

  // ================================================================================
  // INSTITUTIONAL DATA SERVICES - Geocoding, Quality Scoring, Validation, History
  // ================================================================================

// Rate Comps API Routes (from server/routes.ts)
  app.get('/api/rate-comps', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const includeGlobal = req.query.includeGlobal === 'true';
      const scopeFilter = req.query.scope as string | undefined; // 'all' | 'org' | 'global'

      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.set('Pragma', 'no-cache');
      res.set('Expires', '0');

      const filters = compFiltersSchema.parse(req.query);
      const sqlFilters = rcFilterBuilder.buildFilters(filters);
      
      // Fetch org-specific comps (unless filtering to global only)
      let comps: any[] = [];
      let total = 0;
      
      if (scopeFilter !== 'global') {
        const orgResult = await storage.getRateComps({
          orgId,
          filters: sqlFilters,
          sortBy: filters.sortBy,
          sortDir: filters.sortDir,
          page: filters.page,
          pageSize: filters.pageSize,
        });
        comps = orgResult.comps.map((c: any) => ({ ...c, _source: 'org' }));
        total = orgResult.total;
      }
      
      // Include global curated comps if requested (users with Analysis pack)
      if (includeGlobal || scopeFilter === 'all' || scopeFilter === 'global') {
        try {
          const globalComps = await db
            .select()
            .from(rateComps)
            .where(eq(rateComps.scope, "global"))
            .limit(filters.pageSize || 50);
          
          // Add source tag and merge
          const taggedGlobal = globalComps.map((c: any) => ({ ...c, _source: 'global' }));
          
          if (scopeFilter === 'global') {
            comps = taggedGlobal;
            total = taggedGlobal.length;
          } else {
            comps = [...comps, ...taggedGlobal];
            total += taggedGlobal.length;
          }
        } catch (globalErr) {
          console.warn("Could not fetch global rate comps:", globalErr);
        }
      }

      res.json({ comps, total, page: filters.page, pageSize: filters.pageSize });
    } catch (error: any) {
      console.error("Error fetching rate comps:", error);
      res.status(500).json({ message: "Failed to fetch rate comps" });
    }
  });

  // Industry Standards - Public API (pack-gated access)
  // Industry Standards - Public API (pack-gated access)
  app.get('/api/industry-standards', authenticateUser, enforceTenant, async (req: any, res) => {
    try {
      const { category, region, year } = req.query;
      const userPacks = req.user?.packs || [];
      
      const conditions = [eq(industryStandards.scope, "global")];
      
      if (category) {
        conditions.push(eq(industryStandards.category, category as string));
      }
      if (region) {
        conditions.push(eq(industryStandards.region, region as string));
      }
      if (year) {
        conditions.push(eq(industryStandards.effectiveYear, parseInt(year as string)));
      }

      const allStandards = await db
        .select()
        .from(industryStandards)
        .where(and(...conditions))
        .orderBy(desc(industryStandards.effectiveYear), industryStandards.category)
        .limit(200);

      // Filter by pack access - only return standards where user has the required pack
      const accessibleStandards = allStandards.filter(std => {
        if (!std.requiredPack) return true; // No pack required
        return userPacks.includes(std.requiredPack) || req.user?.role === 'owner';
      });

      res.json(accessibleStandards);
    } catch (error) {
      console.error("Error fetching industry standards:", error);
      res.status(500).json({ error: "Failed to fetch industry standards" });
    }
  });
  app.get('/api/rate-comps/ids', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const ids = await storage.getAllRateCompIds(orgId);
      res.json({ ids });
    } catch (error: any) {
      console.error('Error getting rate comp IDs:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/rate-comps/column-values/:column', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { column } = req.params;
      const values = await storage.getRateCompColumnUniqueValues(orgId, column);
      res.json({ values });
    } catch (error: any) {
      console.error('Error getting column values:', error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Cross-reference API - Pull enriched filter options from Sales Comps and CRM Properties
  app.get('/api/rate-comps/cross-reference/filters', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      // Get unique values from Sales Comps for cross-referencing
      const salesCompsStates = await storage.getColumnUniqueValues(orgId, 'state');
      const salesCompsWaterTypes = await storage.getColumnUniqueValues(orgId, 'waterType');
      const salesCompsRegions = await storage.getColumnUniqueValues(orgId, 'region');
      const salesCompsBodiesOfWater = await storage.getColumnUniqueValues(orgId, 'bodyOfWater');
      
      // Get unique values from CRM Properties for enrichment
      const crmProperties = await storage.getCrmPropertiesForOrg(orgId);
      const crmStates = [...new Set(crmProperties.filter(p => p.state).map(p => p.state))];
      const crmCities = [...new Set(crmProperties.filter(p => p.city).map(p => p.city))];
      
      // Merge and deduplicate filter options
      const crossRefFilters = {
        // Merged state options from all sources
        states: {
          salesComps: salesCompsStates,
          crmProperties: crmStates,
          merged: [...new Set([...salesCompsStates, ...crmStates])].sort()
        },
        // Water types from Sales Comps
        waterTypes: {
          salesComps: salesCompsWaterTypes,
          merged: salesCompsWaterTypes
        },
        // Regions from Sales Comps
        regions: {
          salesComps: salesCompsRegions,
          merged: salesCompsRegions
        },
        // Bodies of water from Sales Comps
        bodiesOfWater: {
          salesComps: salesCompsBodiesOfWater,
          merged: salesCompsBodiesOfWater
        },
        // Cities from CRM Properties
        cities: {
          crmProperties: crmCities,
          merged: crmCities
        },
        // Data source metadata
        sources: {
          salesCompsCount: salesCompsStates.length > 0 ? 'available' : 'empty',
          crmPropertiesCount: crmProperties.length
        }
      };
      
      res.json(crossRefFilters);
    } catch (error: any) {
      console.error('Error getting cross-reference filters:', error);
      res.status(500).json({ message: "Failed to fetch cross-reference filters" });
    }
  });

  // Cross-reference API - Get Marina Database lookup
  app.get('/api/rate-comps/cross-reference/marinas', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { q, limit } = req.query;
      
      if (!q || q.trim().length < 2) {
        return res.json([]);
      }
      
      const marinas = await storage.searchMarinas(orgId, q.trim(), limit ? parseInt(limit) : 20);
      res.json(marinas);
    } catch (error: any) {
      console.error('Error searching marinas for cross-reference:', error);
      res.status(500).json({ message: "Failed to search marinas" });
    }
  });

  // Custom Storage Types routes (must be before /:id route)
  app.get('/api/rate-comps/custom-storage-types', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const types = await storage.getRcCustomStorageTypes(orgId);
      res.json(types);
    } catch (error: any) {
      console.error("Error fetching custom storage types:", error);
      res.status(500).json({ message: "Failed to fetch custom storage types" });
    }
  });

  app.post('/api/rate-comps/custom-storage-types', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { name } = req.body;

      if (!name || typeof name !== 'string' || name.trim() === '') {
        return res.status(400).json({ message: "Storage type name is required" });
      }

      // Check for duplicates (case-insensitive)
      const existing = await storage.getRcCustomStorageTypes(orgId);
      if (existing.some(t => t.name.toLowerCase() === name.trim().toLowerCase())) {
        return res.status(400).json({ message: "Storage type already exists" });
      }

      const type = await storage.createRcCustomStorageType({
        orgId,
        name: name.trim(),
        createdBy: userId,
      });

      res.status(201).json(type);
    } catch (error: any) {
      console.error("Error creating custom storage type:", error);
      res.status(500).json({ message: "Failed to create custom storage type" });
    }
  });

  app.delete('/api/rate-comps/custom-storage-types/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const success = await storage.deleteRcCustomStorageType(req.params.id, orgId);

      if (!success) return res.status(404).json({ message: "Storage type not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting custom storage type:", error);
      res.status(500).json({ message: "Failed to delete custom storage type" });
    }
  });

  // Custom Column Management routes (must be before /:id route)
  app.get('/api/rate-comps/columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const columns = await storage.getRateCompColumns(orgId);
      res.json(columns);
    } catch (error: any) {
      console.error("Error fetching custom columns:", error);
      res.status(500).json({ message: "Failed to fetch custom columns" });
    }
  });

  app.post('/api/rate-comps/columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { key, label, type, options, required, visible, orderIndex } = req.body;

      if (!key || !label || !type) {
        return res.status(400).json({ message: "Field key, label, and type are required" });
      }

      // Check for duplicate key
      const existing = await storage.getRateCompColumns(orgId);
      if (existing.some(c => c.key === key)) {
        return res.status(400).json({ message: "Column with this key already exists" });
      }

      const column = await storage.createRateCompColumn({
        orgId,
        key,
        label,
        type,
        options: options || null,
        required: required || false,
        visible: visible !== false,
        orderIndex: orderIndex || 0,
      });

      res.status(201).json(column);
    } catch (error: any) {
      console.error("Error creating custom column:", error);
      res.status(500).json({ message: "Failed to create custom column" });
    }
  });

  app.delete('/api/rate-comps/columns/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const success = await storage.deleteRateCompColumn(req.params.id, orgId);

      if (!success) return res.status(404).json({ message: "Column not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting custom column:", error);
      res.status(500).json({ message: "Failed to delete custom column" });
    }
  });

  // Pending Property Profiles routes (must be before /:id route)
  app.get('/api/rate-comps/pending-property-profiles', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const status = req.query.status as string | undefined;
      const profiles = await storage.getRcPendingPropertyProfiles(orgId, status);
      res.json(profiles);
    } catch (error: any) {
      console.error("Error fetching pending property profiles:", error);
      res.status(500).json({ message: "Failed to fetch pending property profiles" });
    }
  });

  app.post('/api/rate-comps/pending-property-profiles', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { compId, status } = req.body;

      if (!compId) {
        return res.status(400).json({ message: "compId is required" });
      }

      const profile = await storage.createRcPendingPropertyProfile({
        compId,
        orgId,
        status: status || 'pending',
      });

      res.status(201).json(profile);
    } catch (error: any) {
      console.error("Error creating pending property profile:", error);
      res.status(500).json({ message: "Failed to create pending property profile" });
    }
  });

  app.patch('/api/rate-comps/pending-property-profiles/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { status } = req.body;
      
      // Verify ownership before updating
      const existing = await storage.getRcPendingPropertyProfiles(orgId);
      const profile = existing.find(p => p.id === req.params.id);
      if (!profile) {
        return res.status(404).json({ message: "Pending property profile not found" });
      }
      
      const updated = await storage.updateRcPendingPropertyProfile(req.params.id, { status });
      res.json(updated);
    } catch (error: any) {
      console.error("Error updating pending property profile:", error);
      res.status(500).json({ message: "Failed to update pending property profile" });
    }
  });

  app.delete('/api/rate-comps/pending-property-profiles/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      // Verify ownership before deleting
      const existing = await storage.getRcPendingPropertyProfiles(orgId);
      const profile = existing.find(p => p.id === req.params.id);
      if (!profile) {
        return res.status(404).json({ message: "Pending property profile not found" });
      }
      
      const success = await storage.deleteRcPendingPropertyProfile(req.params.id);
      if (!success) return res.status(404).json({ message: "Pending property profile not found" });
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting pending property profile:", error);
      res.status(500).json({ message: "Failed to delete pending property profile" });
    }
  });

  app.get('/api/rate-comps/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const comp = await storage.getRateComp(req.params.id, orgId);
      if (!comp) return res.status(404).json({ message: "Rate comp not found" });
      res.json(comp);
    } catch (error: any) {
      console.error("Error fetching rate comp:", error);
      res.status(500).json({ message: "Failed to fetch rate comp" });
    }
  });

  app.post('/api/rate-comps/backfill-properties', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      
      
      const result = await storage.getRateComps({ orgId, pageSize: 10000 });
      const comps = result.comps;
      const compsWithoutProperty = comps.filter(comp => !comp.propertyId && comp.marina);
      
      
      let created = 0;
      let matched = 0;
      let failed = 0;
      
      for (const comp of compsWithoutProperty) {
        try {
          let propertyId = null;
          
          const matchedProperty = await storage.findPropertyByLocation(
            orgId,
            comp.marina!,
            comp.city || undefined,
            comp.state || undefined
          );
          
          if (matchedProperty) {
            propertyId = matchedProperty.id;
            matched++;
          } else {
            const address = [
              comp.address,
              comp.city && comp.state ? `${comp.city}, ${comp.state}` : comp.city || comp.state
            ].filter(Boolean).join(', ');
            
            const newProperty = await storage.createCrmProperty({
              title: comp.marina!,
              type: 'marina',
              status: 'available',
              address: address || undefined,
              ownerId: orgId,
              listingPrice: comp.salePrice ? String(comp.salePrice) : undefined,
              description: `Auto-created from rate comp backfill`,
            });
            
            propertyId = newProperty.id;
            created++;
          }
          
          if (propertyId) {
            await storage.updateRateComp(comp.id, { propertyId }, orgId);
          }
        } catch (error: any) {
          failed++;
          console.error(`❌ Failed to process rate comp ${comp.id}:`, error);
        }
      }
      
      const summary = {
        total: compsWithoutProperty.length,
        propertiesCreated: created,
        propertiesMatched: matched,
        failed,
      };
      
      
      res.json(summary);
    } catch (error: any) {
      console.error("Error during property backfill:", error);
      res.status(500).json({ message: "Failed to backfill properties" });
    }
  });

  app.post('/api/rate-comps', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const compData = insertRateCompSchema.parse(req.body);

      const comp = await rcCompService.createComp({
        ...compData,
        orgId,
        createdBy: userId,
      }, userId);

      // Auto-create pending property profile if propertyId is not provided
      if (!compData.propertyId) {
        try {
          await storage.createRcPendingPropertyProfile({
            compId: comp.id,
            orgId,
            status: 'pending',
          });
        } catch (pendingError) {
          console.error('Error auto-creating pending property profile for rate comp:', pendingError);
        }
      }

      res.status(201).json(comp);
    } catch (error: any) {
      console.error("Error creating rate comp:", error);
      res.status(500).json({ message: "Failed to create rate comp" });
    }
  });

  app.patch('/api/rate-comps/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const updates = salesCompUpdateSchema.parse(req.body);

      const comp = await rcCompService.updateComp(
        req.params.id,
        { ...updates, updatedBy: userId },
        orgId,
        userId
      );

      if (!comp) return res.status(404).json({ message: "Rate comp not found" });
      
      // Bidirectional sync: Update CRM property if propertyId is linked
      // Only sync fields that were explicitly updated in the request
      const propertyId = (comp as any).propertyId;
      if (propertyId && Object.keys(updates).length > 0) {
        try {
          const existingProperty = await storage.getCrmProperty(propertyId);
          if (existingProperty && existingProperty.orgId === orgId) {
            const currentSpecs = (existingProperty.specifications as any) || {};
            
            // Only sync fields that were actually in the update request
            const syncableFields = ['wetSlips', 'dryRacks', 'acres', 'occupancy', 'yearBuilt', 
              'waterType', 'bodyOfWater', 'waterBodyName', 'region', 'storageTypes',
              'profitCenterStorage', 'profitCenterEvents', 'profitCenterService', 
              'profitCenterThirdPartyLeases', 'profitCenterBoatRentals', 'profitCenterBoatBrokerage',
              'profitCenterRvPark', 'profitCenterFuel', 'profitCenterShipStore', 'profitCenterParts',
              'profitCenterBoatClub', 'profitCenterBoatSales', 'profitCenterFnb', 'profitCenterHospitality'];
            
            const updatedSpecs = { ...currentSpecs };
            let hasChanges = false;
            
            for (const field of syncableFields) {
              if (field in updates && updates[field] !== undefined) {
                updatedSpecs[field] = updates[field];
                hasChanges = true;
              }
            }
            
            if (hasChanges) {
              updatedSpecs.lastSyncedFromRateComp = new Date().toISOString();
              
              const propertyUpdates: any = { specifications: updatedSpecs };
              if ('address' in updates && updates.address !== undefined) {
                propertyUpdates.address = updates.address;
              }
              
              await storage.updateCrmProperty(propertyId, propertyUpdates);
            }
          }
        } catch (syncError) {
          console.error('Error syncing rate comp to CRM property:', syncError);
          // Don't fail the request if sync fails - the rate comp update succeeded
        }
      }
      
      res.json(comp);
    } catch (error: any) {
      console.error("Error updating rate comp:", error);
      res.status(500).json({ message: "Failed to update rate comp" });
    }
  });

  app.delete('/api/rate-comps/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const success = await rcCompService.deleteComp(req.params.id, orgId, userId);
      if (!success) return res.status(404).json({ message: "Rate comp not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting rate comp:", error);
      res.status(500).json({ message: "Failed to delete rate comp" });
    }
  });

  app.post('/api/rate-comps/bulk-update', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const { ids, updates } = bulkUpdateSchema.parse(req.body);
      const count = await rcCompService.bulkUpdateComps(ids, updates, orgId, userId);

      res.json({ updated: count });
    } catch (error: any) {
      console.error("Error bulk updating rate comps:", error);
      res.status(500).json({ message: "Failed to bulk update rate comps" });
    }
  });

  app.post('/api/rate-comps/bulk-delete', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const { ids } = req.body;
      if (!Array.isArray(ids) || ids.length === 0) {
        return res.status(400).json({ message: "Invalid or empty IDs array" });
      }

      const count = await rcCompService.bulkDeleteComps(ids, orgId, userId);
      res.json({ deleted: count });
    } catch (error: any) {
      console.error("Error bulk deleting rate comps:", error);
      res.status(500).json({ message: "Failed to bulk delete rate comps" });
    }
  });

  // Geocoding endpoint
  app.post('/api/rate-comps/:id/geocode', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { id } = req.params;

      const comp = await storage.getRateCompById(id, orgId);
      if (!comp) {
        return res.status(404).json({ message: "Rate comp not found" });
      }

      const addressString = geocodingService.buildAddressString({
        marina: comp.marina,
        address: comp.address || undefined,
        city: comp.city || undefined,
        state: comp.state || undefined,
        zip: comp.zip || undefined,
      });

      if (!addressString) {
        return res.status(400).json({ message: "No address information available to geocode" });
      }

      const result = await geocodingService.geocodeAddress(addressString);

      if ('error' in result) {
        return res.status(400).json(result);
      }

      await rcCompService.updateComp(
        id,
        { 
          lat: result.lat.toString(),
          lng: result.lng.toString(),
          updatedBy: userId 
        },
        orgId,
        userId
      );

      res.json(result);
    } catch (error: any) {
      console.error("Error geocoding rate comp:", error);
      res.status(500).json({ message: "Failed to geocode rate comp" });
    }
  });

  // Upload and Import routes
  app.post('/api/rate-comps/upload', uploadRateComps.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const analysis = await rcParserService.analyzeFile(req.file);
      const fullData = await rcParserService.parseFullFile(req.file);
      
      
      const importRecord = await storage.createRateCompImport({
        orgId,
        createdBy: userId,
        filename: req.file.originalname,
        status: 'mapping',
        parsedData: fullData,
        summary: {
          totalRows: fullData.length,
          successCount: 0,
          errorCount: 0,
          warningCount: 0,
          errors: []
        }
      });

      res.json({
        importId: importRecord.id,
        analysis,
      });
    } catch (error: any) {
      console.error("Error uploading rate comp file:", error);
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  app.post('/api/rate-comps/import/:importId/detect-duplicates', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { mapping, normalization } = req.body;
      
      const result = await rcCompService.detectDuplicates(
        req.params.importId,
        orgId,
        mapping,
        normalization
      );

      res.json(result);
    } catch (error: any) {
      console.error("Error detecting duplicates:", error);
      res.status(500).json({ message: "Failed to detect duplicates" });
    }
  });

  app.post('/api/rate-comps/import/:importId/commit', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const { mapping, normalization, excludedRows = [], parentPortfolioId } = req.body;
      
      
      const result = await rcCompService.processImport(
        req.params.importId,
        orgId,
        userId,
        mapping,
        normalization,
        excludedRows,
        parentPortfolioId
      );
      

      res.json(result);
    } catch (error: any) {
      console.error("Error processing rate comp import:", error);
      res.status(500).json({ message: "Failed to process import" });
    }
  });

  app.get('/api/rate-comps/import/:importId/status', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const importRecord = await storage.getRateCompImport(req.params.importId, orgId);
      if (!importRecord) return res.status(404).json({ message: "Import not found" });

      res.json(importRecord);
    } catch (error: any) {
      console.error("Error fetching import status:", error);
      res.status(500).json({ message: "Failed to fetch import status" });
    }
  });

  // Rate Comp Columns management routes
  app.get('/api/rc-columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const columns = await storage.getRateCompColumns(orgId);
      res.json(columns);
    } catch (error: any) {
      console.error("Error fetching rate comp columns:", error);
      res.status(500).json({ message: "Failed to fetch columns" });
    }
  });

  app.post('/api/rc-columns', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const columnData = compColumnCreateSchema.parse(req.body);
      const column = await storage.createRateCompColumn({
        ...columnData,
        orgId,
      });

      res.status(201).json(column);
    } catch (error: any) {
      console.error("Error creating rate comp column:", error);
      res.status(500).json({ message: "Failed to create column" });
    }
  });

  app.patch('/api/rc-columns/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const updates = compColumnUpdateSchema.parse(req.body);
      const column = await storage.updateRateCompColumn(req.params.id, updates, orgId);

      if (!column) return res.status(404).json({ message: "Column not found" });
      res.json(column);
    } catch (error: any) {
      console.error("Error updating rate comp column:", error);
      res.status(500).json({ message: "Failed to update column" });
    }
  });

  app.delete('/api/rc-columns/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const success = await storage.deleteRateCompColumn(req.params.id, orgId);
      if (!success) return res.status(404).json({ message: "Column not found" });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting rate comp column:", error);
      res.status(500).json({ message: "Failed to delete column" });
    }
  });

  // Rate Tiers routes (flexible pricing tiers)
  app.get('/api/rate-comps/:rateCompId/tiers', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { rateCompId } = req.params;

      const tiers = await storage.getRateTiersByRateComp(rateCompId, orgId);
      res.json(tiers);
    } catch (error: any) {
      console.error("Error fetching rate tiers:", error);
      res.status(500).json({ message: "Failed to fetch rate tiers" });
    }
  });

  app.get('/api/rate-tiers', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { storageType, isCurrentRate, loaMin, loaMax } = req.query;

      const filters: any = {};
      if (storageType) filters.storageType = storageType;
      if (isCurrentRate !== undefined) filters.isCurrentRate = isCurrentRate === 'true';
      if (loaMin || loaMax) {
        filters.loaRange = {};
        if (loaMin) filters.loaRange.min = parseFloat(loaMin);
        if (loaMax) filters.loaRange.max = parseFloat(loaMax);
      }

      const tiers = await storage.getRateTiersByOrg(orgId, Object.keys(filters).length > 0 ? filters : undefined);
      res.json(tiers);
    } catch (error: any) {
      console.error("Error fetching rate tiers:", error);
      res.status(500).json({ message: "Failed to fetch rate tiers" });
    }
  });

  app.get('/api/rate-tiers/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const tier = await storage.getRateTier(req.params.id, orgId);
      if (!tier) return res.status(404).json({ message: "Rate tier not found" });
      res.json(tier);
    } catch (error: any) {
      console.error("Error fetching rate tier:", error);
      res.status(500).json({ message: "Failed to fetch rate tier" });
    }
  });

  app.post('/api/rate-comps/:rateCompId/tiers', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { rateCompId } = req.params;

      const comp = await storage.getRateComp(rateCompId, orgId);
      if (!comp) return res.status(404).json({ message: "Rate comp not found" });

      const tierData = req.body;
      const tier = await storage.createRateTier({
        ...tierData,
        rateCompId,
        orgId,
        createdBy: userId,
      });

      await storage.createRcAuditLog({
        orgId,
        userId,
        entity: 'rate_tier',
        entityId: tier.id,
        action: 'create',
        after: tier,
      });

      res.status(201).json(tier);
    } catch (error: any) {
      console.error("Error creating rate tier:", error);
      res.status(500).json({ message: "Failed to create rate tier" });
    }
  });

  app.post('/api/rate-comps/:rateCompId/tiers/bulk', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { rateCompId } = req.params;

      const comp = await storage.getRateComp(rateCompId, orgId);
      if (!comp) return res.status(404).json({ message: "Rate comp not found" });

      const tiersData = req.body.tiers;
      if (!Array.isArray(tiersData) || tiersData.length === 0) {
        return res.status(400).json({ message: "Invalid or empty tiers array" });
      }

      const tiersToCreate = tiersData.map(tier => ({
        ...tier,
        rateCompId,
        orgId,
        createdBy: userId,
      }));

      const createdTiers = await storage.bulkCreateRateTiers(tiersToCreate);

      await storage.createRcAuditLog({
        orgId,
        userId,
        entity: 'rate_tier',
        entityId: rateCompId,
        action: 'bulk_create',
        after: { count: createdTiers.length },
      });

      res.status(201).json(createdTiers);
    } catch (error: any) {
      console.error("Error bulk creating rate tiers:", error);
      res.status(500).json({ message: "Failed to create rate tiers" });
    }
  });

  app.patch('/api/rate-tiers/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const tier = await storage.getRateTier(req.params.id, orgId);
      if (!tier) return res.status(404).json({ message: "Rate tier not found" });

      const updates = { ...req.body, updatedBy: userId };
      const updatedTier = await storage.updateRateTier(req.params.id, updates, orgId);

      await storage.createRcAuditLog({
        orgId,
        userId,
        entity: 'rate_tier',
        entityId: req.params.id,
        action: 'update',
        before: tier,
        after: updatedTier,
      });

      res.json(updatedTier);
    } catch (error: any) {
      console.error("Error updating rate tier:", error);
      res.status(500).json({ message: "Failed to update rate tier" });
    }
  });

  app.delete('/api/rate-tiers/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const tier = await storage.getRateTier(req.params.id, orgId);
      if (!tier) return res.status(404).json({ message: "Rate tier not found" });

      await storage.deleteRateTier(req.params.id, orgId);

      await storage.createRcAuditLog({
        orgId,
        userId,
        entity: 'rate_tier',
        entityId: req.params.id,
        action: 'delete',
        before: tier,
      });

      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting rate tier:", error);
      res.status(500).json({ message: "Failed to delete rate tier" });
    }
  });

  app.get('/api/rate-comps/:id/with-tiers', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const compWithTiers = await storage.getRateCompWithTiers(req.params.id, orgId);
      if (!compWithTiers) return res.status(404).json({ message: "Rate comp not found" });
      res.json(compWithTiers);
    } catch (error: any) {
      console.error("Error fetching rate comp with tiers:", error);
      res.status(500).json({ message: "Failed to fetch rate comp with tiers" });
    }
  });

  app.post('/api/rate-comps/with-tiers', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters = req.body.filters || {};
      const compsWithTiers = await storage.getRateCompsWithTiers(orgId, filters);
      res.json(compsWithTiers);
    } catch (error: any) {
      console.error("Error fetching rate comps with tiers:", error);
      res.status(500).json({ message: "Failed to fetch rate comps with tiers" });
    }
  });

  // ============================================================================
  // MARINA RATE DATABASE ROUTES
  // ============================================================================

  // List marinas with filtering, sorting, and pagination
  app.get('/api/marina-database', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { q, states, regions, waterTypes, isActive, sortBy, sortDir, page, pageSize } = req.query;

      const filters: Record<string, any> = {};
      if (q) filters.q = q;
      if (states) filters.states = Array.isArray(states) ? states : states.split(',');
      if (regions) filters.regions = Array.isArray(regions) ? regions : regions.split(',');
      if (waterTypes) filters.waterTypes = Array.isArray(waterTypes) ? waterTypes : waterTypes.split(',');
      if (isActive !== undefined) filters.isActive = isActive === 'true';

      const result = await storage.getMarinas({
        orgId,
        filters,
        sortBy: sortBy || 'marinaName',
        sortDir: sortDir || 'asc',
        page: page ? parseInt(page) : 1,
        pageSize: pageSize ? parseInt(pageSize) : 25
      });

      res.json(result);
    } catch (error: any) {
      console.error("Error fetching marinas:", error);
      res.status(500).json({ message: "Failed to fetch marinas" });
    }
  });

  // Search marinas for autocomplete
  app.get('/api/marina-database/search', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { q, limit } = req.query;

      if (!q || q.trim().length < 2) {
        return res.json([]);
      }

      const marinas = await storage.searchMarinas(orgId, q.trim(), limit ? parseInt(limit) : 20);
      res.json(marinas);
    } catch (error: any) {
      console.error("Error searching marinas:", error);
      res.status(500).json({ message: "Failed to search marinas" });
    }
  });

  // Get single marina
  app.get('/api/marina-database/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const marina = await storage.getMarina(req.params.id, orgId);
      if (!marina) return res.status(404).json({ message: "Marina not found" });
      res.json(marina);
    } catch (error: any) {
      console.error("Error fetching marina:", error);
      res.status(500).json({ message: "Failed to fetch marina" });
    }
  });

  // Get marina with all rates (current and historical)
  app.get('/api/marina-database/:id/with-rates', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const marinaWithRates = await storage.getMarinaWithRates(req.params.id, orgId);
      if (!marinaWithRates) return res.status(404).json({ message: "Marina not found" });
      res.json(marinaWithRates);
    } catch (error: any) {
      console.error("Error fetching marina with rates:", error);
      res.status(500).json({ message: "Failed to fetch marina with rates" });
    }
  });

  // Create marina
  app.post('/api/marina-database', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const marina = await storage.createMarina({
        ...req.body,
        orgId,
        createdBy: userId
      });

      res.status(201).json(marina);
    } catch (error: any) {
      console.error("Error creating marina:", error);
      res.status(500).json({ message: "Failed to create marina" });
    }
  });

  // Update marina
  app.patch('/api/marina-database/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const existing = await storage.getMarina(req.params.id, orgId);
      if (!existing) return res.status(404).json({ message: "Marina not found" });

      const marina = await storage.updateMarina(req.params.id, { ...req.body, updatedBy: userId }, orgId);
      res.json(marina);
    } catch (error: any) {
      console.error("Error updating marina:", error);
      res.status(500).json({ message: "Failed to update marina" });
    }
  });

  // Delete marina (soft delete)
  app.delete('/api/marina-database/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const existing = await storage.getMarina(req.params.id, orgId);
      if (!existing) return res.status(404).json({ message: "Marina not found" });

      await storage.deleteMarina(req.params.id, orgId);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting marina:", error);
      res.status(500).json({ message: "Failed to delete marina" });
    }
  });

  // ============================================================================
  // MARINA RATES ROUTES (Historical Rate Tracking)
  // ============================================================================

  // Get rates for a marina with optional filters
  app.get('/api/marina-database/:marinaId/rates', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { marinaId } = req.params;
      const { rateYear, storageType, isCurrentRate } = req.query;

      const filters: any = {};
      if (rateYear) filters.rateYear = parseInt(rateYear);
      if (storageType) filters.storageType = storageType;
      if (isCurrentRate !== undefined) filters.isCurrentRate = isCurrentRate === 'true';

      const rates = await storage.getMarinaRates(marinaId, orgId, Object.keys(filters).length > 0 ? filters : undefined);
      res.json(rates);
    } catch (error: any) {
      console.error("Error fetching marina rates:", error);
      res.status(500).json({ message: "Failed to fetch marina rates" });
    }
  });

  // Get rate history for a marina (all rates over time)
  app.get('/api/marina-database/:marinaId/rate-history', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { marinaId } = req.params;
      const { storageType } = req.query;

      const history = await storage.getMarinaRateHistory(marinaId, orgId, storageType);
      res.json(history);
    } catch (error: any) {
      console.error("Error fetching marina rate history:", error);
      res.status(500).json({ message: "Failed to fetch marina rate history" });
    }
  });

  // Get latest/current rates for a marina
  app.get('/api/marina-database/:marinaId/rates/current', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { marinaId } = req.params;

      const rates = await storage.getLatestMarinaRates(marinaId, orgId);
      res.json(rates);
    } catch (error: any) {
      console.error("Error fetching current marina rates:", error);
      res.status(500).json({ message: "Failed to fetch current marina rates" });
    }
  });

  // Create a new rate entry (marks previous rates as historical if needed)
  app.post('/api/marina-database/:marinaId/rates', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { marinaId } = req.params;

      const marina = await storage.getMarina(marinaId, orgId);
      if (!marina) return res.status(404).json({ message: "Marina not found" });

      const { storageType, rateYear, rateSeason, markPreviousAsHistorical = true } = req.body;

      // If this is a current rate, mark previous rates for same type/year as historical
      if (req.body.isCurrentRate !== false && markPreviousAsHistorical) {
        await storage.markPreviousRatesHistorical(marinaId, storageType, rateYear, orgId);
      }

      const rate = await storage.createMarinaRate({
        ...req.body,
        marinaId,
        orgId,
        createdBy: userId,
        isCurrentRate: req.body.isCurrentRate !== false
      });

      res.status(201).json(rate);
    } catch (error: any) {
      console.error("Error creating marina rate:", error);
      res.status(500).json({ message: "Failed to create marina rate" });
    }
  });

  // Bulk create rates
  app.post('/api/marina-database/:marinaId/rates/bulk', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;
      const { marinaId } = req.params;

      const marina = await storage.getMarina(marinaId, orgId);
      if (!marina) return res.status(404).json({ message: "Marina not found" });

      const { rates, markPreviousAsHistorical = true } = req.body;

      if (!Array.isArray(rates) || rates.length === 0) {
        return res.status(400).json({ message: "Invalid or empty rates array" });
      }

      // If marking previous as historical, do it for each unique storage type/year combo
      if (markPreviousAsHistorical) {
        const combos = new Set(rates.map((r: any) => `${r.storageType}|${r.rateYear}`));
        for (const combo of combos) {
          const [storageType, rateYear] = combo.split('|');
          await storage.markPreviousRatesHistorical(marinaId, storageType, parseInt(rateYear), orgId);
        }
      }

      const ratesToCreate = rates.map((rate: any) => ({
        ...rate,
        marinaId,
        orgId,
        createdBy: userId,
        isCurrentRate: rate.isCurrentRate !== false
      }));

      const createdRates = await storage.bulkCreateMarinaRates(ratesToCreate);
      res.status(201).json(createdRates);
    } catch (error: any) {
      console.error("Error bulk creating marina rates:", error);
      res.status(500).json({ message: "Failed to create marina rates" });
    }
  });

  // Update a rate
  app.patch('/api/marina-rates/:id', async (req: any, res) => {
    try {
      const userId = req.user.id;
      const orgId = req.user.orgId;

      const existing = await storage.getMarinaRate(req.params.id, orgId);
      if (!existing) return res.status(404).json({ message: "Rate not found" });

      const rate = await storage.updateMarinaRate(req.params.id, { ...req.body, updatedBy: userId }, orgId);
      res.json(rate);
    } catch (error: any) {
      console.error("Error updating marina rate:", error);
      res.status(500).json({ message: "Failed to update marina rate" });
    }
  });

  // Delete a rate
  app.delete('/api/marina-rates/:id', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;

      const existing = await storage.getMarinaRate(req.params.id, orgId);
      if (!existing) return res.status(404).json({ message: "Rate not found" });

      await storage.deleteMarinaRate(req.params.id, orgId);
      res.status(204).send();
    } catch (error: any) {
      console.error("Error deleting marina rate:", error);
      res.status(500).json({ message: "Failed to delete marina rate" });
    }
  });

  // Rate Comps Analytics endpoint - returns rate tier metrics
  app.post('/api/rate-comps/analytics', async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters = req.body || {};

      const tierAnalysis = await calculateRateTierMetrics(orgId, {
        states: filters.states,
        storageTypes: filters.storageTypes,
        electricRequired: filters.electricIncluded,
        protectionLevels: filters.protectionLevels,
        sizeMin: filters.loaMin,
        sizeMax: filters.loaMax,
      });

      const stats = {
        count: tierAnalysis.overall.count,
        avgRatePerFt: tierAnalysis.overall.avgNormalizedRate / 100,
        medianRatePerFt: tierAnalysis.overall.medianNormalizedRate / 100,
        minRatePerFt: tierAnalysis.overall.minNormalizedRate / 100,
        maxRatePerFt: tierAnalysis.overall.maxNormalizedRate / 100,
        avgMonthlyRate: (tierAnalysis.overall.avgNormalizedRate / 100) * 35,
        medianMonthlyRate: (tierAnalysis.overall.medianNormalizedRate / 100) * 35,
        avgLoaSize: tierAnalysis.bySize 
          ? (tierAnalysis.bySize.small.count * 20 + tierAnalysis.bySize.medium.count * 32 + 
             tierAnalysis.bySize.large.count * 50 + tierAnalysis.bySize.mega.count * 75) / 
            (tierAnalysis.bySize.small.count + tierAnalysis.bySize.medium.count + 
             tierAnalysis.bySize.large.count + tierAnalysis.bySize.mega.count || 1)
          : 35,
        uniqueMarinas: new Set(tierAnalysis.tiers.map(t => t.rateCompId)).size,
      };

      const byState = Object.entries(tierAnalysis.byState || {}).map(([state, data]: [string, any]) => ({
        state,
        avgRatePerFt: data.avgNormalizedRate / 100,
        medianRatePerFt: data.medianNormalizedRate / 100,
        count: data.count,
      }));

      const byStorageType = Object.entries(tierAnalysis.byStorageType || {}).map(([storageType, data]: [string, any]) => ({
        storageType,
        avgRatePerFt: data.avgNormalizedRate / 100,
        medianRatePerFt: data.medianNormalizedRate / 100,
        count: data.count,
        avgMonthlyRate: (data.avgNormalizedRate / 100) * 35,
      }));

      const rateRanges = [
        { range: '$0-$10', count: 0, avgRate: 0 },
        { range: '$10-$20', count: 0, avgRate: 0 },
        { range: '$20-$30', count: 0, avgRate: 0 },
        { range: '$30-$50', count: 0, avgRate: 0 },
        { range: '$50+', count: 0, avgRate: 0 },
      ];
      
      const loaRanges = [
        { range: 'Under 25\'', count: tierAnalysis.bySize?.small.count || 0, avgRate: (tierAnalysis.bySize?.small.avgRate || 0) / 100 },
        { range: '25\'-40\'', count: tierAnalysis.bySize?.medium.count || 0, avgRate: (tierAnalysis.bySize?.medium.avgRate || 0) / 100 },
        { range: '40\'-60\'', count: tierAnalysis.bySize?.large.count || 0, avgRate: (tierAnalysis.bySize?.large.avgRate || 0) / 100 },
        { range: 'Over 60\'', count: tierAnalysis.bySize?.mega.count || 0, avgRate: (tierAnalysis.bySize?.mega.avgRate || 0) / 100 },
      ];

      tierAnalysis.tiers.forEach(t => {
        const rateDollars = t.normalizedRate / 100;
        if (rateDollars < 10) { rateRanges[0].count++; rateRanges[0].avgRate = (rateRanges[0].avgRate * (rateRanges[0].count - 1) + rateDollars) / rateRanges[0].count; }
        else if (rateDollars < 20) { rateRanges[1].count++; rateRanges[1].avgRate = (rateRanges[1].avgRate * (rateRanges[1].count - 1) + rateDollars) / rateRanges[1].count; }
        else if (rateDollars < 30) { rateRanges[2].count++; rateRanges[2].avgRate = (rateRanges[2].avgRate * (rateRanges[2].count - 1) + rateDollars) / rateRanges[2].count; }
        else if (rateDollars < 50) { rateRanges[3].count++; rateRanges[3].avgRate = (rateRanges[3].avgRate * (rateRanges[3].count - 1) + rateDollars) / rateRanges[3].count; }
        else { rateRanges[4].count++; rateRanges[4].avgRate = (rateRanges[4].avgRate * (rateRanges[4].count - 1) + rateDollars) / rateRanges[4].count; }
      });

      const seasonalityBreakdown = [
        { seasonality: 'annual', count: 0, avgRate: 0 },
        { seasonality: 'seasonal', count: 0, avgRate: 0 },
        { seasonality: 'peak', count: 0, avgRate: 0 },
      ];

      tierAnalysis.tiers.forEach(t => {
        const s = t.seasonality || 'annual';
        const rateDollars = t.normalizedRate / 100;
        const entry = seasonalityBreakdown.find(e => e.seasonality === s);
        if (entry) {
          entry.count++;
          entry.avgRate = (entry.avgRate * (entry.count - 1) + rateDollars) / entry.count;
        } else {
          seasonalityBreakdown[0].count++;
          seasonalityBreakdown[0].avgRate = (seasonalityBreakdown[0].avgRate * (seasonalityBreakdown[0].count - 1) + rateDollars) / seasonalityBreakdown[0].count;
        }
      });
      res.json({
        stats,
        byState,
        byStorageType,
        byYear: (() => {
          const byYearMap: Record<number, { rates: number[]; count: number }> = {};
          tierAnalysis.tiers.forEach((t: any) => {
            const year = t.rateYear || new Date().getFullYear();
            if (!byYearMap[year]) byYearMap[year] = { rates: [], count: 0 };
            byYearMap[year].rates.push(t.normalizedRate / 100);
            byYearMap[year].count++;
          });
          return Object.entries(byYearMap).map(([year, data]) => {
            const sorted = [...data.rates].sort((a, b) => a - b);
            const avg = data.rates.reduce((a, b) => a + b, 0) / data.rates.length;
            const median = sorted.length % 2 === 0 ? (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2 : sorted[Math.floor(sorted.length / 2)];
            return { year: parseInt(year), avgRatePerFt: avg, medianRatePerFt: median, count: data.count };
          }).sort((a, b) => a.year - b.year);
        })(),
        byBoatSize: (() => {
          const ranges = [
            { loaRange: "Under 25'", minLoa: 0, maxLoa: 25 },
            { loaRange: "25' - 35'", minLoa: 25, maxLoa: 35 },
            { loaRange: "35' - 45'", minLoa: 35, maxLoa: 45 },
            { loaRange: "45' - 60'", minLoa: 45, maxLoa: 60 },
            { loaRange: "60' - 80'", minLoa: 60, maxLoa: 80 },
