// MarinaMatch - Deal Sourcing & Prospecting Module
// ============================================================================

// Enums for MarinaMatch
export const dealSourceTypeEnum = pgEnum("deal_source_type", ["broker", "marketplace", "direct", "referral", "owned_network", "web_scrape", "cold_outreach"]);
export const feedStatusEnum = pgEnum("feed_status", ["active", "paused", "error", "pending_setup"]);
export const mandateStatusEnum = pgEnum("mandate_status", ["active", "paused", "archived"]);
export const sourcedDealStatusEnum = pgEnum("sourced_deal_status", ["new", "reviewing", "qualified", "disqualified", "converted", "duplicate"]);
export const brokerTierEnum = pgEnum("broker_tier", ["platinum", "gold", "silver", "bronze", "new"]);
export const marinaTypeEnum = pgEnum("marina_type", ["wet_slips", "dry_storage", "full_service", "yacht_club", "boatyard", "mixed_use", "commercial"]);

// Deal Sources - External feed configurations (brokers, marketplaces, etc.)
export const dealSources = pgTable("deal_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  sourceType: dealSourceTypeEnum("source_type").notNull(),
  // Feed configuration
  feedUrl: text("feed_url"), // RSS/API endpoint
  apiKey: text("api_key"), // Encrypted API key if needed
  feedFormat: text("feed_format").default("rss"), // rss, json, xml
  // Broker/source info
  brokerCompany: text("broker_company"),
  brokerContact: text("broker_contact"),
  brokerEmail: text("broker_email"),
  brokerPhone: text("broker_phone"),
  // Status & sync
  status: feedStatusEnum("status").notNull().default("pending_setup"),
  lastSyncAt: timestamp("last_sync_at"),
  lastSyncStatus: text("last_sync_status"),
  syncErrorCount: integer("sync_error_count").default(0),
  // Settings
  autoImport: boolean("auto_import").notNull().default(false),
  dedupeEnabled: boolean("dedupe_enabled").notNull().default(true),
  minDealSize: decimal("min_deal_size", { precision: 18, scale: 2 }),
  maxDealSize: decimal("max_deal_size", { precision: 18, scale: 2 }),
  targetRegions: text("target_regions").array(),
  // Metrics
  totalDealsImported: integer("total_deals_imported").default(0),
  totalDealsConverted: integer("total_deals_converted").default(0),
  // Metadata
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("deal_sources_org_idx").on(table.orgId),
  statusIdx: index("deal_sources_status_idx").on(table.status),
}));

// Investment Mandates - Define investment thesis/criteria
export const investmentMandates = pgTable("investment_mandates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  description: text("description"),
  status: mandateStatusEnum("status").notNull().default("active"),
  // Deal size criteria
  minDealSize: decimal("min_deal_size", { precision: 18, scale: 2 }),
  maxDealSize: decimal("max_deal_size", { precision: 18, scale: 2 }),
  // Geographic criteria
  targetStates: text("target_states").array(),
  targetRegions: text("target_regions").array(), // e.g., "Gulf Coast", "Great Lakes"
  coastalPreference: text("coastal_preference"), // "ocean", "lake", "river", "any"
  // Marina type criteria
  targetMarinaTypes: text("target_marina_types").array(),
  // Operational criteria
  minSlipCount: integer("min_slip_count"),
  maxSlipCount: integer("max_slip_count"),
  minOccupancy: decimal("min_occupancy", { precision: 5, scale: 2 }),
  minRevenue: decimal("min_revenue", { precision: 18, scale: 2 }),
  minNoi: decimal("min_noi", { precision: 18, scale: 2 }),
  // Cap rate / valuation criteria
  minCapRate: decimal("min_cap_rate", { precision: 5, scale: 2 }),
  maxCapRate: decimal("max_cap_rate", { precision: 5, scale: 2 }),
  // Required amenities/features
  requiredAmenities: text("required_amenities").array(),
  excludedAttributes: text("excluded_attributes").array(), // Things to avoid
  // Priority & scoring weights
  priority: integer("priority").default(1), // 1 = highest
  sizeWeight: integer("size_weight").default(20), // % weight for scoring
  locationWeight: integer("location_weight").default(25),
  typeWeight: integer("type_weight").default(15),
  operationsWeight: integer("operations_weight").default(25),
  valuationWeight: integer("valuation_weight").default(15),
  // Fund association (optional)
  fundId: varchar("fund_id").references(() => funds.id),
  // Metadata
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("investment_mandates_org_idx").on(table.orgId),
  statusIdx: index("investment_mandates_status_idx").on(table.status),
  fundIdx: index("investment_mandates_fund_idx").on(table.fundId),
}));

// Broker Relationships - Track broker contacts and performance
export const brokerRelationships = pgTable("broker_relationships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  // Broker info
  companyName: text("company_name").notNull(),
  primaryContactName: text("primary_contact_name"),
  primaryContactEmail: text("primary_contact_email"),
  primaryContactPhone: text("primary_contact_phone"),
  website: text("website"),
  // Classification
  tier: brokerTierEnum("tier").notNull().default("new"),
  specializations: text("specializations").array(), // e.g., "properties", "yacht clubs", "commercial"
  regions: text("regions").array(), // Geographic coverage
  // Relationship details
  relationshipStartDate: date("relationship_start_date"),
  lastContactDate: date("last_contact_date"),
  preferredContactMethod: text("preferred_contact_method").default("email"),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }), // Standard rate
  // Performance metrics
  totalDealsSubmitted: integer("total_deals_submitted").default(0),
  totalDealsConverted: integer("total_deals_converted").default(0),
  totalDealValue: decimal("total_deal_value", { precision: 18, scale: 2 }).default("0"),
  avgDealQuality: decimal("avg_deal_quality", { precision: 5, scale: 2 }), // 0-100 score
  // Notes & tracking
  notes: text("notes"),
  isActive: boolean("is_active").notNull().default(true),
  // Link to CRM contact if exists (stored as integer, FK added at DB level)
  crmContactId: integer("crm_contact_id"),
  // Broker Portal - shareable link for external deal submissions
  shareToken: varchar("share_token", { length: 64 }).unique(),
  portalEnabled: boolean("portal_enabled").notNull().default(false),
  portalLastAccessedAt: timestamp("portal_last_accessed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("broker_relationships_org_idx").on(table.orgId),
  tierIdx: index("broker_relationships_tier_idx").on(table.tier),
  activeIdx: index("broker_relationships_active_idx").on(table.isActive),
  shareTokenIdx: index("broker_relationships_share_token_idx").on(table.shareToken),
}));

// Sourced Deals - Incoming deals from feeds before conversion to CRM
export const sourcedDeals = pgTable("sourced_deals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  // Source tracking
  dealSourceId: varchar("deal_source_id").references(() => dealSources.id),
  brokerId: varchar("broker_id").references(() => brokerRelationships.id),
  externalId: text("external_id"), // ID from source system
  sourceUrl: text("source_url"), // Original listing URL
  // Status
  status: sourcedDealStatusEnum("status").notNull().default("new"),
  // Basic deal info
  propertyName: text("property_name").notNull(),
  propertyAddress: text("property_address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  latitude: decimal("latitude", { precision: 10, scale: 6 }),
  longitude: decimal("longitude", { precision: 10, scale: 6 }),
  // Marina details
  marinaType: marinaTypeEnum("marina_type"),
  totalSlips: integer("total_slips"),
  wetSlips: integer("wet_slips"),
  dryStorage: integer("dry_storage"),
  // Financial info
  askingPrice: decimal("asking_price", { precision: 18, scale: 2 }),
  grossRevenue: decimal("gross_revenue", { precision: 18, scale: 2 }),
  noi: decimal("noi", { precision: 18, scale: 2 }),
  capRate: decimal("cap_rate", { precision: 5, scale: 2 }),
  pricePerSlip: decimal("price_per_slip", { precision: 18, scale: 2 }),
  // Amenities & features
  amenities: text("amenities").array(),
  description: text("description"),
  // Mandate matching
  mandateScores: jsonb("mandate_scores").$type<{
    mandateId: string;
    mandateName: string;
    score: number;
    breakdown: {
      size: number;
      location: number;
      type: number;
      operations: number;
      valuation: number;
    };
  }[]>(),
  bestMandateScore: decimal("best_mandate_score", { precision: 5, scale: 2 }),
  bestMandateId: varchar("best_mandate_id"),
  // Deduplication
  dedupeHash: text("dedupe_hash"), // Hash for detecting duplicates
  isDuplicate: boolean("is_duplicate").default(false),
  duplicateOfId: varchar("duplicate_of_id"),
  // Conversion tracking (stored as integer for legacy compatibility)
  convertedToDealId: integer("converted_to_deal_id"),
  convertedAt: timestamp("converted_at"),
  convertedBy: varchar("converted_by").references(() => users.id),
  // Review tracking
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  disqualificationReason: text("disqualification_reason"),
  // Metadata
  rawData: jsonb("raw_data"), // Original data from source
  isManual: boolean("is_manual").default(false), // True if submitted via broker/manual entry
  portalSubmissionId: varchar("portal_submission_id"), // Links to broker portal submission if applicable
  importedAt: timestamp("imported_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("sourced_deals_org_idx").on(table.orgId),
  sourceIdx: index("sourced_deals_source_idx").on(table.dealSourceId),
  statusIdx: index("sourced_deals_status_idx").on(table.status),
  brokerIdx: index("sourced_deals_broker_idx").on(table.brokerId),
  mandateScoreIdx: index("sourced_deals_mandate_score_idx").on(table.bestMandateScore),
  dedupeIdx: index("sourced_deals_dedupe_idx").on(table.dedupeHash),
  stateIdx: index("sourced_deals_state_idx").on(table.state),
}));

// Deal Attribution - Track how CRM deals were sourced
export const dealAttributions = pgTable("deal_attributions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  dealId: integer("deal_id").notNull(),
  // Attribution details
  sourceType: dealSourceTypeEnum("source_type").notNull(),
  dealSourceId: varchar("deal_source_id").references(() => dealSources.id),
  brokerId: varchar("broker_id").references(() => brokerRelationships.id),
  sourcedDealId: varchar("sourced_deal_id").references(() => sourcedDeals.id),
  // For referrals
  referredBy: text("referred_by"),
  referralContact: text("referral_contact"),
  // For direct/cold outreach
  outreachCampaignId: varchar("outreach_campaign_id"),
  initialContactDate: date("initial_contact_date"),
  // Commission tracking
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }),
  commissionAmount: decimal("commission_amount", { precision: 18, scale: 2 }),
  commissionPaid: boolean("commission_paid").default(false),
  commissionPaidDate: date("commission_paid_date"),
  // Notes
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("deal_attributions_org_idx").on(table.orgId),
  dealIdx: index("deal_attributions_deal_idx").on(table.dealId),
  sourceTypeIdx: index("deal_attributions_source_type_idx").on(table.sourceType),
  brokerIdx: index("deal_attributions_broker_idx").on(table.brokerId),
}));

// Broker Activity Log - Track interactions with brokers
export const brokerActivityLog = pgTable("broker_activity_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  brokerId: varchar("broker_id").notNull().references(() => brokerRelationships.id),
  // Activity details
  activityType: text("activity_type").notNull(), // "call", "email", "meeting", "deal_submitted", etc.
  activityDate: timestamp("activity_date").notNull().defaultNow(),
  subject: text("subject"),
  description: text("description"),
  // Associated deal if any
  sourcedDealId: varchar("sourced_deal_id").references(() => sourcedDeals.id),
  dealId: integer("deal_id").references(() => crmDeals.id),
  // User tracking
  performedBy: varchar("performed_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("broker_activity_log_org_idx").on(table.orgId),
  brokerIdx: index("broker_activity_log_broker_idx").on(table.brokerId),
  dateIdx: index("broker_activity_log_date_idx").on(table.activityDate),
}));

// Broker Portal Submissions - Audit trail for external broker submissions
export const brokerPortalSubmissionStatusEnum = pgEnum("broker_portal_submission_status", ["pending", "approved", "rejected", "duplicate"]);
export const brokerPortalSubmissions = pgTable("broker_portal_submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  brokerId: varchar("broker_id").notNull().references(() => brokerRelationships.id),
  submissionToken: varchar("submission_token", { length: 64 }).notNull().unique(),
  status: brokerPortalSubmissionStatusEnum("status").notNull().default("pending"),
  // Submitted property data (before promotion to sourcedDeals)
  propertyName: text("property_name").notNull(),
  propertyAddress: text("property_address"),
  city: text("city"),
  state: text("state"),
  askingPrice: decimal("asking_price", { precision: 18, scale: 2 }),
  totalSlips: integer("total_slips"),
  grossRevenue: decimal("gross_revenue", { precision: 18, scale: 2 }),
  description: text("description"),
  contactName: text("contact_name"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  additionalNotes: text("additional_notes"),
  // Raw submission payload for audit
  rawPayload: jsonb("raw_payload"),
  // Review tracking
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  // Links to promoted deal if approved
  promotedToSourcedDealId: varchar("promoted_to_sourced_deal_id").references(() => sourcedDeals.id),
  // Metadata
  submitterIp: text("submitter_ip"),
  submitterUserAgent: text("submitter_user_agent"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("broker_portal_submissions_org_idx").on(table.orgId),
  brokerIdx: index("broker_portal_submissions_broker_idx").on(table.brokerId),
  statusIdx: index("broker_portal_submissions_status_idx").on(table.status),
  tokenIdx: index("broker_portal_submissions_token_idx").on(table.submissionToken),
}));

// Insert schemas and types for MarinaMatch
export const insertDealSourceSchema = createInsertSchema(dealSources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateDealSourceSchema = insertDealSourceSchema.partial();
export type DealSource = typeof dealSources.$inferSelect;
export type InsertDealSource = z.infer<typeof insertDealSourceSchema>;
export type UpdateDealSource = z.infer<typeof updateDealSourceSchema>;

export const insertInvestmentMandateSchema = createInsertSchema(investmentMandates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateInvestmentMandateSchema = insertInvestmentMandateSchema.partial();
export type InvestmentMandate = typeof investmentMandates.$inferSelect;
export type InsertInvestmentMandate = z.infer<typeof insertInvestmentMandateSchema>;
export type UpdateInvestmentMandate = z.infer<typeof updateInvestmentMandateSchema>;

export const mandateCriteria = pgTable("mandate_criteria", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  mandateId: varchar("mandate_id").notNull().references(() => investmentMandates.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  criteriaType: varchar("criteria_type", { length: 50 }).notNull(),
  criteriaKey: varchar("criteria_key", { length: 100 }).notNull(),
  operator: varchar("operator", { length: 20 }).notNull().default("equals"),
  criteriaValue: text("criteria_value").notNull(),
  weight: integer("weight").default(10),
  isRequired: boolean("is_required").default(false),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  mandateIdx: index("mandate_criteria_mandate_idx").on(table.mandateId),
  orgIdx: index("mandate_criteria_org_idx").on(table.orgId),
}));

export const insertMandateCriteriaSchema = createInsertSchema(mandateCriteria).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMandateCriteriaSchema = insertMandateCriteriaSchema.partial();
export type MandateCriteria = typeof mandateCriteria.$inferSelect;
export type InsertMandateCriteria = z.infer<typeof insertMandateCriteriaSchema>;
export type UpdateMandateCriteria = z.infer<typeof updateMandateCriteriaSchema>;

export const insertBrokerRelationshipSchema = createInsertSchema(brokerRelationships).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateBrokerRelationshipSchema = insertBrokerRelationshipSchema.partial();
export type BrokerRelationship = typeof brokerRelationships.$inferSelect;
export type InsertBrokerRelationship = z.infer<typeof insertBrokerRelationshipSchema>;
export type UpdateBrokerRelationship = z.infer<typeof updateBrokerRelationshipSchema>;

export const insertSourcedDealSchema = createInsertSchema(sourcedDeals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  importedAt: true,
});
export const updateSourcedDealSchema = insertSourcedDealSchema.partial();
export type SourcedDeal = typeof sourcedDeals.$inferSelect;
export type InsertSourcedDeal = z.infer<typeof insertSourcedDealSchema>;
export type UpdateSourcedDeal = z.infer<typeof updateSourcedDealSchema>;

export const insertDealAttributionSchema = createInsertSchema(dealAttributions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateDealAttributionSchema = insertDealAttributionSchema.partial();
export type DealAttribution = typeof dealAttributions.$inferSelect;
export type InsertDealAttribution = z.infer<typeof insertDealAttributionSchema>;
export type UpdateDealAttribution = z.infer<typeof updateDealAttributionSchema>;

export const insertBrokerActivityLogSchema = createInsertSchema(brokerActivityLog).omit({
  id: true,
  createdAt: true,
});
export type BrokerActivityLog = typeof brokerActivityLog.$inferSelect;
export type InsertBrokerActivityLog = z.infer<typeof insertBrokerActivityLogSchema>;

export const insertBrokerPortalSubmissionSchema = createInsertSchema(brokerPortalSubmissions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateBrokerPortalSubmissionSchema = insertBrokerPortalSubmissionSchema.partial();
export type BrokerPortalSubmission = typeof brokerPortalSubmissions.$inferSelect;
export type InsertBrokerPortalSubmission = z.infer<typeof insertBrokerPortalSubmissionSchema>;
export type UpdateBrokerPortalSubmission = z.infer<typeof updateBrokerPortalSubmissionSchema>;

// ============================================================================
// MarinaMatch Intel - Scraped Listings & Investment Criteria
// ============================================================================

export const marinaListings = pgTable("marina_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  scope: varchar("scope", { length: 20 }).default("org").notNull(),
  requiredPack: varchar("required_pack", { length: 50 }),
  isCurated: boolean("is_curated").default(false),
  curatedByUserId: varchar("curated_by_user_id"),
  curatedAt: timestamp("curated_at"),
  sourcePlatform: varchar("source_platform", { length: 100 }).notNull(),
  sourceUrl: text("source_url").notNull(),
  sourceListingId: varchar("source_listing_id"),
  scrapeRunId: varchar("scrape_run_id"),
  dedupeHash: varchar("dedupe_hash", { length: 64 }).notNull(),
  title: text("title").notNull(),
  propertyName: text("property_name"),
  propertyAddress: text("property_address"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  zipCode: varchar("zip_code", { length: 20 }),
  region: varchar("region", { length: 100 }),
  latitude: numeric("latitude", { precision: 10, scale: 7 }),
  longitude: numeric("longitude", { precision: 10, scale: 7 }),
  marinaType: varchar("marina_type", { length: 50 }),
  propertyType: varchar("property_type", { length: 50 }),
  dealType: varchar("deal_type", { length: 50 }),
  totalSlips: integer("total_slips"),
  wetSlips: integer("wet_slips"),
  dryStorageSpaces: integer("dry_storage_spaces"),
  acreage: numeric("acreage", { precision: 10, scale: 2 }),
  waterFrontage: numeric("water_frontage", { precision: 10, scale: 2 }),
  hasFuel: boolean("has_fuel").default(false),
  hasShipStore: boolean("has_ship_store").default(false),
  hasRestaurant: boolean("has_restaurant").default(false),
  hasRepairShop: boolean("has_repair_shop").default(false),
  hasDryStorage: boolean("has_dry_storage").default(false),
  hasBoatRamp: boolean("has_boat_ramp").default(false),
  amenities: jsonb("amenities"),
  askingPrice: numeric("asking_price", { precision: 15, scale: 2 }),
  pricePerSlip: numeric("price_per_slip", { precision: 12, scale: 2 }),
  grossRevenue: numeric("gross_revenue", { precision: 15, scale: 2 }),
  noi: numeric("noi", { precision: 15, scale: 2 }),
  ebitda: numeric("ebitda", { precision: 15, scale: 2 }),
  capRate: numeric("cap_rate", { precision: 5, scale: 2 }),
  occupancyRate: numeric("occupancy_rate", { precision: 5, scale: 2 }),
  status: varchar("status", { length: 30 }).default("active"),
  isFeatured: boolean("is_featured").default(false),
  isReviewed: boolean("is_reviewed").default(false),
  reviewedBy: varchar("reviewed_by"),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  bestCriteriaId: varchar("best_criteria_id"),
  bestMatchScore: integer("best_match_score"),
  matchScores: jsonb("match_scores"),
  brokerName: text("broker_name"),
  brokerCompany: text("broker_company"),
  brokerPhone: varchar("broker_phone", { length: 50 }),
  brokerEmail: varchar("broker_email", { length: 255 }),
  attributionText: text("attribution_text"),
  originalDescription: text("original_description"),
  heroImageUrl: text("hero_image_url"),
  images: jsonb("images"),
  services: text("services").array(),
  tenantSummary: text("tenant_summary"),
  extractionConfidence: integer("extraction_confidence"),
  listingDate: timestamp("listing_date"),
  lastScrapedAt: timestamp("last_scraped_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("marina_listings_org_idx").on(table.orgId),
  sourceIdx: index("marina_listings_source_idx").on(table.sourcePlatform),
  statusIdx: index("marina_listings_status_idx").on(table.status),
  stateIdx: index("marina_listings_state_idx").on(table.state),
  dedupeHashIdx: uniqueIndex("marina_listings_dedupe_hash_idx").on(table.dedupeHash),
}));

export const investmentCriteriaProfiles = pgTable("investment_criteria_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  name: varchar("name", { length: 255 }).notNull().default("Default Investment Criteria"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  isDefault: boolean("is_default").default(false),
  minMatchScoreAlert: integer("min_match_score_alert").default(70),
  locationWeight: integer("location_weight").default(20),
  financialWeight: integer("financial_weight").default(25),
  operationalWeight: integer("operational_weight").default(15),
  sizeWeight: integer("size_weight").default(15),
  capitalWeight: integer("capital_weight").default(10),
  involvementWeight: integer("involvement_weight").default(5),
  capexWeight: integer("capex_weight").default(10),

  // Enhanced Alert Settings (from guidance docs)
  alertEnabled: boolean("alert_enabled").default(true),
  alertFrequency: varchar("alert_frequency", { length: 20 }).default("daily"), // instant, daily, weekly
  alertMaxListingsPerEmail: integer("alert_max_listings_per_email").default(20),

  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("criteria_profiles_org_idx").on(table.orgId),
}));

export const investmentCriteriaLocation = pgTable("investment_criteria_location", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  targetStates: text("target_states").array(),
  targetRegions: text("target_regions").array(),
  targetMetros: text("target_metros").array(),
  excludedStates: text("excluded_states").array(),
  maxDistanceFromCoast: integer("max_distance_from_coast"),
  preferIcwAccess: boolean("prefer_icw_access").default(false),
  preferOceanAccess: boolean("prefer_ocean_access").default(false),

  // Enhanced with must-have and importance (from guidance docs)
  geographyMustHave: boolean("geography_must_have").default(true),
  geographyImportance: integer("geography_importance").default(5), // 1-5 scale

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaFinancial = pgTable("investment_criteria_financial", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Price criteria with must-have and importance
  minAskingPrice: numeric("min_asking_price", { precision: 15, scale: 2 }),
  maxAskingPrice: numeric("max_asking_price", { precision: 15, scale: 2 }),
  priceMustHave: boolean("price_must_have").default(true),
  priceImportance: integer("price_importance").default(5), // 1-5 scale

  // Revenue criteria with metric type
  minGrossRevenue: numeric("min_gross_revenue", { precision: 15, scale: 2 }),
  maxGrossRevenue: numeric("max_gross_revenue", { precision: 15, scale: 2 }),
  revenueMetricType: varchar("revenue_metric_type", { length: 20 }).default("T12"), // T12, Average3Yr, ProFormaYear1
  revenueMustHave: boolean("revenue_must_have").default(false),
  revenueImportance: integer("revenue_importance").default(3),

  // Cap Rate with type selection
  minCapRate: numeric("min_cap_rate", { precision: 5, scale: 2 }),
  maxCapRate: numeric("max_cap_rate", { precision: 5, scale: 2 }),
  capRateType: varchar("cap_rate_type", { length: 20 }).default("T12"), // T12, ProFormaYear1, Stabilized
  capRateMustHave: boolean("cap_rate_must_have").default(false),
  capRateImportance: integer("cap_rate_importance").default(4),

  // EBITDA criteria
  minEbitda: numeric("min_ebitda", { precision: 15, scale: 2 }),
  maxEbitda: numeric("max_ebitda", { precision: 15, scale: 2 }),
  ebitdaMetricType: varchar("ebitda_metric_type", { length: 20 }).default("T12"),
  ebitdaMustHave: boolean("ebitda_must_have").default(false),
  ebitdaImportance: integer("ebitda_importance").default(3),

  // NOI criteria
  minNoi: numeric("min_noi", { precision: 15, scale: 2 }),
  maxNoi: numeric("max_noi", { precision: 15, scale: 2 }),
  noiMustHave: boolean("noi_must_have").default(false),
  noiImportance: integer("noi_importance").default(3),

  // Operating Margin (EBITDA/Revenue as decimal, e.g., 0.25 = 25%)
  minOperatingMargin: numeric("min_operating_margin", { precision: 5, scale: 4 }),
  maxOperatingMargin: numeric("max_operating_margin", { precision: 5, scale: 4 }),
  operatingMarginMustHave: boolean("operating_margin_must_have").default(false),
  operatingMarginImportance: integer("operating_margin_importance").default(4),

  // Price per slip criteria
  minPricePerSlip: numeric("min_price_per_slip", { precision: 12, scale: 2 }),
  maxPricePerSlip: numeric("max_price_per_slip", { precision: 12, scale: 2 }),
  pricePerSlipMustHave: boolean("price_per_slip_must_have").default(false),
  pricePerSlipImportance: integer("price_per_slip_importance").default(2),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaOperational = pgTable("investment_criteria_operational", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  targetMarinaTypes: text("target_marina_types").array(),
  targetPropertyTypes: text("target_property_types").array(),
  minOccupancyRate: numeric("min_occupancy_rate", { precision: 5, scale: 2 }),
  requireFuelDock: boolean("require_fuel_dock").default(false),
  requireShipStore: boolean("require_ship_store").default(false),
  requireRepairShop: boolean("require_repair_shop").default(false),
  requireRestaurant: boolean("require_restaurant").default(false),
  requireDryStorage: boolean("require_dry_storage").default(false),
  requireBoatRamp: boolean("require_boat_ramp").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaSize = pgTable("investment_criteria_size", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  minTotalSlips: integer("min_total_slips"),
  maxTotalSlips: integer("max_total_slips"),
  minWetSlips: integer("min_wet_slips"),
  maxWetSlips: integer("max_wet_slips"),
  minDryStorage: integer("min_dry_storage"),
  maxDryStorage: integer("max_dry_storage"),
  minAcreage: numeric("min_acreage", { precision: 10, scale: 2 }),
  maxAcreage: numeric("max_acreage", { precision: 10, scale: 2 }),
  minWaterFrontage: numeric("min_water_frontage", { precision: 10, scale: 2 }),
  maxWaterFrontage: numeric("max_water_frontage", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaCapital = pgTable("investment_criteria_capital", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  totalCapitalAvailable: numeric("total_capital_available", { precision: 15, scale: 2 }),
  maxEquityPerDeal: numeric("max_equity_per_deal", { precision: 15, scale: 2 }),
  targetLtvRatio: numeric("target_ltv_ratio", { precision: 5, scale: 2 }),
  preferredDebtType: varchar("preferred_debt_type", { length: 50 }),
  minCashOnCashReturn: numeric("min_cash_on_cash_return", { precision: 5, scale: 2 }),
  minIrrTarget: numeric("min_irr_target", { precision: 5, scale: 2 }),
  targetHoldPeriod: integer("target_hold_period"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaInvolvement = pgTable("investment_criteria_involvement", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  involvementLevel: varchar("involvement_level", { length: 30 }),
  requireManagementInPlace: boolean("require_management_in_place").default(false),
  willingToRelocate: boolean("willing_to_relocate").default(false),
  maxTravelDistance: integer("max_travel_distance"),
  hoursPerWeekAvailable: integer("hours_per_week_available"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaCapex = pgTable("investment_criteria_capex", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  deferredMaintenanceTolerance: varchar("deferred_maintenance_tolerance", { length: 30 }),
  maxCapexBudget: numeric("max_capex_budget", { precision: 15, scale: 2 }),
  capexAsPercentOfPurchase: numeric("capex_as_percent_of_purchase", { precision: 5, scale: 2 }),
  preferTurnkey: boolean("prefer_turnkey").default(true),
  willingToRenovate: boolean("willing_to_renovate").default(false),
  environmentalIssuesOk: boolean("environmental_issues_ok").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ============================================================================
// Storage Revenue Mix Criteria - Per guidance docs
// Allows user to define which departments count as "storage" and min/max % share
// ============================================================================
export const investmentCriteriaStorageMix = pgTable("investment_criteria_storage_mix", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Which departments to include in the "Storage" bucket
  // Default: Wet Slips, Lift Slips, Dry Racks, Moorings, Trailer Storage, Indoor Storage
  includedDepartments: jsonb("included_departments").default(sql`'["Wet Slips", "Lift Slips", "Dry Racks", "Moorings", "Trailer Storage", "Indoor Storage"]'::jsonb`),

  // Min/max % of total revenue from storage departments (0-1 as decimal)
  minStorageShare: numeric("min_storage_share", { precision: 5, scale: 4 }),
  maxStorageShare: numeric("max_storage_share", { precision: 5, scale: 4 }),

  // Hard filter or soft preference
  storageMixMustHave: boolean("storage_mix_must_have").default(true),
  storageMixImportance: integer("storage_mix_importance").default(5), // 1-5 scale

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ============================================================================
// Department Configuration - Exclusions, Preferences, Max Share Limits
// Per guidance docs: allow user to exclude, prefer, or cap certain revenue segments
// ============================================================================
export const investmentCriteriaDepartments = pgTable("investment_criteria_departments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Departments to exclude entirely (hard filter)
  // Example: ["Boat Sales", "F&B"]
  excludedDepartments: jsonb("excluded_departments").default(sql`'[]'::jsonb`),

  // Departments that increase score if present
  // Example: ["Fuel", "Ship Store"]
  preferredDepartments: jsonb("preferred_departments").default(sql`'[]'::jsonb`),

  // Max allowed revenue share per department (soft cap with score penalty)
  // Example: { "Boat Sales": 0.10, "F&B": 0.20 }
  maxSharePerDepartment: jsonb("max_share_per_department").default(sql`'{}'::jsonb`),

  // How strictly to enforce exclusions
  excludeMode: varchar("exclude_mode", { length: 20 }).default("reject"), // reject = hard, penalize = soft
  excludeThreshold: numeric("exclude_threshold", { precision: 5, scale: 4 }).default("0.01"), // Revenue % threshold to trigger exclusion

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ============================================================================
// Storage Types & Rates Criteria - Per guidance docs
// Define desired storage types and minimum rates per type
// ============================================================================
export const investmentCriteriaStorageTypes = pgTable("investment_criteria_storage_types", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Desired storage types
  // Example: ["Wet Slips", "Lift Slips", "Dry Racks"]
  desiredTypes: jsonb("desired_types").default(sql`'["Wet Slips"]'::jsonb`),

  // Minimum total slip/storage count across all types
  minTotalSlips: integer("min_total_slips"),

  // Minimum rates per storage type (JSONB array of objects)
  // Example: [{ "type": "Wet Slips", "minRate": 18, "basis": "$/ft/month" }]
  storageRates: jsonb("storage_rates").default(sql`'[]'::jsonb`),

  // Scoring settings
  storageTypesMustHave: boolean("storage_types_must_have").default(false),
  storageTypesImportance: integer("storage_types_importance").default(3),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const marinaMatchGoals = pgTable("marina_match_goals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  goalType: varchar("goal_type", { length: 50 }).notNull(),
  goalName: varchar("goal_name", { length: 255 }).notNull(),
  targetValue: numeric("target_value", { precision: 15, scale: 2 }).notNull(),
  currentValue: numeric("current_value", { precision: 15, scale: 2 }).default("0"),
  timePeriod: varchar("time_period", { length: 30 }),
  startDate: date("start_date"),
  endDate: date("end_date"),
  priority: integer("priority").default(0),
  isPrimary: boolean("is_primary").default(false),
  displayFormat: varchar("display_format", { length: 30 }).default("number"),
  color: varchar("color", { length: 20 }),
  isActive: boolean("is_active").default(true),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("goals_org_idx").on(table.orgId),
}));

export const marinaMatchGoalProgress = pgTable("marina_match_goal_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  goalId: varchar("goal_id").notNull().references(() => marinaMatchGoals.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  recordedValue: numeric("recorded_value", { precision: 15, scale: 2 }).notNull(),
  recordedAt: timestamp("recorded_at").notNull().defaultNow(),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const marinaScrapeources = pgTable("marina_scrape_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  scope: varchar("scope", { length: 20 }).default("org").notNull(),
  isGlobalSource: boolean("is_global_source").default(false),
  platform: varchar("platform", { length: 100 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  baseUrl: text("base_url"),
  searchUrl: text("search_url"),
  config: jsonb("config"),
  rateLimitRpm: integer("rate_limit_rpm").default(30),
  respectRobotsTxt: boolean("respect_robots_txt").default(true),
  userAgent: varchar("user_agent", { length: 255 }).default("MarinaMatchBot/1.0"),
  isActive: boolean("is_active").default(true),
  isManaged: boolean("is_managed").default(false), // True for system-created default sources

  // Ingestion method configuration
  ingestionMethod: varchar("ingestion_method", { length: 30 }).default("scraping"), // api, feed, scraping, manual, rss

  // Search/filter configuration for marina listings
  propertyType: varchar("property_type", { length: 50 }).default("marina"),
  keywordsInclude: text("keywords_include").array().default(sql`ARRAY['marina', 'boatyard', 'yacht club', 'boat slip', 'dock', 'waterfront marina']`),
  keywordsExclude: text("keywords_exclude").array().default(sql`ARRAY['rv storage', 'self-storage', 'warehouse', 'mini storage']`),

  // Geography filters
  geographyStates: text("geography_states").array(), // Array of state abbreviations to filter
  geographyRegion: varchar("geography_region", { length: 100 }), // Optional region name
  geographyRadius: numeric("geography_radius", { precision: 10, scale: 2 }), // Radius in miles from center point

  // Price and size filters
  minPrice: numeric("min_price", { precision: 15, scale: 2 }),
  maxPrice: numeric("max_price", { precision: 15, scale: 2 }),
  minSlips: integer("min_slips"),
  maxSlips: integer("max_slips"),

  // Polling configuration
  pollingIntervalMinutes: integer("polling_interval_minutes").default(60),

  // Multi-page crawl configuration
  seedUrls: text("seed_urls").array(), // Multiple starting URLs for crawling
  crawlMode: varchar("crawl_mode", { length: 30 }).default("single"), // single, pagination, multi_seed, sitemap
  paginationSelector: varchar("pagination_selector", { length: 255 }), // CSS selector for "Next" button/link
  paginationUrlPattern: varchar("pagination_url_pattern", { length: 500 }), // URL pattern with {page} placeholder
  listingLinkSelector: varchar("listing_link_selector", { length: 255 }), // CSS selector to find listing detail links
  maxPagesPerRun: integer("max_pages_per_run").default(10), // Limit pages crawled per run
  maxCrawlDepth: integer("max_crawl_depth").default(1), // How many link levels to follow
  tokenBudgetPerRun: numeric("token_budget_per_run", { precision: 10, scale: 4 }).default("0.50"), // Max $ to spend on AI per run

  // Delta tracking for detecting new/updated listings
  lastSeenListingId: varchar("last_seen_listing_id", { length: 255 }),
  lastSeenContentHash: varchar("last_seen_content_hash", { length: 64 }),
  lastDeltaCheckAt: timestamp("last_delta_check_at"),

  // Source capabilities (what methods this source supports)
  capabilities: text("capabilities").array().default(sql`ARRAY['scraping']`), // api, scraping, rss, webhook, manual
  capabilityNotes: text("capability_notes"), // Notes about API access requirements, etc.

  // Scrape tracking
  lastScrapeAt: timestamp("last_scrape_at"),
  lastScrapeStatus: varchar("last_scrape_status", { length: 30 }),
  lastScrapeCount: integer("last_scrape_count"),
  totalListingsFound: integer("total_listings_found").default(0),

  // Source health tracking
  successCount: integer("success_count").default(0),
  failureCount: integer("failure_count").default(0),
  consecutiveFailures: integer("consecutive_failures").default(0),
  lastFailureReason: text("last_failure_reason"),
  healthStatus: varchar("health_status", { length: 20 }).default("unknown"), // unknown, healthy, warning, failing, disabled
  lastFetchMethod: varchar("last_fetch_method", { length: 20 }), // static, headless
  requiresJsRendering: boolean("requires_js_rendering").default(false), // Auto-learned preference

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("scrape_sources_org_idx").on(table.orgId),
}));

export const marinaScrapeRuns = pgTable("marina_scrape_runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  sourceId: varchar("source_id").references(() => marinaScrapeources.id, { onDelete: "set null" }),
  platform: varchar("platform", { length: 255 }).notNull(),
  status: varchar("status", { length: 30 }).notNull(),
  listingsFound: integer("listings_found").default(0),
  listingsNew: integer("listings_new").default(0),
  listingsUpdated: integer("listings_updated").default(0),
  listingsRemoved: integer("listings_removed").default(0),
  errorsCount: integer("errors_count").default(0),

  // Multi-page crawl tracking
  pagesCrawled: integer("pages_crawled").default(0),
  pagesSkipped: integer("pages_skipped").default(0),
  linksDiscovered: integer("links_discovered").default(0),
  tokensCost: numeric("tokens_cost", { precision: 10, scale: 4 }).default("0"), // Estimated $ spent on AI

  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  durationMs: integer("duration_ms"),
  errorMessage: text("error_message"),
  details: jsonb("details"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("scrape_runs_org_idx").on(table.orgId),
}));

export const marinaListingMatches = pgTable("marina_listing_matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  listingId: varchar("listing_id").notNull().references(() => marinaListings.id, { onDelete: "cascade" }),
  criteriaProfileId: varchar("criteria_profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  overallScore: integer("overall_score").notNull(),
  locationScore: integer("location_score"),
  financialScore: integer("financial_score"),
  operationalScore: integer("operational_score"),
  sizeScore: integer("size_score"),
  capitalScore: integer("capital_score"),
  involvementScore: integer("involvement_score"),
  capexScore: integer("capex_score"),
  scoreBreakdown: jsonb("score_breakdown"),
  passesHardRequirements: boolean("passes_hard_requirements").default(true),
  disqualificationReasons: jsonb("disqualification_reasons"),
  calculatedAt: timestamp("calculated_at").notNull().defaultNow(),
}, (table) => ({
  listingIdx: index("listing_matches_listing_idx").on(table.listingId),
  profileIdx: index("listing_matches_profile_idx").on(table.criteriaProfileId),
}));

export const marinaMatchAlerts = pgTable("marina_match_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  userId: varchar("user_id"),
  name: varchar("name", { length: 255 }).notNull(),
  criteriaProfileId: varchar("criteria_profile_id").references(() => investmentCriteriaProfiles.id, { onDelete: "set null" }),
  minMatchScore: integer("min_match_score").default(70),
  sendImmediately: boolean("send_immediately").default(true),
  digestFrequency: varchar("digest_frequency", { length: 20 }),
  notifyEmail: boolean("notify_email").default(true),
  notifyInApp: boolean("notify_in_app").default(true),
  emailAddresses: text("email_addresses").array(),
  isActive: boolean("is_active").default(true),
  lastSentAt: timestamp("last_sent_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("alerts_org_idx").on(table.orgId),
}));

export const marinaMatchAlertHistory = pgTable("marina_match_alert_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  alertId: varchar("alert_id").notNull().references(() => marinaMatchAlerts.id, { onDelete: "cascade" }),
  listingId: varchar("listing_id").references(() => marinaListings.id, { onDelete: "set null" }),
  orgId: varchar("org_id").notNull(),
  matchScore: integer("match_score").notNull(),
  sentAt: timestamp("sent_at").notNull().defaultNow(),
  channel: varchar("channel", { length: 20 }),
  status: varchar("status", { length: 20 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas and types for MarinaMatch Intel
export const insertMarinaListingSchema = createInsertSchema(marinaListings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastScrapedAt: true,
});
export const updateMarinaListingSchema = insertMarinaListingSchema.partial();
export type MarinaListing = typeof marinaListings.$inferSelect;
export type InsertMarinaListing = z.infer<typeof insertMarinaListingSchema>;

export const insertInvestmentCriteriaProfileSchema = createInsertSchema(investmentCriteriaProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateInvestmentCriteriaProfileSchema = insertInvestmentCriteriaProfileSchema.partial();
export type InvestmentCriteriaProfile = typeof investmentCriteriaProfiles.$inferSelect;

// Export types for new criteria tables
export type InvestmentCriteriaLocation = typeof investmentCriteriaLocation.$inferSelect;
export type InvestmentCriteriaFinancial = typeof investmentCriteriaFinancial.$inferSelect;
export type InvestmentCriteriaOperational = typeof investmentCriteriaOperational.$inferSelect;
export type InvestmentCriteriaSize = typeof investmentCriteriaSize.$inferSelect;
export type InvestmentCriteriaCapital = typeof investmentCriteriaCapital.$inferSelect;
export type InvestmentCriteriaInvolvement = typeof investmentCriteriaInvolvement.$inferSelect;
export type InvestmentCriteriaCapex = typeof investmentCriteriaCapex.$inferSelect;
export type InvestmentCriteriaStorageMix = typeof investmentCriteriaStorageMix.$inferSelect;
export type InvestmentCriteriaDepartments = typeof investmentCriteriaDepartments.$inferSelect;
export type InvestmentCriteriaStorageTypes = typeof investmentCriteriaStorageTypes.$inferSelect;
export type MarinaListingMatch = typeof marinaListingMatches.$inferSelect;

export const insertMarinaMatchGoalSchema = createInsertSchema(marinaMatchGoals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMarinaMatchGoalSchema = insertMarinaMatchGoalSchema.partial();
export type MarinaMatchGoal = typeof marinaMatchGoals.$inferSelect;

export const insertMarinaScrapeSourceSchema = createInsertSchema(marinaScrapeources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMarinaScrapeSourceSchema = insertMarinaScrapeSourceSchema.partial();
export type MarinaScrapeSource = typeof marinaScrapeources.$inferSelect;

export const insertMarinaMatchAlertSchema = createInsertSchema(marinaMatchAlerts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMarinaMatchAlertSchema = insertMarinaMatchAlertSchema.partial();
export type MarinaMatchAlert = typeof marinaMatchAlerts.$inferSelect;

// ============================================================================
// MarinaMatch Listing Feedback System
// Global feedback collection for AI training and listing quality improvement
// ============================================================================

export const listingFeedbackReasons = [
  "sold_closed",
  "under_contract", 
  "off_market",
  "duplicate_listing",
  "not_a_marina",
  "incorrect_information",
  "spam_or_fake",
  "broken_link",
  "other"
] as const;

export const marinaListingFeedback = pgTable("marina_listing_feedback", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  listingId: varchar("listing_id").notNull().references(() => marinaListings.id, { onDelete: "cascade" }),
  userId: varchar("user_id"),
  orgId: varchar("org_id"),
  reason: varchar("reason", { length: 50 }).notNull(),
  customReason: text("custom_reason"),
  details: text("details"),
  listingTitle: text("listing_title"),
  listingSource: varchar("listing_source", { length: 100 }),
  listingUrl: text("listing_url"),
  status: varchar("status", { length: 20 }).default("pending"),
  reviewedBy: varchar("reviewed_by"),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  aiPatternApplied: boolean("ai_pattern_applied").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  listingIdx: index("feedback_listing_idx").on(table.listingId),
  statusIdx: index("feedback_status_idx").on(table.status),
  reasonIdx: index("feedback_reason_idx").on(table.reason),
}));

export const marinaAiFilterPatterns = pgTable("marina_ai_filter_patterns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  patternType: varchar("pattern_type", { length: 50 }).notNull(),
  pattern: text("pattern").notNull(),
  reason: varchar("reason", { length: 50 }).notNull(),
  source: varchar("source", { length: 100 }),
  feedbackCount: integer("feedback_count").default(1),
  isActive: boolean("is_active").default(true),
  confidence: numeric("confidence", { precision: 5, scale: 2 }).default("1.00"),
  createdFromFeedbackId: varchar("created_from_feedback_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  typeIdx: index("ai_pattern_type_idx").on(table.patternType),
  activeIdx: index("ai_pattern_active_idx").on(table.isActive),
}));

export const userHiddenListings = pgTable("user_hidden_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  userId: varchar("user_id").notNull(),
  orgId: varchar("org_id").notNull(),
  listingId: varchar("listing_id").notNull().references(() => marinaListings.id, { onDelete: "cascade" }),
  reason: varchar("reason", { length: 50 }),
  hiddenAt: timestamp("hidden_at").notNull().defaultNow(),
}, (table) => ({
  userListingIdx: index("user_hidden_listing_idx").on(table.userId, table.listingId),
  orgListingIdx: index("org_hidden_listing_idx").on(table.orgId, table.listingId),
}));

export type UserHiddenListing = typeof userHiddenListings.$inferSelect;

export const insertListingFeedbackSchema = createInsertSchema(marinaListingFeedback).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});
export type ListingFeedback = typeof marinaListingFeedback.$inferSelect;
export type InsertListingFeedback = z.infer<typeof insertListingFeedbackSchema>;

export const insertAiFilterPatternSchema = createInsertSchema(marinaAiFilterPatterns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AiFilterPattern = typeof marinaAiFilterPatterns.$inferSelect;

// ============================================================================
// OM Builder Module (Offering Memorandum Builder)
// Tables for building and managing investment offering memorandums
// ============================================================================

export const omStatusEnum = pgEnum("om_status", ["draft", "review", "published", "archived"]);
export const omDocTypeEnum = pgEnum("om_doc_type", ["om", "executive_summary", "ic_memo", "pitch_deck"]);
export const omTemplateScopeEnum = pgEnum("om_template_scope", ["block", "page", "om"]);
export const omTemplateOwnerTypeEnum = pgEnum("om_template_owner_type", ["global", "org", "user"]);
export const omDatasetTypeEnum = pgEnum("om_dataset_type", ["underwriting", "sales_comps", "rent_comps", "market", "demographics", "custom"]);

export const oms = pgTable("oms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  projectId: varchar("project_id").notNull(),
  organizationId: varchar("organization_id"),
  dealId: varchar("deal_id").references(() => crmDeals.id, { onDelete: 'set null' }),
  modelingProjectId: varchar("modeling_project_id").references(() => modelingProjects.id, { onDelete: 'set null' }),
  name: text("name").notNull(),
  docType: omDocTypeEnum("doc_type").notNull().default('om'),
