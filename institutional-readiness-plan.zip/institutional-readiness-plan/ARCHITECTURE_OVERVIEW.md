# Marinalytics Platform - Architecture Overview

**Generated:** February 2026  
**Purpose:** Reference documentation for institutional readiness implementation

---

## Application Summary

**Marinalytics** is a comprehensive marina management and investment analysis platform built on a modern full-stack JavaScript architecture. Development began September 2025, with ongoing activity through February 2026 (approximately 7,500 commits across 6 months of development).

---

## Technology Stack

| Layer | Technology |
|-------|------------|
| **Frontend** | React 18, TypeScript, Vite, TailwindCSS, shadcn/ui |
| **Backend** | Node.js, Express, TypeScript |
| **Database** | PostgreSQL (Neon-backed via Replit) |
| **ORM** | Drizzle ORM |
| **State Management** | TanStack Query (React Query v5), Zustand |
| **Authentication** | Session-based with Replit Auth integration |
| **Rate Limiting** | express-rate-limit (in-memory + optional Redis via ioredis) |
| **Logging** | Pino with pino-pretty |
| **File Storage** | Local uploads directory (with S3 migration utility available) |
| **Real-time** | WebSocket (DockTalk module) |

---

## Directory Structure

```
marinalytics/
├── client/                      # Frontend application
│   ├── src/
│   │   ├── App.tsx              # Main app router (68k lines)
│   │   ├── components/          # Reusable UI components
│   │   ├── pages/               # Route-level page components
│   │   ├── hooks/               # Custom React hooks
│   │   ├── lib/                 # Utility libraries
│   │   ├── contexts/            # React context providers
│   │   ├── stores/              # Zustand stores
│   │   ├── types/               # TypeScript type definitions
│   │   └── config/              # Frontend configuration
│   └── replit_integrations/     # Replit-specific integrations
│
├── server/                      # Backend application
│   ├── index.ts                 # Express app entry point
│   ├── routes.ts                # Main API routes (33k lines)
│   ├── storage.ts               # Data access layer (327k lines)
│   ├── db.ts                    # Database connection
│   │
│   ├── middleware/              # Express middleware
│   │   ├── authorization.ts     # Permission checking
│   │   ├── auth-resolver.ts     # Authentication resolution
│   │   ├── csrf.ts              # CSRF protection
│   │   ├── error-handler.ts     # Centralized error handling
│   │   ├── file-security.ts     # File upload security
│   │   ├── input-validation.ts  # Request validation
│   │   ├── logging.ts           # Request logging
│   │   ├── rate-limiting.ts     # Rate limiting (Redis)
│   │   ├── rbac.ts              # Role-based access control
│   │   ├── security.ts          # Security headers
│   │   ├── session-management.ts# Session handling
│   │   ├── tenant-context.ts    # Multi-tenant context
│   │   ├── tenant-isolation.ts  # Tenant data isolation
│   │   ├── validate.ts          # Input validation
│   │   └── webhook-security.ts  # Webhook verification
│   │
│   ├── lib/                     # Server utilities
│   │   ├── logger.ts            # Pino logger config
│   │   └── leases/              # Lease calculation utilities
│   │
│   ├── services/                # Business logic services
│   │   ├── ai/                  # AI/LLM integrations
│   │   ├── analytics/           # Analytics & reporting
│   │   ├── capital-markets/     # Capital markets features
│   │   ├── crm/                 # CRM functionality
│   │   ├── document-builder/    # Document generation
│   │   ├── finance-kernel/      # Financial calculations
│   │   ├── financial/           # Financial analysis
│   │   ├── fuel/                # Fuel management
│   │   ├── pnl/                 # P&L tracking
│   │   ├── ratecomps/           # Rate comparables
│   │   ├── rent-roll-v2/        # Rent roll management
│   │   ├── salescomps/          # Sales comparables
│   │   └── opssos/              # Operations SOS
│   │
│   ├── routes/                  # Modular route handlers
│   │   ├── settings-routes.ts
│   │   ├── leases.ts
│   │   └── wizard-drafts.ts
│   │
│   ├── docktalk/                # Real-time chat module
│   ├── marinamatch/             # Marina matching service
│   ├── integrations/            # Third-party integrations
│   └── security/                # Security utilities
│
├── shared/                      # Shared code between client/server
│   ├── schema.ts                # Drizzle schema (24k lines)
│   ├── models/                  # Shared data models
│   ├── utils/                   # Shared utilities
│   └── exit/                    # Exit strategy calculations
│
└── attached_assets/             # User-provided assets
```

---

## Key Files by Size

| File | Lines | Purpose |
|------|-------|---------|
| `server/storage.ts` | 327,233 | Data access layer, all CRUD operations |
| `client/src/App.tsx` | 68,808 | Main React app with all routes |
| `client/src/index.css` | 34,812 | Global styles and theme |
| `server/routes.ts` | 32,887 | All API route handlers |
| `shared/schema.ts` | 23,595 | Drizzle ORM schema definitions |

---

## Security Infrastructure (Already Implemented)

### Rate Limiting (`server/middleware/security.ts` + `rate-limiting.ts`)
Primary rate limits configured in `security.ts`:
- Global API: 300 requests/15 minutes
- Login: 10 attempts/15 minutes
- Registration: 5 attempts/hour

Advanced Redis-backed rate limiting available in `rate-limiting.ts` (optional):
- AI endpoints: 10 requests/minute
- Uploads: 20/hour
- Exports: 5/hour

### CSRF Protection (`server/middleware/csrf.ts`)
- Token rotation on each state-changing request
- Timing-safe comparison
- Exemptions for webhooks and auth endpoints

### RBAC (`server/middleware/rbac.ts`)
- 5 roles: owner, admin, editor, viewer, auditor
- 18+ granular permissions
- Database-backed role assignments

### Tenant Isolation (`server/middleware/tenant-isolation.ts`)
- Automatic orgId injection on mutations
- Cross-tenant access prevention
- Violation logging

### Logging (`server/lib/logger.ts`)
- Pino structured logging
- PII redaction (passwords, tokens, cookies)
- Request ID tracking
- Child loggers for context

### Error Handling (`server/middleware/error-handler.ts`)
- Custom error classes (ValidationError, AuthError, etc.)
- Zod error formatting
- Request ID in all error responses
- Stack traces hidden in production

### Audit Logging (`server/audit-middleware.ts`)
- Before/after state tracking
- Change diff detection
- IP and user agent logging

---

## Database Schema Highlights

The schema includes tables for:

**Core Entities:**
- Organizations (multi-tenant)
- Users & Roles
- Projects (valuations)

**Valuator Module:**
- Properties, Units, Leases
- Rent rolls, Operating expenses
- Capital improvements

**CRM:**
- Contacts, Companies, Deals
- Activities, Tasks

**Finance:**
- Fuel transactions
- P&L tracking
- Capital markets data

**Documents:**
- VDR (Virtual Data Room)
- Document reconciliation
- File metadata

**Audit:**
- Audit logs
- Session logs
- Notifications

---

## Background Services

The application initializes several background services on startup (see `server/index.ts`):

1. **Deadline Monitor** (`deadline-monitor.ts`) - Tracks and alerts on deadlines
2. **Reconciliation Service** (`reconciliation-service.ts`) - Document reconciliation
3. **VDR File Service** (`vdr-file-service.ts`) - Virtual data room file management
4. **DockTalk Cron Jobs** (`docktalk/cron-jobs.ts`) - Background tasks for chat module
5. **MarinaMatch Intel** (`marinamatch/services/intel-cron.ts`) - Market intelligence
6. **Listing Scheduler** (`marinamatch/services/listing-scheduler.ts`) - Listing data collection
7. **Integration Catalog** - Seeds integration configurations on startup

---

## API Patterns

### Authentication Flow
1. User authenticates via Replit Auth
2. Session created with userId and orgId
3. All API requests include session cookie
4. `authResolver()` middleware extracts user/org from session
5. `requireAuth()` middleware enforces authentication on protected routes

### Request Flow (as configured in security.ts and index.ts)
```
Request → Helmet → CORS → Cookie Parser → Rate Limit → CSRF → Auth Resolver → Route Handler → Response
                                                                                      ↓
                                                                                 Audit Log
```

### Response Patterns
Currently inconsistent - some routes return raw data, others wrap in envelopes.

**Target format:**
```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "requestId": "...",
    "page": 1,
    "limit": 50,
    "total": 100
  }
}
```

---

## Integration Points

### External Services
- **Stripe** - Payment processing (webhook endpoint ready)
- **SendGrid** - Email delivery
- **OpenAI** - AI/LLM features
- **Google Calendar** - Calendar integration

### Replit Integrations
- Database (PostgreSQL)
- Auth (Log in with Replit)
- Object Storage (S3-compatible)

---

## Testing Coverage

**Existing Tests:**
- `financial-validators.test.ts`
- `exit-strategy-calculator.test.ts`
- `critical-path.test.ts`
- `import-validators.test.ts`
- `sensitivity-matrix-service.test.ts`
- `seasonality-profile-service.test.ts`
- `debt-schedule-service.test.ts`
- `scenario-governance-service.test.ts`
- `modeling-periods.test.ts`

**Gaps:**
- Security middleware tests
- API route integration tests
- End-to-end tests

---

## Notes for Implementation

1. **Large Files Warning**: `routes.ts` and `storage.ts` are very large. Consider modularizing before adding new features.

2. **Schema Changes**: Any schema changes require Drizzle migrations. Use `npx drizzle-kit push:pg` carefully.

3. **Rate Limiting Dependency**: Rate limiting requires Redis. Ensure `REDIS_URL` is configured in production.

4. **Multi-tenant Architecture**: All queries should filter by `orgId`. The tenant isolation middleware helps but doesn't cover all edge cases.

5. **WebSocket**: DockTalk WebSocket is disabled in development to avoid conflicts with Vite HMR.
