# Institutional-Grade Readiness Action Plan

**Generated:** February 2026  
**Target Application:** Marinalytics Platform  
**Current State:** Production-ready with substantial security infrastructure already in place

---

## Executive Summary

This action plan identifies gaps and provides detailed implementation guidance for achieving institutional-grade readiness. The application already has **strong foundational security**, including rate limiting, CSRF protection, RBAC, tenant isolation, structured logging, and audit trails.

### Current Infrastructure Strengths ✅
- Rate limiting via express-rate-limit (300/15min global, 10/15min login, 5/hr registration)
- Full CSRF protection with server-side validation and token rotation
- Role-Based Access Control (RBAC) with 5 roles (owner, admin, editor, viewer, auditor) and 18+ permissions
- Multi-tenant isolation middleware with org ID enforcement
- Structured logging with Pino (includes automatic PII redaction)
- Centralized error handling with custom error classes (AppError, ValidationError, etc.)
- Audit logging with before/after tracking and diff detection

### Remaining Gaps to Address
The gaps below are organized by priority and effort level.

---

## PRIORITY 1: CRITICAL SECURITY GAPS

### 1.1 Consistent Backend Authorization Enforcement

**Gap:** Not all API routes consistently apply authentication and authorization middleware.

**Current State:**
- `authResolver()` and `requireAuth()` middleware exist in `auth-resolver.ts`
- Security middleware is configured in `security.ts` (Helmet, CORS, rate limiting, CSRF)
- Some routes in the large `routes.ts` file may lack consistent protection

**Action Items:**

```typescript
// server/routes.ts - Apply global auth to all /api routes
import { authResolver, requireAuth, isPublicRoute } from './middleware/auth-resolver';
import { requireTenantMatch } from './middleware/tenant-isolation';

export function registerRoutes(app: Express) {
  // Public routes (before auth middleware) - defined in auth-resolver.ts publicRoutes Set
  app.get('/health', healthCheck);
  
  // Apply auth resolver to extract user/org from session
  app.use('/api', authResolver());
  
  // Apply auth requirement to non-public routes
  app.use('/api', (req, res, next) => {
    if (isPublicRoute(req.path)) return next();
    return requireAuth()(req, res, next);
  });
  
  // Apply tenant isolation
  app.use('/api', requireTenantMatch);
  
  // All protected routes below this line
  // ...existing routes
}
```

**Audit Checklist:**
- [ ] Run grep to find all `app.get`, `app.post`, `app.put`, `app.patch`, `app.delete` in routes.ts
- [ ] Verify each route has appropriate middleware chain
- [ ] Create a route security matrix documenting which middleware applies to each route
- [ ] Add integration tests for auth on each route

**Acceptance Criteria:**
- Every non-public route returns 401 without valid auth token
- Every route with orgId parameter validates tenant ownership
- Security matrix document exists and is kept updated

---

### 1.2 File Upload Security

**Gap:** File uploads may lack comprehensive validation (size, type, malware scanning).

**Current Location:** `server/security/file-upload-security.ts`, `server/middleware/file-security.ts`

**Required Enhancements:**

```typescript
// server/middleware/file-security.ts - Enhanced version
import { Request, Response, NextFunction } from 'express';
import { createHash } from 'crypto';
import path from 'path';

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const ALLOWED_EXTENSIONS = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.csv', '.jpg', '.jpeg', '.png'];
const BLOCKED_EXTENSIONS = ['.exe', '.bat', '.cmd', '.sh', '.ps1', '.js', '.php'];

const MAGIC_NUMBERS: Record<string, string> = {
  'application/pdf': '255044462d',
  'image/jpeg': 'ffd8ffe0',
  'image/png': '89504e47',
  'application/zip': '504b0304',
};

export interface FileSecurityOptions {
  maxSize?: number;
  allowedTypes?: string[];
  scanForMalware?: boolean;
}

export function validateFileUpload(options: FileSecurityOptions = {}) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const file = req.file;
    if (!file) return next();

    const maxSize = options.maxSize || MAX_FILE_SIZE;
    
    // 1. Size check
    if (file.size > maxSize) {
      return res.status(413).json({
        error: 'File too large',
        code: 'FILE_TOO_LARGE',
        maxSize: maxSize,
      });
    }

    // 2. Extension check
    const ext = path.extname(file.originalname).toLowerCase();
    if (BLOCKED_EXTENSIONS.includes(ext)) {
      return res.status(400).json({
        error: 'File type not allowed',
        code: 'BLOCKED_FILE_TYPE',
      });
    }

    // 3. Magic number validation (content-type spoofing prevention)
    const buffer = file.buffer.slice(0, 10);
    const hex = buffer.toString('hex');
    const declaredType = file.mimetype;
    const expectedMagic = MAGIC_NUMBERS[declaredType];
    
    if (expectedMagic && !hex.startsWith(expectedMagic)) {
      return res.status(400).json({
        error: 'File content does not match declared type',
        code: 'CONTENT_TYPE_MISMATCH',
      });
    }

    // 4. Filename sanitization
    const sanitizedName = file.originalname
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      .substring(0, 200);
    file.originalname = sanitizedName;

    // 5. Generate content hash for deduplication/auditing
    const hash = createHash('sha256').update(file.buffer).digest('hex');
    (req as any).fileHash = hash;

    next();
  };
}
```

**Acceptance Criteria:**
- [ ] All file upload endpoints use `validateFileUpload` middleware
- [ ] Files exceeding size limits are rejected with clear error
- [ ] Blocked file types return 400 error
- [ ] Magic number validation prevents content-type spoofing
- [ ] All uploaded files are logged with hash for audit trail

---

### 1.3 API Security Headers

**Gap:** Verify all security headers are properly configured.

**Location:** `server/middleware/security.ts`

**Required Configuration:**

```typescript
// server/middleware/security.ts - Verify these are present
import helmet from 'helmet';

export function configureSecurityMiddleware(app: Express) {
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"], // Adjust for your needs
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "wss:", "https:"],
        frameSrc: ["'none'"],
        objectSrc: ["'none'"],
      },
    },
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
      preload: true,
    },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    permittedCrossDomainPolicies: { permittedPolicies: 'none' },
    xssFilter: true,
    noSniff: true,
    ieNoOpen: true,
    frameguard: { action: 'deny' },
  }));
  
  // Additional custom headers
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Request-Id', req.requestId || 'unknown');
    res.removeHeader('X-Powered-By');
    next();
  });
}
```

---

## PRIORITY 2: OBSERVABILITY & MONITORING

### 2.1 External Log Aggregation

**Gap:** Logs go to console only; need external sink for production monitoring.

**Implementation Options:**

Option A: **Datadog Integration**
```typescript
// server/lib/logger.ts - Add Datadog transport
import pino from 'pino';

const transport = pino.transport({
  targets: [
    // Console (dev only)
    ...(isDevelopment() ? [{
      target: 'pino-pretty',
      options: { colorize: true },
    }] : []),
    // Datadog (production)
    ...(!isDevelopment() ? [{
      target: 'pino-datadog-transport',
      options: {
        apiKey: process.env.DD_API_KEY,
        service: 'marinalytics',
        env: process.env.NODE_ENV,
      },
    }] : []),
  ],
});
```

Option B: **Self-hosted ELK Stack via Loki**
```typescript
// Using pino-loki
import pino from 'pino';

const transport = pino.transport({
  target: 'pino-loki',
  options: {
    host: process.env.LOKI_URL,
    labels: { job: 'marinalytics', env: process.env.NODE_ENV },
  },
});
```

**Acceptance Criteria:**
- [ ] Production logs are shipped to external aggregator
- [ ] Logs are searchable by requestId, userId, tenantId
- [ ] PII redaction is verified in external logs
- [ ] Log retention policy is defined (recommend: 90 days)

---

### 2.2 Application Performance Monitoring (APM)

**Gap:** No tracing or APM for debugging distributed issues.

**Implementation:**

```typescript
// server/lib/tracing.ts - OpenTelemetry setup
import { NodeSDK } from '@opentelemetry/sdk-node';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';

const sdk = new NodeSDK({
  traceExporter: new OTLPTraceExporter({
    url: process.env.OTEL_EXPORTER_ENDPOINT,
  }),
  instrumentations: [
    getNodeAutoInstrumentations({
      '@opentelemetry/instrumentation-express': { enabled: true },
      '@opentelemetry/instrumentation-pg': { enabled: true },
      '@opentelemetry/instrumentation-http': { enabled: true },
    }),
  ],
});

sdk.start();

process.on('SIGTERM', () => {
  sdk.shutdown().then(() => process.exit(0));
});
```

---

### 2.3 Health Check Enhancements

**Gap:** Health checks exist but may not cover all dependencies.

```typescript
// server/routes/health.ts - Comprehensive health checks
import { Router } from 'express';
import { db } from '../db';
// Note: If using Redis for rate limiting, import from rate-limiting.ts:
// import { rateLimitRedis } from '../middleware/rate-limiting';

const router = Router();

router.get('/health/ready', async (req, res) => {
  const checks = {
    database: false,
    redis: false,
    timestamp: new Date().toISOString(),
  };

  try {
    // Database check
    await db.execute('SELECT 1');
    checks.database = true;
  } catch (e) {
    checks.database = false;
  }

  try {
    // Redis check
    await rateLimitRedis.ping();
    checks.redis = true;
  } catch (e) {
    checks.redis = false;
  }

  const allHealthy = Object.values(checks).every(v => v === true || typeof v === 'string');
  
  res.status(allHealthy ? 200 : 503).json({
    status: allHealthy ? 'healthy' : 'unhealthy',
    checks,
  });
});

router.get('/health/live', (req, res) => {
  res.status(200).json({ status: 'alive' });
});

export default router;
```

---

## PRIORITY 3: API STANDARDS & CONSISTENCY

### 3.1 API Versioning

**Gap:** No API versioning strategy; breaking changes will affect all clients.

**Implementation:**

```typescript
// server/routes/v1/index.ts - Versioned API router
import { Router } from 'express';

const v1Router = Router();

// Mount all v1 routes
v1Router.use('/projects', projectRoutes);
v1Router.use('/valuator', valuatorRoutes);
v1Router.use('/crm', crmRoutes);
// ...

export default v1Router;

// server/index.ts - Mount versioned routes
app.use('/api/v1', v1Router);

// Deprecated routes (with warning header)
app.use('/api', (req, res, next) => {
  res.setHeader('Deprecation', 'true');
  res.setHeader('Sunset', '2026-12-31');
  next();
}, v1Router);
```

---

### 3.2 Standardized Response Envelope

**Gap:** Response formats vary across endpoints.

```typescript
// server/lib/response.ts - Standard response helpers
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    requestId?: string;
  };
}

export function success<T>(res: Response, data: T, meta?: ApiResponse<T>['meta']) {
  return res.json({
    success: true,
    data,
    meta: {
      ...meta,
      requestId: (res.req as any).requestId,
    },
  });
}

export function paginated<T>(
  res: Response,
  items: T[],
  page: number,
  limit: number,
  total: number
) {
  return res.json({
    success: true,
    data: items,
    meta: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      requestId: (res.req as any).requestId,
    },
  });
}

export function error(res: Response, statusCode: number, code: string, message: string, details?: unknown) {
  return res.status(statusCode).json({
    success: false,
    error: { code, message, details },
    meta: { requestId: (res.req as any).requestId },
  });
}
```

---

### 3.3 Default Pagination

**Gap:** List endpoints may return unbounded results.

```typescript
// server/middleware/pagination.ts
import { Request, Response, NextFunction } from 'express';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 50;
const MAX_LIMIT = 100;

export function parsePagination(req: Request, res: Response, next: NextFunction) {
  const page = Math.max(1, parseInt(req.query.page as string) || DEFAULT_PAGE);
  const limit = Math.min(
    MAX_LIMIT,
    Math.max(1, parseInt(req.query.limit as string) || DEFAULT_LIMIT)
  );
  const offset = (page - 1) * limit;

  req.pagination = { page, limit, offset };
  next();
}

// Type augmentation
declare global {
  namespace Express {
    interface Request {
      pagination?: {
        page: number;
        limit: number;
        offset: number;
      };
    }
  }
}
```

---

## PRIORITY 4: DATA INTEGRITY & COMPLIANCE

### 4.1 Database Indexing Audit

**Gap:** Large tables may lack appropriate indexes for common query patterns.

**Action Items:**
- [ ] Review all tables with >10k rows
- [ ] Add indexes for common WHERE clauses
- [ ] Add composite indexes for JOIN patterns
- [ ] Analyze query plans for slow queries

```sql
-- Example: Add missing indexes
CREATE INDEX CONCURRENTLY idx_audit_logs_org_created 
  ON audit_logs (org_id, created_at DESC);

CREATE INDEX CONCURRENTLY idx_projects_org_status 
  ON projects (org_id, status) WHERE deleted_at IS NULL;

CREATE INDEX CONCURRENTLY idx_crm_contacts_org_email 
  ON crm_contacts (org_id, email) WHERE deleted_at IS NULL;
```

---

### 4.2 Backup & Recovery Runbook

**Gap:** No documented backup/recovery procedures.

**Required Documentation:**

```markdown
# Backup & Recovery Runbook

## Automated Backups
- Replit's managed Postgres includes automatic daily backups
- Point-in-time recovery available for last 7 days

## Manual Backup Procedure
1. Access Replit database tools
2. Export full database dump
3. Store in secure, versioned location

## Recovery Procedure
1. Use Replit's rollback feature to restore to checkpoint
2. For partial recovery, restore specific tables from backup
3. Verify data integrity after recovery

## Testing Schedule
- Monthly: Test restore to staging environment
- Quarterly: Full disaster recovery drill
```

---

### 4.3 Data Retention Policy

**Gap:** No automated cleanup of old data.

```typescript
// server/services/data-retention-service.ts
import { db } from '../db';
import { sql } from 'drizzle-orm';
import { logger } from '../lib/logger';

const RETENTION_POLICIES = {
  audit_logs: 365,        // 1 year
  session_logs: 90,       // 90 days
  notifications: 180,     // 6 months
  api_logs: 30,           // 30 days
  temp_files: 7,          // 7 days
};

export async function runDataRetention(): Promise<void> {
  for (const [table, days] of Object.entries(RETENTION_POLICIES)) {
    try {
      const result = await db.execute(sql`
        DELETE FROM ${sql.identifier(table)}
        WHERE created_at < NOW() - INTERVAL '${days} days'
        RETURNING id
      `);
      
      logger.info({
        type: 'data_retention',
        table,
        deletedCount: result.rowCount,
        retentionDays: days,
      });
    } catch (error) {
      logger.error({ error, table }, 'Data retention job failed');
    }
  }
}

// Schedule: Run daily at 3 AM
```

---

## PRIORITY 5: TESTING & QUALITY

### 5.1 Test Coverage Expansion

**Current Tests:**
- `financial-validators.test.ts`
- `exit-strategy-calculator.test.ts`
- `critical-path.test.ts`
- `import-validators.test.ts`
- Various service tests

**Required Additions:**

```typescript
// server/__tests__/security/auth.test.ts
describe('Authentication Middleware', () => {
  it('should reject requests without auth token', async () => {
    const res = await request(app).get('/api/projects');
    expect(res.status).toBe(401);
  });

  it('should reject requests with invalid token', async () => {
    const res = await request(app)
      .get('/api/projects')
      .set('Authorization', 'Bearer invalid');
    expect(res.status).toBe(401);
  });

  it('should allow requests with valid token', async () => {
    const res = await request(app)
      .get('/api/projects')
      .set('Authorization', `Bearer ${validToken}`);
    expect(res.status).toBe(200);
  });
});

// server/__tests__/security/tenant-isolation.test.ts
describe('Tenant Isolation', () => {
  it('should prevent access to other tenant data', async () => {
    const res = await request(app)
      .get(`/api/projects/${otherTenantProjectId}`)
      .set('Authorization', `Bearer ${userToken}`);
    expect(res.status).toBe(403);
  });
});
```

**Coverage Targets:**
- [ ] Security middleware: 100%
- [ ] API routes: 80%
- [ ] Business logic services: 70%
- [ ] Utility functions: 60%

---

## PRIORITY 6: FRONTEND RESILIENCE

### 6.1 Error Boundaries

**Gap:** Page-level errors may crash entire app.

```tsx
// client/src/components/ErrorBoundary.tsx
import { Component, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error boundary caught:', error, errorInfo);
    // Send to error tracking service
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="flex flex-col items-center justify-center min-h-[400px] p-8">
          <h2 className="text-xl font-semibold text-red-600 mb-4">
            Something went wrong
          </h2>
          <button
            onClick={() => this.setState({ hasError: false })}
            className="px-4 py-2 bg-primary text-white rounded"
          >
            Try again
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

// Usage in App.tsx - wrap each route
<Route path="/projects">
  <ErrorBoundary>
    <ProjectsPage />
  </ErrorBoundary>
</Route>
```

---

### 6.2 Accessibility Audit

**Gap:** Accessibility coverage not demonstrated.

**Checklist:**
- [ ] All interactive elements have proper focus states
- [ ] Color contrast meets WCAG AA (4.5:1 for text)
- [ ] All images have alt text
- [ ] Forms have proper labels and aria attributes
- [ ] Keyboard navigation works throughout
- [ ] Screen reader testing completed

**Tools:**
- axe DevTools browser extension
- Lighthouse accessibility audit
- NVDA/VoiceOver manual testing

---

## IMPLEMENTATION TIMELINE

| Phase | Focus Area | Duration | Dependencies |
|-------|------------|----------|--------------|
| 1 | Auth enforcement audit & fix | 1 week | None |
| 2 | File upload security | 3 days | None |
| 3 | API versioning & response envelope | 1 week | None |
| 4 | External logging setup | 2-3 days | APM vendor selection |
| 5 | Pagination defaults | 2 days | None |
| 6 | Test coverage expansion | 2 weeks | Ongoing |
| 7 | Accessibility audit & fixes | 1 week | None |
| 8 | Documentation & runbooks | 3 days | All above |

---

## APPENDIX: FILES REFERENCE

The following files in the `reference-files/` folder provide context for implementation:

**Security Middleware:**
- `security.ts` - Main security configuration (Helmet, CORS, rate limiting setup)
- `auth-resolver.ts` - Authentication resolution and requireAuth middleware
- `session-management.ts` - Session handling
- `csrf.ts` - CSRF protection implementation
- `rate-limiting.ts` - Redis-backed rate limiting (optional advanced config)
- `rbac.ts` - Role-based access control with 5 roles
- `authorization.ts` - Fine-grained permission checking
- `tenant-isolation.ts` - Multi-tenant data isolation

**Core Infrastructure:**
- `error-handler.ts` - Centralized error handling with custom error classes
- `audit-middleware.ts` - Audit logging with before/after tracking
- `logger.ts` - Pino structured logging with PII redaction
- `index.ts` - Server entry point showing middleware registration order

---

## NOTES FOR CLAUDE

When implementing these changes:

1. **Do NOT break existing functionality** - All changes should be additive or replace existing patterns consistently
2. **Test each change in isolation** - Use the existing test patterns as templates
3. **Follow existing code conventions** - Match the style in the reference files
4. **Update documentation** - Add JSDoc comments for new middleware and functions
5. **Consider backwards compatibility** - Especially for API changes

The app is already in production with real users. Prioritize stability over speed.
