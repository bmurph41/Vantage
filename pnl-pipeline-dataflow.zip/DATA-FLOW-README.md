# P&L Pipeline Data Flow: Upload → Review → Historical P&L → Pro Forma

## Pipeline Overview

### 1. Document Upload & AI Parsing
- **UI**: `client/src/pages/modeling/projects/workspace/uploads.tsx`
- **Upload UI**: `client/src/pages/modeling/doc-intel/UploadDropzone.tsx`
- **Parse orchestrator**: `server/services/pnl/parseOrchestrator.ts`
- **PDF extraction**: `server/services/pnl/pdfTableExtractor.ts`
- **AI classification**: `server/services/doc-intel-service.ts` + `server/services/document-intelligence-service.ts`
- **Category/dept mapping**: `server/services/pnl/mapping.ts`
- **DB tables**: `doc_intel_uploads` (upload metadata), `doc_intel_extracted_items` (parsed line items)
- **Schema**: See `schema-ts-excerpt--doc-intel-and-pnl-tables.ts`

### 2. Document Review UI (confirm/edit parsed items)
- **Review wizard**: `client/src/pages/modeling/doc-intel/ReviewWizard.tsx`
- **Multi-doc review**: `client/src/pages/modeling/doc-intel/MultiDocumentReview.tsx`
- **Review grid**: `client/src/components/doc-intel/PLReviewGrid.tsx`
- **P&L table view**: `client/src/components/doc-intel/PLTableView.tsx`
- **Department verification**: `client/src/components/doc-intel/PnlDepartmentVerification.tsx`
- **API routes for item updates**: `PATCH /api/doc-intel/items/:itemId` and `PATCH /api/doc-intel/uploads/:uploadId/items/bulk`
- **Category saved to**: `doc_intel_extracted_items.category` and `.department` columns

### 3. Historical P&L Tab
- **UI**: `client/src/pages/modeling/projects/workspace/historical-pl.tsx`
- **Data source**: `GET /api/modeling/projects/:projectId/historical-pl` (in routes-ts-excerpt)
- **Aggregation**: `server/services/pnl/aggregationService.ts`
- **Period storage**: `modeling_financial_periods` table
- **Question to trace**: Does it read category/dept from `doc_intel_extracted_items` directly, or from `modeling_financial_periods`?

### 4. Pro Forma P&L Tab
- **UI**: `client/src/pages/modeling/projects/workspace/pro-forma.tsx`
- **Engine**: `server/services/pro-forma-engine-service.ts`
- **Data source**: `GET /api/modeling/projects/:projectId/pro-forma` (in routes-ts-excerpt)
- **Question to trace**: Does baseline year come from Historical P&L data or a separate query?

### 5. COA (Chart of Accounts) Mapping Layer
- **Mapping engine**: `server/services/coa-mapping-engine.ts`
- **Taxonomy seed**: `server/services/coa-taxonomy-seed.ts`
- **Routes**: `server/routes/coa-taxonomy-routes.ts`, `server/routes/coa-routes.ts`
- **Review UI**: `client/src/pages/modeling/doc-intel/CoaMappingReview.tsx`
- **Departmental P&L**: `client/src/pages/modeling/doc-intel/DepartmentalPL.tsx`

### 6. Key Schema Tables (see schema excerpt)
- `doc_intel_uploads` — upload metadata (project, status, docType)
- `doc_intel_extracted_items` — parsed line items (label, amount, category, department, confidence, status)
- `modeling_financial_periods` — aggregated period data
- `coa_mapped_line_items` — COA-mapped items with canonical account links
- `mm_standard_accounts` — standard chart of accounts

### Key API Routes (see routes-ts-excerpt, lines 20372–26200 of server/routes.ts)
- `GET /api/modeling/projects/:projectId/pnl-overrides` — P&L category overrides
- `GET /api/modeling/projects/:projectId/financial-periods` — financial periods
- `GET /api/modeling/projects/:projectId/historical-pl` — historical P&L data
- `GET /api/modeling/projects/:projectId/pro-forma` — pro forma projections
- `GET /api/doc-intel/uploads/:uploadId/items` — parsed items per upload
- `PATCH /api/doc-intel/items/:itemId` — update single item (category, dept, status)
- `PATCH /api/doc-intel/uploads/:uploadId/items/bulk` — bulk update items
- `GET /api/modeling/projects/:projectId/pnl-lines` — P&L line items
- `GET /api/modeling/projects/:projectId/pnl-summary` — P&L summary
