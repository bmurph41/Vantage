  app.get('/api/modeling/projects/:projectId/pnl-overrides', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      const { modelingPnlOverrides } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');

      const overrides = await db.select()
        .from(modelingPnlOverrides)
        .where(and(eq(modelingPnlOverrides.projectId, projectId), eq(modelingPnlOverrides.orgId, orgId)));

      res.json(overrides);
    } catch (error: any) {
      console.error('Failed to fetch P&L overrides:', error);
      res.status(500).json({ error: 'Failed to fetch P&L overrides' });
    }
  });

  app.post('/api/modeling/projects/:projectId/pnl-overrides', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { lineItemKey, category, overrideType, overrideDepartment, overrideCategory, notes } = req.body;

      if (!lineItemKey || !overrideType) {
        return res.status(400).json({ error: 'lineItemKey and overrideType are required' });
      }
      if (overrideType === 'department' && !overrideDepartment && !overrideCategory) {
        return res.status(400).json({ error: 'overrideDepartment or overrideCategory is required for department overrides' });
      }

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      const { modelingPnlOverrides } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');

      const [existing] = await db.select()
        .from(modelingPnlOverrides)
        .where(and(
          eq(modelingPnlOverrides.projectId, projectId),
          eq(modelingPnlOverrides.lineItemKey, lineItemKey),
          eq(modelingPnlOverrides.overrideType, overrideType),
        ));

      let result;
      if (existing) {
        [result] = await db.update(modelingPnlOverrides)
          .set({
            category: category || existing.category,
            overrideDepartment: overrideDepartment !== undefined ? (overrideDepartment || existing.overrideDepartment) : existing.overrideDepartment,
            overrideCategory: overrideCategory !== undefined ? (overrideCategory || null) : existing.overrideCategory,
            notes: notes !== undefined ? notes : existing.notes,
            isActive: true,
            updatedAt: new Date(),
          })
          .where(eq(modelingPnlOverrides.id, existing.id))
          .returning();
      } else {
        [result] = await db.insert(modelingPnlOverrides).values({
          projectId,
          orgId,
          lineItemKey,
          category: category || null,
          overrideType,
          overrideDepartment: overrideDepartment || null,
          overrideCategory: overrideCategory || null,
          isActive: true,
          notes: notes || null,
          createdBy: userId,
        }).returning();
      }

      res.json(result);
    } catch (error: any) {
      console.error('Failed to upsert P&L override:', error);
      res.status(500).json({ error: 'Failed to save P&L override' });
    }
  });

  app.patch('/api/modeling/projects/:projectId/pnl-overrides/:overrideId/clear-category', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, overrideId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      const { modelingPnlOverrides } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');

      const [existing] = await db.select()
        .from(modelingPnlOverrides)
        .where(and(eq(modelingPnlOverrides.id, overrideId), eq(modelingPnlOverrides.orgId, orgId)));

      if (!existing) return res.status(404).json({ error: 'Override not found' });

      if (existing.overrideDepartment) {
        const [updated] = await db.update(modelingPnlOverrides)
          .set({ overrideCategory: null, updatedAt: new Date() })
          .where(eq(modelingPnlOverrides.id, overrideId))
          .returning();
        res.json(updated);
      } else {
        const [deleted] = await db.delete(modelingPnlOverrides)
          .where(eq(modelingPnlOverrides.id, overrideId))
          .returning();
        res.json({ success: true });
      }
    } catch (error: any) {
      console.error('Failed to clear category override:', error);
      res.status(500).json({ error: 'Failed to clear category override' });
    }
  });

  app.delete('/api/modeling/projects/:projectId/pnl-overrides/:overrideId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, overrideId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) return res.status(404).json({ error: 'Project not found' });

      const { modelingPnlOverrides } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');

      const [deleted] = await db.delete(modelingPnlOverrides)
        .where(and(eq(modelingPnlOverrides.id, overrideId), eq(modelingPnlOverrides.orgId, orgId)))
        .returning();

      if (!deleted) return res.status(404).json({ error: 'Override not found' });
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete P&L override:', error);
      res.status(500).json({ error: 'Failed to delete P&L override' });
    }
  });

  // ============================================================================
  // DISPLAY NAME OVERRIDES - Project-level and org-level name customization
  // ============================================================================

  // Get all name overrides for a project (includes org defaults for unset items)
  app.get('/api/modeling/projects/:projectId/name-overrides', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const { modelingNameOverrides, orgPnlDisplayDefaults } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');
      
      const overrides = await db.select()
        .from(modelingNameOverrides)
        .where(and(eq(modelingNameOverrides.projectId, projectId), eq(modelingNameOverrides.orgId, orgId)));
      
      const orgDefaults = await db.select()
        .from(orgPnlDisplayDefaults)
        .where(and(eq(orgPnlDisplayDefaults.orgId, orgId), eq(orgPnlDisplayDefaults.isActive, true)));
      
      res.json({ overrides, orgDefaults });
    } catch (error: any) {
      console.error('Failed to fetch name overrides:', error);
      res.status(500).json({ error: 'Failed to fetch name overrides' });
    }
  });

  // Create or update a name override (also upserts org default)
  app.post('/api/modeling/projects/:projectId/name-overrides', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { scope, originalName, displayName, category, department } = req.body;
      
      if (!scope || !originalName || !displayName) {
        return res.status(400).json({ error: 'scope, originalName, and displayName are required' });
      }
      
      const { modelingNameOverrides, orgPnlDisplayDefaults } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');
      
      const overrideConditions = [
        eq(modelingNameOverrides.projectId, projectId),
        eq(modelingNameOverrides.orgId, orgId),
        eq(modelingNameOverrides.scope, scope),
        eq(modelingNameOverrides.originalName, originalName),
      ];
      if (scope === 'line_item' && category) {
        overrideConditions.push(eq(modelingNameOverrides.category, category));
      }
      const [existing] = await db.select()
        .from(modelingNameOverrides)
        .where(and(...overrideConditions));
      
      let override;
      if (existing) {
        [override] = await db.update(modelingNameOverrides)
          .set({ displayName, category, department, updatedAt: new Date() })
          .where(eq(modelingNameOverrides.id, existing.id))
          .returning();
      } else {
        [override] = await db.insert(modelingNameOverrides).values({
          orgId,
          projectId,
          scope,
          originalName,
          displayName,
          category: category || null,
          department: department || null,
          createdBy: userId,
        }).returning();
      }
      
      // Upsert org-level default
      const [existingDefault] = await db.select()
        .from(orgPnlDisplayDefaults)
        .where(and(
          eq(orgPnlDisplayDefaults.orgId, orgId),
          eq(orgPnlDisplayDefaults.scope, scope),
          eq(orgPnlDisplayDefaults.originalName, originalName)
        ));
      
      if (existingDefault) {
        await db.update(orgPnlDisplayDefaults)
          .set({
            displayName,
            timesUsed: (existingDefault.timesUsed || 0) + 1,
            updatedAt: new Date(),
          })
          .where(eq(orgPnlDisplayDefaults.id, existingDefault.id));
      } else {
        await db.insert(orgPnlDisplayDefaults).values({
          orgId,
          scope,
          originalName,
          displayName,
          category: category || null,
          department: department || null,
        });
      }
      
      res.json(override);
    } catch (error: any) {
      console.error('Failed to save name override:', error);
      res.status(500).json({ error: 'Failed to save name override' });
    }
  });

  // Delete a name override (reverts to original name for this project)
  app.delete('/api/modeling/projects/:projectId/name-overrides/:overrideId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { overrideId } = req.params;
      
      const { modelingNameOverrides } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');
      
      const [deleted] = await db.delete(modelingNameOverrides)
        .where(and(eq(modelingNameOverrides.id, overrideId), eq(modelingNameOverrides.orgId, orgId)))
        .returning();
      
      if (!deleted) {
        return res.status(404).json({ error: 'Override not found' });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete name override:', error);
      res.status(500).json({ error: 'Failed to delete name override' });
    }
  });
  // ============================================================================
  // MODELING FINANCIAL PERIODS - Year-based financial data for pricing/yields
  // ============================================================================

  // Get all financial periods for a project
  app.get('/api/modeling/projects/:projectId/financial-periods', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const periods = await storage.getModelingFinancialPeriods(projectId, orgId);
      res.json(periods);
    } catch (error: any) {
      console.error('Failed to fetch financial periods:', error);
      res.status(500).json({ error: 'Failed to fetch financial periods' });
    }
  });

  // Get available period options for year selector (returns just period type and label)
  app.get('/api/modeling/projects/:projectId/available-periods', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const periods = await storage.getAvailableFinancialPeriods(projectId, orgId);
      res.json(periods);
    } catch (error: any) {
      console.error('Failed to fetch available periods:', error);
      res.status(500).json({ error: 'Failed to fetch available periods' });
    }
  });

  // Get a specific financial period by ID
  app.get('/api/modeling/financial-periods/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const period = await storage.getModelingFinancialPeriod(req.params.id, orgId);
      
      if (!period) {
        return res.status(404).json({ error: 'Financial period not found' });
      }
      
      res.json(period);
    } catch (error: any) {
      console.error('Failed to fetch financial period:', error);
      res.status(500).json({ error: 'Failed to fetch financial period' });
    }
  });

  // Get financial period by label for a project
  app.get('/api/modeling/projects/:projectId/financial-periods/by-label/:label', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, label } = req.params;
      
      const period = await storage.getModelingFinancialPeriodByLabel(projectId, label, orgId);
      
      if (!period) {
        return res.status(404).json({ error: 'Financial period not found' });
      }
      
      res.json(period);
    } catch (error: any) {
      console.error('Failed to fetch financial period by label:', error);
      res.status(500).json({ error: 'Failed to fetch financial period by label' });
    }
  });

  // Create a new financial period
  app.post('/api/modeling/projects/:projectId/financial-periods', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const data = {
        ...req.body,
        orgId,
        modelingProjectId: projectId,
        createdBy: userId
      };
      
      const period = await storage.createModelingFinancialPeriod(data);
      res.status(201).json(period);
    } catch (error: any) {
      console.error('Failed to create financial period:', error);
      res.status(500).json({ error: 'Failed to create financial period' });
    }
  });

  // Update a financial period
  app.patch('/api/modeling/financial-periods/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      const period = await storage.updateModelingFinancialPeriod(req.params.id, req.body, orgId);
      
      if (!period) {
        return res.status(404).json({ error: 'Financial period not found' });
      }
      
      res.json(period);
    } catch (error: any) {
      console.error('Failed to update financial period:', error);
      res.status(500).json({ error: 'Failed to update financial period' });
    }
  });

  // Delete a financial period
  app.delete('/api/modeling/financial-periods/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const success = await storage.deleteModelingFinancialPeriod(req.params.id, orgId);
      
      if (!success) {
        return res.status(404).json({ error: 'Financial period not found' });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete financial period:', error);
      res.status(500).json({ error: 'Failed to delete financial period' });
    }
  });

  // Recalculate yields for a financial period (based on purchase price and NOI)
  app.post('/api/modeling/financial-periods/:id/recalculate', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { purchasePrice, totalUnits } = req.body;
      
      const period = await storage.getModelingFinancialPeriod(req.params.id, orgId);
      if (!period) {
        return res.status(404).json({ error: 'Financial period not found' });
      }
      
      // Calculate yields
      const noi = period.noi ? Number(period.noi) : 0;
      const price = purchasePrice || Number(period.purchasePrice) || 0;
      const units = totalUnits || period.totalUnits || 0;
      const revenue = period.totalRevenue ? Number(period.totalRevenue) : 0;
      
      const capRate = price > 0 ? noi / price : 0;
      const pricePerUnit = units > 0 ? price / units : 0;
      const noiMargin = revenue > 0 ? noi / revenue : 0;
      
      const updated = await storage.updateModelingFinancialPeriod(
        req.params.id,
        {
          purchasePrice: price.toString(),
          capRate: capRate.toString(),
          pricePerUnit: pricePerUnit.toString(),
          noiMargin: noiMargin.toString(),
          totalUnits: units,
          lastCalculatedAt: new Date()
        },
        orgId
      );
      
      res.json(updated);
    } catch (error: any) {
      console.error('Failed to recalculate financial period:', error);
      res.status(500).json({ error: 'Failed to recalculate financial period' });
    }
  });

  // ============================================================================
  // MODELING PERIOD ADJUSTMENTS - Normalization adjustments for financial periods
  // ============================================================================

  // Get all adjustments for a project (optionally filtered by period)
  app.get('/api/modeling/projects/:projectId/adjustments', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { periodLabel } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const adjustments = await storage.getModelingPeriodAdjustments(
        projectId, 
        orgId, 
        periodLabel as string | undefined
      );
      res.json(adjustments);
    } catch (error: any) {
      console.error('Failed to fetch adjustments:', error);
      res.status(500).json({ error: 'Failed to fetch adjustments' });
    }
  });

  // Get active adjustments for a specific period
  app.get('/api/modeling/projects/:projectId/adjustments/period/:periodLabel', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, periodLabel } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const adjustments = await storage.getActiveAdjustmentsForPeriod(projectId, periodLabel, orgId);
      res.json(adjustments);
    } catch (error: any) {
      console.error('Failed to fetch adjustments for period:', error);
      res.status(500).json({ error: 'Failed to fetch adjustments for period' });
    }
  });

  // Create a new adjustment
  app.post('/api/modeling/projects/:projectId/adjustments', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const data = {
        ...req.body,
        orgId,
        modelingProjectId: projectId,
        createdBy: userId
      };
      
      const adjustment = await storage.createModelingPeriodAdjustment(data);
      res.status(201).json(adjustment);
    } catch (error: any) {
      console.error('Failed to create adjustment:', error);
      if (error.code === '23505') {
        return res.status(409).json({ error: 'An adjustment for this target already exists for this period' });
      }
      res.status(500).json({ error: 'Failed to create adjustment' });
    }
  });

  // Update an adjustment
  app.patch('/api/modeling/adjustments/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      
      const adjustment = await storage.updateModelingPeriodAdjustment(
        req.params.id,
        { ...req.body, updatedBy: userId },
        orgId
      );
      
      if (!adjustment) {
        return res.status(404).json({ error: 'Adjustment not found' });
      }
      
      res.json(adjustment);
    } catch (error: any) {
      console.error('Failed to update adjustment:', error);
      res.status(500).json({ error: 'Failed to update adjustment' });
    }
  });

  // Toggle adjustment active state
  app.patch('/api/modeling/adjustments/:id/toggle', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { isActive } = req.body;
      
      const adjustment = await storage.toggleAdjustmentActive(req.params.id, isActive, orgId);
      
      if (!adjustment) {
        return res.status(404).json({ error: 'Adjustment not found' });
      }
      
      res.json(adjustment);
    } catch (error: any) {
      console.error('Failed to toggle adjustment:', error);
      res.status(500).json({ error: 'Failed to toggle adjustment' });
    }
  });

  // Delete an adjustment
  app.delete('/api/modeling/adjustments/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const success = await storage.deleteModelingPeriodAdjustment(req.params.id, orgId);
      
      if (!success) {
        return res.status(404).json({ error: 'Adjustment not found' });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete adjustment:', error);
      res.status(500).json({ error: 'Failed to delete adjustment' });
    }
  });

  // ============================================================================
  // MODELING ANALYTICS - Drill-down analytics for financial data
  // ============================================================================

  // Get category-level aggregations
  app.get('/api/modeling/projects/:projectId/analytics/categories', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const categories = await storage.getActualsAggregationByCategory(projectId, orgId);
      res.json(categories);
    } catch (error: any) {
      console.error('Failed to fetch category analytics:', error);
      res.status(500).json({ error: 'Failed to fetch category analytics' });
    }
  });

  // Get subcategory-level (department) aggregations for a category
  app.get('/api/modeling/projects/:projectId/analytics/categories/:category/subcategories', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, category } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const subcategories = await storage.getActualsAggregationBySubcategory(projectId, category, orgId);
      res.json(subcategories);
    } catch (error: any) {
      console.error('Failed to fetch subcategory analytics:', error);
      res.status(500).json({ error: 'Failed to fetch subcategory analytics' });
    }
  });

  // Get line item-level aggregations for a subcategory
  app.get('/api/modeling/projects/:projectId/analytics/categories/:category/subcategories/:subcategory/line-items', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, category, subcategory } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const lineItems = await storage.getActualsAggregationByLineItem(projectId, category, subcategory, orgId);
      res.json(lineItems);
    } catch (error: any) {
      console.error('Failed to fetch line item analytics:', error);
      res.status(500).json({ error: 'Failed to fetch line item analytics' });
    }
  });

  // Get financial summary with adjustments applied
  app.get('/api/modeling/projects/:projectId/analytics/summary/:periodLabel', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, periodLabel } = req.params;
      const applyAdjustments = req.query.applyAdjustments !== 'false';
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const summary = await storage.getFinancialSummaryWithAdjustments(
        projectId,
        periodLabel,
        orgId,
        applyAdjustments
      );
      res.json(summary);
    } catch (error: any) {
      console.error('Failed to fetch financial summary:', error);
      res.status(500).json({ error: 'Failed to fetch financial summary' });
    }
  });

  // =============================================
  // Unified Marina Catalog - Custom Profit Centers & Amenities
  // =============================================

  app.get('/api/catalog/items', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const type = req.query.type as string | undefined;
      
      let query = db.select().from(customCatalogItems).where(eq(customCatalogItems.orgId, orgId));
      if (type) {
        query = db.select().from(customCatalogItems).where(and(eq(customCatalogItems.orgId, orgId), eq(customCatalogItems.type, type)));
      }
      
      const items = await query;
      res.json(items);
    } catch (error: any) {
      console.error('Failed to fetch catalog items:', error);
      res.status(500).json({ error: 'Failed to fetch catalog items' });
    }
  });

  app.post('/api/catalog/items', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const parsed = insertCustomCatalogItemSchema.parse({
        ...req.body,
        orgId,
        createdBy: userId,
      });

      const existing = await db.select().from(customCatalogItems).where(
        and(
          eq(customCatalogItems.orgId, orgId),
          eq(customCatalogItems.type, parsed.type),
          eq(customCatalogItems.name, parsed.name)
        )
      );
      
      if (existing.length > 0) {
        return res.json(existing[0]);
      }

      const [item] = await db.insert(customCatalogItems).values(parsed).returning();
      res.status(201).json(item);
    } catch (error: any) {
      console.error('Failed to create catalog item:', error);
      res.status(500).json({ error: 'Failed to create catalog item' });
    }
  });

  app.delete('/api/catalog/items/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { id } = req.params;
      
      await db.delete(customCatalogItems).where(
        and(eq(customCatalogItems.id, id), eq(customCatalogItems.orgId, orgId))
      );
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete catalog item:', error);
      res.status(500).json({ error: 'Failed to delete catalog item' });
    }
  });

  // Project Workspace - Configuration
  app.get('/api/modeling/projects/:projectId/config', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const cm = (project.customMetrics as any) || {};
      const configDefault = { holdPeriod: 5, startDate: '2026-01-31', cashFlowGranularity: 'annual', seasonMonths: [4, 5, 6, 7, 8, 9, 10], departments: {} };
      const config = { ...configDefault, ...(cm.config || {}) };

      if (cm.profitCenters && !config.profitCenters) {
        const wizardToInputsKeyMap: Record<string, string> = {
          commercialTenants: 'pc_commercial_leases',
          fuelSales: 'pc_fuel_dock',
          shipStore: 'pc_ships_store',
          serviceDepartment: 'pc_service',
          boatRentals: 'pc_rental_boats',
          boatClub: 'pc_boat_club',
          boatSales: 'pc_boat_sales',
        };
        const allKnownProfitCenterIds = [
          'pc_fuel_dock', 'pc_marina_amenities', 'pc_ships_store',
          'pc_commercial_leases', 'pc_service', 'pc_parts',
          'pc_boat_club', 'pc_rental_boats', 'pc_boat_sales',
          'pc_boat_finance', 'pc_boat_brokerage', 'pc_fb',
          'pc_rv_park', 'pc_hospitality',
        ];
        const translated: Record<string, any> = {};
        for (const pcId of allKnownProfitCenterIds) {
          translated[pcId] = { isEnabled: false };
        }
        for (const [wizardKey, wizardVal] of Object.entries(cm.profitCenters)) {
          const inputsKey = wizardToInputsKeyMap[wizardKey];
          if (inputsKey && wizardVal && typeof wizardVal === 'object') {
            translated[inputsKey] = { isEnabled: (wizardVal as any).enabled ?? false };
          }
        }
        config.profitCenters = translated;
        if (cm.profitCenters.commercialTenants?.enabled && cm.profitCenters.commercialTenants?.numberOfSuites) {
          config.commercialLeaseCount = cm.profitCenters.commercialTenants.numberOfSuites;
        }
      }
      if (cm.seasonality?.profile && !cm.config?.seasonalityProfile) {
        config.seasonalityProfile = cm.seasonality.profile;
      }
      if (cm.underwriting?.holdPeriodYears && !cm.config?.holdPeriod) {
        config.holdPeriod = cm.underwriting.holdPeriodYears;
      }
      if (cm.seasonality?.seasonStartMonth && cm.seasonality?.seasonEndMonth && !cm.config?.seasonMonths) {
        const start = parseInt(String(cm.seasonality.seasonStartMonth), 10);
        const end = parseInt(String(cm.seasonality.seasonEndMonth), 10);
        if (!isNaN(start) && !isNaN(end) && start >= 1 && start <= 12 && end >= 1 && end <= 12) {
          const months: number[] = [];
          if (start <= end) {
            for (let m = start; m <= end; m++) months.push(m);
          } else {
            for (let m = start; m <= 12; m++) months.push(m);
            for (let m = 1; m <= end; m++) months.push(m);
          }
          config.seasonMonths = months;
        }
      }
      if (cm.storageMix && !config.departments) {
        config.departments = {};
      }
      if (cm.storageMix?.items && Object.keys(config.departments).length === 0) {
        const depts: Record<string, any> = {};
        const isYearRound = cm.seasonality?.profile === 'year_round';
        const wizardStorageIds = new Set<string>();
        for (const item of cm.storageMix.items) {
          if (item.storageType) {
            wizardStorageIds.add(item.storageType);
            const count = parseInt(String(item.count)) || 0;
            const occMode = item.occupancyInputMode || 'percentage';
            let occupiedCount = '';
            let occupancyPercent = '';
            if (occMode === 'count' && item.occupiedCount != null && item.occupiedCount !== '') {
              occupiedCount = String(item.occupiedCount);
              if (count > 0) {
                occupancyPercent = String(Math.round((parseInt(String(item.occupiedCount)) / count) * 100));
              }
            } else if (item.currentOccupancy != null && item.currentOccupancy !== '') {
              occupancyPercent = String(item.currentOccupancy);
              if (count > 0) {
                occupiedCount = String(Math.round((parseFloat(String(item.currentOccupancy)) / 100) * count));
              }
            }
            depts[item.storageType] = {
              isEnabled: true,
              section: 'storage',
              seasons: isYearRound ? ['annual'] : ['seasonal'],
              capacity: count > 0 ? String(count) : '',
              leasable: '',
              occupiedCount,
              occupancyPercent,
              occupancyInputMode: occMode,
              hasDesignatedSpaces: false,
              designatedSpaceIds: [],
            };
          }
        }
        const allKnownStorageTypes = [
          'wet_slips', 'lift_slips', 'moorings', 'dinghies', 'jet_skis',
          'dry_racks_indoor', 'dry_racks_outdoor', 'land_storage',
          'boats_on_trailers', 'trailers', 'carports', 'houseboats',
          'liveaboards', 'rv_sites'
        ];
        for (const stId of allKnownStorageTypes) {
          if (!wizardStorageIds.has(stId)) {
            depts[stId] = {
              isEnabled: false,
              section: 'storage',
              seasons: isYearRound ? ['annual'] : ['seasonal'],
              capacity: '', leasable: '', occupiedCount: '', occupancyPercent: '',
              occupancyInputMode: 'percentage',
              hasDesignatedSpaces: false, designatedSpaceIds: [],
            };
          }
        }
        config.departments = depts;
      }
      
      res.json(config);
    } catch (error: any) {
      console.error('Failed to fetch project config:', error);
      res.status(500).json({ error: 'Failed to fetch project config' });
    }
  });

  app.post('/api/modeling/projects/:projectId/config', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const existingMetrics = (project.customMetrics as any) || {};
      const updatedMetrics = {
        ...existingMetrics,
        config: req.body
      };
      
      const updated = await storage.updateModelingProject(
        projectId,
        { customMetrics: updatedMetrics, updatedBy: userId },
        orgId
      );
      
      res.json(req.body);
    } catch (error: any) {
      console.error('Failed to save project config:', error);
      res.status(500).json({ error: 'Failed to save project config' });
    }
  });

  app.patch('/api/modeling/projects/:projectId/config', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const existingMetrics = (project.customMetrics as any) || {};
      const existingConfig = existingMetrics.config || {};
      const mergedConfig = { ...existingConfig, ...req.body };

      const updatedMetrics = {
        ...existingMetrics,
        config: mergedConfig,
      };

      await storage.updateModelingProject(
        projectId,
        { customMetrics: updatedMetrics, updatedBy: userId },
        orgId
      );

      if (req.body.holdPeriod !== undefined) {
        const existingMPC = await db.select().from(modelingProjectConfig).where(eq(modelingProjectConfig.modelingProjectId, projectId)).limit(1);
        if (existingMPC.length > 0) {
          await db.update(modelingProjectConfig)
            .set({ holdPeriod: Number(req.body.holdPeriod), updatedAt: new Date() })
            .where(eq(modelingProjectConfig.modelingProjectId, projectId));
        }
      }

      res.json(mergedConfig);
    } catch (error: any) {
      console.error('Failed to patch project config:', error);
      res.status(500).json({ error: 'Failed to patch project config' });
    }
  });

  // Update timeline configuration (Phase 1 - Institutional Grade)
  app.patch('/api/modeling/projects/:projectId/config/timeline', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { projectionStartRule, irrDisplayPreference, stabilizedNoiMode, stabilizedNoiYear, acquisitionCloseDate, ttmEndDate } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      // Update or create modeling_project_config record
      const existingConfig = await db.select().from(modelingProjectConfig).where(eq(modelingProjectConfig.modelingProjectId, projectId)).limit(1);
      
      const timelineFields = {
        projectionStartRule: projectionStartRule || 'acq_close_year',
        irrDisplayPreference: irrDisplayPreference || 'monthly',
        stabilizedNoiMode: stabilizedNoiMode || 'fixed_year',
        stabilizedNoiYear: stabilizedNoiYear || 3,
        acquisitionCloseDate: acquisitionCloseDate ? new Date(acquisitionCloseDate) : null,
        ttmEndDate: ttmEndDate ? new Date(ttmEndDate) : null,
      };
      
      let result;
      if (existingConfig.length > 0) {
        [result] = await db.update(modelingProjectConfig)
          .set(timelineFields)
          .where(eq(modelingProjectConfig.modelingProjectId, projectId))
          .returning();
      } else {
        [result] = await db.insert(modelingProjectConfig)
          .values({ modelingProjectId: projectId, ...timelineFields })
          .returning();
      }
      
      // Also update customMetrics.config for backward compatibility
      const existingMetrics = (project.customMetrics as any) || {};
      const updatedMetrics = {
        ...existingMetrics,
        config: { ...(existingMetrics.config || {}), ...timelineFields }
      };
      await storage.updateModelingProject(projectId, { customMetrics: updatedMetrics, updatedBy: userId }, orgId);
      
      res.json({ success: true, config: result });
    } catch (error: any) {
      console.error('Failed to update timeline config:', error);
      res.status(500).json({ error: 'Failed to update timeline configuration' });
    }
  });

  // ============================================
  // SEASONALITY PROFILES (Phase 3)
  // ============================================
  
  // Get all seasonality profiles for org
  app.get('/api/modeling/seasonality-profiles', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const profiles = await seasonalityProfileService.getProfiles(orgId);
      res.json(profiles);
    } catch (error: any) {
      console.error('Failed to fetch seasonality profiles:', error);
      res.status(500).json({ error: 'Failed to fetch seasonality profiles' });
    }
  });
  
  // Get a specific profile
  app.get('/api/modeling/seasonality-profiles/:profileId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { profileId } = req.params;
      const profile = await seasonalityProfileService.getProfile(profileId, orgId);
      if (!profile) {
        return res.status(404).json({ error: 'Profile not found' });
      }
      res.json(profile);
    } catch (error: any) {
      console.error('Failed to fetch seasonality profile:', error);
      res.status(500).json({ error: 'Failed to fetch seasonality profile' });
    }
  });
  
  // Create a new profile
  app.post('/api/modeling/seasonality-profiles', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { name, months, description, isDefault } = req.body;
      if (!name || !months || !Array.isArray(months)) {
        return res.status(400).json({ error: 'Name and months array required' });
      }
      const profile = await seasonalityProfileService.createProfile(orgId, name, months, { description, isDefault });
      res.json(profile);
    } catch (error: any) {
      console.error('Failed to create seasonality profile:', error);
      res.status(500).json({ error: 'Failed to create seasonality profile' });
    }
  });
  
  // Update a profile
  app.patch('/api/modeling/seasonality-profiles/:profileId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { profileId } = req.params;
      const updates = req.body;
      const profile = await seasonalityProfileService.updateProfile(profileId, orgId, updates);
      if (!profile) {
        return res.status(404).json({ error: 'Profile not found' });
      }
      res.json(profile);
    } catch (error: any) {
      if (error.message === 'Cannot modify system profiles') {
        return res.status(403).json({ error: error.message });
      }
      console.error('Failed to update seasonality profile:', error);
      res.status(500).json({ error: 'Failed to update seasonality profile' });
    }
  });
  
  // Delete a profile
  app.delete('/api/modeling/seasonality-profiles/:profileId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { profileId } = req.params;
      const deleted = await seasonalityProfileService.deleteProfile(profileId, orgId);
      if (!deleted) {
        return res.status(404).json({ error: 'Profile not found' });
      }
      res.json({ success: true });
    } catch (error: any) {
      if (error.message === 'Cannot delete system profiles') {
        return res.status(403).json({ error: error.message });
      }
      console.error('Failed to delete seasonality profile:', error);
      res.status(500).json({ error: 'Failed to delete seasonality profile' });
    }
  });
  
  // Get project seasonality
  app.get('/api/modeling/projects/:projectId/seasonality', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const profile = await seasonalityProfileService.getProjectSeasonality(projectId, orgId);
      res.json(profile);
    } catch (error: any) {
      console.error('Failed to fetch project seasonality:', error);
      res.status(500).json({ error: 'Failed to fetch project seasonality' });
    }
  });
  
  // Set project seasonality
  app.patch('/api/modeling/projects/:projectId/seasonality', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { profileId } = req.body;
      if (!profileId) {
        return res.status(400).json({ error: 'profileId required' });
      }
      await seasonalityProfileService.setProjectSeasonality(projectId, profileId, orgId);
      const profile = await seasonalityProfileService.getProjectSeasonality(projectId, orgId);
      res.json({ success: true, profile });
    } catch (error: any) {
      console.error('Failed to set project seasonality:', error);
      res.status(500).json({ error: 'Failed to set project seasonality' });
    }
  });
  // ============================================
  // SCENARIO GOVERNANCE (Phase 5)
  // ============================================
  
  // Check if scenario can be modified
  app.get('/api/modeling/projects/:projectId/scenarios/:scenarioId/can-modify', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { scenarioId } = req.params;
      const result = await scenarioGovernanceService.canModifyScenario(scenarioId, orgId);
      res.json(result);
    } catch (error: any) {
      console.error('Failed to check scenario modifiability:', error);
      res.status(500).json({ error: 'Failed to check scenario' });
    }
  });
  
  // Fork a scenario (creates editable copy)
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/fork', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { scenarioId } = req.params;
      const { name, description } = req.body;
      const result = await scenarioGovernanceService.forkScenario(scenarioId, orgId, userId, { name, description });
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      res.json(result.newScenario);
    } catch (error: any) {
      console.error('Failed to fork scenario:', error);
      res.status(500).json({ error: 'Failed to fork scenario' });
    }
  });
  
  // Submit scenario for approval
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/submit', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { scenarioId } = req.params;
      const { notes } = req.body;
      const result = await scenarioGovernanceService.submitForApproval(scenarioId, orgId, userId, notes);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to submit scenario:', error);
      res.status(500).json({ error: 'Failed to submit scenario' });
    }
  });
  
  // Approve scenario (makes it IMMUTABLE)
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/approve', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { scenarioId } = req.params;
      const { notes } = req.body;
      const result = await scenarioGovernanceService.approveScenario(scenarioId, orgId, userId, notes);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      res.json({ success: true, message: 'Scenario approved and is now immutable' });
    } catch (error: any) {
      console.error('Failed to approve scenario:', error);
      res.status(500).json({ error: 'Failed to approve scenario' });
    }
  });
  
  // Reject scenario
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/reject', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { scenarioId } = req.params;
      const { notes } = req.body;
      if (!notes) {
        return res.status(400).json({ error: 'Rejection reason required' });
      }
      const result = await scenarioGovernanceService.rejectScenario(scenarioId, orgId, userId, notes);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to reject scenario:', error);
      res.status(500).json({ error: 'Failed to reject scenario' });
    }
  });
  
  // Withdraw approval submission
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/withdraw', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { scenarioId } = req.params;
      const { reason } = req.body;
      const result = await scenarioGovernanceService.withdrawSubmission(scenarioId, orgId, userId, reason);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to withdraw submission:', error);
      res.status(500).json({ error: 'Failed to withdraw submission' });
    }
  });
  
  // Get version history
  app.get('/api/modeling/projects/:projectId/scenarios/:scenarioType/history', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, scenarioType } = req.params;
      const history = await scenarioGovernanceService.getVersionHistory(projectId, scenarioType, orgId);
      res.json(history);
    } catch (error: any) {
      console.error('Failed to get version history:', error);
      res.status(500).json({ error: 'Failed to get version history' });
    }
  });
  
  // Compare two versions
  app.get('/api/modeling/projects/:projectId/scenarios/compare', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { baseVersionId, compareVersionId } = req.query;
      if (!baseVersionId || !compareVersionId) {
        return res.status(400).json({ error: 'baseVersionId and compareVersionId required' });
      }
      const comparison = await scenarioGovernanceService.compareVersions(
        baseVersionId as string,
        compareVersionId as string,
        orgId
      );
      if (!comparison) {
        return res.status(404).json({ error: 'Versions not found' });
      }
      res.json(comparison);
    } catch (error: any) {
      console.error('Failed to compare versions:', error);
      res.status(500).json({ error: 'Failed to compare versions' });
    }
  });
  
  // Rollback to previous version
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/rollback', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { scenarioId } = req.params;
      const { reason } = req.body;
      if (!reason) {
        return res.status(400).json({ error: 'Rollback reason required' });
      }
      const result = await scenarioGovernanceService.rollbackToVersion(scenarioId, orgId, userId, reason);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }
      res.json(result.newScenario);
    } catch (error: any) {
      console.error('Failed to rollback:', error);
      res.status(500).json({ error: 'Failed to rollback' });
    }
  });
  
  // Get audit log
  app.get('/api/modeling/projects/:projectId/audit-log', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { scenarioVersionId, limit } = req.query;
      const logs = await scenarioGovernanceService.getAuditLog(orgId, {
        projectId,
        scenarioVersionId: scenarioVersionId as string | undefined,
        limit: limit ? parseInt(limit as string) : 100,
      });
      res.json(logs);
    } catch (error: any) {
      console.error('Failed to get audit log:', error);
      res.status(500).json({ error: 'Failed to get audit log' });
    }
  });

  // Project Workspace - Unified Deal Pricing (single-driver model)
  app.post('/api/modeling/projects/:projectId/deal-pricing/unified', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const {
        pricingDriver = 'targetIRR',
        purchasePrice,
        targetIRR,
        goingInCapRate,
        targetYearCapRate,
        targetYear,
        holdPeriod = 5,
        exitCapRate = 7.5,
        lockedInputs = [],
        periodLabel,
        periodNOI,
        periodRevenue,
        periodExpenses,
        useNormalizedData = true,
      } = req.body;

      let adjustedNOI = periodNOI ? Number(periodNOI) : undefined;
      let adjustedRevenue = periodRevenue ? Number(periodRevenue) : undefined;
      let adjustedExpenses = periodExpenses ? Number(periodExpenses) : undefined;

      if (useNormalizedData && periodLabel) {
        try {
          const adjustments = await storage.getActiveAdjustmentsForPeriod(projectId, periodLabel, orgId);
          if (adjustments.length > 0) {
            for (const adj of adjustments) {
              const target = (adj.targetIdentifier || '').toLowerCase();
              const value = Number(adj.adjustmentValue) || 0;
              const adjType = adj.adjustmentType;
              if (target === 'revenue' || target.includes('revenue')) {
                const base = adjustedRevenue || 0;
                if (adjType === 'absolute') adjustedRevenue = base + value;
                else if (adjType === 'percentage') adjustedRevenue = base * (1 + value / 100);
                else if (adjType === 'replace') adjustedRevenue = value;
              } else if (target === 'expenses' || target.includes('expense')) {
                const base = adjustedExpenses || 0;
                if (adjType === 'absolute') adjustedExpenses = base + value;
                else if (adjType === 'percentage') adjustedExpenses = base * (1 + value / 100);
                else if (adjType === 'replace') adjustedExpenses = value;
              } else if (target === 'noi' || target.includes('noi')) {
                const base = adjustedNOI || 0;
                if (adjType === 'absolute') adjustedNOI = base + value;
                else if (adjType === 'percentage') adjustedNOI = base * (1 + value / 100);
                else if (adjType === 'replace') adjustedNOI = value;
              }
            }
            if (adjustedRevenue !== undefined && adjustedExpenses !== undefined) {
              const recalcNOI = adjustedRevenue - adjustedExpenses;
              if (adjustedNOI === undefined || adjustedNOI === (periodNOI ? Number(periodNOI) : undefined)) {
                adjustedNOI = recalcNOI;
              }
            }
          }
        } catch (adjError) {
          console.warn('Failed to apply period adjustments:', adjError);
        }
      }

      const result = await dealPricingService.calculateUnified(projectId, orgId, {
        pricingDriver,
        purchasePrice: purchasePrice ? Number(purchasePrice) : undefined,
        targetIRR: targetIRR ? Number(targetIRR) : undefined,
        goingInCapRate: goingInCapRate ? Number(goingInCapRate) : undefined,
        targetYearCapRate: targetYearCapRate ? Number(targetYearCapRate) : undefined,
        targetYear: targetYear ? Number(targetYear) : undefined,
        holdPeriod: Number(holdPeriod),
        exitCapRate: Number(exitCapRate),
        lockedInputs: Array.isArray(lockedInputs) ? lockedInputs : [],
        periodLabel,
        periodNOI: adjustedNOI,
        periodRevenue: adjustedRevenue,
        periodExpenses: adjustedExpenses,
      });

      try {
        const project = await storage.getModelingProject(projectId, orgId);
        if (project) {
          const cm = { ...((project.customMetrics as any) || {}) };
          cm.dealPricingResults = {
            irr: result.irr,
            equityMultiple: result.equityMultiple,
            cashOnCash: result.averageCashOnCash,
            noi: result.projectFinancials.year1NOI,
            purchasePrice: result.purchasePrice,
            goingInCapRate: result.goingInCapRate,
            exitValue: result.exitValue,
            npv: result.npv,
            moic: result.moic,
            updatedAt: new Date().toISOString(),
          };
          await storage.updateModelingProject(projectId, { customMetrics: cm, updatedBy: req.user.id } as any, orgId);
        }
      } catch (persistErr) {
        console.warn('Failed to persist deal pricing results:', persistErr);
      }

      res.json(result);
    } catch (error: any) {
      console.error('Failed to calculate unified deal pricing:', error);
      res.status(500).json({ error: error.message || 'Failed to calculate deal pricing' });
    }
  });

  // Project Workspace - Deal Pricing (legacy bidirectional solve-for calculations)
  app.post('/api/modeling/projects/:projectId/deal-pricing', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const {
        manualPurchasePrice,
        targetIRR,
        goingInCapRate,
        targetYearCapRate,
        targetYear,
        holdPeriod = 5,
        exitCapRate = 7.5,
        revenueGrowthRate,
        expenseGrowthRate,
        periodLabel,
        periodNOI,
        periodRevenue,
        periodExpenses,
        useNormalizedData = true,
      } = req.body;

      let adjustedNOI = periodNOI ? Number(periodNOI) : undefined;
      let adjustedRevenue = periodRevenue ? Number(periodRevenue) : undefined;
      let adjustedExpenses = periodExpenses ? Number(periodExpenses) : undefined;

      if (useNormalizedData && periodLabel) {
        try {
          const adjustments = await storage.getActiveAdjustmentsForPeriod(projectId, periodLabel, orgId);
          if (adjustments.length > 0) {
            for (const adj of adjustments) {
              const target = (adj.targetIdentifier || '').toLowerCase();
              const value = Number(adj.adjustmentValue) || 0;
              const adjType = adj.adjustmentType;

              if (target === 'revenue' || target.includes('revenue')) {
                const base = adjustedRevenue || 0;
                if (adjType === 'absolute') adjustedRevenue = base + value;
                else if (adjType === 'percentage') adjustedRevenue = base * (1 + value / 100);
                else if (adjType === 'replace') adjustedRevenue = value;
              } else if (target === 'expenses' || target.includes('expense')) {
                const base = adjustedExpenses || 0;
                if (adjType === 'absolute') adjustedExpenses = base + value;
                else if (adjType === 'percentage') adjustedExpenses = base * (1 + value / 100);
                else if (adjType === 'replace') adjustedExpenses = value;
              } else if (target === 'noi' || target.includes('noi')) {
                const base = adjustedNOI || 0;
                if (adjType === 'absolute') adjustedNOI = base + value;
                else if (adjType === 'percentage') adjustedNOI = base * (1 + value / 100);
                else if (adjType === 'replace') adjustedNOI = value;
              }
            }
            if (adjustedRevenue !== undefined && adjustedExpenses !== undefined) {
              const recalcNOI = adjustedRevenue - adjustedExpenses;
              if (adjustedNOI === undefined || adjustedNOI === (periodNOI ? Number(periodNOI) : undefined)) {
                adjustedNOI = recalcNOI;
              }
            }
          }
        } catch (adjError) {
          console.warn('Failed to apply period adjustments:', adjError);
        }
      }

      const results = await dealPricingService.calculateAllPricingModes(
        projectId,
        orgId,
        {
          manualPurchasePrice: manualPurchasePrice ? Number(manualPurchasePrice) : undefined,
          targetIRR: targetIRR ? Number(targetIRR) : undefined,
          goingInCapRate: goingInCapRate ? Number(goingInCapRate) : undefined,
          targetYearCapRate: targetYearCapRate ? Number(targetYearCapRate) : undefined,
          targetYear: targetYear ? Number(targetYear) : undefined,
          holdPeriod: Number(holdPeriod),
          exitCapRate: Number(exitCapRate),
          revenueGrowthRate: revenueGrowthRate ? Number(revenueGrowthRate) / 100 : undefined,
          expenseGrowthRate: expenseGrowthRate ? Number(expenseGrowthRate) / 100 : undefined,
          periodLabel,
          periodNOI: adjustedNOI,
          periodRevenue: adjustedRevenue,
          periodExpenses: adjustedExpenses,
        }
      );

      res.json({
        ...results,
        usingNormalizedData: useNormalizedData,
      });
    } catch (error: any) {
      console.error('Failed to calculate deal pricing:', error);
      res.status(500).json({ error: error.message || 'Failed to calculate deal pricing' });
    }
  });

  // Get persisted deal pricing inputs
  app.get('/api/modeling/projects/:projectId/deal-pricing/inputs', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      const customMetrics = (project.customMetrics as any) || {};
      const dealPricing = customMetrics.dealPricing || null;
      res.json(dealPricing);
    } catch (error: any) {
      console.error('Failed to get deal pricing inputs:', error);
      res.status(500).json({ error: error.message || 'Failed to get deal pricing inputs' });
    }
  });

  // Persist deal pricing inputs (auto-save as user changes them)
  app.put('/api/modeling/projects/:projectId/deal-pricing/inputs', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { targetIRR, goingInCapRate, exitCapRate, holdPeriod, pricingDriver, purchasePrice, lockedInputs } = req.body;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const customMetrics = { ...((project.customMetrics as any) || {}) };
      customMetrics.dealPricing = {
        targetIRR,
        goingInCapRate,
        exitCapRate,
        holdPeriod,
        pricingDriver,
        purchasePrice,
        lockedInputs: Array.isArray(lockedInputs) ? lockedInputs : [],
        updatedAt: new Date().toISOString(),
      };

      const updates: any = { customMetrics, updatedBy: userId };
      if (purchasePrice !== undefined && purchasePrice !== null) {
        updates.purchasePrice = String(purchasePrice);
      }
      if (goingInCapRate !== undefined && goingInCapRate !== null) {
        updates.year1CapRate = String(goingInCapRate);
      }

      const updated = await storage.updateModelingProject(projectId, updates, orgId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to save deal pricing inputs:', error);
      res.status(500).json({ error: error.message || 'Failed to save deal pricing inputs' });
    }
  });

  app.post('/api/modeling/projects/:projectId/save', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;

      const project = await storage.updateModelingProject(projectId, { updatedBy: userId } as any, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      res.json({ success: true, updatedAt: project.updatedAt });
    } catch (error: any) {
      console.error('Failed to save project:', error);
      res.status(500).json({ error: error.message || 'Failed to save project' });
    }
  });

  app.put('/api/modeling/projects/:projectId/target-price', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { targetPrice } = req.body;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const customMetrics = { ...((project.customMetrics as any) || {}) };
      customMetrics.targetPrice = targetPrice;

      await storage.updateModelingProject(projectId, { customMetrics, updatedBy: userId }, orgId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to save target price:', error);
      res.status(500).json({ error: error.message || 'Failed to save target price' });
    }
  });

  // Save deal pricing configuration (legacy explicit save button)
  app.post('/api/modeling/projects/:projectId/deal-pricing/save', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { purchasePrice, year1CapRate } = req.body;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const updates: any = { updatedBy: userId };
      if (purchasePrice !== undefined) {
        updates.purchasePrice = String(purchasePrice);
      }
      if (year1CapRate !== undefined) {
        updates.year1CapRate = String(year1CapRate);
      }

      const updated = await storage.updateModelingProject(projectId, updates, orgId);
      res.json(updated);
    } catch (error: any) {
      console.error('Failed to save deal pricing:', error);
      res.status(500).json({ error: error.message || 'Failed to save deal pricing' });
    }
  });

  // Project Workspace - Period Adjustments (Analytics & Normalization)
  app.get('/api/modeling/projects/:projectId/period-adjustments', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { periodLabel } = req.query;

      const adjustments = await storage.getModelingPeriodAdjustments(projectId, orgId, periodLabel as string);
      res.json(adjustments);
    } catch (error: any) {
      console.error('Failed to fetch period adjustments:', error);
      res.status(500).json({ error: error.message || 'Failed to fetch period adjustments' });
    }
  });

  app.post('/api/modeling/projects/:projectId/period-adjustments', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const {
        periodLabel,
        scope,
        targetIdentifier,
        targetLabel,
        adjustmentType,
        adjustmentValue,
        originalValue,
        adjustedValue,
        reason,
        isActive = true
      } = req.body;

      const adjustment = await storage.createModelingPeriodAdjustment({
        id: crypto.randomUUID(),
        orgId,
        modelingProjectId: projectId,
        periodLabel,
        scope,
        targetIdentifier,
        targetLabel,
        adjustmentType,
        adjustmentValue: String(adjustmentValue),
        originalValue: originalValue ? String(originalValue) : null,
        adjustedValue: adjustedValue ? String(adjustedValue) : null,
        reason,
        isActive,
        createdBy: userId,
      });

      res.json(adjustment);
    } catch (error: any) {
      console.error('Failed to create period adjustment:', error);
      res.status(500).json({ error: error.message || 'Failed to create period adjustment' });
    }
  });

  app.patch('/api/modeling/projects/:projectId/period-adjustments/:adjustmentId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, adjustmentId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const adjustment = await storage.getModelingPeriodAdjustment(adjustmentId, orgId);
      if (!adjustment) {
        return res.status(404).json({ error: 'Adjustment not found' });
      }

      const {
        adjustmentType,
        adjustmentValue,
        originalValue,
        adjustedValue,
        reason,
        isActive
      } = req.body;

      const updates: any = { updatedBy: userId };
      if (adjustmentType !== undefined) updates.adjustmentType = adjustmentType;
      if (adjustmentValue !== undefined) updates.adjustmentValue = String(adjustmentValue);
      if (originalValue !== undefined) updates.originalValue = String(originalValue);
      if (adjustedValue !== undefined) updates.adjustedValue = String(adjustedValue);
      if (reason !== undefined) updates.reason = reason;
      if (isActive !== undefined) updates.isActive = isActive;

      const updated = await storage.updateModelingPeriodAdjustment(adjustmentId, updates, orgId);
      res.json(updated);
    } catch (error: any) {
      console.error('Failed to update period adjustment:', error);
      res.status(500).json({ error: error.message || 'Failed to update period adjustment' });
    }
  });

  app.delete('/api/modeling/projects/:projectId/period-adjustments/:adjustmentId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, adjustmentId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const deleted = await storage.deleteModelingPeriodAdjustment(adjustmentId, orgId);
      if (!deleted) {
        return res.status(404).json({ error: 'Adjustment not found' });
      }

      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete period adjustment:', error);
      res.status(500).json({ error: error.message || 'Failed to delete period adjustment' });
    }
  });

  // Project Workspace - Assumptions
  app.get('/api/modeling/projects/:projectId/assumptions', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const assumptions = (project.customMetrics as any)?.assumptions || null;
      res.json(assumptions);
    } catch (error: any) {
      console.error('Failed to fetch project assumptions:', error);
      res.status(500).json({ error: 'Failed to fetch project assumptions' });
    }
  });

  app.post('/api/modeling/projects/:projectId/assumptions', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const existingMetrics = (project.customMetrics as any) || {};
      const updatedMetrics = {
        ...existingMetrics,
        assumptions: req.body
      };
      
      const updated = await storage.updateModelingProject(
        projectId,
        { customMetrics: updatedMetrics, updatedBy: userId },
        orgId
      );
      
      res.json(req.body);
    } catch (error: any) {
      console.error('Failed to save project assumptions:', error);
      res.status(500).json({ error: 'Failed to save project assumptions' });
    }
  });

  // Project Workspace - Multi-Year Historical P&L
  app.get('/api/modeling/projects/:projectId/historical-pl', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { proFormaEngineService } = await import('./services/pro-forma-engine-service');
      const multiYearData = await proFormaEngineService.getMultiYearHistoricalPL(projectId, orgId);
      res.json(multiYearData);
    } catch (error: any) {
      console.error('Failed to fetch multi-year historical P&L:', error);
      res.status(500).json({ error: 'Failed to fetch multi-year historical P&L' });
    }
  });

  // Project Workspace - Historical P&L with data binding (single year)
  app.get('/api/modeling/projects/:projectId/historical-pl/:year', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, year } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { proFormaEngineService } = await import('./services/pro-forma-engine-service');
      const historicalData = await proFormaEngineService.getHistoricalPL(
        projectId, 
        orgId, 
        year ? parseInt(year) : undefined
      );
      res.json(historicalData);
    } catch (error: any) {
      console.error('Failed to fetch historical P&L:', error);
      res.status(500).json({ error: 'Failed to fetch historical P&L' });
    }
  });

  // Project Workspace - Pro Forma with real-time calculations
  app.get('/api/modeling/projects/:projectId/pro-forma', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const scenarioType = (req.query.scenario as string) || 'base';
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { proFormaEngineService } = await import('./services/pro-forma-engine-service');
      const proFormaData = await proFormaEngineService.generateProForma(projectId, orgId, scenarioType);
      res.json(proFormaData);
    } catch (error: any) {
      console.error('Failed to fetch pro forma:', error);
      res.status(500).json({ error: 'Failed to fetch pro forma' });
    }
  });

  app.get('/api/modeling/projects/:projectId/scenario-comparison', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { proFormaEngineService } = await import('./services/pro-forma-engine-service');

      const scenarioTypes = ['base', 'aggressive', 'conservative'];
      const scenarioLabels: Record<string, { name: string; description: string }> = {
        base: { name: 'Base Case', description: 'Conservative assumptions based on historical performance' },
        aggressive: { name: 'Upside Case', description: 'Optimistic scenario with value-add initiatives' },
        conservative: { name: 'Downside Case', description: 'Stress test with adverse market conditions' },
      };

      const proFormaResults = await Promise.all(
        scenarioTypes.map(async (st) => {
          try {
            const pf = await proFormaEngineService.generateProForma(projectId, orgId, st);
            return { scenarioType: st, data: pf, error: null };
          } catch (err: any) {
            return { scenarioType: st, data: null, error: err.message };
          }
        })
      );

      const safe = (v: number) => (isFinite(v) ? v : 0);

      const scenarios = proFormaResults
        .filter(r => r.data)
        .map(r => {
          const pf = r.data!;
          const m = pf.metrics;
          const noiMargin = (pf.revenue.totals?.[0] ?? 0) > 0
            ? (safe(pf.noi?.[0] ?? 0) / pf.revenue.totals[0]) * 100
            : 0;

          const revenueBreakdown = pf.revenue.lineItems.map(li => ({
            name: li.name || li.subcategory || li.department || 'Other',
            value: li.projections?.[0] ?? li.baseAmount ?? 0,
          })).filter(r => r.value > 0);

          const irr = safe(m.irr);
          const eqMult = safe(m.equityMultiple);
          const exitVal = safe(m.exitValue);
          const purchasePrice = safe(m.purchasePrice);

          const risks: Array<{ id: string; severity: 'low' | 'medium' | 'high'; message: string }> = [];
          if (irr < 10) risks.push({ id: 'low_irr', severity: 'high', message: `IRR of ${irr.toFixed(1)}% is below 10% threshold` });
          else if (irr < 15) risks.push({ id: 'moderate_irr', severity: 'medium', message: `IRR of ${irr.toFixed(1)}% is below 15% target` });
          if (noiMargin < 30) risks.push({ id: 'thin_margin', severity: 'high', message: `NOI margin of ${noiMargin.toFixed(1)}% is below 30%` });
          else if (noiMargin < 40) risks.push({ id: 'moderate_margin', severity: 'medium', message: `NOI margin of ${noiMargin.toFixed(1)}% is below 40%` });
          if (eqMult < 1.5) risks.push({ id: 'low_equity', severity: 'high', message: `Equity multiple of ${eqMult.toFixed(2)}x is below 1.5x` });
          if (m.minDscr !== undefined && isFinite(m.minDscr) && m.minDscr < 1.2) risks.push({ id: 'low_dscr', severity: 'high', message: `Min DSCR of ${m.minDscr.toFixed(2)}x is below 1.2x` });
          if (exitVal < purchasePrice && purchasePrice > 0) risks.push({ id: 'value_loss', severity: 'high', message: 'Exit value is below purchase price' });

          const label = scenarioLabels[r.scenarioType] || { name: r.scenarioType, description: '' };

          return {
            id: r.scenarioType,
            name: label.name,
            description: label.description,
            color: r.scenarioType === 'base' ? '#3b82f6' : r.scenarioType === 'aggressive' ? '#10b981' : '#ef4444',
            metrics: {
              purchasePrice: purchasePrice,
              noi: safe(m.year1Noi),
              stabilizedNoi: safe(m.stabilizedNoi),
              capRate: safe(m.goingInCapRate),
              exitCapRate: safe(m.exitCapRate),
              irr,
              unleveredIrr: safe(m.unleveredIrr),
              equityMultiple: eqMult,
              cashOnCash: purchasePrice > 0 ? safe((pf.leveredCashFlow?.[0] ?? 0) / purchasePrice) * 100 : 0,
              exitValue: exitVal,
              totalRevenue: pf.revenue.totals?.[0] ?? 0,
              totalExpenses: pf.expenses.totals?.[0] ?? 0,
              noiMargin: safe(noiMargin),
              totalReturn: safe(m.totalReturn),
              minDscr: m.minDscr !== undefined ? safe(m.minDscr) : undefined,
              avgDscr: m.avgDscr !== undefined ? safe(m.avgDscr) : undefined,
            },
            assumptions: {
              revenueGrowth: m.revenueGrowthRate,
              expenseGrowth: m.expenseGrowthRate,
              exitCapRate: m.exitCapRate,
            },
            yearlyData: (pf.annualProjections || []).map(ap => ({
              year: (ap.yearIndex ?? 0) + 1,
              label: ap.label || `Year ${(ap.yearIndex ?? 0) + 1}`,
              revenue: safe(ap.revenue),
              expenses: safe(ap.expenses),
              noi: safe(ap.noi),
              cashFlow: safe(ap.leveredCashFlow),
              debtService: safe(ap.debtService),
            })),
            revenueBreakdown,
            risks,
          };
        });

      const baseMetrics = scenarios.find(s => s.id === 'base')?.metrics;
      const metricDefs = [
        { id: 'purchasePrice', name: 'Purchase Price', unit: 'currency' },
        { id: 'noi', name: 'Year 1 NOI', unit: 'currency' },
        { id: 'capRate', name: 'Going-In Cap Rate', unit: 'percent' },
        { id: 'irr', name: 'Levered IRR', unit: 'percent' },
        { id: 'equityMultiple', name: 'Equity Multiple', unit: 'multiple' },
        { id: 'exitValue', name: 'Exit Value', unit: 'currency' },
        { id: 'noiMargin', name: 'NOI Margin', unit: 'percent' },
        { id: 'totalReturn', name: 'Total Return', unit: 'currency' },
      ];

      const comparisonMetrics = metricDefs.map(md => ({
        id: md.id,
        name: md.name,
        unit: md.unit,
        metric: md.name,
        scenarios: scenarios.map(s => {
          const val = (s.metrics as any)[md.id] ?? 0;
          const baseVal = baseMetrics ? (baseMetrics as any)[md.id] ?? 0 : val;
          return {
            id: s.id,
            value: val,
            variance: baseVal !== 0 && s.id !== 'base' ? ((val - baseVal) / Math.abs(baseVal)) * 100 : 0,
          };
        }),
      }));

      res.json({ projectId, scenarios, comparisonMetrics });
    } catch (error: any) {
      console.error('Failed to generate scenario comparison:', error);
      res.status(500).json({ error: 'Failed to generate scenario comparison' });
    }
  });

  // Project Workspace - Executive Summary with real-time calculations
  app.get('/api/modeling/projects/:projectId/executive-summary/:scenario', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, scenario } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { proFormaEngineService } = await import('./services/pro-forma-engine-service');
      const proForma = await proFormaEngineService.generateProForma(projectId, orgId, scenario);
      
      const summaryData = {
        scenario,
        projectName: project.marinaName || project.name,
        purchasePrice: proForma.metrics.purchasePrice,
        totalUnits: project.totalUnits,
        acreage: project.acreage,
        leveredIRR: proForma.metrics.irr,
        unleveredIRR: proForma.metrics.unleveredIrr,
        equityMultiple: proForma.metrics.equityMultiple,
        unleveredEquityMultiple: proForma.metrics.unleveredEquityMultiple,
        metrics: {
          goingInCapRate: proForma.metrics.goingInCapRate,
          exitCapRate: proForma.metrics.exitCapRate,
          irr: proForma.metrics.irr,
          equityMultiple: proForma.metrics.equityMultiple,
          totalReturn: proForma.metrics.totalReturn
        },
        yearOne: {
          revenue: proForma.revenue.totals[0],
          expenses: proForma.expenses.totals[0],
          noi: proForma.noi[0]
        },
        exitYear: {
          revenue: proForma.revenue.totals[proForma.revenue.totals.length - 1],
          expenses: proForma.expenses.totals[proForma.expenses.totals.length - 1],
          noi: proForma.noi[proForma.noi.length - 1],
          exitValue: proForma.metrics.exitValue
        },
        growthRates: {
          revenue: proForma.metrics.revenueGrowthRate,
          expenses: proForma.metrics.expenseGrowthRate
        },
        projectionYears: proForma.years,
        noiByyear: proForma.noi
      };
      
      res.json(summaryData);
    } catch (error: any) {
      console.error('Failed to fetch executive summary:', error);
      res.status(500).json({ error: 'Failed to fetch executive summary' });
    }
  });

  // ============================================================================
  // MONTE CARLO SIMULATION - Stochastic Analysis Engine
  // ============================================================================

  // Get persisted Monte Carlo results and config (does NOT auto-run)
  app.get('/api/modeling/projects/:projectId/monte-carlo', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const customMetrics = (project.customMetrics as any) || {};
      const savedResults = customMetrics.monteCarloResults || null;
      const savedConfig = customMetrics.monteCarloConfig || null;

      if (!savedResults) {
        const { monteCarloService } = await import('./services/monte-carlo-service');
        const baseFinancials = await (await import('./services/deal-pricing-service')).dealPricingService.getProjectFinancials(projectId, orgId);
        const dealPricingInputs = customMetrics.dealPricing || {};
        const purchasePrice = dealPricingInputs.purchasePrice || (baseFinancials.purchasePrice ? Number(baseFinancials.purchasePrice) : 5000000);
        const year1NOI = baseFinancials.year1NOI || 500000;
        const defaultVariables = monteCarloService.buildDefaultVariables(purchasePrice, year1NOI, dealPricingInputs);
        return res.json({ hasResults: false, config: savedConfig, defaultVariables });
      }

      res.json({ hasResults: true, ...savedResults, config: savedConfig });
    } catch (error: any) {
      console.error('Failed to get Monte Carlo data:', error);
      res.status(500).json({ error: 'Failed to get Monte Carlo data' });
    }
  });

  // Run Monte Carlo simulation and persist results
  app.post('/api/modeling/projects/:projectId/monte-carlo/run', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { variables, iterations = 10000, confidenceLevel = 0.95 } = req.body;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { monteCarloService } = await import('./services/monte-carlo-service');
      const simulationInput: { iterations: number; confidenceLevel: number; variables?: any } = {
        iterations,
        confidenceLevel,
      };
      if (variables) {
        simulationInput.variables = variables;
      }

      const analysis = await monteCarloService.runSimulation(projectId, orgId, simulationInput);

      const resultsToSave = {
        ...analysis,
        results: {
          irr: { ...analysis.results.irr, values: [] },
          npv: { ...analysis.results.npv, values: [] },
          equityMultiple: { ...analysis.results.equityMultiple, values: [] },
          cashOnCash: { ...analysis.results.cashOnCash, values: [] },
        },
      };

      const customMetrics = { ...((project.customMetrics as any) || {}) };
      customMetrics.monteCarloResults = resultsToSave;
      customMetrics.monteCarloConfig = {
        variables: analysis.variables,
        iterations,
        confidenceLevel,
        updatedAt: new Date().toISOString(),
      };

      await storage.updateModelingProject(projectId, { customMetrics, updatedBy: userId }, orgId);

      res.json(analysis);
    } catch (error: any) {
      console.error('Failed to run Monte Carlo simulation:', error);
      res.status(500).json({ error: 'Failed to run Monte Carlo simulation' });
    }
  });

  // Save Monte Carlo configuration (variable distributions)
  app.post('/api/modeling/projects/:projectId/monte-carlo/config', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { variables, iterations, confidenceLevel } = req.body;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const customMetrics = { ...((project.customMetrics as any) || {}) };
      customMetrics.monteCarloConfig = {
        variables,
        iterations: iterations || 10000,
        confidenceLevel: confidenceLevel || 0.95,
        updatedAt: new Date().toISOString(),
      };

      await storage.updateModelingProject(projectId, { customMetrics, updatedBy: userId }, orgId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to save Monte Carlo config:', error);
      res.status(500).json({ error: 'Failed to save Monte Carlo config' });
    }
  });

  // Quick simulation for real-time feedback
  app.get('/api/modeling/projects/:projectId/monte-carlo/quick', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { monteCarloService } = await import('./services/monte-carlo-service');
      const quickResult = await monteCarloService.quickSimulation(projectId, orgId);
      res.json(quickResult);
    } catch (error: any) {
      console.error('Failed to run quick Monte Carlo:', error);
      res.status(500).json({ error: 'Failed to run quick Monte Carlo' });
    }
  });

  // ============================================================================
  // DCF CALCULATOR - Real-Time Discounted Cash Flow Analysis
  // ============================================================================

  // Perform full DCF analysis with multiple scenarios
  app.get('/api/modeling/projects/:projectId/dcf', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { dcfCalculatorService } = await import('./services/dcf-calculator-service');
      const analysis = await dcfCalculatorService.performDCFAnalysis(projectId, orgId);
      res.json(analysis);
    } catch (error: any) {
      console.error('Failed to perform DCF analysis:', error);
      res.status(500).json({ error: 'Failed to perform DCF analysis' });
    }
  });

  // Calculate DCF with custom scenarios
  app.post('/api/modeling/projects/:projectId/dcf/calculate', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { scenarios } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { dcfCalculatorService } = await import('./services/dcf-calculator-service');
      const analysis = await dcfCalculatorService.performDCFAnalysis(projectId, orgId, scenarios);
      res.json(analysis);
    } catch (error: any) {
      console.error('Failed to calculate custom DCF:', error);
      res.status(500).json({ error: 'Failed to calculate custom DCF' });
    }
  });

  // Quick IRR calculation for real-time updates
  app.post('/api/dcf/quick-irr', authenticateUser, async (req: any, res) => {
    try {
      const { input } = req.body;
      
      const { dcfCalculatorService } = await import('./services/dcf-calculator-service');
      const irr = dcfCalculatorService.quickIRR(input);
      res.json({ irr });
    } catch (error: any) {
      console.error('Failed to calculate quick IRR:', error);
      res.status(500).json({ error: 'Failed to calculate quick IRR' });
    }
  });

  // Quick NPV calculation for real-time updates
  app.post('/api/dcf/quick-npv', authenticateUser, async (req: any, res) => {
    try {
      const { input } = req.body;
      
      const { dcfCalculatorService } = await import('./services/dcf-calculator-service');
      const npv = dcfCalculatorService.quickNPV(input);
      res.json({ npv });
    } catch (error: any) {
      console.error('Failed to calculate quick NPV:', error);
      res.status(500).json({ error: 'Failed to calculate quick NPV' });
    }
  });

  // Generate sensitivity matrix
  app.post('/api/dcf/sensitivity', authenticateUser, async (req: any, res) => {
    try {
      const { baseInput, var1Config, var2Config, metric } = req.body;
      
      const { dcfCalculatorService } = await import('./services/dcf-calculator-service');
      const matrix = dcfCalculatorService.generateSensitivityMatrix(
        baseInput,
        var1Config,
        var2Config,
        metric
      );
      res.json(matrix);
    } catch (error: any) {
      console.error('Failed to generate sensitivity matrix:', error);
      res.status(500).json({ error: 'Failed to generate sensitivity matrix' });
    }
  });

  // ============================================================================
  // MARINA PROFIT CENTER MODULE - Multi-Revenue Stream Financial Modeling
  // ============================================================================

  // Get comprehensive marina profit center analysis
  app.get('/api/modeling/projects/:projectId/profit-centers', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { marinaProfitCenterService } = await import('./services/marina-profit-center-service');
      const financialModel = await marinaProfitCenterService.calculateMarinaFinancials(projectId, orgId);
      res.json(financialModel);
    } catch (error: any) {
      console.error('Failed to calculate profit centers:', error);
      res.status(500).json({ error: 'Failed to calculate profit centers' });
    }
  });

  // Get profit center breakdown for a specific year
  app.get('/api/modeling/projects/:projectId/profit-centers/breakdown', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const year = req.query.year ? parseInt(req.query.year as string) : undefined;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { marinaProfitCenterService } = await import('./services/marina-profit-center-service');
      const breakdown = await marinaProfitCenterService.getProfitCenterBreakdown(projectId, orgId, year);
      res.json(breakdown);
    } catch (error: any) {
      console.error('Failed to get profit center breakdown:', error);
      res.status(500).json({ error: 'Failed to get profit center breakdown' });
    }
  });

  // Calculate with custom assumptions
  app.post('/api/modeling/projects/:projectId/profit-centers/calculate', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { assumptions } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { marinaProfitCenterService } = await import('./services/marina-profit-center-service');
      const financialModel = await marinaProfitCenterService.calculateMarinaFinancials(projectId, orgId, assumptions);
      res.json(financialModel);
    } catch (error: any) {
      console.error('Failed to calculate custom profit centers:', error);
      res.status(500).json({ error: 'Failed to calculate custom profit centers' });
    }
  });

  // ============================================================================
  // LEASE CASH FLOW ENGINE - Argus-Style Lease-by-Lease DCF
  // ============================================================================

  // Get full lease-by-lease cash flow analysis
  app.get('/api/modeling/projects/:projectId/lease-cashflow', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const scenarioType = (req.query.scenario as string) || 'base';
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { leaseCashFlowEngine } = await import('./services/lease-cashflow-engine');
      const cashFlowData = await leaseCashFlowEngine.calculatePropertyCashFlow(
        projectId, 
        orgId, 
        scenarioType
      );
      res.json(cashFlowData);
    } catch (error: any) {
      console.error('Failed to calculate lease cash flow:', error);
      res.status(500).json({ error: 'Failed to calculate lease cash flow' });
    }
  });

  // Get rollover schedule (lease expirations by year)
  app.get('/api/modeling/projects/:projectId/rollover-schedule', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { leaseCashFlowEngine } = await import('./services/lease-cashflow-engine');
      const rolloverData = await leaseCashFlowEngine.getRolloverSchedule(projectId, orgId);
      res.json(rolloverData);
    } catch (error: any) {
      console.error('Failed to get rollover schedule:', error);
      res.status(500).json({ error: 'Failed to get rollover schedule' });
    }
  });

  // Get tenant performance metrics
  app.get('/api/modeling/projects/:projectId/tenant-performance', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { leaseCashFlowEngine } = await import('./services/lease-cashflow-engine');
      const tenantData = await leaseCashFlowEngine.getTenantPerformance(projectId, orgId);
      res.json(tenantData);
    } catch (error: any) {
      console.error('Failed to get tenant performance:', error);
      res.status(500).json({ error: 'Failed to get tenant performance' });
    }
  });

  // Calculate custom scenario with overridden assumptions
  app.post('/api/modeling/projects/:projectId/lease-cashflow/calculate', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { scenarioType, assumptions } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }
      
      const { leaseCashFlowEngine } = await import('./services/lease-cashflow-engine');
      const cashFlowData = await leaseCashFlowEngine.calculatePropertyCashFlow(
        projectId, 
        orgId, 
        scenarioType || 'base',
        assumptions
      );
      res.json(cashFlowData);
    } catch (error: any) {
      console.error('Failed to calculate custom scenario:', error);
      res.status(500).json({ error: 'Failed to calculate custom scenario' });
    }
  });

  // ============================================================================
  // OPERATIONS DATA SYNC - Sync Rent Roll, Fuel Sales, Ship Store to Modeling
  // ============================================================================

  // Trigger operations data sync for a modeling project
  app.post('/api/modeling/projects/:projectId/sync-operations', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { dataSources, dateRangeStart, dateRangeEnd, syncType } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { operationsDataSyncService } = await import('./services/operations-data-sync-service');
      
      const result = await operationsDataSyncService.syncOperationsData({
        projectId,
        orgId,
        userId,
        dataSources: dataSources || ['rent_roll', 'fuel_sales', 'ship_store'],
        dateRangeStart: dateRangeStart ? new Date(dateRangeStart) : undefined,
        dateRangeEnd: dateRangeEnd ? new Date(dateRangeEnd) : undefined,
        syncType: syncType || 'manual'
      });

      res.json(result);
    } catch (error: any) {
      console.error('Failed to sync operations data:', error);
      res.status(500).json({ error: 'Failed to sync operations data' });
    }
  });

  // Get actuals data for a modeling project
  app.get('/api/modeling/projects/:projectId/actuals', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { year } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { operationsDataSyncService } = await import('./services/operations-data-sync-service');
      
      const actuals = await operationsDataSyncService.getActualsForProject(
        projectId, 
        year ? parseInt(year as string) : undefined
      );

      const { modelingPnlOverrides } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');
      const overrides = await db.select()
        .from(modelingPnlOverrides)
        .where(and(eq(modelingPnlOverrides.projectId, projectId), eq(modelingPnlOverrides.orgId, orgId)));

      const excludeSet = new Set(
        overrides.filter(o => o.overrideType === 'exclude' && o.isActive).map(o => o.lineItemKey)
      );
      const deptOverrideMap: Record<string, string> = {};
      overrides.filter(o => o.overrideType === 'department' && o.isActive && o.overrideDepartment)
        .forEach(o => { deptOverrideMap[o.lineItemKey] = o.overrideDepartment!; });

      // Group by category and subcategory for P&L display
      const { inferDepartment } = await import('./utils/department-mapping');
      const grouped = actuals.reduce((acc: any, item) => {
        const subcategory = item.subcategory || '';
        if (excludeSet.has(subcategory)) return acc;

        const key = `${item.category}-${subcategory}`;
        if (!acc[key]) {
          const dept = deptOverrideMap[subcategory] || item.department || inferDepartment(subcategory, item.category);
          acc[key] = {
            category: item.category,
            subcategory,
            department: dept,
            monthlyData: {},
            annualTotal: 0
          };
        }
        const MONTH_KEYS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']; const monthKey = MONTH_KEYS[(item.month - 1) % 12];
        const amount = parseFloat(item.amount);
        acc[key].monthlyData[monthKey] = (acc[key].monthlyData[monthKey] || 0) + amount;
        acc[key].annualTotal += amount;
        return acc;
      }, {});
      res.json({
        raw: actuals,
        grouped: Object.values(grouped),
        year: year ? parseInt(year as string) : undefined
      });

    } catch (error: any) {
      console.error('Failed to fetch actuals:', error);
      res.status(500).json({ error: 'Failed to fetch actuals' });
    }
  });

  // Get available years for actuals data
  app.get('/api/modeling/projects/:projectId/actuals/years', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { operationsDataSyncService } = await import('./services/operations-data-sync-service');
      const years = await operationsDataSyncService.getAvailableYears(projectId);

      res.json({ years });
    } catch (error: any) {
      console.error('Failed to fetch available years:', error);
      res.status(500).json({ error: 'Failed to fetch available years' });
    }
  });

  // Get actuals for multiple years for comparison
  app.get('/api/modeling/projects/:projectId/actuals/multi-year', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { years } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { operationsDataSyncService } = await import('./services/operations-data-sync-service');
      const yearList = years ? String(years).split(',').map(Number) : [];
      const actualsData = await operationsDataSyncService.getActualsForMultipleYears(projectId, yearList);

      const { modelingPnlOverrides } = await import('@shared/schema');
      const { eq, and } = await import('drizzle-orm');
      const overrides = await db.select()
        .from(modelingPnlOverrides)
        .where(and(eq(modelingPnlOverrides.projectId, projectId), eq(modelingPnlOverrides.orgId, orgId)));
      const excludeSet = new Set(
        overrides.filter(o => o.overrideType === 'exclude' && o.isActive).map(o => o.lineItemKey)
      );
      const deptOverrideMap: Record<string, string> = {};
      overrides.filter(o => o.overrideType === 'department' && o.isActive && o.overrideDepartment)
        .forEach(o => { deptOverrideMap[o.lineItemKey] = o.overrideDepartment!; });
      const categoryOverrideMap: Record<string, string> = {};
      overrides.filter(o => o.overrideType === 'department' && o.isActive && o.overrideCategory)
        .forEach(o => { categoryOverrideMap[o.lineItemKey] = o.overrideCategory!; });

      const { inferDepartment: inferDepartmentFn } = await import('./utils/department-mapping');
      // Group each year's data
      const groupedByYear: Record<number, any> = {};
      for (const [year, actuals] of Object.entries(actualsData)) {
        const grouped = (actuals as any[]).reduce((acc: any, item) => {
          const subcategory = item.subcategory || '';
          if (excludeSet.has(subcategory)) return acc;

          const effectiveCategory = categoryOverrideMap[subcategory] || item.category;
          const key = `${effectiveCategory}-${subcategory}`;
          if (!acc[key]) {
            const dept = deptOverrideMap[subcategory] || item.department || inferDepartmentFn(subcategory, effectiveCategory);
            acc[key] = {
              category: effectiveCategory,
              subcategory,
              department: dept,
              monthlyData: {},
              annualTotal: 0
            };
          }
          const MONTH_KEYS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']; const monthKey = MONTH_KEYS[(item.month - 1) % 12];
          const amount = parseFloat(item.amount);
          acc[key].monthlyData[monthKey] = (acc[key].monthlyData[monthKey] || 0) + amount;
          acc[key].annualTotal += amount;
          return acc;
        }, {});
        groupedByYear[Number(year)] = Object.values(grouped);
      }

      res.json({ byYear: groupedByYear, years: yearList });
    } catch (error: any) {
      console.error('Failed to fetch multi-year actuals:', error);
      res.status(500).json({ error: 'Failed to fetch multi-year actuals' });
    }
  });

  // Get sync job history for a project
  app.get('/api/modeling/projects/:projectId/sync-history', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { operationsDataSyncService } = await import('./services/operations-data-sync-service');
      const history = await operationsDataSyncService.getSyncJobHistory(projectId);

      res.json(history);
    } catch (error: any) {
      console.error('Failed to fetch sync history:', error);
      res.status(500).json({ error: 'Failed to fetch sync history' });
    }
  });

  // Get data source summary for a project
  app.get('/api/modeling/projects/:projectId/data-sources', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { operationsDataSyncService } = await import('./services/operations-data-sync-service');
      const summary = await operationsDataSyncService.getDataSourceSummary(projectId);

      res.json(summary);
    } catch (error: any) {
      console.error('Failed to fetch data sources:', error);
      res.status(500).json({ error: 'Failed to fetch data sources' });
    }
  });

  // ============================================================================
  // SCENARIO VERSIONING - Institutional-grade scenario management with history
  // ============================================================================

  // Get all current scenarios for a project
  app.get('/api/modeling/projects/:projectId/scenarios', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenarios = await scenarioVersioningService.getCurrentScenarios(projectId);

      res.json(scenarios);
    } catch (error: any) {
      console.error('Failed to fetch scenarios:', error);
      res.status(500).json({ error: 'Failed to fetch scenarios' });
    }
  });

  // Initialize default scenarios for a project
  app.post('/api/modeling/projects/:projectId/scenarios/init', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenarios = await scenarioVersioningService.initializeDefaultScenarios(projectId, orgId, userId);

      res.json(scenarios);
    } catch (error: any) {
      console.error('Failed to initialize scenarios:', error);
      res.status(500).json({ error: 'Failed to initialize scenarios' });
    }
  });

  // Create a new scenario
  app.post('/api/modeling/projects/:projectId/scenarios', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { scenarioType, name, description, revenueGrowthRate, expenseGrowthRate, exitCapRate, assumptions } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenario = await scenarioVersioningService.createScenario({
        orgId,
        projectId,
        userId,
        scenarioType,
        name,
        description,
        revenueGrowthRate,
        expenseGrowthRate,
        exitCapRate,
        assumptions
      });

      res.json(scenario);
    } catch (error: any) {
      console.error('Failed to create scenario:', error);
      res.status(500).json({ error: 'Failed to create scenario' });
    }
  });

  // Get a specific scenario by ID
  app.get('/api/modeling/projects/:projectId/scenarios/:scenarioId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, scenarioId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenario = await scenarioVersioningService.getScenarioById(scenarioId);

      if (!scenario) {
        return res.status(404).json({ error: 'Scenario not found' });
      }

      res.json(scenario);
    } catch (error: any) {
      console.error('Failed to fetch scenario:', error);
      res.status(500).json({ error: 'Failed to fetch scenario' });
    }
  });

  // Update a scenario (optionally create new version)
  app.patch('/api/modeling/projects/:projectId/scenarios/:scenarioId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      const { name, description, revenueGrowthRate, expenseGrowthRate, exitCapRate, assumptions, createNewVersion } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenario = await scenarioVersioningService.updateScenario({
        scenarioId,
        userId,
        name,
        description,
        revenueGrowthRate,
        expenseGrowthRate,
        exitCapRate,
        assumptions,
        createNewVersion
      });

      res.json(scenario);
    } catch (error: any) {
      console.error('Failed to update scenario:', error);
      res.status(500).json({ error: 'Failed to update scenario' });
    }
  });

  // Get version history for a scenario type
  app.get('/api/modeling/projects/:projectId/scenarios/:scenarioType/history', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, scenarioType } = req.params;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const history = await scenarioVersioningService.getScenarioVersionHistory(projectId, scenarioType as any, limit);

      res.json(history);
    } catch (error: any) {
      console.error('Failed to fetch scenario history:', error);
      res.status(500).json({ error: 'Failed to fetch scenario history' });
    }
  });

  // Restore a previous scenario version
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/restore', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const restored = await scenarioVersioningService.restoreVersion(scenarioId, userId);

      res.json(restored);
    } catch (error: any) {
      console.error('Failed to restore scenario:', error);
      res.status(500).json({ error: 'Failed to restore scenario' });
    }
  });

  // Submit scenario for approval
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/submit', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenario = await scenarioVersioningService.submitForApproval(scenarioId, userId);

      res.json(scenario);
    } catch (error: any) {
      console.error('Failed to submit scenario:', error);
      res.status(500).json({ error: 'Failed to submit scenario' });
    }
  });

  // Approve a scenario
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/approve', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      const { notes } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenario = await scenarioVersioningService.approveScenario(scenarioId, userId, notes);

      res.json(scenario);
    } catch (error: any) {
      console.error('Failed to approve scenario:', error);
      res.status(500).json({ error: 'Failed to approve scenario' });
    }
  });

  // Reject a scenario
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/reject', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      const { notes } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const scenario = await scenarioVersioningService.rejectScenario(scenarioId, userId, notes);

      res.json(scenario);
    } catch (error: any) {
      console.error('Failed to reject scenario:', error);
      res.status(500).json({ error: 'Failed to reject scenario' });
    }
  });

  // Get audit history for a project
  app.get('/api/modeling/projects/:projectId/audit', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { limit, entityType } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const history = await scenarioVersioningService.getAuditHistory(projectId, {
        limit: limit ? parseInt(limit as string) : undefined,
        entityType: entityType as string
      });

      res.json(history);
    } catch (error: any) {
      console.error('Failed to fetch audit history:', error);
      res.status(500).json({ error: 'Failed to fetch audit history' });
    }
  });

  // Compare multiple scenarios
  app.post('/api/modeling/projects/:projectId/scenarios/compare', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { scenarioIds } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const comparison = await scenarioVersioningService.compareScenarios(projectId, scenarioIds);

      res.json(comparison);
    } catch (error: any) {
      console.error('Failed to compare scenarios:', error);
      res.status(500).json({ error: 'Failed to compare scenarios' });
    }
  });

  // Generate IC Memo for a project
  app.get('/api/modeling/projects/:projectId/ic-memo', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const format = (req.query.format as string) || 'json';
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { icMemoService } = await import('./services/ic-memo-service');
      const memoData = await icMemoService.generateMemoData(projectId, orgId, userId);

      if (format === 'text') {
        const memoText = icMemoService.formatMemoAsText(memoData);
        res.setHeader('Content-Type', 'text/plain');
        res.setHeader('Content-Disposition', `attachment; filename="IC_Memo_${project.marinaName?.replace(/[^a-zA-Z0-9]/g, '_') || 'Project'}_${new Date().toISOString().split('T')[0]}.txt"`);
        return res.send(memoText);
      }

      res.json(memoData);
    } catch (error: any) {
      console.error('Failed to generate IC memo:', error);
      res.status(500).json({ error: 'Failed to generate IC memo' });
    }
  });

  // Get audit trail for a project
  app.get('/api/modeling/projects/:projectId/audit-log', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const limit = parseInt(req.query.limit as string) || 100;
      const entityType = req.query.entityType as string | undefined;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const auditLog = await scenarioVersioningService.getAuditHistory(projectId, { 
        limit, 
        entityType 
      });

      res.json(auditLog);
    } catch (error: any) {
      console.error('Failed to fetch audit log:', error);
      res.status(500).json({ error: 'Failed to fetch audit log' });
    }
  });

  // ==================== SENSITIVITY MATRIX ROUTES ====================
  
  // Generate sensitivity matrix for a project
  app.post('/api/modeling/projects/:projectId/sensitivity-matrix', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { scenarioType = 'base', config, save, name, description } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { sensitivityMatrixService } = await import('./services/sensitivity-matrix-service');
      const result = await sensitivityMatrixService.generateMatrix(projectId, orgId, scenarioType, config);

      if (save) {
        const userId = req.user.id;
        const savedId = await sensitivityMatrixService.saveMatrix(projectId, orgId, userId, result, name, description);
        result.id = savedId;
      }

      res.json(result);
    } catch (error: any) {
      console.error('Failed to generate sensitivity matrix:', error);
      res.status(500).json({ error: 'Failed to generate sensitivity matrix' });
    }
  });

  // Get saved sensitivity matrices for a project
  app.get('/api/modeling/projects/:projectId/sensitivity-matrices', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { sensitivityMatrixService } = await import('./services/sensitivity-matrix-service');
      const matrices = await sensitivityMatrixService.getMatrices(projectId, orgId);

      res.json(matrices);
    } catch (error: any) {
      console.error('Failed to fetch sensitivity matrices:', error);
      res.status(500).json({ error: 'Failed to fetch sensitivity matrices' });
    }
  });

  // ==================== BENCHMARK COMPARISON ROUTES ====================

  // Compare project metrics against sales comps benchmarks
  app.get('/api/modeling/projects/:projectId/benchmarks', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { region, state, yearStart, yearEnd, priceMin, priceMax } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { benchmarkComparisonService } = await import('./services/benchmark-comparison-service');
      const benchmarks = await benchmarkComparisonService.compareToBenchmarks(projectId, orgId, {
        region: region as string,
        state: state as string,
        yearRange: yearStart && yearEnd ? { 
          start: parseInt(yearStart as string), 
          end: parseInt(yearEnd as string) 
        } : undefined,
        priceRange: priceMin && priceMax ? { 
          min: parseFloat(priceMin as string), 
          max: parseFloat(priceMax as string) 
        } : undefined
      });

      res.json(benchmarks);
    } catch (error: any) {
      console.error('Failed to get benchmark comparison:', error);
      res.status(500).json({ error: 'Failed to get benchmark comparison' });
    }
  });

  // Get portfolio risk metrics
  app.get('/api/modeling/portfolio/risk-metrics', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      const { benchmarkComparisonService } = await import('./services/benchmark-comparison-service');
      const riskMetrics = await benchmarkComparisonService.getPortfolioRiskMetrics(orgId);

      res.json(riskMetrics);
    } catch (error: any) {
      console.error('Failed to get portfolio risk metrics:', error);
      res.status(500).json({ error: 'Failed to get portfolio risk metrics' });
    }
  });

  // ==================== MULTI-APPROVER WORKFLOW ROUTES ====================

  // Create approval request for a scenario
  app.post('/api/modeling/projects/:projectId/approval-requests', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { scenarioVersionId, title, description, requiredApprovers, quorumCount, deadline } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { multiApproverService } = await import('./services/multi-approver-service');
      const requestId = await multiApproverService.createApprovalRequest(projectId, orgId, userId, {
        scenarioVersionId,
        title,
        description,
        requiredApprovers,
        quorumCount: quorumCount || 1,
        deadline: deadline ? new Date(deadline) : undefined
      });

      res.json({ id: requestId, message: 'Approval request created successfully' });
    } catch (error: any) {
      console.error('Failed to create approval request:', error);
      res.status(500).json({ error: 'Failed to create approval request' });
    }
  });

  // Get approval requests for a project
  app.get('/api/modeling/projects/:projectId/approval-requests', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { multiApproverService } = await import('./services/multi-approver-service');
      const requests = await multiApproverService.getProjectApprovalRequests(projectId, orgId);

      res.json(requests);
    } catch (error: any) {
      console.error('Failed to get approval requests:', error);
      res.status(500).json({ error: 'Failed to get approval requests' });
    }
  });

  // Get pending approvals for current user
  app.get('/api/modeling/pending-approvals', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      
      const { multiApproverService } = await import('./services/multi-approver-service');
      const pendingApprovals = await multiApproverService.getPendingApprovalsForUser(userId, orgId);

      res.json(pendingApprovals);
    } catch (error: any) {
      console.error('Failed to get pending approvals:', error);
      res.status(500).json({ error: 'Failed to get pending approvals' });
    }
  });

  // Submit approval decision
  app.post('/api/modeling/approval-requests/:requestId/decide', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { requestId } = req.params;
      const { decision, comments } = req.body;
      
      if (!['approved', 'rejected'].includes(decision)) {
        return res.status(400).json({ error: 'Decision must be "approved" or "rejected"' });
      }

      const { multiApproverService } = await import('./services/multi-approver-service');
      const result = await multiApproverService.submitDecision(orgId, userId, {
        approvalRequestId: requestId,
        decision,
        comments
      });

      res.json({ 
        message: `Decision submitted: ${decision}`,
        requestStatus: result.requestStatus,
        isComplete: result.isComplete
      });
    } catch (error: any) {
      console.error('Failed to submit decision:', error);
      res.status(400).json({ error: error.message || 'Failed to submit decision' });
    }
  });

  // Get single approval request details
  app.get('/api/modeling/approval-requests/:requestId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { requestId } = req.params;
      
      const { multiApproverService } = await import('./services/multi-approver-service');
      const request = await multiApproverService.getApprovalRequest(requestId, orgId);

      if (!request) {
        return res.status(404).json({ error: 'Approval request not found' });
      }

      res.json(request);
    } catch (error: any) {
      console.error('Failed to get approval request:', error);
      res.status(500).json({ error: 'Failed to get approval request' });
    }
  });

  // ==================== DOCUMENT INTELLIGENCE ROUTES ====================

  // Create document intelligence job from VDR document (parse P&L or Rent Roll)
  app.post('/api/modeling/projects/:projectId/document-intelligence', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { vdrDocumentId, documentType } = req.body;

      if (!vdrDocumentId || !documentType) {
        return res.status(400).json({ error: 'vdrDocumentId and documentType are required' });
      }

      if (!['p&l', 'rent_roll'].includes(documentType)) {
        return res.status(400).json({ error: 'documentType must be "p&l" or "rent_roll"' });
      }

      const { documentIntelligenceService } = await import('./services/document-intelligence-service');
      const jobId = await documentIntelligenceService.createJobFromVdrDocument(
        orgId,
        userId,
        projectId,
        vdrDocumentId,
        documentType
      );

      res.json({ jobId, message: 'Document intelligence job created' });
    } catch (error: any) {
      console.error('Failed to create document intelligence job:', error);
      res.status(400).json({ error: error.message || 'Failed to create document intelligence job' });
    }
  });

  // Get document intelligence jobs for a project
  app.get('/api/modeling/projects/:projectId/document-intelligence', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;

      const { documentIntelligenceService } = await import('./services/document-intelligence-service');
      const jobs = await documentIntelligenceService.getProjectJobs(projectId, orgId);

      res.json(jobs);
    } catch (error: any) {
      console.error('Failed to get document intelligence jobs:', error);
      if (error.message?.includes('not found') || error.message?.includes('access denied')) {
        return res.status(404).json({ error: error.message });
      }
      res.status(500).json({ error: 'Failed to get document intelligence jobs' });
    }
  });

  // Get document intelligence job status and result
  app.get('/api/modeling/document-intelligence/:jobId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { jobId } = req.params;

      const { documentIntelligenceService } = await import('./services/document-intelligence-service');
      const job = await documentIntelligenceService.getJob(jobId, orgId);

      if (!job) {
        return res.status(404).json({ error: 'Job not found' });
      }

      const result = job.status === 'completed' 
        ? await documentIntelligenceService.getJobResult(jobId, orgId)
        : null;

      res.json({ job, result });
    } catch (error: any) {
      console.error('Failed to get document intelligence job:', error);
      res.status(500).json({ error: 'Failed to get document intelligence job' });
    }
  });

  // Approve document intelligence result
  app.post('/api/modeling/document-intelligence/:resultId/approve', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { resultId } = req.params;
      const { modifications } = req.body;

      const { documentIntelligenceService } = await import('./services/document-intelligence-service');
      await documentIntelligenceService.approveResult(resultId, orgId, userId, modifications);

      res.json({ message: 'Result approved' });
    } catch (error: any) {
      console.error('Failed to approve result:', error);
      res.status(500).json({ error: 'Failed to approve result' });
    }
  });

  // Reject document intelligence result
  app.post('/api/modeling/document-intelligence/:resultId/reject', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { resultId } = req.params;
      const { reason } = req.body;

      if (!reason) {
        return res.status(400).json({ error: 'Rejection reason is required' });
      }

      const { documentIntelligenceService } = await import('./services/document-intelligence-service');
      await documentIntelligenceService.rejectResult(resultId, orgId, userId, reason);

      res.json({ message: 'Result rejected' });
    } catch (error: any) {
      console.error('Failed to reject result:', error);
      res.status(500).json({ error: 'Failed to reject result' });
    }
  });

  // Import approved result to modeling actuals
  app.post('/api/modeling/document-intelligence/:resultId/import', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { resultId } = req.params;
      const { year, month, overwriteExisting } = req.body;

      if (!year) {
        return res.status(400).json({ error: 'Year is required' });
      }

      const { documentIntelligenceService } = await import('./services/document-intelligence-service');
      const result = await documentIntelligenceService.importToModelingActuals(resultId, orgId, userId, {
        year,
        month,
        overwriteExisting
      });

      res.json({ 
        message: `Imported ${result.imported} line items, skipped ${result.skipped}`,
        imported: result.imported,
        skipped: result.skipped
      });
    } catch (error: any) {
      console.error('Failed to import to actuals:', error);
      res.status(400).json({ error: error.message || 'Failed to import to actuals' });
    }
  });

  app.get('/api/modeling/document-intelligence/:resultId/structured', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { resultId } = req.params;

      const { documentIntelligenceService } = await import('./services/document-intelligence-service');
      const data = await documentIntelligenceService.getStructuredPLData(resultId, orgId);

      res.json(data);
    } catch (error: any) {
      console.error('Failed to get structured P&L data:', error);
      res.status(400).json({ error: error.message || 'Failed to get structured P&L data' });
    }
  });

  // ==================== COMMENT THREADS ROUTES ====================

  // Create a comment thread
  app.post('/api/modeling/projects/:projectId/threads', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { scenarioVersionId, targetType, targetId, targetLabel, initialComment } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      if (!targetType || !initialComment) {
        return res.status(400).json({ error: 'targetType and initialComment are required' });
      }

      const { commentThreadsService } = await import('./services/comment-threads-service');
      const threadId = await commentThreadsService.createThread(projectId, orgId, userId, {
        scenarioVersionId,
        targetType,
        targetId,
        targetLabel,
        initialComment
      });

      res.json({ id: threadId, message: 'Thread created successfully' });
    } catch (error: any) {
      console.error('Failed to create comment thread:', error);
      res.status(500).json({ error: 'Failed to create comment thread' });
    }
  });

  // Get all threads for a project
  app.get('/api/modeling/projects/:projectId/threads', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { scenarioVersionId, status, targetType } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { commentThreadsService } = await import('./services/comment-threads-service');
      const threads = await commentThreadsService.getProjectThreads(projectId, orgId, {
        scenarioVersionId: scenarioVersionId as string,
        status: status as 'open' | 'resolved' | 'archived',
        targetType: targetType as string
      });

      res.json(threads);
    } catch (error: any) {
      console.error('Failed to get comment threads:', error);
      res.status(500).json({ error: 'Failed to get comment threads' });
    }
  });

  // Get unresolved thread count for a project
  app.get('/api/modeling/projects/:projectId/threads/unresolved-count', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const { commentThreadsService } = await import('./services/comment-threads-service');
      const count = await commentThreadsService.getUnresolvedCount(projectId, orgId);

      res.json(count);
    } catch (error: any) {
      console.error('Failed to get unresolved count:', error);
      res.status(500).json({ error: 'Failed to get unresolved count' });
    }
  });

  // Get single thread with comments
  app.get('/api/modeling/threads/:threadId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { threadId } = req.params;
      
      const { commentThreadsService } = await import('./services/comment-threads-service');
      const thread = await commentThreadsService.getThread(threadId, orgId);

      if (!thread) {
        return res.status(404).json({ error: 'Thread not found' });
      }

      res.json(thread);
    } catch (error: any) {
      console.error('Failed to get thread:', error);
      res.status(500).json({ error: 'Failed to get thread' });
    }
  });

  // Add comment to thread
  app.post('/api/modeling/threads/:threadId/comments', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { threadId } = req.params;
      const { content, mentions } = req.body;
      
      if (!content) {
        return res.status(400).json({ error: 'Comment content is required' });
      }

      const { commentThreadsService } = await import('./services/comment-threads-service');
      const commentId = await commentThreadsService.addComment(orgId, userId, {
        threadId,
        content,
        mentions
      });

      res.json({ id: commentId, message: 'Comment added successfully' });
    } catch (error: any) {
      console.error('Failed to add comment:', error);
      res.status(400).json({ error: error.message || 'Failed to add comment' });
    }
  });

  // Edit comment
  app.patch('/api/modeling/comments/:commentId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { commentId } = req.params;
      const { content } = req.body;
      
      if (!content) {
        return res.status(400).json({ error: 'Comment content is required' });
      }

      const { commentThreadsService } = await import('./services/comment-threads-service');
      await commentThreadsService.editComment(commentId, orgId, userId, content);

      res.json({ message: 'Comment updated successfully' });
    } catch (error: any) {
      console.error('Failed to edit comment:', error);
      res.status(400).json({ error: error.message || 'Failed to edit comment' });
    }
  });

  // Resolve thread
  app.post('/api/modeling/threads/:threadId/resolve', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { threadId } = req.params;
      
      const { commentThreadsService } = await import('./services/comment-threads-service');
      await commentThreadsService.resolveThread(threadId, orgId, userId);

      res.json({ message: 'Thread resolved successfully' });
    } catch (error: any) {
      console.error('Failed to resolve thread:', error);
      res.status(400).json({ error: error.message || 'Failed to resolve thread' });
    }
  });

  // Reopen thread
  app.post('/api/modeling/threads/:threadId/reopen', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { threadId } = req.params;
      
      const { commentThreadsService } = await import('./services/comment-threads-service');
      await commentThreadsService.reopenThread(threadId, orgId, userId);

      res.json({ message: 'Thread reopened successfully' });
    } catch (error: any) {
      console.error('Failed to reopen thread:', error);
      res.status(400).json({ error: error.message || 'Failed to reopen thread' });
    }
  });

  // Archive thread
  app.post('/api/modeling/threads/:threadId/archive', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { threadId } = req.params;
      
      const { commentThreadsService } = await import('./services/comment-threads-service');
      await commentThreadsService.archiveThread(threadId, orgId, userId);

      res.json({ message: 'Thread archived successfully' });
    } catch (error: any) {
      console.error('Failed to archive thread:', error);
      res.status(400).json({ error: error.message || 'Failed to archive thread' });
    }
  });

  // ==================== VDR INTEGRATION ROUTES ====================

  // Export modeling outputs to VDR
  app.post('/api/modeling/projects/:projectId/export-to-vdr', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { includeICMemo, includeProForma, includeScenarioComparison, includeSensitivityAnalysis, scenarioVersionIds } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { vdrModelingIntegrationService } = await import('./services/vdr-modeling-integration-service');
      const result = await vdrModelingIntegrationService.exportToVDR(projectId, orgId, userId, {
        includeICMemo,
        includeProForma,
        includeScenarioComparison,
        includeSensitivityAnalysis,
        scenarioVersionIds
      });

      res.json({
        message: `Successfully exported ${result.documents.length} documents to VDR`,
        ...result
      });
    } catch (error: any) {
      console.error('Failed to export to VDR:', error);
      res.status(400).json({ error: error.message || 'Failed to export to VDR' });
    }
  });

  // Get VDR export history for a project
  app.get('/api/modeling/projects/:projectId/vdr-exports', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { vdrModelingIntegrationService } = await import('./services/vdr-modeling-integration-service');
      const history = await vdrModelingIntegrationService.getVDRExportHistory(projectId, orgId);

      res.json(history);
    } catch (error: any) {
      console.error('Failed to get VDR export history:', error);
      res.status(500).json({ error: 'Failed to get VDR export history' });
    }
  });

  app.get('/api/modeling/projects/:projectId/vdr-documents', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const ddProjectId = project.ddProjectId;
      if (!ddProjectId) {
        return res.json([]);
      }

      const { vdrDocuments, vdrFolders } = await import('@shared/schema');
      const { isNull } = await import('drizzle-orm');

      const documents = await db
        .select({
          id: vdrDocuments.id,
          filename: vdrDocuments.filename,
          originalFilename: vdrDocuments.originalFilename,
          mimeType: vdrDocuments.mimeType,
          size: vdrDocuments.size,
          storagePath: vdrDocuments.storagePath,
          folderName: vdrFolders.name,
          folderPath: vdrFolders.path,
          aiCategory: vdrDocuments.aiCategory,
          tags: vdrDocuments.tags,
          createdAt: vdrDocuments.createdAt,
        })
        .from(vdrDocuments)
        .innerJoin(vdrFolders, eq(vdrDocuments.folderId, vdrFolders.id))
        .where(and(
          eq(vdrDocuments.projectId, ddProjectId),
          eq(vdrDocuments.orgId, orgId),
          eq(vdrDocuments.isCurrentVersion, true),
          isNull(vdrDocuments.deletedAt)
        ))
        .orderBy(vdrDocuments.createdAt);

      res.json(documents);
    } catch (error: any) {
      console.error('Failed to fetch VDR documents:', error);
      res.status(500).json({ error: 'Failed to fetch VDR documents' });
    }
  });

  app.post('/api/modeling/projects/:projectId/import-vdr-document', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { vdrDocumentId, docType, year } = req.body;

      if (!vdrDocumentId) {
        return res.status(400).json({ error: 'vdrDocumentId is required' });
      }

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { vdrDocuments } = await import('@shared/schema');

      const [vdrDoc] = await db.select()
        .from(vdrDocuments)
        .where(and(
          eq(vdrDocuments.id, vdrDocumentId),
          eq(vdrDocuments.orgId, orgId)
        ))
        .limit(1);

      if (!vdrDoc) {
        return res.status(404).json({ error: 'VDR document not found' });
      }

      if (!project.ddProjectId || vdrDoc.projectId !== project.ddProjectId) {
        return res.status(403).json({ error: 'Document does not belong to this project\'s linked Data Room' });
      }

      const fsModule = await import('fs');
      const pathModule = await import('path');

      const sourceExists = fsModule.existsSync(vdrDoc.storagePath);
      if (!sourceExists) {
        return res.status(404).json({ error: 'VDR document file not found on disk' });
      }

      const docIntelDir = pathModule.default.join(process.cwd(), 'server', 'uploads', 'doc-intel');
      fsModule.mkdirSync(docIntelDir, { recursive: true });

      const timestamp = Date.now();
      const ext = pathModule.default.extname(vdrDoc.originalFilename);
      const newFilename = `${timestamp}-vdr-${crypto.randomBytes(8).toString('hex')}${ext}`;
      const destPath = pathModule.default.join(docIntelDir, newFilename);

      fsModule.copyFileSync(vdrDoc.storagePath, destPath);

      const stat = fsModule.statSync(destPath);

      const result = await docIntelService.createUploadWithDuplicateCheck(
        orgId,
        {
          modelingProjectId: projectId,
          filename: newFilename,
          originalName: vdrDoc.originalFilename,
          storagePath: destPath,
          mimeType: vdrDoc.mimeType,
          fileSize: stat.size,
          docType: docType || null,
          year: year ? parseInt(year) : null,
          uploadedBy: userId,
          status: 'uploaded',
          holdingStatus: 'staging',
          holdingTags: null,
          holdingNotes: `Imported from Data Room: ${vdrDoc.filename}`,
        },
        false
      );

      res.status(201).json({
        ...result.upload,
        isDuplicate: result.isDuplicate,
        source: 'vdr',
        vdrDocumentId: vdrDoc.id,
      });

      setImmediate(async () => {
        try {
          console.log(`[DocIntel] Starting automatic AI parsing for VDR import ${result.upload.id}`);
          await docIntelService.parseAndExtract(orgId, result.upload.id);
          console.log(`[DocIntel] Parsing complete for VDR import ${result.upload.id}, categorizing...`);
          await docIntelService.categorizeItems(orgId, result.upload.id);
          console.log(`[DocIntel] Categorization complete for VDR import ${result.upload.id}`);
          await docIntelService.updateUpload(orgId, result.upload.id, { status: 'reviewing' });
        } catch (parseError: any) {
          console.error(`[DocIntel] Background parsing failed for VDR import ${result.upload.id}:`, parseError.message);
        }
      });
    } catch (error: any) {
      console.error('Failed to import VDR document:', error);
      res.status(500).json({ error: 'Failed to import VDR document' });
    }
  });

  // ==================== MODELING EXCEL EXPORT ROUTES ====================

  // Export modeling project to Excel with multiple sheets
  app.get('/api/modeling/projects/:projectId/export-excel', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { caseId, includeAllCases, includeAddbacks, includeLeaseUp } = req.query;
      
      const { exportModelingProjectToExcel } = await import('./services/modeling-export');
      
      const buffer = await exportModelingProjectToExcel(projectId, orgId, {
        caseId: caseId as string | undefined,
        includeAllCases: includeAllCases !== 'false',
        includeAddbacks: includeAddbacks !== 'false',
        includeLeaseUp: includeLeaseUp !== 'false',
      });

      const project = await storage.getModelingProject(projectId, orgId);
      const filename = `${(project?.name || 'model').replace(/[^a-zA-Z0-9]/g, '_')}_export.xlsx`;

      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.send(buffer);
    } catch (error: any) {
      console.error('Failed to export modeling project to Excel:', error);
      res.status(500).json({ error: 'Failed to export modeling project' });
    }
  });

  // Export case comparison to Excel
  app.post('/api/modeling/projects/:projectId/export-case-comparison', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { caseIds } = req.body;
      
      if (!Array.isArray(caseIds) || caseIds.length < 2) {
        return res.status(400).json({ error: 'At least 2 case IDs required for comparison' });
      }

      const { exportCaseComparisonToExcel } = await import('./services/modeling-export');
      
      const buffer = await exportCaseComparisonToExcel(projectId, orgId, caseIds);

      const project = await storage.getModelingProject(projectId, orgId);
      const filename = `${(project?.name || 'model').replace(/[^a-zA-Z0-9]/g, '_')}_case_comparison.xlsx`;

      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.send(buffer);
    } catch (error: any) {
      console.error('Failed to export case comparison to Excel:', error);
      res.status(500).json({ error: 'Failed to export case comparison' });
    }
  });

  // ==================== DEBT SENSITIVITY ROUTES ====================

  // Analyze debt sensitivity across lender structures
  app.post('/api/modeling/projects/:projectId/debt-sensitivity', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { scenarioVersionId, purchasePrice, lenderStructures, rateShifts } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      if (!scenarioVersionId || !purchasePrice) {
        return res.status(400).json({ error: 'scenarioVersionId and purchasePrice are required' });
      }

      const { debtSensitivityService } = await import('./services/debt-sensitivity-service');
      
      let structures = lenderStructures;
      if (!structures || structures.length === 0) {
        structures = await debtSensitivityService.getStandardLenderStructures(purchasePrice);
      }

      const shifts = rateShifts || [-1.0, -0.5, 0, 0.5, 1.0, 1.5, 2.0];

      const analysis = await debtSensitivityService.analyzeDebtSensitivity(projectId, orgId, userId, {
        scenarioVersionId,
        purchasePrice,
        lenderStructures: structures,
        rateShifts: shifts
      });

      res.json(analysis);
    } catch (error: any) {
      console.error('Failed to analyze debt sensitivity:', error);
      res.status(400).json({ error: error.message || 'Failed to analyze debt sensitivity' });
    }
  });

  // Get standard lender structures
  app.get('/api/modeling/debt-sensitivity/lender-templates', authenticateUser, async (req: any, res) => {
    try {
      const { purchasePrice } = req.query;
      const price = parseFloat(purchasePrice as string) || 10000000;

      const { debtSensitivityService } = await import('./services/debt-sensitivity-service');
      const structures = await debtSensitivityService.getStandardLenderStructures(price);

      res.json(structures);
    } catch (error: any) {
      console.error('Failed to get lender templates:', error);
      res.status(500).json({ error: 'Failed to get lender templates' });
    }
  });

  // Compare multiple lenders and get recommendations
  app.post('/api/modeling/projects/:projectId/lender-comparison', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { scenarioVersionId, purchasePrice, targetDSCR } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { debtSensitivityService } = await import('./services/debt-sensitivity-service');
      const comparison = await debtSensitivityService.compareMultipleLenders(
        projectId,
        orgId,
        scenarioVersionId,
        purchasePrice,
        targetDSCR || 1.25
      );

      res.json(comparison);
    } catch (error: any) {
      console.error('Failed to compare lenders:', error);
      res.status(400).json({ error: error.message || 'Failed to compare lenders' });
    }
  });

  // ==================== WATERFALL CUSTOMIZATION ROUTES ====================

  // Calculate waterfall distribution
  app.post('/api/modeling/projects/:projectId/waterfall', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const input = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      if (!input.scenarioVersionId || !input.totalInvestment) {
        return res.status(400).json({ error: 'scenarioVersionId and totalInvestment are required' });
      }

      const { waterfallService } = await import('./services/waterfall-service');
      const result = await waterfallService.calculateWaterfall(projectId, orgId, userId, input);

      res.json(result);
    } catch (error: any) {
      console.error('Failed to calculate waterfall:', error);
      res.status(400).json({ error: error.message || 'Failed to calculate waterfall' });
    }
  });

  // Get standard waterfall configurations
  app.get('/api/modeling/waterfall/templates', authenticateUser, async (req: any, res) => {
    try {
      const { waterfallService } = await import('./services/waterfall-service');
      const configs = await waterfallService.getStandardWaterfallConfigs();

      res.json(configs);
    } catch (error: any) {
      console.error('Failed to get waterfall templates:', error);
      res.status(500).json({ error: 'Failed to get waterfall templates' });
    }
  });

  // Compare multiple waterfall structures
  app.post('/api/modeling/projects/:projectId/waterfall/compare', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { baseInput, configs } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { waterfallService } = await import('./services/waterfall-service');
      const comparison = await waterfallService.compareWaterfallStructures(
        projectId,
        orgId,
        baseInput,
        configs
      );

      res.json(comparison);
    } catch (error: any) {
      console.error('Failed to compare waterfall structures:', error);
      res.status(400).json({ error: error.message || 'Failed to compare waterfall structures' });
    }
  });

  // ==================== EXTERNAL API ROUTES ====================

  // Export single project data
  app.get('/api/modeling/export/project/:projectId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      const { format } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { externalAPIService } = await import('./services/external-api-service');
      const exportData = await externalAPIService.exportProject(
        projectId, 
        orgId, 
        userId, 
        (format as 'json' | 'csv' | 'xml') || 'json'
      );

      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="project_${projectId}.csv"`);
        res.send(exportData);
      } else if (format === 'xml') {
        res.setHeader('Content-Type', 'application/xml');
        res.setHeader('Content-Disposition', `attachment; filename="project_${projectId}.xml"`);
        res.send(exportData);
      } else {
        res.json(exportData);
      }
    } catch (error: any) {
      console.error('Failed to export project:', error);
      res.status(400).json({ error: error.message || 'Failed to export project' });
    }
  });

  // Export portfolio data
  app.get('/api/modeling/export/portfolio', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { status, region, outcome, minValue, maxValue } = req.query;

      const { externalAPIService } = await import('./services/external-api-service');
      const exportData = await externalAPIService.exportPortfolio(orgId, userId, {
        status: status as string,
        region: region as string,
        outcome: outcome as string,
        minValue: minValue ? parseFloat(minValue as string) : undefined,
        maxValue: maxValue ? parseFloat(maxValue as string) : undefined
      });

      res.json(exportData);
    } catch (error: any) {
      console.error('Failed to export portfolio:', error);
      res.status(400).json({ error: error.message || 'Failed to export portfolio' });
    }
  });

  // Get webhook payload preview
  app.get('/api/modeling/webhook/preview/:projectId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { eventType } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { externalAPIService } = await import('./services/external-api-service');
      const payload = await externalAPIService.getWebhookPayload(
        projectId,
        orgId,
        (eventType as 'scenario_approved' | 'project_updated' | 'analysis_completed') || 'project_updated'
      );

      res.json(payload);
    } catch (error: any) {
      console.error('Failed to get webhook payload:', error);
      res.status(400).json({ error: error.message || 'Failed to get webhook payload' });
    }
  });

  // Generate API documentation
  app.get('/api/modeling/api-docs', authenticateUser, async (req: any, res) => {
    try {
      const docs = {
        version: '1.0.0',
        endpoints: [
          {
            method: 'GET',
            path: '/api/modeling/export/project/:projectId',
            description: 'Export project data in JSON, CSV, or XML format',
            params: { format: 'json | csv | xml' }
          },
          {
            method: 'GET',
            path: '/api/modeling/export/portfolio',
            description: 'Export portfolio data with optional filters',
            params: { status: 'string', region: 'string', outcome: 'string', minValue: 'number', maxValue: 'number' }
          },
          {
            method: 'GET',
            path: '/api/modeling/webhook/preview/:projectId',
            description: 'Preview webhook payload for integration testing',
            params: { eventType: 'scenario_approved | project_updated | analysis_completed' }
          },
          {
            method: 'POST',
            path: '/api/modeling/projects/:projectId/pro-forma',
            description: 'Generate pro forma projections from actuals'
          },
          {
            method: 'POST',
            path: '/api/modeling/projects/:projectId/sensitivity-matrix',
            description: 'Generate sensitivity analysis matrix'
          },
          {
            method: 'GET',
            path: '/api/modeling/projects/:projectId/benchmarks',
            description: 'Compare project metrics against sales comps'
          },
          {
            method: 'POST',
            path: '/api/modeling/projects/:projectId/debt-sensitivity',
            description: 'Analyze debt sensitivity across lender structures'
          },
          {
            method: 'POST',
            path: '/api/modeling/projects/:projectId/waterfall',
            description: 'Calculate LP/GP waterfall distributions'
          }
        ],
        authentication: 'Bearer token or session cookie required',
        rateLimit: '100 requests per minute'
      };

      res.json(docs);
    } catch (error: any) {
      console.error('Failed to get API docs:', error);
      res.status(500).json({ error: 'Failed to get API docs' });
    }
  });

  // Get modeling analytics and metrics
  app.get('/api/modeling/analytics', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      // Parse filter parameters
      const filters: any = {};
      if (req.query.region) filters.region = req.query.region;
      if (req.query.state) filters.state = req.query.state;
      if (req.query.dealOutcome) filters.dealOutcome = req.query.dealOutcome;
      if (req.query.brokerId) filters.brokerId = req.query.brokerId;
      if (req.query.minPrice) filters.minPrice = parseFloat(req.query.minPrice as string);
      if (req.query.maxPrice) filters.maxPrice = parseFloat(req.query.maxPrice as string);
      if (req.query.minSize) filters.minSize = parseInt(req.query.minSize as string);
      if (req.query.maxSize) filters.maxSize = parseInt(req.query.maxSize as string);
      if (req.query.startDate) filters.startDate = new Date(req.query.startDate as string);
      if (req.query.endDate) filters.endDate = new Date(req.query.endDate as string);
      
      const analytics = await storage.getModelingAnalytics(orgId, filters);
      res.json(analytics);
    } catch (error: any) {
      console.error('Failed to fetch modeling analytics:', error);
      res.status(500).json({ error: 'Failed to fetch modeling analytics' });
    }
  });

  // ============================================================================
  // APPROVAL NOTIFICATIONS - Email and In-App Notifications for Scenario Approvals
  // ============================================================================

  // Get pending approvals for the organization
  app.get('/api/approvals/pending', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      const pendingApprovals = await approvalNotificationService.getPendingApprovals(orgId);
      res.json(pendingApprovals);
    } catch (error: any) {
      console.error('Failed to get pending approvals:', error);
      res.status(500).json({ error: 'Failed to get pending approvals' });
    }
  });

  // Get approval statistics
  app.get('/api/approvals/stats', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      const stats = await approvalNotificationService.getApprovalStats(orgId);
      res.json(stats);
    } catch (error: any) {
      console.error('Failed to get approval stats:', error);
      res.status(500).json({ error: 'Failed to get approval statistics' });
    }
  });

  // Get available approvers for the organization
  app.get('/api/approvals/approvers', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      const approvers = await approvalNotificationService.getOrgApprovers(orgId);
      res.json(approvers);
    } catch (error: any) {
      console.error('Failed to get approvers:', error);
      res.status(500).json({ error: 'Failed to get approvers' });
    }
  });

  // Get user notifications
  app.get('/api/notifications', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const unreadOnly = req.query.unreadOnly === 'true';
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      const notifications = await approvalNotificationService.getUserNotifications(orgId, userId, unreadOnly);
      res.json(notifications);
    } catch (error: any) {
      console.error('Failed to get notifications:', error);
      res.status(500).json({ error: 'Failed to get notifications' });
    }
  });

  // Get unread notification count
  app.get('/api/notifications/unread-count', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      const count = await approvalNotificationService.getUnreadCount(orgId, userId);
      res.json({ count });
    } catch (error: any) {
      console.error('Failed to get unread count:', error);
      res.status(500).json({ error: 'Failed to get unread count' });
    }
  });

  // Mark notification as read
  app.post('/api/notifications/:notificationId/read', authenticateUser, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { notificationId } = req.params;
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      await approvalNotificationService.markNotificationRead(notificationId, userId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to mark notification as read:', error);
      res.status(500).json({ error: 'Failed to mark notification as read' });
    }
  });

  // Mark all notifications as read
  app.post('/api/notifications/mark-all-read', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      await approvalNotificationService.markAllNotificationsRead(orgId, userId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to mark all notifications as read:', error);
      res.status(500).json({ error: 'Failed to mark all notifications as read' });
    }
  });

  // Submit scenario for approval with specific approvers
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/submit-for-approval', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      const { approverIds } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      
      const updated = await scenarioVersioningService.submitForApproval(scenarioId, userId);

      if (approverIds && approverIds.length > 0) {
        await approvalNotificationService.notifyApprovalRequested(scenarioId, userId, approverIds);
      } else {
        const orgApprovers = await approvalNotificationService.getOrgApprovers(orgId);
        const approverUserIds = orgApprovers.map(a => a.id).filter(id => id !== userId);
        if (approverUserIds.length > 0) {
          await approvalNotificationService.notifyApprovalRequested(scenarioId, userId, approverUserIds);
        }
      }

      res.json(updated);
    } catch (error: any) {
      console.error('Failed to submit for approval:', error);
      res.status(500).json({ error: 'Failed to submit for approval' });
    }
  });

  // Approve scenario with notifications
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/approve-with-notification', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      const { notes } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      
      const updated = await scenarioVersioningService.approveScenario(scenarioId, userId, notes);
      await approvalNotificationService.notifyApprovalDecision(scenarioId, 'approved', userId, notes);

      res.json(updated);
    } catch (error: any) {
      console.error('Failed to approve scenario:', error);
      res.status(500).json({ error: 'Failed to approve scenario' });
    }
  });

  // Reject scenario with notifications
  app.post('/api/modeling/projects/:projectId/scenarios/:scenarioId/reject-with-notification', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, scenarioId } = req.params;
      const { notes } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      const { scenarioVersioningService } = await import('./services/scenario-versioning-service');
      const { approvalNotificationService } = await import('./services/approval-notification-service');
      
      const updated = await scenarioVersioningService.rejectScenario(scenarioId, userId, notes);
      await approvalNotificationService.notifyApprovalDecision(scenarioId, 'rejected', userId, notes);

      res.json(updated);
    } catch (error: any) {
      console.error('Failed to reject scenario:', error);
      res.status(500).json({ error: 'Failed to reject scenario' });
    }
  });

  // ============================================================================
  // QUICKBOOKS INTEGRATION - OAuth2 Connection and P&L Sync
  // ============================================================================

  // Get QuickBooks connection status
  app.get('/api/quickbooks/status', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { quickBooksService } = await import('./services/quickbooks-service');
      const status = await quickBooksService.getConnectionStatus(orgId);
      res.json(status);
    } catch (error: any) {
      console.error('Failed to get QuickBooks status:', error);
      res.status(500).json({ error: 'Failed to get connection status' });
    }
  });

  // Get QuickBooks authorization URL
  app.get('/api/quickbooks/auth-url', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { quickBooksService } = await import('./services/quickbooks-service');
      const authUrl = quickBooksService.getAuthorizationUrl(orgId);
      res.json({ authUrl });
    } catch (error: any) {
      console.error('Failed to generate auth URL:', error);
      res.status(500).json({ error: 'Failed to generate authorization URL' });
    }
  });

  // QuickBooks OAuth callback
  app.get('/api/quickbooks/callback', async (req, res) => {
    try {
      const { code, realmId, state, error: oauthError } = req.query;
      
      if (oauthError) {
        console.error('QuickBooks OAuth error:', oauthError);
        return res.redirect('/settings/integrations?qb_error=authorization_denied');
      }

      if (!code || !realmId || !state) {
        return res.redirect('/settings/integrations?qb_error=missing_params');
      }

      const { quickBooksService } = await import('./services/quickbooks-service');
      await quickBooksService.handleCallback(
        code as string,
        realmId as string,
        state as string
      );

      res.redirect('/settings/integrations?qb_connected=true');
    } catch (error: any) {
      console.error('Failed to handle QuickBooks callback:', error);
      res.redirect('/settings/integrations?qb_error=connection_failed');
    }
  });

  // Disconnect QuickBooks
  app.post('/api/quickbooks/disconnect', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { quickBooksService } = await import('./services/quickbooks-service');
      await quickBooksService.disconnect(orgId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to disconnect QuickBooks:', error);
      res.status(500).json({ error: 'Failed to disconnect' });
    }
  });

  // Get QuickBooks company info
  app.get('/api/quickbooks/company', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { quickBooksService } = await import('./services/quickbooks-service');
      const companyInfo = await quickBooksService.getCompanyInfo(orgId);
      res.json(companyInfo);
    } catch (error: any) {
      console.error('Failed to get company info:', error);
      res.status(500).json({ error: 'Failed to get company information' });
    }
  });

  // Get QuickBooks chart of accounts
  app.get('/api/quickbooks/accounts', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { quickBooksService } = await import('./services/quickbooks-service');
      const accounts = await quickBooksService.getChartOfAccounts(orgId);
      res.json(accounts);
    } catch (error: any) {
      console.error('Failed to get chart of accounts:', error);
      res.status(500).json({ error: 'Failed to get chart of accounts' });
    }
  });

  // Get QuickBooks P&L report
  app.get('/api/quickbooks/profit-and-loss', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ error: 'Start date and end date are required' });
      }

      const { quickBooksService } = await import('./services/quickbooks-service');
      const report = await quickBooksService.getProfitAndLoss(
        orgId,
        startDate as string,
        endDate as string
      );
      res.json(report);
    } catch (error: any) {
      console.error('Failed to get P&L report:', error);
      res.status(500).json({ error: 'Failed to get Profit & Loss report' });
    }
  });

  // Sync QuickBooks P&L to modeling actuals
  app.post('/api/quickbooks/sync/:projectId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { startDate, endDate } = req.body;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Project not found' });
      }

      if (!startDate || !endDate) {
        return res.status(400).json({ error: 'Start date and end date are required' });
      }

      const { quickBooksService } = await import('./services/quickbooks-service');
      const result = await quickBooksService.syncProfitAndLossToActuals(
        orgId,
        projectId,
        startDate,
        endDate
      );
      res.json(result);
    } catch (error: any) {
      console.error('Failed to sync QuickBooks data:', error);
      res.status(500).json({ error: 'Failed to sync QuickBooks data' });
    }
  });

  // Get QuickBooks sync history
  app.get('/api/quickbooks/sync-history', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const limit = parseInt(req.query.limit as string) || 20;
      const { quickBooksService } = await import('./services/quickbooks-service');
      const history = await quickBooksService.getSyncHistory(orgId, limit);
      res.json(history);
    } catch (error: any) {
      console.error('Failed to get sync history:', error);
      res.status(500).json({ error: 'Failed to get sync history' });
    }
  });

  // Update account mapping
  app.post('/api/quickbooks/account-mapping', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { mapping } = req.body;
      
      if (!mapping) {
        return res.status(400).json({ error: 'Mapping data is required' });
      }

      const { quickBooksService } = await import('./services/quickbooks-service');
      await quickBooksService.updateAccountMapping(orgId, mapping);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to update account mapping:', error);
      res.status(500).json({ error: 'Failed to update account mapping' });
    }
  });

  // ============================================================================
  // PORTFOLIO ROLL-UPS - Aggregate Views Across Modeling Projects
  // ============================================================================

  // Get portfolio summary
  app.get('/api/portfolio/summary', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const projectIds = req.query.projectIds ? (req.query.projectIds as string).split(',') : undefined;
      const { portfolioRollupService } = await import('./services/portfolio-rollup-service');
      const summary = await portfolioRollupService.getPortfolioSummary(orgId, projectIds);
      res.json(summary);
    } catch (error: any) {
      console.error('Failed to get portfolio summary:', error);
      res.status(500).json({ error: 'Failed to get portfolio summary' });
    }
  });

  // Get project rollups with filters
  app.get('/api/portfolio/projects', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const filters: any = {};
      if (req.query.region) filters.region = req.query.region as string;
      if (req.query.state) filters.state = req.query.state as string;
      if (req.query.status) filters.status = req.query.status as string;
      if (req.query.minValue) filters.minValue = parseFloat(req.query.minValue as string);
      if (req.query.maxValue) filters.maxValue = parseFloat(req.query.maxValue as string);
      
      const { portfolioRollupService } = await import('./services/portfolio-rollup-service');
      const projects = await portfolioRollupService.getProjectRollups(orgId, filters);
      res.json(projects);
    } catch (error: any) {
      console.error('Failed to get project rollups:', error);
      res.status(500).json({ error: 'Failed to get project rollups' });
    }
  });

  // Get portfolio breakdown by region, state, status, and year
  app.get('/api/portfolio/breakdown', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { portfolioRollupService } = await import('./services/portfolio-rollup-service');
      const breakdown = await portfolioRollupService.getPortfolioBreakdown(orgId);
      res.json(breakdown);
    } catch (error: any) {
      console.error('Failed to get portfolio breakdown:', error);
      res.status(500).json({ error: 'Failed to get portfolio breakdown' });
    }
  });

  // Get portfolio projections for all scenarios
  app.get('/api/portfolio/projections', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const projectIds = req.query.projectIds ? (req.query.projectIds as string).split(',') : undefined;
      const yearsToProject = parseInt(req.query.years as string) || 5;
      
      const { portfolioRollupService } = await import('./services/portfolio-rollup-service');
      const projections = await portfolioRollupService.getPortfolioProjections(orgId, projectIds, yearsToProject);
      res.json(projections);
    } catch (error: any) {
      console.error('Failed to get portfolio projections:', error);
      res.status(500).json({ error: 'Failed to get portfolio projections' });
    }
  });

  // Get top performing projects
  app.get('/api/portfolio/top-performers', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const { portfolioRollupService } = await import('./services/portfolio-rollup-service');
      const topPerformers = await portfolioRollupService.getTopPerformingProjects(orgId, limit);
      res.json(topPerformers);
    } catch (error: any) {
      console.error('Failed to get top performers:', error);
      res.status(500).json({ error: 'Failed to get top performing projects' });
    }
  });

  // Get underperforming projects
  app.get('/api/portfolio/underperformers', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const occupancyThreshold = parseFloat(req.query.threshold as string) || 70;
      
      const { portfolioRollupService } = await import('./services/portfolio-rollup-service');
      const underperformers = await portfolioRollupService.getUnderperformingProjects(orgId, occupancyThreshold);
      res.json(underperformers);
    } catch (error: any) {
      console.error('Failed to get underperformers:', error);
      res.status(500).json({ error: 'Failed to get underperforming projects' });
    }
  });

  // Export full portfolio report
  app.get('/api/portfolio/export', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      
      const { portfolioRollupService } = await import('./services/portfolio-rollup-service');
      const report = await portfolioRollupService.exportPortfolioReport(orgId);
      res.json(report);
    } catch (error: any) {
      console.error('Failed to export portfolio report:', error);
      res.status(500).json({ error: 'Failed to export portfolio report' });
    }
  });

  // ============================================================================
  // DOCUMENT INTELLIGENCE - AI-Powered Financial Document Parsing
  // ============================================================================

  // Configure multer for document uploads
  const docIntelUpload = multer({
    storage: multer.diskStorage({
      destination: (req, file, cb) => {
        const uploadDir = path.join(process.cwd(), 'server', 'uploads', 'doc-intel');
        fs.ensureDirSync(uploadDir);
        cb(null, uploadDir);
      },
      filename: (req, file, cb) => {
        const timestamp = Date.now();
        const ext = path.extname(file.originalname);
        cb(null, `${timestamp}-${crypto.randomBytes(8).toString('hex')}${ext}`);
      }
    }),
    limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit for financial docs
    fileFilter: (req, file, cb) => {
      const allowedTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // xlsx
        'application/vnd.ms-excel', // xls
        'text/csv',
        'application/pdf'
      ];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type. Only Excel, CSV, and PDF files are allowed.'));
      }
    }
  });

  // Initialize organization with default categories and patterns
// Custom Document Types Routes - to be added to routes.ts

// --- CUSTOM DOCUMENT TYPES ---

// Get all custom document types for organization
app.get('/api/doc-intel/custom-document-types', authenticateUser, async (req: any, res) => {
  try {
    const orgId = req.user.orgId;
    const { customDocumentTypes } = await import('@shared/schema');
    const types = await db.select().from(customDocumentTypes).where(eq(customDocumentTypes.orgId, orgId)).orderBy(customDocumentTypes.sortOrder);
    res.json(types);
  } catch (error: any) {
    console.error('Failed to fetch custom document types:', error);
    res.status(500).json({ error: 'Failed to fetch custom document types' });
  }
});

// Create custom document type
app.post('/api/doc-intel/custom-document-types', authenticateUser, async (req: any, res) => {
  try {
    const orgId = req.user.orgId;
    const userId = req.user.id;
    const { name, description } = req.body;

    if (!name?.trim()) {
      return res.status(400).json({ error: 'Name is required' });
    }

    const { customDocumentTypes } = await import('@shared/schema');
    
    // Check for duplicates
    const existing = await db.select().from(customDocumentTypes)
      .where(and(eq(customDocumentTypes.orgId, orgId), eq(customDocumentTypes.name, name.trim())));
    
    if (existing.length > 0) {
      return res.status(400).json({ error: 'A document type with this name already exists' });
    }

    const [newType] = await db.insert(customDocumentTypes).values({
      orgId,
      name: name.trim(),
      description: description || null,
      createdBy: userId,
    }).returning();

    res.status(201).json(newType);
  } catch (error: any) {
    console.error('Failed to create custom document type:', error);
    res.status(500).json({ error: 'Failed to create custom document type' });
  }
});

// Delete custom document type
app.delete('/api/doc-intel/custom-document-types/:id', authenticateUser, async (req: any, res) => {
  try {
    const orgId = req.user.orgId;
    const { id } = req.params;

    const { customDocumentTypes } = await import('@shared/schema');
    await db.delete(customDocumentTypes).where(and(eq(customDocumentTypes.id, id), eq(customDocumentTypes.orgId, orgId)));
    res.json({ success: true });
  } catch (error: any) {
    console.error('Failed to delete custom document type:', error);
    res.status(500).json({ error: 'Failed to delete custom document type' });
  }
});
  app.post('/api/modeling/doc-intel/init', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const result = await docIntelService.initializeOrganization(orgId);
      res.json(result);
    } catch (error: any) {
      console.error('Failed to initialize document intelligence:', error);
      res.status(500).json({ error: 'Failed to initialize document intelligence' });
    }
  });

  // --- P&L CATEGORIES ---
  
  // Get all categories for organization (hierarchical)
  app.get('/api/modeling/doc-intel/categories', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const hierarchical = req.query.hierarchical === 'true';
      
      if (hierarchical) {
        const categories = await docIntelService.getCategoriesHierarchical(orgId);
        res.json(categories);
      } else {
        const categories = await docIntelService.getCategories(orgId);
        res.json(categories);
      }
    } catch (error: any) {
      console.error('Failed to fetch categories:', error);
      res.status(500).json({ error: 'Failed to fetch categories' });
    }
  });

  // Create category
  app.post('/api/modeling/doc-intel/categories', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const category = await docIntelService.createCategory(orgId, req.body);
      res.status(201).json(category);
    } catch (error: any) {
      console.error('Failed to create category:', error);
      res.status(500).json({ error: 'Failed to create category' });
    }
  });

  // Update category
  app.patch('/api/modeling/doc-intel/categories/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const category = await docIntelService.updateCategory(orgId, req.params.id, req.body);
      if (!category) {
        return res.status(404).json({ error: 'Category not found' });
      }
      res.json(category);
    } catch (error: any) {
      console.error('Failed to update category:', error);
      res.status(500).json({ error: 'Failed to update category' });
    }
  });

  // Delete category (soft delete)
  app.delete('/api/modeling/doc-intel/categories/:id', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      await docIntelService.deleteCategory(orgId, req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete category:', error);
      res.status(500).json({ error: 'Failed to delete category' });
    }
  });

  // --- DOCUMENT UPLOADS ---
  
  // Get all uploads for a project
  app.get('/api/modeling/projects/:projectId/documents', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      const { holdingOnly, holdingStatus } = req.query;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Modeling project not found' });
      }
      
      let uploads = await docIntelService.getProjectUploads(orgId, projectId);
      
      if (holdingOnly === 'true') {
        uploads = uploads.filter((u: any) => 
          u.holdingStatus && ['staging', 'validated', 'ready_to_process'].includes(u.holdingStatus)
        );
      }
      
      if (holdingStatus) {
        uploads = uploads.filter((u: any) => u.holdingStatus === holdingStatus);
      }
      
      const uploadIds = uploads.map((u: any) => u.id);
      let statsMap: Record<string, { total: number; pending: number; confirmed: number; rejected: number; needsReview: number; highConfidence: number; lowConfidence: number }> = {};
      if (uploadIds.length > 0) {
        const { docIntelExtractedItems } = await import('@shared/schema');
        const { sql, inArray, and: andOp, eq: eqOp } = await import('drizzle-orm');
        const statsRows = await db.select({
          uploadId: docIntelExtractedItems.uploadId,
          total: sql<number>`count(*)::int`,
          pending: sql<number>`count(*) filter (where ${docIntelExtractedItems.status} = 'pending')::int`,
          confirmed: sql<number>`count(*) filter (where ${docIntelExtractedItems.status} = 'confirmed')::int`,
          rejected: sql<number>`count(*) filter (where ${docIntelExtractedItems.status} = 'rejected')::int`,
          highConfidence: sql<number>`count(*) filter (where ${docIntelExtractedItems.confidenceScore}::numeric >= 0.8)::int`,
          lowConfidence: sql<number>`count(*) filter (where ${docIntelExtractedItems.confidenceScore}::numeric < 0.8)::int`,
        })
          .from(docIntelExtractedItems)
          .where(andOp(
            eqOp(docIntelExtractedItems.orgId, orgId),
            inArray(docIntelExtractedItems.uploadId, uploadIds)
          ))
          .groupBy(docIntelExtractedItems.uploadId);
        for (const row of statsRows) {
          statsMap[row.uploadId] = {
            total: row.total,
            pending: row.pending,
            confirmed: row.confirmed,
            rejected: row.rejected,
            needsReview: row.pending,
            highConfidence: row.highConfidence,
            lowConfidence: row.lowConfidence,
          };
        }
      }
      
      const enriched = uploads.map((u: any) => ({
        ...u,
        stats: statsMap[u.id] || null,
      }));
      
      res.json(enriched);
    } catch (error: any) {
      console.error('Failed to fetch document uploads:', error);
      res.status(500).json({ error: 'Failed to fetch document uploads' });
    }
  });

  // Upload new document for processing (with SHA-256 duplicate detection)
  app.post('/api/modeling/projects/:projectId/documents', authenticateUser, docIntelUpload.single('file'), validateFileUpload({ maxSize: 50 * 1024 * 1024 }), async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Modeling project not found' });
      }
      
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }
      
      let holdingTags: string[] = [];
      if (req.body.tags) {
        try {
          holdingTags = JSON.parse(req.body.tags);
        } catch {
          holdingTags = [];
        }
      }
      
      const checkProjectOnly = req.body.checkProjectOnly === 'true';
      
      const displayName = req.body.displayName?.trim() || req.file.originalname;
      
      const isT12 = req.body.isT12 === 'true';
      const rentRollSubType = req.body.docType === 'rent_roll' && req.body.rentRollSubType ? req.body.rentRollSubType : null;
      const isMultiYear = req.body.isMultiYear === 'true';
      let multiYears: number[] | null = null;
      if (isMultiYear && req.body.multiYears) {
        try {
          multiYears = JSON.parse(req.body.multiYears).map((y: string | number) => parseInt(String(y))).filter((y: number) => !isNaN(y));
        } catch { multiYears = null; }
      }
      const dataGranularity = req.body.dataGranularity === 'annual' ? 'annual' : 'monthly';
      const sheetIndex = req.body.sheetIndex != null ? parseInt(req.body.sheetIndex) : null;
      const sheetName = req.body.sheetName || null;
      const periodMetadata: any = {};
      if (isT12) {
        periodMetadata.t12StartMonth = req.body.t12StartMonth ? parseInt(req.body.t12StartMonth) : null;
        periodMetadata.t12StartYear = req.body.t12StartYear ? parseInt(req.body.t12StartYear) : null;
        periodMetadata.t12EndMonth = req.body.t12EndMonth ? parseInt(req.body.t12EndMonth) : null;
        periodMetadata.t12EndYear = req.body.t12EndYear ? parseInt(req.body.t12EndYear) : null;
      }
      if (sheetIndex != null) {
        periodMetadata.sheetIndex = sheetIndex;
        periodMetadata.sheetName = sheetName;
      }
      const finalPeriodMetadata = Object.keys(periodMetadata).length > 0 ? periodMetadata : null;

      let holdingTagsList = holdingTags;
      if (isT12 && !holdingTagsList.includes('T12')) {
        holdingTagsList = [...holdingTagsList, 'T12'];
      }
      if (isMultiYear && !holdingTagsList.includes('Multi-Year')) {
        holdingTagsList = [...holdingTagsList, 'Multi-Year'];
      }
      
      const allowOverwrite = req.body.allowOverwrite === 'true';
      
      const result = await docIntelService.createUploadWithDuplicateCheck(
        orgId, 
        {
          modelingProjectId: projectId,
          filename: req.file.filename,
          originalName: displayName,
          storagePath: req.file.path,
          mimeType: req.file.mimetype,
          fileSize: req.file.size,
          docType: req.body.docType || null,
          year: req.body.year ? parseInt(req.body.year) : null,
          dataGranularity: dataGranularity as 'monthly' | 'annual',
          uploadedBy: userId,
          status: 'uploaded',
          holdingStatus: req.body.holdingStatus || 'staging',
          holdingTags: holdingTagsList.length > 0 ? holdingTagsList : null,
          holdingNotes: req.body.notes || null,
          isT12: isT12,
          isMultiYear: isMultiYear,
          multiYears: multiYears,
          periodMetadata: finalPeriodMetadata,
          rentRollSubType: rentRollSubType,
        },
        checkProjectOnly,
        allowOverwrite
      );
      
      if (result.isDuplicate && !allowOverwrite) {
        return res.status(409).json({
          error: 'duplicate',
          message: `This file has already been uploaded as "${result.originalUpload?.originalName || 'unknown'}"`,
          existingUploadId: result.originalUpload?.id,
          existingUploadName: result.originalUpload?.originalName,
          existingUploadDate: result.originalUpload?.createdAt,
        });
      }
      
      const isPnlDoc = (req.body.docType === 'pnl');
      
      if (isPnlDoc) {
        res.status(201).json({
          ...result.upload,
          isDuplicate: result.isDuplicate,
          savedToDataRoom: false,
          originalUpload: result.originalUpload ? {
            id: result.originalUpload.id,
            originalName: result.originalUpload.originalName,
            createdAt: result.originalUpload.createdAt,
          } : null,
        });
        
        setImmediate(async () => {
          try {
            console.log(`[DocIntel] Starting automatic AI parsing for upload ${result.upload.id}`);
            await docIntelService.parseAndExtract(orgId, result.upload.id);
            console.log(`[DocIntel] Parsing complete for upload ${result.upload.id}, categorizing...`);
            await docIntelService.categorizeItems(orgId, result.upload.id);
            console.log(`[DocIntel] Categorization complete for upload ${result.upload.id}`);
            await docIntelService.updateUpload(orgId, result.upload.id, { status: 'reviewing' });
          } catch (parseError: any) {
            console.error(`[DocIntel] Background parsing failed for upload ${result.upload.id}:`, parseError.message);
          }
        });
      } else {
        let savedToVdr = false;
        try {
          const ddProjectId = project.ddProjectId;
          if (ddProjectId) {
            const { vdrFolders, vdrDocuments: vdrDocsTable } = await import('@shared/schema');
            const docTypeLabel = req.body.docType === 'rent_roll' ? 'Rent Rolls'
              : req.body.docType === 'balance_sheet' ? 'Balance Sheets'
              : req.body.docType === 'rate_sheet' ? 'Rate Sheets'
              : req.body.docType === 'invoice' ? 'Invoices'
              : 'Other Documents';
            const folderPath = `/Financial Documents/${docTypeLabel}`;
            
            let [parentFolder] = await db.select().from(vdrFolders)
              .where(and(eq(vdrFolders.projectId, ddProjectId), eq(vdrFolders.orgId, orgId), eq(vdrFolders.name, 'Financial Documents')))
              .limit(1);
            if (!parentFolder) {
              [parentFolder] = await db.insert(vdrFolders).values({
                projectId: ddProjectId, orgId, name: 'Financial Documents', path: '/Financial Documents',
                createdBy: userId,
              }).returning();
            }
            
            let [targetFolder] = await db.select().from(vdrFolders)
              .where(and(eq(vdrFolders.projectId, ddProjectId), eq(vdrFolders.orgId, orgId), eq(vdrFolders.name, docTypeLabel), eq(vdrFolders.parentFolderId, parentFolder.id)))
              .limit(1);
            if (!targetFolder) {
              [targetFolder] = await db.insert(vdrFolders).values({
                projectId: ddProjectId, orgId, name: docTypeLabel, path: folderPath,
                parentFolderId: parentFolder.id, createdBy: userId,
              }).returning();
            }
            
            const fileBuffer = await fs.readFile(req.file.path);
            const hashHex = require('crypto').createHash('sha256').update(fileBuffer).digest('hex');
            
            await db.insert(vdrDocsTable).values({
              folderId: targetFolder.id, projectId: ddProjectId, orgId,
              filename: displayName, originalFilename: req.file.originalname,
              mimeType: req.file.mimetype, size: req.file.size,
              checksum: hashHex, storagePath: req.file.path,
              uploadedBy: userId,
              aiCategory: docTypeLabel,
              tags: [req.body.docType],
            });
            savedToVdr = true;
            console.log(`[DocIntel] Non-P&L document ${result.upload.id} saved to VDR folder: ${folderPath}`);
          }
        } catch (vdrError: any) {
          console.error(`[DocIntel] Failed to save to VDR for upload ${result.upload.id}:`, vdrError.message);
        }
        
        await docIntelService.updateUpload(orgId, result.upload.id, { status: 'completed' });
        
        res.status(201).json({
          ...result.upload,
          status: 'completed',
          isDuplicate: result.isDuplicate,
          savedToDataRoom: savedToVdr,
          originalUpload: result.originalUpload ? {
            id: result.originalUpload.id,
            originalName: result.originalUpload.originalName,
            createdAt: result.originalUpload.createdAt,
          } : null,
        });
      }
    } catch (error: any) {
      console.error('Failed to upload document:', error);
      res.status(500).json({ error: 'Failed to upload document', details: error?.message });
    }
  });

  // Get single upload with stats
  app.get('/api/modeling/projects/:projectId/documents/:uploadId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      
      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload || upload.modelingProjectId !== projectId) {
        return res.status(404).json({ error: 'Document not found' });
      }
      
      const stats = await docIntelService.getUploadStats(orgId, uploadId);
      res.json({ ...upload, stats });
    } catch (error: any) {
      console.error('Failed to fetch document:', error);
      res.status(500).json({ error: 'Failed to fetch document' });
    }
  });

  // Update upload metadata (doc type, year, wizard step)
  app.patch('/api/modeling/projects/:projectId/documents/:uploadId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      
      const upload = await docIntelService.updateUpload(orgId, uploadId, req.body);
      if (!upload) {
        return res.status(404).json({ error: 'Document not found' });
      }
      
      res.json(upload);
    } catch (error: any) {
      console.error('Failed to update document:', error);
      res.status(500).json({ error: 'Failed to update document' });
    }
  });

  // Delete upload and associated items
  app.delete('/api/modeling/projects/:projectId/documents/:uploadId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { uploadId } = req.params;
      
      await docIntelService.deleteUpload(orgId, uploadId);
      res.json({ success: true });
    } catch (error: any) {
      console.error('Failed to delete document:', error);
      res.status(500).json({ error: 'Failed to delete document' });
    }
  });

  // Validate document in holding station (mark as ready for processing)
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/validate', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, uploadId } = req.params;
      
      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload || upload.modelingProjectId !== projectId) {
        return res.status(404).json({ error: 'Document not found' });
      }
      
      const validationErrors: string[] = [];
      if (!upload.docType) {
        validationErrors.push('Document type is required');
      }
      if (!upload.year) {
        validationErrors.push('Fiscal year is required');
      }
      
      const updatedUpload = await docIntelService.updateUpload(orgId, uploadId, {
        holdingStatus: validationErrors.length === 0 ? 'validated' : 'staging',
        validationErrors: validationErrors.length > 0 ? validationErrors : null,
        validatedAt: validationErrors.length === 0 ? new Date() : null,
        validatedBy: validationErrors.length === 0 ? userId : null,
      });
      
      if (validationErrors.length > 0) {
        return res.status(400).json({ 
          error: 'Validation failed', 
          validationErrors 
        });
      }
      
      res.json(updatedUpload);
    } catch (error: any) {
      console.error('Failed to validate document:', error);
      res.status(500).json({ error: 'Failed to validate document' });
    }
  });

  // --- PARSING & EXTRACTION ---
  
  // Parse document and extract line items
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/parse', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      
      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload || upload.modelingProjectId !== projectId) {
        return res.status(404).json({ error: 'Document not found' });
      }
      
      const items = await docIntelService.parseAndExtract(orgId, uploadId);
      res.json({ items, count: items.length });
    } catch (error: any) {
      console.error('Failed to parse document:', error);
      res.status(500).json({ error: 'Failed to parse document' });
    }
  });

  // Categorize extracted items using rules
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/categorize', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      const { enabledDepartments } = req.body || {};
      
      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload || upload.modelingProjectId !== projectId) {
        return res.status(404).json({ error: 'Document not found' });
      }
      
      const items = await docIntelService.categorizeItems(orgId, uploadId, enabledDepartments);
      
      // Update upload to reviewing status
      await docIntelService.updateUpload(orgId, uploadId, { 
        status: 'reviewing',
        reviewStartedAt: new Date(),
        wizardStep: 2
      });
      
      res.json({ items, count: items.length });
    } catch (error: any) {
      console.error('Failed to categorize items:', error);
      res.status(500).json({ error: 'Failed to categorize items' });
    }
  });

  // --- EXTRACTED ITEMS ---
  
  // Get all extracted items for an upload
  app.get('/api/modeling/projects/:projectId/documents/:uploadId/items', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      
      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload || upload.modelingProjectId !== projectId) {
        return res.status(404).json({ error: 'Document not found' });
      }
      
      const grouped = req.query.grouped === 'true';
      if (grouped) {
        const groupedItems = await docIntelService.getExtractedItemsGrouped(orgId, uploadId);
        return res.json(groupedItems);
      }

      // Always apply learning rules for auto-confirmation
      const marinaId = upload.marinaId ?? null;
      const itemsWithRules = await docIntelService.getExtractedItemsWithLearningRules(orgId, uploadId, marinaId);
      
      const withCategories = req.query.withCategories === 'true';
      if (withCategories) {
        const categories = await docIntelService.getCategories(orgId);
        const categoryMap = new Map(categories.map((c: any) => [c.id, c]));
        const items = itemsWithRules.map((item: any) => ({
          ...item,
          suggestedCategory: item.categorySuggested ? categoryMap.get(item.categorySuggested) : undefined,
          confirmedCategory: item.categoryConfirmed ? categoryMap.get(item.categoryConfirmed) : undefined,
        }));
        return res.json(items);
      }
      
      res.json(itemsWithRules);
    } catch (error: any) {
      console.error('Failed to fetch extracted items:', error);
      res.status(500).json({ error: 'Failed to fetch extracted items' });
    }
  });

  // Confirm an extracted item (assign category and optionally department)
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/items/:itemId/confirm', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { itemId } = req.params;
      const { categoryId, amount, department } = req.body;
      
      if (!categoryId) {
        return res.status(400).json({ error: 'Cannot confirm: Category is required.' });
      }
      if (!department) {
        return res.status(400).json({ error: 'Cannot confirm: Department is required.' });
      }
      
      const item = await docIntelService.confirmItem(orgId, itemId, categoryId, userId, amount, department);
      res.json(item);
    } catch (error: any) {
      console.error('Failed to confirm item:', error);
      res.status(500).json({ error: error.message || 'Failed to confirm item' });
    }
  });

  // Reject an extracted item
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/items/:itemId/reject', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { itemId } = req.params;
      
      const item = await docIntelService.rejectItem(orgId, itemId);
      res.json(item);
    } catch (error: any) {
      console.error('Failed to reject item:', error);
      res.status(500).json({ error: 'Failed to reject item' });
    }
  });

  // Exclude an extracted item (different from reject - marks as excluded from import)
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/items/:itemId/exclude', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { itemId } = req.params;
      
      const item = await docIntelService.excludeItem(orgId, itemId);
      res.json(item);
    } catch (error: any) {
      console.error('Failed to exclude item:', error);
      res.status(500).json({ error: 'Failed to exclude item' });
    }
  });

  // --- Simplified routes for PLReviewGrid component ---
  
  // Get extracted items by upload ID (simpler route)
  app.get('/api/doc-intel/uploads/:uploadId/items', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { uploadId } = req.params;
      const grouped = req.query.grouped === 'true';
      
      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload) {
        return res.status(404).json({ error: 'Upload not found' });
      }
      
      if (grouped) {
        const groupedItems = await docIntelService.getExtractedItemsGrouped(orgId, uploadId);
        return res.json(groupedItems);
      }
      
      const items = await docIntelService.getExtractedItemsWithCategories(orgId, uploadId);
      res.json(items);
    } catch (error: any) {
      console.error('Failed to fetch items:', error);
      res.status(500).json({ error: 'Failed to fetch items' });
    }
  });
  
  // Update a single extracted item
  app.patch('/api/doc-intel/items/:itemId', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { itemId } = req.params;
      const updates = req.body;
      
      const item = await docIntelService.updateExtractedItem(orgId, itemId, updates, userId);
      if (!item) {
        return res.status(404).json({ error: 'Item not found' });
      }

      let propagation = { propagatedCount: 0, affectedUploadIds: [] as string[] };
      const hasStatusChange = updates.status !== undefined;
      const hasClassificationChange = updates.categoryTierConfirmed !== undefined || 
        updates.revenueCogsDeptConfirmed !== undefined || updates.expenseDeptConfirmed !== undefined;
      if (hasStatusChange || hasClassificationChange) {
        propagation = await docIntelService.propagateClassificationToSiblingUploads(
          orgId, item.uploadId, item.rawText, updates, userId
        );
      }

      res.json({ ...item, _propagation: propagation });
    } catch (error: any) {
      if (error.message?.startsWith('Cannot confirm:')) {
        return res.status(400).json({ error: error.message });
      }
      console.error('Failed to update item:', error);
      res.status(500).json({ error: 'Failed to update item' });
    }
  });
  
  // Bulk update extracted items
  app.patch('/api/doc-intel/uploads/:uploadId/items/bulk', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { uploadId } = req.params;
      const { itemIds, updates } = req.body;
      
      if (!Array.isArray(itemIds) || itemIds.length === 0) {
        return res.status(400).json({ error: 'itemIds array required' });
      }
      
      let results: any[];
      try {
        results = await docIntelService.bulkUpdateExtractedItems(orgId, itemIds, updates, userId);
      } catch (bulkError: any) {
        if (bulkError.message?.startsWith('Cannot confirm:')) {
          return res.status(400).json({ error: bulkError.message });
        }
        throw bulkError;
      }

      const allAffectedUploadIds = new Set<string>();
      let totalPropagated = 0;
      const hasStatusChange = updates.status !== undefined;
      const hasClassificationChange = updates.categoryTierConfirmed !== undefined || 
        updates.revenueCogsDeptConfirmed !== undefined || updates.expenseDeptConfirmed !== undefined;
      if (hasStatusChange || hasClassificationChange) {
        const uniqueTexts = [...new Set(results.map(r => r.rawText))];
        for (const rawText of uniqueTexts) {
          const propagation = await docIntelService.propagateClassificationToSiblingUploads(
            orgId, uploadId, rawText, updates, userId
          );
          totalPropagated += propagation.propagatedCount;
          propagation.affectedUploadIds.forEach(id => allAffectedUploadIds.add(id));
        }
      }

      res.json({ 
        updated: results.length, 
        _propagation: { 
          propagatedCount: totalPropagated, 
          affectedUploadIds: [...allAffectedUploadIds] 
        } 
      });
    } catch (error: any) {
      console.error('Failed to bulk update items:', error);
      res.status(500).json({ error: 'Failed to bulk update items' });
    }
  });

  // Auto-confirm high confidence items
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/items/confirm-high-confidence', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { uploadId } = req.params;
      const threshold = parseFloat(req.body.threshold) || 0.9;
      
      const count = await docIntelService.confirmAllHighConfidence(orgId, uploadId, userId, threshold);
      res.json({ confirmed: count });
    } catch (error: any) {
      console.error('Failed to auto-confirm items:', error);
      res.status(500).json({ error: 'Failed to auto-confirm items' });
    }
  });

  // --- APPROVAL WORKFLOW ---

  // Approve a document for import (marks document as ready to apply)
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/approve', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { uploadId } = req.params;
      const { notes } = req.body;
      
      const upload = await docIntelService.approveDocument(orgId, uploadId, userId, notes);
      res.json(upload);
    } catch (error: any) {
      console.error('Failed to approve document:', error);
      res.status(500).json({ error: 'Failed to approve document' });
    }
  });

  // --- IMPORT TO P&L ---
  
  // Import confirmed items to P&L Lines
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/import', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { projectId, uploadId } = req.params;
      const { fiscalYear } = req.body;
      
      console.log("[Doc Intel Import] projectId:", projectId, "uploadId:", uploadId, "fiscalYear:", fiscalYear);
      const lines = await docIntelService.importConfirmedItems(orgId, uploadId, projectId, userId, fiscalYear);
      res.json({ imported: lines.length, lines });
      console.log("[Doc Intel Import] Result - imported lines:", lines.length);
    } catch (error: any) {
      console.error('Failed to import items:', error);
      res.status(500).json({ error: 'Failed to import items' });
    }
  });
  // Reprocess a completed document - reset to review state
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/reprocess', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      
      const result = await docIntelService.reprocessUpload(orgId, uploadId);
      res.json(result);
    } catch (error: any) {
      console.error('Failed to reprocess document:', error);
      res.status(500).json({ error: 'Failed to reprocess document' });
    }
  });
  // Retry parsing a stuck or errored document
  app.post("/api/modeling/projects/:projectId/documents/:uploadId/retry", authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;

      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload || upload.modelingProjectId !== projectId) {
        return res.status(404).json({ error: "Document not found" });
      }

      res.json({ message: "Retrying parse", uploadId });

      setImmediate(async () => {
        try {
          console.log(`[DocIntel] Retrying parse for upload ${uploadId}`);
          const items = await docIntelService.retryParse(orgId, uploadId);
          console.log(`[DocIntel] Retry parse complete for ${uploadId}, ${items.length} items extracted`);
          await docIntelService.categorizeItems(orgId, uploadId);
          console.log(`[DocIntel] Retry categorization complete for ${uploadId}`);
          const { updateUpload } = docIntelService;
          await docIntelService.updateUpload(orgId, uploadId, { status: "reviewing" });
        } catch (parseError: any) {
          console.error(`[DocIntel] Retry parse failed for ${uploadId}:`, parseError.message);
        }
      });
    } catch (error: any) {
      console.error("Failed to retry document:", error);
      res.status(500).json({ error: "Failed to retry document parsing" });
    }
  });
  // Import Rent Roll document to Rent Roll module with customer creation and CRM linking
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/import-rent-roll', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      const { 
        rentRollId, 
        rentRollName, 
        effectiveDate, 
        createCustomers = true, 
        linkToCrm = true 
      } = req.body;
      
      const result = await docIntelService.importRentRollToModule(orgId, uploadId, {
        rentRollId,
        rentRollName,
        effectiveDate,
        createCustomers,
        linkToCrm,
      });
      
      res.json({
        success: true,
        rentRoll: result.rentRoll,
        stats: {
          entriesImported: result.entries.length,
          customersCreated: result.customers.length,
          contactsLinked: result.matchedContacts.length,
          errors: result.errors.length,
        },
        entries: result.entries,
        customers: result.customers,
        matchedContacts: result.matchedContacts,
        errors: result.errors,
      });
    } catch (error: any) {
      console.error('Failed to import rent roll:', error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Failed to import rent roll' 
      });
    }
  });

  // Preview rent roll document parsing (without importing)
  app.post('/api/modeling/projects/:projectId/documents/:uploadId/preview-rent-roll', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId, uploadId } = req.params;
      
      const upload = await docIntelService.getUpload(orgId, uploadId);
      if (!upload) {
        return res.status(404).json({ error: 'Document not found' });
      }
      
      const parsed = await docIntelService.parseRentRollFile(upload.storagePath);
      
      const tenantNames = parsed
        .filter(p => p.tenantName && p.status !== 'vacant')
        .map(p => p.tenantName as string);
      
      const uniqueTenants = [...new Set(tenantNames)];
      const crmMatches = await docIntelService.matchTenantsToCrmContacts(orgId, uniqueTenants);
      
      res.json({
        entries: parsed,
        summary: {
          totalUnits: parsed.length,
          occupiedUnits: parsed.filter(p => p.status !== 'vacant').length,
          vacantUnits: parsed.filter(p => p.status === 'vacant').length,
          totalMonthlyRevenue: parsed.reduce((sum, p) => sum + p.monthlyRate, 0),
          uniqueTenants: uniqueTenants.length,
        },
        crmMatching: crmMatches,
      });
    } catch (error: any) {
      console.error('Failed to preview rent roll:', error);
      res.status(500).json({ 
        error: error instanceof Error ? error.message : 'Failed to preview rent roll' 
      });
    }
  });

  // Match tenant names to CRM contacts
  app.post('/api/modeling/doc-intel/match-tenants', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { tenantNames } = req.body;
      
      if (!Array.isArray(tenantNames)) {
        return res.status(400).json({ error: 'tenantNames must be an array' });
      }
      
      const result = await docIntelService.matchTenantsToCrmContacts(orgId, tenantNames);
      res.json(result);
    } catch (error: any) {
      console.error('Failed to match tenants:', error);
      res.status(500).json({ error: 'Failed to match tenants to CRM contacts' });
    }
  });

  // Get P&L Lines for a project
  app.get('/api/modeling/projects/:projectId/pnl-lines', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Modeling project not found' });
      }
      
      const lines = await docIntelService.getProjectPnlLines(orgId, projectId);
      res.json(lines);
    } catch (error: any) {
      console.error('Failed to fetch P&L lines:', error);
      res.status(500).json({ error: 'Failed to fetch P&L lines' });
    }
  });

  // Get P&L Summary by category for variance preview
  app.get('/api/modeling/projects/:projectId/pnl-summary', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;
      
      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Modeling project not found' });
      }
      
      const summary = await docIntelService.getPnlSummaryByCategory(orgId, projectId);
      res.json(summary);
    } catch (error: any) {
      console.error('Failed to fetch P&L summary:', error);
      res.status(500).json({ error: 'Failed to fetch P&L summary' });
    }
  });

  // --- CATEGORY MAPPINGS & RULES ---
  
  // Get category mappings for organization
  app.get('/api/modeling/doc-intel/mappings', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const projectId = req.query.projectId as string | undefined;
      
      const mappings = await docIntelService.getCategoryMappings(orgId, projectId);
      res.json(mappings);
    } catch (error: any) {
      console.error('Failed to fetch category mappings:', error);
      res.status(500).json({ error: 'Failed to fetch category mappings' });
    }
  });

  // Create learning rule from user feedback
  app.post('/api/modeling/doc-intel/rules', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const userId = req.user.id;
      const { name, keywords, categoryId } = req.body;
      
      if (!name || !keywords || !categoryId) {
        return res.status(400).json({ error: 'name, keywords, and categoryId are required' });
      }
      
      const rule = await docIntelService.createLearningRule(orgId, name, keywords, categoryId, userId);
      res.status(201).json(rule);
    } catch (error: any) {
      console.error('Failed to create learning rule:', error);
      res.status(500).json({ error: 'Failed to create learning rule' });
    }
  });

  // ============================================================================
  // EXIT STRATEGY SUITE
  // ============================================================================

  // --- EXIT DASHBOARD METRICS ---
  app.get('/api/modeling/projects/:projectId/exit/metrics', authenticateUser, async (req: any, res) => {
    try {
      const orgId = req.user.orgId;
      const { projectId } = req.params;

      const project = await storage.getModelingProject(projectId, orgId);
      if (!project) {
        return res.status(404).json({ error: 'Modeling project not found' });
      }

      const { modelingActuals, modelingFinancialPeriods } = await import('@shared/schema');

      const propertyValue = project.purchasePrice ? parseFloat(project.purchasePrice.toString()) : null;

      let t12Ebitda: number | null = null;
      let t12Label: string | null = null;

      try {
        const financialPeriods = await db.select()
          .from(modelingFinancialPeriods)
          .where(and(
            eq(modelingFinancialPeriods.modelingProjectId, projectId),
            eq(modelingFinancialPeriods.orgId, orgId)
          ));

        const t12Period = financialPeriods.find(p => p.periodType === 't12');
        if (t12Period) {
          t12Ebitda = t12Period.ebitda ? parseFloat(t12Period.ebitda) : (t12Period.noi ? parseFloat(t12Period.noi) : null);
          t12Label = t12Period.periodLabel || 'T12';
        }

        if (t12Ebitda === null) {
          const actuals = await db.select({
            year: modelingActuals.year,
            month: modelingActuals.month,
            category: modelingActuals.category,
            amount: modelingActuals.amount,
          })
          .from(modelingActuals)
          .where(and(
            eq(modelingActuals.modelingProjectId, projectId),
            eq(modelingActuals.orgId, orgId)
          ));

          if (actuals.length > 0) {
            const periods = new Set(actuals.map(a => `${a.year}-${String(a.month).padStart(2, '0')}`));
            const sortedPeriods = Array.from(periods).sort().slice(-12);

            if (sortedPeriods.length > 0) {
              const validPeriods = new Set(sortedPeriods);
              let revenue = 0;
              let cogs = 0;
              let expenses = 0;

              for (const actual of actuals) {
                const key = `${actual.year}-${String(actual.month).padStart(2, '0')}`;
                if (!validPeriods.has(key)) continue;
                const amt = parseFloat(actual.amount?.toString() || '0');
                const cat = actual.category?.toLowerCase() || '';
                if (cat === 'revenue') revenue += amt;
                else if (cat === 'cogs') cogs += amt;
                else if (cat === 'expenses' || cat === 'expense') expenses += amt;
              }
              t12Ebitda = revenue - cogs - expenses;

              const firstPeriod = sortedPeriods[0].split('-');
              const lastPeriod = sortedPeriods[sortedPeriods.length - 1].split('-');
              const startMonth = parseInt(firstPeriod[1]);
