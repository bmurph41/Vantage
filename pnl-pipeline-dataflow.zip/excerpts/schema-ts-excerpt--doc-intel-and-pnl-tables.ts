]);

// Canonical Line Items (COA Master) - the "gold standard" categories
export const pnlCanonicalLineItems = pgTable('pnl_canonical_line_items', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  coaCode: varchar('coa_code', { length: 100 }).notNull().unique(),
  displayName: text('display_name').notNull(),
  majorGroup: pnlMajorGroupEnum('major_group').notNull(),
  subcategoryGroup: text('subcategory_group').notNull(),
  description: text('description'),
  sortOrder: integer('sort_order').default(0),
  isActive: boolean('is_active').default(true).notNull(),
  isSystemDefault: boolean('is_system_default').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  coaCodeIdx: index('pnl_canonical_coa_code_idx').on(table.coaCode),
  majorGroupIdx: index('pnl_canonical_major_group_idx').on(table.majorGroup),
  subcategoryIdx: index('pnl_canonical_subcategory_idx').on(table.subcategoryGroup),
}));

// Segments (Business Units)
export const pnlSegments = pgTable('pnl_segments', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  segmentCode: varchar('segment_code', { length: 100 }).notNull().unique(),
  segmentName: text('segment_name').notNull(),
  segmentType: pnlSegmentTypeEnum('segment_type').notNull(),
  sortOrder: integer('sort_order').default(0),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  segmentCodeIdx: index('pnl_segments_code_idx').on(table.segmentCode),
  segmentTypeIdx: index('pnl_segments_type_idx').on(table.segmentType),
}));

// Line Item Aliases - maps raw labels to canonical codes
export const pnlLineItemAliases = pgTable('pnl_line_item_aliases', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').references(() => organizations.id),
  rawLabel: text('raw_label').notNull(),
  normalizedLabel: text('normalized_label').notNull(),
  canonicalCoaCode: varchar('canonical_coa_code', { length: 100 }).notNull(),
  segmentCode: varchar('segment_code', { length: 100 }),
  confidence: decimal('confidence', { precision: 5, scale: 4 }).default('1.0'),
  source: text('source').default('seed'),
  notes: text('notes'),
  timesUsed: integer('times_used').default(0),
  lastUsedAt: timestamp('last_used_at'),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('pnl_aliases_org_idx').on(table.orgId),
  normalizedIdx: index('pnl_aliases_normalized_idx').on(table.normalizedLabel),
  coaCodeIdx: index('pnl_aliases_coa_code_idx').on(table.canonicalCoaCode),
}));

// Keyword Rules - for pattern-based matching
export const pnlKeywordRules = pgTable('pnl_keyword_rules', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').references(() => organizations.id),
  keywords: text('keywords').array().notNull(),
  matchType: text('match_type').default('contains'),
  canonicalCoaCode: varchar('canonical_coa_code', { length: 100 }).notNull(),
  segmentCode: varchar('segment_code', { length: 100 }),
  priority: integer('priority').default(100),
  confidence: decimal('confidence', { precision: 5, scale: 4 }).default('0.8'),
  timesMatched: integer('times_matched').default(0),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('pnl_keyword_rules_org_idx').on(table.orgId),
  coaCodeIdx: index('pnl_keyword_rules_coa_idx').on(table.canonicalCoaCode),
  priorityIdx: index('pnl_keyword_rules_priority_idx').on(table.priority),
}));

// Type exports
export type PnlCanonicalLineItem = typeof pnlCanonicalLineItems.$inferSelect;
export type InsertPnlCanonicalLineItem = typeof pnlCanonicalLineItems.$inferInsert;
export type PnlSegment = typeof pnlSegments.$inferSelect;
export type InsertPnlSegment = typeof pnlSegments.$inferInsert;
export type PnlLineItemAlias = typeof pnlLineItemAliases.$inferSelect;
export type InsertPnlLineItemAlias = typeof pnlLineItemAliases.$inferInsert;
export type PnlKeywordRule = typeof pnlKeywordRules.$inferSelect;
export type InsertPnlKeywordRule = typeof pnlKeywordRules.$inferInsert;


// Document Uploads - Files uploaded for intelligent parsing
export const docIntelUploads = pgTable('doc_intel_uploads', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // File info
  filename: text('filename').notNull(),
  originalName: text('original_name').notNull(),
  storagePath: text('storage_path').notNull(),
  mimeType: text('mime_type').notNull(),
  fileSize: integer('file_size').notNull(),
  hashSha256: text('hash_sha256'), // For duplicate detection

  // Classification
  docType: docIntelDocTypeEnum('doc_type'),
  year: integer('year'), // Fiscal year of document
  dataGranularity: text('data_granularity').$type<'monthly' | 'annual'>().default('monthly'),

  // Processing status
  status: docIntelProcessingStatusEnum('status').notNull().default('uploaded'),
  errorMessage: text('error_message'),

  // Holding Station - Staging queue before processing
  holdingStatus: holdingStationStatusEnum('holding_status').default('staging'),
  holdingTags: text('holding_tags').array(), // User-defined tags for organization
  holdingNotes: text('holding_notes'), // Notes about the document
  isT12: boolean('is_t12').default(false),
  isMultiYear: boolean('is_multi_year').default(false),
  multiYears: jsonb('multi_years').$type<number[]>(),
  periodMetadata: jsonb('period_metadata').$type<{ t12StartMonth?: number; t12StartYear?: number; t12EndMonth?: number; t12EndYear?: number }>(),
  isDuplicate: boolean('is_duplicate').default(false),
  duplicateOfId: varchar('duplicate_of_id'), // Reference to original if duplicate
  validationErrors: jsonb('validation_errors').$type<string[]>(), // Validation issues
  validatedAt: timestamp('validated_at'),
  validatedBy: varchar('validated_by').references(() => users.id),

  // Review progress
  wizardStep: integer('wizard_step').default(1), // Current step in review wizard (1-5)
  reviewStartedAt: timestamp('review_started_at'),
  reviewCompletedAt: timestamp('review_completed_at'),

  // Approval workflow
  approvalNotes: text('approval_notes'), // Notes from reviewer before applying
  approvedAt: timestamp('approved_at'),
  approvedBy: varchar('approved_by').references(() => users.id),
  appliedAt: timestamp('applied_at'), // When data was written to model
  appliedBy: varchar('applied_by').references(() => users.id),

  // Rent Roll sub-type (only for rent_roll docType)
  rentRollSubType: text('rent_roll_sub_type'),

  // Metadata
  uploadedBy: varchar('uploaded_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('doc_intel_uploads_org_idx').on(table.orgId),
  projectIdx: index('doc_intel_uploads_project_idx').on(table.modelingProjectId),
  statusIdx: index('doc_intel_uploads_status_idx').on(table.status),
  docTypeIdx: index('doc_intel_uploads_doc_type_idx').on(table.docType),
  holdingStatusIdx: index('doc_intel_uploads_holding_status_idx').on(table.holdingStatus),
}));

// Extracted Items - Line items parsed from documents
export const docIntelExtractedItems = pgTable('doc_intel_extracted_items', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  uploadId: varchar('upload_id').notNull().references(() => docIntelUploads.id, { onDelete: 'cascade' }),

  // Extracted raw data
  rawText: text('raw_text').notNull(), // Original text from document
  amount: decimal('amount', { precision: 18, scale: 2 }),
  extractedDate: text('extracted_date'), // Date string found in document
  sourcePage: integer('source_page'), // Page/sheet number
  sourceRow: integer('source_row'), // Row number in spreadsheet

  // AI suggestions
  categorySuggested: varchar('category_suggested').references(() => pnlCategories.id),
  confidenceScore: decimal('confidence_score', { precision: 5, scale: 4 }), // 0.0000 to 1.0000
  matchedRuleId: varchar('matched_rule_id'), // Which rule triggered this suggestion

  // Department assignment (AI suggested + user confirmed)
  departmentSuggested: docIntelDepartmentEnum('department_suggested'),
  departmentConfirmed: docIntelDepartmentEnum('department_confirmed'),


  // Category tier (Revenue, COGS, Expense) for simplified P&L categorization
  categoryTierSuggested: pnlCategoryTierEnum('category_tier_suggested'),
  categoryTierConfirmed: pnlCategoryTierEnum('category_tier_confirmed'),

  // Marina-specific departments (different options for Revenue/COGS vs Expense)
  revenueCogsDeptSuggested: revenueCogsDeptEnum('revenue_cogs_dept_suggested'),
  revenueCogsDeptConfirmed: revenueCogsDeptEnum('revenue_cogs_dept_confirmed'),
  expenseDeptSuggested: expenseDeptEnum('expense_dept_suggested'),
  expenseDeptConfirmed: expenseDeptEnum('expense_dept_confirmed'),

  // Period mapping for multi-column P&L extraction
  periodKey: text('period_key'), // e.g., "2024", "Q1 2024", "Jan 2024"
  columnIndex: integer('column_index'), // Column position in source spreadsheet
  // User confirmation
  status: docIntelItemStatusEnum('status').notNull().default('pending'),
  categoryConfirmed: varchar('category_confirmed').references(() => pnlCategories.id),
  amountConfirmed: decimal('amount_confirmed', { precision: 18, scale: 2 }),
  confirmedBy: varchar('confirmed_by').references(() => users.id),
  confirmedAt: timestamp('confirmed_at'),

  // Review notes
  reviewNotes: text('review_notes'),

  // Destination mapping
  targetTable: text('target_table'), // e.g., 'pnl_lines', 'rent_roll_entries'
  targetRecordId: varchar('target_record_id'), // ID of created record after import

  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('doc_intel_items_org_idx').on(table.orgId),
  uploadIdx: index('doc_intel_items_upload_idx').on(table.uploadId),
  statusIdx: index('doc_intel_items_status_idx').on(table.status),
  categoryIdx: index('doc_intel_items_category_idx').on(table.categorySuggested),
}));

// Category Mappings - Pattern-based rules for auto-categorization
export const docIntelCategoryMappings = pgTable('doc_intel_category_mappings', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Rule definition
  name: text('name').notNull(), // e.g., "Dock Revenue Pattern"
  pattern: text('pattern').notNull(), // Regex pattern to match
  categoryId: varchar('category_id').notNull().references(() => pnlCategories.id),
  targetTable: text('target_table').notNull().default('pnl_lines'), // Destination table

  // Scope
  projectId: varchar('project_id').references(() => modelingProjects.id), // null = org-wide

  // Confidence & priority
  confidenceThreshold: decimal('confidence_threshold', { precision: 5, scale: 4 }).default('0.8'),
  priority: integer('priority').default(0), // Higher = checked first

  isActive: boolean('is_active').default(true).notNull(),
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('doc_intel_mappings_org_idx').on(table.orgId),
  categoryIdx: index('doc_intel_mappings_category_idx').on(table.categoryId),
  projectIdx: index('doc_intel_mappings_project_idx').on(table.projectId),
  activeIdx: index('doc_intel_mappings_active_idx').on(table.isActive),
}));

// Learning Rules - Complex rules that improve from user feedback
export const docIntelLearningRules = pgTable('doc_intel_learning_rules', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Rule definition
  name: text('name').notNull(),
  ruleJson: jsonb('rule_json').notNull(), // Complex rule with conditions
  categoryId: varchar('category_id').notNull().references(() => pnlCategories.id),
  targetTable: text('target_table').notNull().default('pnl_lines'),

  // Learning metrics
  timesApplied: integer('times_applied').default(0),
  timesConfirmed: integer('times_confirmed').default(0),
  timesRejected: integer('times_rejected').default(0),
  confidenceScore: decimal('confidence_score', { precision: 5, scale: 4 }).default('0.5'),

  // Scope
  projectId: varchar('project_id').references(() => modelingProjects.id), // null = org-wide

  isActive: boolean('is_active').default(true).notNull(),
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('doc_intel_rules_org_idx').on(table.orgId),
  categoryIdx: index('doc_intel_rules_category_idx').on(table.categoryId),
  activeIdx: index('doc_intel_rules_active_idx').on(table.isActive),
}));

// Training Examples - User confirmations used for learning
export const docIntelTrainingExamples = pgTable('doc_intel_training_examples', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  extractedItemId: varchar('extracted_item_id').references(() => docIntelExtractedItems.id, { onDelete: 'cascade' }),

  // Training data
  textSnippet: text('text_snippet').notNull(), // The text that was categorized
  labelCategoryId: varchar('label_category_id').notNull().references(() => pnlCategories.id),
  labelTable: text('label_table').notNull(), // Target table for this type

  // Context
  projectId: varchar('project_id').references(() => modelingProjects.id),
  docType: docIntelDocTypeEnum('doc_type'),

  // Tracking
  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('doc_intel_training_org_idx').on(table.orgId),
  categoryIdx: index('doc_intel_training_category_idx').on(table.labelCategoryId),
  projectIdx: index('doc_intel_training_project_idx').on(table.projectId),
}));

// P&L Lines - Actual P&L data imported from documents
export const pnlLines = pgTable('pnl_lines', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Category & description
  categoryId: varchar('category_id').references(() => pnlCategories.id),
  lineDescription: text('line_description').notNull(),

  // Financial data
  amount: decimal('amount', { precision: 18, scale: 2 }).notNull(),
  fiscalYear: integer('fiscal_year'),
  fiscalMonth: integer('fiscal_month'), // 1-12, null for annual

  // Source tracking
  sourceUploadId: varchar('source_upload_id').references(() => docIntelUploads.id),
  sourceItemId: varchar('source_item_id').references(() => docIntelExtractedItems.id),
  isManualEntry: boolean('is_manual_entry').default(false).notNull(),

  notes: text('notes'),
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('pnl_lines_org_idx').on(table.orgId),
  projectIdx: index('pnl_lines_project_idx').on(table.modelingProjectId),
  categoryIdx: index('pnl_lines_category_idx').on(table.categoryId),
  yearIdx: index('pnl_lines_year_idx').on(table.fiscalYear),
}));

// Insert schemas for Document Intelligence
export const insertPnlCategorySchema = createInsertSchema(pnlCategories).omit({
  id: true,
  orgId: true,
  createdAt: true,
  updatedAt: true,
});

export const updatePnlCategorySchema = insertPnlCategorySchema.partial();

export const insertDocIntelUploadSchema = createInsertSchema(docIntelUploads).omit({
  id: true,
  orgId: true,
  createdAt: true,
  updatedAt: true,
});

export const updateDocIntelUploadSchema = insertDocIntelUploadSchema.partial();

export const insertDocIntelExtractedItemSchema = createInsertSchema(docIntelExtractedItems).omit({
  id: true,
  orgId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  amount: z.string().or(z.number()).optional(),
  confidenceScore: z.string().or(z.number()).optional(),
  amountConfirmed: z.string().or(z.number()).optional(),
});

export const updateDocIntelExtractedItemSchema = insertDocIntelExtractedItemSchema.partial();

export const insertDocIntelCategoryMappingSchema = createInsertSchema(docIntelCategoryMappings).omit({
  id: true,
  orgId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  confidenceThreshold: z.string().or(z.number()).optional(),
});

export const updateDocIntelCategoryMappingSchema = insertDocIntelCategoryMappingSchema.partial();

export const insertDocIntelLearningRuleSchema = createInsertSchema(docIntelLearningRules).omit({
  id: true,
  orgId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  confidenceScore: z.string().or(z.number()).optional(),
});

export const updateDocIntelLearningRuleSchema = insertDocIntelLearningRuleSchema.partial();

export const insertDocIntelTrainingExampleSchema = createInsertSchema(docIntelTrainingExamples).omit({
  id: true,
  orgId: true,
  createdAt: true,
});

export const insertPnlLineSchema = createInsertSchema(pnlLines).omit({
  id: true,
  orgId: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  amount: z.string().or(z.number()),
});

export const updatePnlLineSchema = insertPnlLineSchema.partial();

// Type exports for Document Intelligence
export type PnlCategory = typeof pnlCategories.$inferSelect;
export type InsertPnlCategory = z.infer<typeof insertPnlCategorySchema>;
export type UpdatePnlCategory = z.infer<typeof updatePnlCategorySchema>;

export type DocIntelUpload = typeof docIntelUploads.$inferSelect;
export type InsertDocIntelUpload = z.infer<typeof insertDocIntelUploadSchema>;
export type UpdateDocIntelUpload = z.infer<typeof updateDocIntelUploadSchema>;

export type DocIntelExtractedItem = typeof docIntelExtractedItems.$inferSelect;
export type InsertDocIntelExtractedItem = z.infer<typeof insertDocIntelExtractedItemSchema>;
export type UpdateDocIntelExtractedItem = z.infer<typeof updateDocIntelExtractedItemSchema>;

export type DocIntelCategoryMapping = typeof docIntelCategoryMappings.$inferSelect;
export type InsertDocIntelCategoryMapping = z.infer<typeof insertDocIntelCategoryMappingSchema>;
export type UpdateDocIntelCategoryMapping = z.infer<typeof updateDocIntelCategoryMappingSchema>;

export type DocIntelLearningRule = typeof docIntelLearningRules.$inferSelect;
export type InsertDocIntelLearningRule = z.infer<typeof insertDocIntelLearningRuleSchema>;
export type UpdateDocIntelLearningRule = z.infer<typeof updateDocIntelLearningRuleSchema>;

export type DocIntelTrainingExample = typeof docIntelTrainingExamples.$inferSelect;
export type InsertDocIntelTrainingExample = z.infer<typeof insertDocIntelTrainingExampleSchema>;

export type PnlLine = typeof pnlLines.$inferSelect;
export type InsertPnlLine = z.infer<typeof insertPnlLineSchema>;
export type UpdatePnlLine = z.infer<typeof updatePnlLineSchema>;

// ============================================================================
// Operations → Modeling Data Pipeline
// Canonical actuals schema for aggregating operations data into modeling
// ============================================================================

// Data source type for tracking where actuals data originated
export const actualsDataSourceEnum = pgEnum("actuals_data_source", [
  "rent_roll",      // From Rent Roll module
  "fuel_sales",     // From Fuel Sales module
  "ship_store",     // From Ship Store module
  "quickbooks",     // From QuickBooks Online sync
  "manual_entry",   // Manually entered by user
  "csv_import",     // Imported from CSV file
  "doc_intel"       // Parsed from Document Intelligence
]);

// Sync status for data pipeline jobs
export const syncStatusEnum = pgEnum("sync_status", [
  "pending",
  "in_progress",
  "completed",
  "failed",
  "partial"
]);

// Modeling Actuals - Canonical store for historical financial data linked to modeling projects
export const modelingActuals = pgTable('modeling_actuals', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Period information
  year: integer('year').notNull(),
  month: integer('month').notNull(), // 1-12

  // Category classification (matches P&L structure)
  category: text('category').notNull(), // 'Revenue', 'COGS', 'Expenses'
  subcategory: text('subcategory').notNull(), // e.g., 'Wet Slips', 'Fuel Sales', 'Payroll'
  department: text('department'), // e.g., 'Storage', 'Fuel', 'Payroll' — persisted from classification
  lineItemDescription: text('line_item_description'),

  // Amounts
  amount: decimal('amount', { precision: 15, scale: 2 }).notNull(),

  // Data source tracking for audit
  dataSource: actualsDataSourceEnum('data_source').notNull(),
  sourceRecordId: varchar('source_record_id'), // ID from source system
  sourceRecordType: text('source_record_type'), // e.g., 'rent_roll_entry', 'fuel_sale', 'ship_store_transaction'

  // Sync metadata
  syncedAt: timestamp('synced_at').defaultNow().notNull(),
  syncJobId: varchar('sync_job_id'),

  // Audit
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('modeling_actuals_org_idx').on(table.orgId),
  projectIdx: index('modeling_actuals_project_idx').on(table.modelingProjectId),
  periodIdx: index('modeling_actuals_period_idx').on(table.year, table.month),
  categoryIdx: index('modeling_actuals_category_idx').on(table.category, table.subcategory),
  dataSourceIdx: index('modeling_actuals_data_source_idx').on(table.dataSource),
  uniqueLineItem: unique('modeling_actuals_unique_line').on(
    table.modelingProjectId, table.year, table.month, table.category, table.subcategory, table.lineItemDescription
  ),
}));

// Financial Period Type - defines the type of financial period
export const financialPeriodTypeEnum = pgEnum("financial_period_type", [
  "calendar_year",    // Full calendar year (2023, 2024, 2025, etc.)
  "t12",              // Trailing 12 months
  "year_1",           // First year of pro forma projection
  "custom"            // User-defined period
]);

// Modeling Financial Periods - Aggregated financial summaries by period for pricing/yield calculations
export const modelingFinancialPeriods = pgTable('modeling_financial_periods', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Period identification
  periodType: financialPeriodTypeEnum('period_type').notNull(),
  periodLabel: text('period_label').notNull(), // Display label: "2024", "T12", "Year 1", etc.
  periodYear: integer('period_year'), // Calendar year if applicable (null for T12, Year 1)
  periodStartDate: date('period_start_date'), // Actual date range for the period
  periodEndDate: date('period_end_date'),
  sortOrder: integer('sort_order').default(0), // For ordering in dropdown

  // Revenue metrics
  totalRevenue: decimal('total_revenue', { precision: 15, scale: 2 }),
  wetSlipRevenue: decimal('wet_slip_revenue', { precision: 15, scale: 2 }),
  dryStorageRevenue: decimal('dry_storage_revenue', { precision: 15, scale: 2 }),
  fuelRevenue: decimal('fuel_revenue', { precision: 15, scale: 2 }),
  shipStoreRevenue: decimal('ship_store_revenue', { precision: 15, scale: 2 }),
  otherRevenue: decimal('other_revenue', { precision: 15, scale: 2 }),

  // Expense metrics
  totalExpenses: decimal('total_expenses', { precision: 15, scale: 2 }),
  operatingExpenses: decimal('operating_expenses', { precision: 15, scale: 2 }),
  payrollExpenses: decimal('payroll_expenses', { precision: 15, scale: 2 }),
  utilitiesExpenses: decimal('utilities_expenses', { precision: 15, scale: 2 }),
  insuranceExpenses: decimal('insurance_expenses', { precision: 15, scale: 2 }),
  maintenanceExpenses: decimal('maintenance_expenses', { precision: 15, scale: 2 }),
  managementFees: decimal('management_fees', { precision: 15, scale: 2 }),
  otherExpenses: decimal('other_expenses', { precision: 15, scale: 2 }),

  // Profitability metrics
  grossProfit: decimal('gross_profit', { precision: 15, scale: 2 }),
  noi: decimal('noi', { precision: 15, scale: 2 }), // Net Operating Income
  ebitda: decimal('ebitda', { precision: 15, scale: 2 }),

  // Pricing inputs for this period
  purchasePrice: decimal('purchase_price', { precision: 15, scale: 2 }),

  // Calculated yields based on period NOI and purchase price
  capRate: decimal('cap_rate', { precision: 5, scale: 4 }), // e.g., 0.0725 = 7.25%
  pricePerUnit: decimal('price_per_unit', { precision: 15, scale: 2 }),
  noiMargin: decimal('noi_margin', { precision: 5, scale: 4 }), // NOI / Total Revenue

  // Occupancy metrics (if applicable)
  occupancyRate: decimal('occupancy_rate', { precision: 5, scale: 4 }),
  totalUnits: integer('total_units'),
  occupiedUnits: integer('occupied_units'),

  // Data quality indicators
  isProjected: boolean('is_projected').default(false), // true for Year 1 or future projections
  dataCompleteness: decimal('data_completeness', { precision: 5, scale: 2 }), // 0-100% completeness score
  lastCalculatedAt: timestamp('last_calculated_at'),

  // Audit fields
  notes: text('notes'),
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('modeling_fin_periods_org_idx').on(table.orgId),
  projectIdx: index('modeling_fin_periods_project_idx').on(table.modelingProjectId),
  periodTypeIdx: index('modeling_fin_periods_type_idx').on(table.periodType),
  periodYearIdx: index('modeling_fin_periods_year_idx').on(table.periodYear),
  sortOrderIdx: index('modeling_fin_periods_sort_idx').on(table.sortOrder),
  uniquePeriod: unique('modeling_fin_periods_unique').on(
    table.modelingProjectId, table.periodType, table.periodLabel
  ),
}));

// Adjustment scope and type enums for normalization
export const adjustmentScopeEnum = pgEnum("adjustment_scope", [
  "line_item",    // Adjustment applies to a specific line item
  "subcategory",  // Adjustment applies to a subcategory/department
  "category"      // Adjustment applies to an entire category (Revenue, COGS, Expenses)
]);

export const adjustmentTypeEnum = pgEnum("adjustment_type", [
  "absolute",     // Add/subtract a fixed dollar amount
  "percentage",   // Adjust by a percentage (e.g., +10% or -5%)
  "replace"       // Replace the original value entirely
]);

// Modeling Period Adjustments - Store normalization adjustments for financial periods
// These adjustments allow users to "normalize" financial data by adjusting unusual items
export const modelingPeriodAdjustments = pgTable('modeling_period_adjustments', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Period this adjustment applies to
  periodLabel: text('period_label').notNull(), // e.g., "2024", "T12", "Year 1"

  // Scope of adjustment
  scope: adjustmentScopeEnum('scope').notNull(),

  // Target identifier based on scope:
  // - line_item: "category|subcategory|lineItemDescription" 
  // - subcategory: "category|subcategory"
  // - category: "category"
  targetIdentifier: text('target_identifier').notNull(),

  // Human-readable label for the target
  targetLabel: text('target_label').notNull(),

  // Adjustment configuration
  adjustmentType: adjustmentTypeEnum('adjustment_type').notNull(),
  adjustmentValue: decimal('adjustment_value', { precision: 15, scale: 2 }).notNull(),

  // Original value before adjustment (for reference/display)
  originalValue: decimal('original_value', { precision: 15, scale: 2 }),

  // Calculated adjusted value
  adjustedValue: decimal('adjusted_value', { precision: 15, scale: 2 }),

  // Reason for the adjustment (required for audit trail)
  reason: text('reason').notNull(),

  // Whether this adjustment is currently active
  isActive: boolean('is_active').default(true).notNull(),

  // Audit fields
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedBy: varchar('updated_by').references(() => users.id),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('period_adj_org_idx').on(table.orgId),
  projectIdx: index('period_adj_project_idx').on(table.modelingProjectId),
  periodIdx: index('period_adj_period_idx').on(table.periodLabel),
  scopeIdx: index('period_adj_scope_idx').on(table.scope),
  activeIdx: index('period_adj_active_idx').on(table.isActive),
  uniqueAdjustment: unique('period_adj_unique').on(
    table.modelingProjectId, table.periodLabel, table.scope, table.targetIdentifier
  ),
}));

// Operations Data Sync Jobs - Track sync operations from Operations modules
export const operationsDataSyncJobs = pgTable('operations_data_sync_jobs', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Job configuration
  syncType: text('sync_type').notNull(), // 'full', 'incremental', 'manual'
  dataSources: text('data_sources').array().notNull(), // ['rent_roll', 'fuel_sales', 'ship_store']
  dateRangeStart: date('date_range_start'),
  dateRangeEnd: date('date_range_end'),

  // Job status
  status: syncStatusEnum('status').notNull().default('pending'),
  startedAt: timestamp('started_at'),
  completedAt: timestamp('completed_at'),

  // Results
  recordsProcessed: integer('records_processed').default(0),
  recordsImported: integer('records_imported').default(0),
  recordsSkipped: integer('records_skipped').default(0),
  recordsFailed: integer('records_failed').default(0),

  // Error tracking
  errorLog: jsonb('error_log').default(sql`'[]'`),

  // Metadata
  triggeredBy: varchar('triggered_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('ops_sync_jobs_org_idx').on(table.orgId),
  projectIdx: index('ops_sync_jobs_project_idx').on(table.modelingProjectId),
  statusIdx: index('ops_sync_jobs_status_idx').on(table.status),
  dateIdx: index('ops_sync_jobs_date_idx').on(table.createdAt),
}));

// Operations Data Mappings - Configure how operations data maps to P&L categories
export const operationsDataMappings = pgTable('operations_data_mappings', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Source configuration
  dataSource: actualsDataSourceEnum('data_source').notNull(),
  sourceField: text('source_field').notNull(), // e.g., 'fuel_type', 'slip_type', 'category_id'
  sourceValue: text('source_value'), // Optional filter value

  // Target P&L mapping
  targetCategory: text('target_category').notNull(), // 'Revenue', 'COGS', 'Expenses'
  targetSubcategory: text('target_subcategory').notNull(), // e.g., 'Fuel Sales', 'Ship Store'
  targetDescription: text('target_description'), // Optional line item description

  // Calculation rules
  amountField: text('amount_field').notNull(), // Which field to use for amount
  aggregationMethod: text('aggregation_method').notNull().default('sum'), // 'sum', 'count', 'average'

  // Status
  isActive: boolean('is_active').notNull().default(true),
  priority: integer('priority').default(0), // For ordering when multiple mappings match

  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('ops_data_mappings_org_idx').on(table.orgId),
  sourceIdx: index('ops_data_mappings_source_idx').on(table.dataSource, table.sourceField),
  activeIdx: index('ops_data_mappings_active_idx').on(table.isActive),
}));

// QuickBooks Integration - OAuth and sync configuration
export const quickbooksIntegrations = pgTable('quickbooks_integrations', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id).unique(),

  // OAuth tokens (encrypted at rest)
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  realmId: text('realm_id'), // QuickBooks company ID
  tokenExpiresAt: timestamp('token_expires_at'),

  // Connection status
  isConnected: boolean('is_connected').notNull().default(false),
  lastSyncAt: timestamp('last_sync_at'),
  syncFrequency: integer('sync_frequency').default(60), // minutes
  autoSyncEnabled: boolean('auto_sync_enabled').default(false),

  // Chart of Accounts mapping
  chartOfAccountsMapping: jsonb('coa_mapping').default(sql`'{}'`), // Maps QB accounts to P&L categories

  // Sync configuration
  syncStartDate: date('sync_start_date'), // How far back to sync
  excludedAccounts: text('excluded_accounts').array().default(sql`'{}'`), // Account IDs to skip

  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('qb_integrations_org_idx').on(table.orgId),
  connectedIdx: index('qb_integrations_connected_idx').on(table.isConnected),
}));

// QuickBooks Sync Logs - Track sync operations with QuickBooks
export const quickbooksSyncLogs = pgTable('quickbooks_sync_logs', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  integrationId: varchar('integration_id').notNull().references(() => quickbooksIntegrations.id, { onDelete: 'cascade' }),
  modelingProjectId: varchar('modeling_project_id').references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Sync details
  syncType: text('sync_type').notNull(), // 'full', 'incremental', 'manual'
  status: syncStatusEnum('status').notNull().default('pending'),

  // Period synced
  periodStart: date('period_start'),
  periodEnd: date('period_end'),

  // Results
  transactionsProcessed: integer('transactions_processed').default(0),
  transactionsImported: integer('transactions_imported').default(0),
  transactionsSkipped: integer('transactions_skipped').default(0),
  transactionsFailed: integer('transactions_failed').default(0),

  // Error tracking
  errorLog: jsonb('error_log').default(sql`'[]'`),

  // Timestamps
  startedAt: timestamp('started_at'),
  completedAt: timestamp('completed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('qb_sync_logs_org_idx').on(table.orgId),
  integrationIdx: index('qb_sync_logs_integration_idx').on(table.integrationId),
  projectIdx: index('qb_sync_logs_project_idx').on(table.modelingProjectId),
  statusIdx: index('qb_sync_logs_status_idx').on(table.status),
  dateIdx: index('qb_sync_logs_date_idx').on(table.createdAt),
}));

// Modeling Scenario Versions - Persist scenarios with version history for PE/Family Office compliance
export const modelingScenarioVersions = pgTable('modeling_scenario_versions', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Scenario identification
  scenarioType: text('scenario_type').notNull(), // 'base', 'aggressive', 'conservative', 'custom'
  name: text('name').notNull(),
  description: text('description'),

  // Version tracking
  version: integer('version').notNull().default(1),
  isCurrentVersion: boolean('is_current_version').notNull().default(true),
  previousVersionId: varchar('previous_version_id').references((): any => modelingScenarioVersions.id),

  // Scenario configuration
  revenueGrowthRate: decimal('revenue_growth_rate', { precision: 5, scale: 2 }),
  expenseGrowthRate: decimal('expense_growth_rate', { precision: 5, scale: 2 }),
  exitCapRate: decimal('exit_cap_rate', { precision: 5, scale: 2 }),

  // Additional assumptions (flexible JSON)
  assumptions: jsonb('assumptions').default(sql`'{}'`), // Stores all granular assumptions

  // Approval workflow
  status: text('status').notNull().default('draft'), // 'draft', 'pending_approval', 'approved', 'rejected'
  approvedBy: varchar('approved_by').references(() => users.id),
  approvedAt: timestamp('approved_at'),
  approvalNotes: text('approval_notes'),

  // Audit trail
  createdBy: varchar('created_by').notNull().references(() => users.id),
  updatedBy: varchar('updated_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('scenario_versions_org_idx').on(table.orgId),
  projectIdx: index('scenario_versions_project_idx').on(table.modelingProjectId),
  typeIdx: index('scenario_versions_type_idx').on(table.scenarioType),
  currentIdx: index('scenario_versions_current_idx').on(table.isCurrentVersion),
  statusIdx: index('scenario_versions_status_idx').on(table.status),
  uniqueCurrentVersion: unique('scenario_versions_unique_current').on(
    table.modelingProjectId, table.scenarioType, table.isCurrentVersion
  ).nullsNotDistinct(),
}));

// Modeling Audit Log - Comprehensive audit trail for compliance
export const modelingAuditLog = pgTable('modeling_audit_log', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Event details
  eventType: text('event_type').notNull(), // 'scenario_created', 'scenario_updated', 'scenario_approved', 'data_synced', 'export_generated', etc.
  entityType: text('entity_type').notNull(), // 'scenario', 'actuals', 'assumption', 'export'
  entityId: varchar('entity_id'),

  // Change tracking
  previousValue: jsonb('previous_value'),
  newValue: jsonb('new_value'),
  changedFields: text('changed_fields').array(),

  // Context
  userId: varchar('user_id').notNull().references(() => users.id),
  userEmail: text('user_email'),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),

  // Timestamp
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('modeling_audit_org_idx').on(table.orgId),
  projectIdx: index('modeling_audit_project_idx').on(table.modelingProjectId),
  eventTypeIdx: index('modeling_audit_event_type_idx').on(table.eventType),
  entityIdx: index('modeling_audit_entity_idx').on(table.entityType, table.entityId),
  userIdx: index('modeling_audit_user_idx').on(table.userId),
  dateIdx: index('modeling_audit_date_idx').on(table.createdAt),
}));

// Modeling Multi-Approver Workflow - IC committee approvals with quorum requirements
export const modelingApprovalRequests = pgTable('modeling_approval_requests', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  scenarioVersionId: varchar('scenario_version_id').notNull().references(() => modelingScenarioVersions.id),

  // Request details
  title: text('title').notNull(),
  description: text('description'),
  requestedBy: varchar('requested_by').notNull().references(() => users.id),
  requestedAt: timestamp('requested_at').defaultNow().notNull(),

  // Workflow configuration
  requiredApprovers: jsonb('required_approvers').notNull(), // Array of user IDs required to approve
  quorumCount: integer('quorum_count').notNull().default(1), // Minimum approvals needed
  deadline: timestamp('deadline'),

  // Status tracking
  status: text('status').notNull().default('pending'), // 'pending', 'approved', 'rejected', 'expired'
  completedAt: timestamp('completed_at'),

  // Audit
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('approval_req_org_idx').on(table.orgId),
  projectIdx: index('approval_req_project_idx').on(table.modelingProjectId),
  scenarioIdx: index('approval_req_scenario_idx').on(table.scenarioVersionId),
  statusIdx: index('approval_req_status_idx').on(table.status),
}));

// Individual approver decisions
export const modelingApproverDecisions = pgTable('modeling_approver_decisions', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  approvalRequestId: varchar('approval_request_id').notNull().references(() => modelingApprovalRequests.id, { onDelete: 'cascade' }),
  approverId: varchar('approver_id').notNull().references(() => users.id),

  // Decision
  decision: text('decision').notNull(), // 'approved', 'rejected', 'pending'
  comments: text('comments'),
  decidedAt: timestamp('decided_at'),

  // Audit
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  requestIdx: index('approver_decision_request_idx').on(table.approvalRequestId),
  approverIdx: index('approver_decision_approver_idx').on(table.approverId),
  uniqueApproverRequest: unique('unique_approver_request').on(table.approvalRequestId, table.approverId),
}));

// Modeling Comment Threads - IC feedback and collaboration on scenarios
export const modelingCommentThreads = pgTable('modeling_comment_threads', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  scenarioVersionId: varchar('scenario_version_id').references(() => modelingScenarioVersions.id),

  // Thread context
  targetType: text('target_type').notNull(), // 'scenario', 'metric', 'assumption', 'line_item'
  targetId: text('target_id'), // ID of the specific element being discussed
  targetLabel: text('target_label'), // Human-readable label (e.g., "Revenue Growth Rate")

  // Thread status
  status: text('status').notNull().default('open'), // 'open', 'resolved', 'archived'
  resolvedBy: varchar('resolved_by').references(() => users.id),
  resolvedAt: timestamp('resolved_at'),

  // Metadata
  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('comment_thread_org_idx').on(table.orgId),
  projectIdx: index('comment_thread_project_idx').on(table.modelingProjectId),
  scenarioIdx: index('comment_thread_scenario_idx').on(table.scenarioVersionId),
  statusIdx: index('comment_thread_status_idx').on(table.status),
}));

// Individual comments within threads
export const modelingComments = pgTable('modeling_comments', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  threadId: varchar('thread_id').notNull().references(() => modelingCommentThreads.id, { onDelete: 'cascade' }),

  // Comment content
  content: text('content').notNull(),

  // Mentions and reactions
  mentions: jsonb('mentions'), // Array of user IDs mentioned

  // Edit tracking
  isEdited: boolean('is_edited').default(false),
  editedAt: timestamp('edited_at'),

  // Metadata
  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  threadIdx: index('comment_thread_id_idx').on(table.threadId),
  createdByIdx: index('comment_created_by_idx').on(table.createdBy),
}));

// Modeling Sensitivity Matrix - Store sensitivity analysis results with scenario versioning
export const modelingSensitivityMatrices = pgTable('modeling_sensitivity_matrices', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  scenarioVersionId: varchar('scenario_version_id').references(() => modelingScenarioVersions.id),

  // Analysis configuration
  analysisType: text('analysis_type').notNull(), // 'exit_cap_vs_growth', 'revenue_vs_expenses', 'irr_sensitivity', 'custom'
  name: text('name'),
  description: text('description'),

  // Variable configuration
  xAxisVariable: text('x_axis_variable').notNull(), // 'exit_cap_rate', 'revenue_growth', etc.
  xAxisMin: numeric('x_axis_min'),
  xAxisMax: numeric('x_axis_max'),
  xAxisStep: numeric('x_axis_step'),

  yAxisVariable: text('y_axis_variable').notNull(),
  yAxisMin: numeric('y_axis_min'),
  yAxisMax: numeric('y_axis_max'),
  yAxisStep: numeric('y_axis_step'),

  // Target metric being analyzed
  targetMetric: text('target_metric').notNull(), // 'irr', 'equity_multiple', 'noi', 'exit_value'

  // Computed matrix data
  matrixData: jsonb('matrix_data').notNull(), // 2D array of computed values
  baselineValue: numeric('baseline_value'),

  // Metadata
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('sensitivity_org_idx').on(table.orgId),
  projectIdx: index('sensitivity_project_idx').on(table.modelingProjectId),
  scenarioIdx: index('sensitivity_scenario_idx').on(table.scenarioVersionId),
  typeIdx: index('sensitivity_type_idx').on(table.analysisType),
}));

// Document Intelligence - AI-powered P&L and Rent Roll parsing
export const documentIntelligenceJobs = pgTable('document_intelligence_jobs', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').references(() => modelingProjects.id),

  documentPath: text('document_path').notNull(),
  documentType: text('document_type').notNull(), // 'p&l', 'rent_roll'
  fileName: text('file_name'),

  status: text('status').notNull().default('pending'), // 'pending', 'processing', 'completed', 'failed'
  itemsExtracted: integer('items_extracted'),
  errorMessage: text('error_message'),

  createdBy: varchar('created_by').notNull().references(() => users.id),
  startedAt: timestamp('started_at'),
  completedAt: timestamp('completed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('doc_intel_job_org_idx').on(table.orgId),
  projectIdx: index('doc_intel_job_project_idx').on(table.modelingProjectId),
  statusIdx: index('doc_intel_job_status_idx').on(table.status),
}));

export const documentIntelligenceResults = pgTable('document_intelligence_results', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  jobId: varchar('job_id').notNull().references(() => documentIntelligenceJobs.id, { onDelete: 'cascade' }),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  resultType: text('result_type').notNull(), // 'p&l', 'rent_roll'
  extractedData: jsonb('extracted_data').notNull(), // Full extraction result
  confidence: numeric('confidence'), // Overall confidence score 0-1

  reviewStatus: text('review_status').notNull().default('pending'), // 'pending', 'approved', 'rejected'
  reviewedBy: varchar('reviewed_by').references(() => users.id),
  reviewedAt: timestamp('reviewed_at'),
  modifications: jsonb('modifications'), // User modifications before approval

  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  jobIdx: index('doc_intel_result_job_idx').on(table.jobId),
  orgIdx: index('doc_intel_result_org_idx').on(table.orgId),
  statusIdx: index('doc_intel_result_status_idx').on(table.reviewStatus),
}));

// Insert schemas for new tables
export const insertModelingActualsSchema = createInsertSchema(modelingActuals).omit({
  id: true,
  syncedAt: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOperationsDataSyncJobSchema = createInsertSchema(operationsDataSyncJobs).omit({
  id: true,
  createdAt: true,
});

export const insertOperationsDataMappingSchema = createInsertSchema(operationsDataMappings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertQuickbooksIntegrationSchema = createInsertSchema(quickbooksIntegrations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertQuickbooksSyncLogSchema = createInsertSchema(quickbooksSyncLogs).omit({
  id: true,
  createdAt: true,
});

export const insertModelingScenarioVersionSchema = createInsertSchema(modelingScenarioVersions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertModelingAuditLogSchema = createInsertSchema(modelingAuditLog).omit({
  id: true,
  createdAt: true,
});

export const insertModelingSensitivityMatrixSchema = createInsertSchema(modelingSensitivityMatrices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertModelingApprovalRequestSchema = createInsertSchema(modelingApprovalRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  requestedAt: true,
});

export const insertModelingApproverDecisionSchema = createInsertSchema(modelingApproverDecisions).omit({
  id: true,
  createdAt: true,
});

export const insertModelingCommentThreadSchema = createInsertSchema(modelingCommentThreads).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertModelingCommentSchema = createInsertSchema(modelingComments).omit({
  id: true,
  createdAt: true,
});

export const insertDocumentIntelligenceJobSchema = createInsertSchema(documentIntelligenceJobs).omit({
  id: true,
  createdAt: true,
});

export const insertDocumentIntelligenceResultSchema = createInsertSchema(documentIntelligenceResults).omit({
  id: true,
  createdAt: true,
});

// Type exports for Operations → Modeling pipeline
export type ModelingActuals = typeof modelingActuals.$inferSelect;
export type InsertModelingActuals = z.infer<typeof insertModelingActualsSchema>;

export type OperationsDataSyncJob = typeof operationsDataSyncJobs.$inferSelect;
export type InsertOperationsDataSyncJob = z.infer<typeof insertOperationsDataSyncJobSchema>;

export type OperationsDataMapping = typeof operationsDataMappings.$inferSelect;
export type InsertOperationsDataMapping = z.infer<typeof insertOperationsDataMappingSchema>;

export type QuickbooksIntegration = typeof quickbooksIntegrations.$inferSelect;
export type InsertQuickbooksIntegration = z.infer<typeof insertQuickbooksIntegrationSchema>;

export type QuickbooksSyncLog = typeof quickbooksSyncLogs.$inferSelect;
export type InsertQuickbooksSyncLog = z.infer<typeof insertQuickbooksSyncLogSchema>;

export type ModelingScenarioVersion = typeof modelingScenarioVersions.$inferSelect;
export type InsertModelingScenarioVersion = z.infer<typeof insertModelingScenarioVersionSchema>;

export type ModelingAuditLog = typeof modelingAuditLog.$inferSelect;
export type InsertModelingAuditLog = z.infer<typeof insertModelingAuditLogSchema>;

export type ModelingSensitivityMatrix = typeof modelingSensitivityMatrices.$inferSelect;
export type InsertModelingSensitivityMatrix = z.infer<typeof insertModelingSensitivityMatrixSchema>;

export type ModelingApprovalRequest = typeof modelingApprovalRequests.$inferSelect;
export type InsertModelingApprovalRequest = z.infer<typeof insertModelingApprovalRequestSchema>;

export type ModelingApproverDecision = typeof modelingApproverDecisions.$inferSelect;
export type InsertModelingApproverDecision = z.infer<typeof insertModelingApproverDecisionSchema>;

export type ModelingCommentThread = typeof modelingCommentThreads.$inferSelect;
export type InsertModelingCommentThread = z.infer<typeof insertModelingCommentThreadSchema>;

export type ModelingComment = typeof modelingComments.$inferSelect;
export type InsertModelingComment = z.infer<typeof insertModelingCommentSchema>;

export type DocumentIntelligenceJob = typeof documentIntelligenceJobs.$inferSelect;
export type InsertDocumentIntelligenceJob = z.infer<typeof insertDocumentIntelligenceJobSchema>;

export type DocumentIntelligenceResult = typeof documentIntelligenceResults.$inferSelect;
export type InsertDocumentIntelligenceResult = z.infer<typeof insertDocumentIntelligenceResultSchema>;

// ============================================================================
// Demographics & Market Intelligence Schema
// ============================================================================

// FRED API data cache - stores economic indicators by region
export const demographicsCache = pgTable('demographics_cache', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Geographic identifiers
  stateCode: varchar('state_code', { length: 2 }).notNull(),
  region: varchar('region', { length: 50 }),
  county: varchar('county', { length: 100 }),

  // FRED API data series
  seriesId: varchar('series_id', { length: 50 }).notNull(), // e.g., 'FLFLFN', 'MEHOINUSFLA'
  seriesName: varchar('series_name', { length: 200 }).notNull(),
  category: varchar('category', { length: 50 }).notNull(), // 'population', 'income', 'employment', 'housing'

  // Data values (array of historical data points)
  dataPoints: jsonb('data_points').notNull().default(sql`'[]'`), // [{date, value}, ...]
  latestValue: numeric('latest_value'),
  latestDate: date('latest_date'),

  // Computed metrics
  yoyChange: numeric('yoy_change'), // Year-over-year change
  fiveYearCagr: numeric('five_year_cagr'), // 5-year compound annual growth rate

  // Cache management
  fetchedAt: timestamp('fetched_at').notNull().defaultNow(),
  expiresAt: timestamp('expires_at').notNull(),

  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('demographics_cache_org_idx').on(table.orgId),
  stateIdx: index('demographics_cache_state_idx').on(table.stateCode),
  seriesIdx: index('demographics_cache_series_idx').on(table.seriesId),
  categoryIdx: index('demographics_cache_category_idx').on(table.category),
  uniqueEntry: unique('demographics_cache_unique').on(table.orgId, table.stateCode, table.seriesId),
}));

// Regional market statistics - aggregated from sales comps
export const regionalMarketStats = pgTable('regional_market_stats', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Geographic identifiers
  stateCode: varchar('state_code', { length: 2 }).notNull(),
  region: varchar('region', { length: 50 }),

  // Marina supply metrics
  totalMarinas: integer('total_marinas').notNull().default(0),
  totalWetSlips: integer('total_wet_slips').notNull().default(0),
  totalDryRacks: integer('total_dry_racks').notNull().default(0),

  // Transaction metrics
  transactionCount: integer('transaction_count').notNull().default(0),
  avgSalePrice: numeric('avg_sale_price'),
  medianSalePrice: numeric('median_sale_price'),
  avgPricePerSlip: numeric('avg_price_per_slip'),
  medianPricePerSlip: numeric('median_price_per_slip'),
  avgCapRate: numeric('avg_cap_rate'),
  medianCapRate: numeric('median_cap_rate'),

  // Time-based trends (last 5 years)
  priceGrowth1Yr: numeric('price_growth_1yr'),
  priceGrowth3Yr: numeric('price_growth_3yr'),
  priceGrowth5Yr: numeric('price_growth_5yr'),

  // Detailed time series
  yearlyStats: jsonb('yearly_stats').notNull().default(sql`'[]'`), // [{year, txCount, avgPrice, avgPPS}, ...]

  // Computation metadata
  computedAt: timestamp('computed_at').notNull().defaultNow(),
  dataAsOf: date('data_as_of'), // Latest transaction date included

  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('regional_market_stats_org_idx').on(table.orgId),
  stateIdx: index('regional_market_stats_state_idx').on(table.stateCode),
  regionIdx: index('regional_market_stats_region_idx').on(table.region),
  uniqueEntry: unique('regional_market_stats_unique').on(table.orgId, table.stateCode, table.region),
}));

// Insert schemas for demographics tables
export const insertDemographicsCacheSchema = createInsertSchema(demographicsCache).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRegionalMarketStatsSchema = createInsertSchema(regionalMarketStats).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Type exports for demographics
export type DemographicsCache = typeof demographicsCache.$inferSelect;
export type InsertDemographicsCache = z.infer<typeof insertDemographicsCacheSchema>;

export type RegionalMarketStats = typeof regionalMarketStats.$inferSelect;
export type InsertRegionalMarketStats = z.infer<typeof insertRegionalMarketStatsSchema>;

// Location-based demographic summary from Census API
export interface DemographicSummary {
  // Core Demographics
  totalPopulation: number;
  totalMales?: number;
  totalFemales?: number;
  medianAge: number;
  medianAgeMale?: number;
  medianAgeFemale?: number;

  // Age Analytics
  ageDistribution?: Record<string, number>;
  ageByGender?: Record<string, any>;
  generationalCohorts?: Record<string, number>;

  // Income Analytics
  medianHouseholdIncome: number;
  meanHouseholdIncome?: number;
  perCapitaIncome?: number;
  medianFamilyIncome?: number;
  incomeDistribution?: Record<string, number>;

  // Education Analytics
  educationLevels?: Record<string, number>;

  // Employment Analytics
  employmentStats?: Record<string, number>;
  industryDistribution?: Record<string, number>;

  // Housing Analytics
  housingStats?: Record<string, number>;
  householdSize?: number;
  medianHomeValue?: number;

  // Race & Ethnicity
  raceEthnicity?: Record<string, number>;

  // Geographic
  populationDensity?: number;
  geographicLevel?: string;
  fipsState?: string;
  fipsCounty?: string;
  fipsTract?: string;
}

// Location demographics cache - stores Census API responses
export const locationDemographicsCache = pgTable('location_demographics_cache', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Geographic identifiers
  latitude: real('latitude').notNull(),
  longitude: real('longitude').notNull(),
  address: text('address'),
  city: varchar('city', { length: 100 }),
  stateCode: varchar('state_code', { length: 2 }),
  zipCode: varchar('zip_code', { length: 10 }),

  // Census geography identifiers
  fipsState: varchar('fips_state', { length: 2 }),
  fipsCounty: varchar('fips_county', { length: 3 }),
  fipsTract: varchar('fips_tract', { length: 6 }),
  geographicLevel: varchar('geographic_level', { length: 20 }),

  // Trade area configuration
  radiusMiles: real('radius_miles'), // null = point location

  // Demographic data (full Census response)
  demographicData: jsonb('demographic_data').notNull(),

  // Cache management
  fetchedAt: timestamp('fetched_at').notNull().defaultNow(),
  expiresAt: timestamp('expires_at').notNull(),

  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('loc_demo_cache_org_idx').on(table.orgId),
  coordsIdx: index('loc_demo_cache_coords_idx').on(table.latitude, table.longitude),
  stateIdx: index('loc_demo_cache_state_idx').on(table.stateCode),
  uniqueLocation: unique('loc_demo_cache_unique').on(table.orgId, table.latitude, table.longitude, table.radiusMiles),
}));

export const insertLocationDemographicsCacheSchema = createInsertSchema(locationDemographicsCache).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type LocationDemographicsCache = typeof locationDemographicsCache.$inferSelect;
export type InsertLocationDemographicsCache = z.infer<typeof insertLocationDemographicsCacheSchema>;

// Demographic Project Locations - stores location configurations per modeling project
export const demographicProjectLocations = pgTable('demographic_project_locations', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Location data
  address: text('address').notNull(),
  latitude: real('latitude').notNull(),
  longitude: real('longitude').notNull(),
  label: varchar('label', { length: 100 }),

  // Trade area configuration
  analysisMode: varchar('analysis_mode', { length: 20 }).notNull().default('distance'), // 'distance' | 'drivetime'
  distanceRings: jsonb('distance_rings').notNull().default(sql`'[1]'::jsonb`), // Array of miles: [1, 3, 5, 10]
  driveTimes: jsonb('drive_times').notNull().default(sql`'[]'::jsonb`), // Array of minutes: [5, 10, 15, 20]

  // Display order
  sortOrder: integer('sort_order').default(0),

  // Metadata
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('demo_proj_loc_org_idx').on(table.orgId),
  projectIdx: index('demo_proj_loc_project_idx').on(table.modelingProjectId),
  uniqueLocation: unique('demo_proj_loc_unique').on(table.modelingProjectId, table.latitude, table.longitude),
}));

export const insertDemographicProjectLocationSchema = createInsertSchema(demographicProjectLocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type DemographicProjectLocation = typeof demographicProjectLocations.$inferSelect;
export type InsertDemographicProjectLocation = z.infer<typeof insertDemographicProjectLocationSchema>;

// ============================================================================
// Background Jobs - Job Queue for Heavy Analytics and Processing Tasks
// ============================================================================
export const backgroundJobs = pgTable('background_jobs', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),

  type: varchar('type', { length: 50 }).notNull(),
  status: varchar('status', { length: 20 }).notNull().default('pending'),
  priority: integer('priority').notNull().default(2),

  payload: jsonb('payload').notNull().default(sql`'{}'`),
  result: jsonb('result'),
  error: text('error'),

  orgId: varchar('org_id').references(() => organizations.id),
  userId: varchar('user_id').references(() => users.id),

  scheduledFor: timestamp('scheduled_for').notNull().defaultNow(),
  startedAt: timestamp('started_at'),
  completedAt: timestamp('completed_at'),

  maxRetries: integer('max_retries').notNull().default(3),
  retryCount: integer('retry_count').notNull().default(0),

  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  typeIdx: index('bg_jobs_type_idx').on(table.type),
  statusIdx: index('bg_jobs_status_idx').on(table.status),
  priorityIdx: index('bg_jobs_priority_idx').on(table.priority),
  orgIdx: index('bg_jobs_org_idx').on(table.orgId),
  scheduledIdx: index('bg_jobs_scheduled_idx').on(table.scheduledFor),
  statusScheduledIdx: index('bg_jobs_status_scheduled_idx').on(table.status, table.scheduledFor),
}));

export const insertBackgroundJobSchema = createInsertSchema(backgroundJobs).omit({
  createdAt: true,
  updatedAt: true,
});

export type BackgroundJob = typeof backgroundJobs.$inferSelect;
export type InsertBackgroundJob = z.infer<typeof insertBackgroundJobSchema>;

// ============================================================================
// CROSS-MODULE INTEGRATION LAYER
// Enables full connectivity between CRM, Sales Comps, Rate Comps, DD, VDR, and Modeling
// ============================================================================

// Deal-to-Sales Comps Junction - Many-to-many for comparable analysis
export const dealSalesComps = pgTable('deal_sales_comps', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  dealId: varchar('deal_id').notNull().references(() => crmDeals.id, { onDelete: 'cascade' }),
  salesCompId: varchar('sales_comp_id').notNull().references(() => salesComps.id, { onDelete: 'cascade' }),

  // Comparison metadata
  relevanceScore: integer('relevance_score'), // 0-100 relevance scoring
  isPrimary: boolean('is_primary').default(false), // Primary comparable
  notes: text('notes'),
  comparisonType: varchar('comparison_type', { length: 50 }).default('similar'), // similar, aspirational, market_floor, market_ceiling

  // Auto-calculated similarity metrics
  distanceMiles: real('distance_miles'), // Geographic distance
  priceDifferencePercent: real('price_difference_percent'),
  sizeDifferencePercent: real('size_difference_percent'),

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('deal_sales_comps_org_idx').on(table.orgId),
  dealIdx: index('deal_sales_comps_deal_idx').on(table.dealId),
  compIdx: index('deal_sales_comps_comp_idx').on(table.salesCompId),
  uniqueDealComp: unique('deal_sales_comps_unique').on(table.dealId, table.salesCompId),
}));

export const insertDealSalesCompSchema = createInsertSchema(dealSalesComps).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type DealSalesComp = typeof dealSalesComps.$inferSelect;
export type InsertDealSalesComp = z.infer<typeof insertDealSalesCompSchema>;

// Deal-to-Rate Comps Junction - Many-to-many for rate benchmarking
export const dealRateComps = pgTable('deal_rate_comps', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  dealId: varchar('deal_id').notNull().references(() => crmDeals.id, { onDelete: 'cascade' }),
  rateCompId: varchar('rate_comp_id').notNull().references(() => rateComps.id, { onDelete: 'cascade' }),

  // Comparison metadata
  relevanceScore: integer('relevance_score'), // 0-100 relevance scoring
  isPrimary: boolean('is_primary').default(false),
  notes: text('notes'),
  comparisonType: varchar('comparison_type', { length: 50 }).default('benchmark'), // benchmark, premium, discount, market_rate

  // Rate comparison metrics
  rateVariancePercent: real('rate_variance_percent'),
  occupancyComparison: real('occupancy_comparison'),

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('deal_rate_comps_org_idx').on(table.orgId),
  dealIdx: index('deal_rate_comps_deal_idx').on(table.dealId),
  compIdx: index('deal_rate_comps_comp_idx').on(table.rateCompId),
  uniqueDealComp: unique('deal_rate_comps_unique').on(table.dealId, table.rateCompId),
}));

export const insertDealRateCompSchema = createInsertSchema(dealRateComps).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type DealRateComp = typeof dealRateComps.$inferSelect;
export type InsertDealRateComp = z.infer<typeof insertDealRateCompSchema>;

// Deal-to-VDR Links - Connect CRM deals directly to VDR folders
export const dealVdrLinks = pgTable('deal_vdr_links', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  dealId: varchar('deal_id').notNull().references(() => crmDeals.id, { onDelete: 'cascade' }),
  vdrFolderId: varchar('vdr_folder_id').notNull().references(() => vdrFolders.id, { onDelete: 'cascade' }),

  // Link metadata
  linkType: varchar('link_type', { length: 50 }).notNull().default('deal_room'), // deal_room, due_diligence, closing, archive
  isActive: boolean('is_active').notNull().default(true),

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('deal_vdr_links_org_idx').on(table.orgId),
  dealIdx: index('deal_vdr_links_deal_idx').on(table.dealId),
  vdrIdx: index('deal_vdr_links_vdr_idx').on(table.vdrFolderId),
  uniqueDealVdr: unique('deal_vdr_links_unique').on(table.dealId, table.vdrFolderId),
}));

export const insertDealVdrLinkSchema = createInsertSchema(dealVdrLinks).omit({
  id: true,
  createdAt: true,
});

export type DealVdrLink = typeof dealVdrLinks.$inferSelect;
export type InsertDealVdrLink = z.infer<typeof insertDealVdrLinkSchema>;

// CRM Deal to DD Project Conversion Tracking
export const dealDdConversions = pgTable('deal_dd_conversions', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  dealId: varchar('deal_id').notNull().references(() => crmDeals.id),
  ddProjectId: varchar('dd_project_id').notNull().references(() => projects.id),

  // Conversion metadata
  conversionType: varchar('conversion_type', { length: 50 }).notNull().default('manual'), // manual, automated, api
  conversionStatus: varchar('conversion_status', { length: 50 }).notNull().default('completed'), // pending, completed, failed, rolled_back

  // What was migrated
  contactsMigrated: integer('contacts_migrated').default(0),
  documentsMigrated: integer('documents_migrated').default(0),
  taskTemplateUsed: varchar('task_template_used'),

  // VDR auto-creation
  vdrFolderCreated: boolean('vdr_folder_created').default(false),
  vdrFolderId: varchar('vdr_folder_id').references(() => vdrFolders.id),
  vdrTemplateUsed: varchar('vdr_template_used'),

  // Audit trail
  convertedBy: varchar('converted_by').notNull().references(() => users.id),
  convertedAt: timestamp('converted_at').notNull().defaultNow(),
  rollbackAt: timestamp('rollback_at'),
  rollbackBy: varchar('rollback_by').references(() => users.id),
  rollbackReason: text('rollback_reason'),

  notes: text('notes'),
  metadata: jsonb('metadata').default(sql`'{}'`),
}, (table) => ({
  orgIdx: index('deal_dd_conversions_org_idx').on(table.orgId),
  dealIdx: index('deal_dd_conversions_deal_idx').on(table.dealId),
  projectIdx: index('deal_dd_conversions_project_idx').on(table.ddProjectId),
  statusIdx: index('deal_dd_conversions_status_idx').on(table.conversionStatus),
  uniqueConversion: unique('deal_dd_conversions_unique').on(table.dealId, table.ddProjectId),
}));

export const insertDealDdConversionSchema = createInsertSchema(dealDdConversions).omit({
  id: true,
  convertedAt: true,
});

export type DealDdConversion = typeof dealDdConversions.$inferSelect;
export type InsertDealDdConversion = z.infer<typeof insertDealDdConversionSchema>;

// Property-to-Sales Comps Junction - Link CRM properties to sales comps
export const propertySalesComps = pgTable('property_sales_comps', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull().references(() => crmProperties.id, { onDelete: 'cascade' }),
  salesCompId: varchar('sales_comp_id').notNull().references(() => salesComps.id, { onDelete: 'cascade' }),

  // Comparison metadata
  relevanceScore: integer('relevance_score'),
  isPrimary: boolean('is_primary').default(false),
  notes: text('notes'),

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('property_sales_comps_org_idx').on(table.orgId),
  propertyIdx: index('property_sales_comps_property_idx').on(table.propertyId),
  compIdx: index('property_sales_comps_comp_idx').on(table.salesCompId),
  uniquePropertyComp: unique('property_sales_comps_unique').on(table.propertyId, table.salesCompId),
}));

export const insertPropertySalesCompSchema = createInsertSchema(propertySalesComps).omit({
  id: true,
  createdAt: true,
});

export type PropertySalesComp = typeof propertySalesComps.$inferSelect;
export type InsertPropertySalesComp = z.infer<typeof insertPropertySalesCompSchema>;

// Property-to-Rate Comps Junction
export const propertyRateComps = pgTable('property_rate_comps', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull().references(() => crmProperties.id, { onDelete: 'cascade' }),
  rateCompId: varchar('rate_comp_id').notNull().references(() => rateComps.id, { onDelete: 'cascade' }),

  // Comparison metadata
  relevanceScore: integer('relevance_score'),
  isPrimary: boolean('is_primary').default(false),
  notes: text('notes'),

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('property_rate_comps_org_idx').on(table.orgId),
  propertyIdx: index('property_rate_comps_property_idx').on(table.propertyId),
  compIdx: index('property_rate_comps_comp_idx').on(table.rateCompId),
  uniquePropertyComp: unique('property_rate_comps_unique').on(table.propertyId, table.rateCompId),
}));

export const insertPropertyRateCompSchema = createInsertSchema(propertyRateComps).omit({
  id: true,
  createdAt: true,
});

export type PropertyRateComp = typeof propertyRateComps.$inferSelect;
export type InsertPropertyRateComp = z.infer<typeof insertPropertyRateCompSchema>;

// Modeling Project to Comps Integration - Track multiple comps per modeling project
export const modelingProjectComps = pgTable('modeling_project_comps', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Can reference either sales comp or rate comp
  salesCompId: varchar('sales_comp_id').references(() => salesComps.id, { onDelete: 'cascade' }),
  rateCompId: varchar('rate_comp_id').references(() => rateComps.id, { onDelete: 'cascade' }),

  // Comparison metadata
  compType: varchar('comp_type', { length: 20 }).notNull(), // 'sales' or 'rate'
  relevanceScore: integer('relevance_score'),
  isPrimary: boolean('is_primary').default(false),
  usedInValuation: boolean('used_in_valuation').default(false), // Whether used in cap rate or valuation calc
  weight: real('weight').default(1.0), // Weighting for blended analysis
  notes: text('notes'),

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('modeling_project_comps_org_idx').on(table.orgId),
  projectIdx: index('modeling_project_comps_project_idx').on(table.modelingProjectId),
  salesCompIdx: index('modeling_project_comps_sales_idx').on(table.salesCompId),
  rateCompIdx: index('modeling_project_comps_rate_idx').on(table.rateCompId),
}));

export const insertModelingProjectCompSchema = createInsertSchema(modelingProjectComps).omit({
  id: true,
  createdAt: true,
});

export type ModelingProjectComp = typeof modelingProjectComps.$inferSelect;
export type InsertModelingProjectComp = z.infer<typeof insertModelingProjectCompSchema>;

// Modeling Financial Periods - Schema and Types
export const insertModelingFinancialPeriodSchema = createInsertSchema(modelingFinancialPeriods).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateModelingFinancialPeriodSchema = insertModelingFinancialPeriodSchema.partial();

export type ModelingFinancialPeriod = typeof modelingFinancialPeriods.$inferSelect;
export type InsertModelingFinancialPeriod = z.infer<typeof insertModelingFinancialPeriodSchema>;
export type UpdateModelingFinancialPeriod = z.infer<typeof updateModelingFinancialPeriodSchema>;

// Modeling Period Adjustments - Schema and Types
export const insertModelingPeriodAdjustmentSchema = createInsertSchema(modelingPeriodAdjustments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const updateModelingPeriodAdjustmentSchema = insertModelingPeriodAdjustmentSchema.partial();

export type ModelingPeriodAdjustment = typeof modelingPeriodAdjustments.$inferSelect;
export type InsertModelingPeriodAdjustment = z.infer<typeof insertModelingPeriodAdjustmentSchema>;
export type UpdateModelingPeriodAdjustment = z.infer<typeof updateModelingPeriodAdjustmentSchema>;

// Cross-Module Audit Trail - Track all cross-module operations
export const crossModuleAuditLog = pgTable('cross_module_audit_log', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  userId: varchar('user_id').notNull().references(() => users.id),

  // Source and target modules
  sourceModule: varchar('source_module', { length: 50 }).notNull(), // crm, sales_comps, rate_comps, dd, vdr, modeling
  targetModule: varchar('target_module', { length: 50 }).notNull(),

  // Entity references
  sourceEntityType: varchar('source_entity_type', { length: 50 }).notNull(), // deal, property, project, folder, etc.
  sourceEntityId: varchar('source_entity_id').notNull(),
  targetEntityType: varchar('target_entity_type', { length: 50 }).notNull(),
  targetEntityId: varchar('target_entity_id').notNull(),

  // Action details
  action: varchar('action', { length: 50 }).notNull(), // link, unlink, convert, sync, import, export
  actionStatus: varchar('action_status', { length: 20 }).notNull().default('completed'), // pending, completed, failed

  // Context
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  metadata: jsonb('metadata').default(sql`'{}'`),
  errorMessage: text('error_message'),

  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('cross_module_audit_org_idx').on(table.orgId),
  userIdx: index('cross_module_audit_user_idx').on(table.userId),
  sourceIdx: index('cross_module_audit_source_idx').on(table.sourceModule, table.sourceEntityType, table.sourceEntityId),
  targetIdx: index('cross_module_audit_target_idx').on(table.targetModule, table.targetEntityType, table.targetEntityId),
  createdIdx: index('cross_module_audit_created_idx').on(table.createdAt),
}));

export const insertCrossModuleAuditLogSchema = createInsertSchema(crossModuleAuditLog).omit({
  id: true,
  createdAt: true,
});

export type CrossModuleAuditLog = typeof crossModuleAuditLog.$inferSelect;
export type InsertCrossModuleAuditLog = z.infer<typeof insertCrossModuleAuditLogSchema>;

// ============================================================================
// Target Demographics - User-defined demographic criteria for site suitability scoring
// ============================================================================
export const targetDemographics = pgTable('target_demographics', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  userId: varchar('user_id').notNull().references(() => users.id),

  // Optional project-specific override (null = organization-wide default)
  projectId: varchar('project_id').references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Target ranges for demographic criteria (null = not considered in scoring)
  medianAgeMin: real('median_age_min'),
  medianAgeMax: real('median_age_max'),
  medianIncomeMin: real('median_income_min'),
  medianIncomeMax: real('median_income_max'),
  populationDensityMin: real('population_density_min'),
  populationDensityMax: real('population_density_max'),
  householdSizeMin: real('household_size_min'),
  householdSizeMax: real('household_size_max'),
  educationBachelorsMin: real('education_bachelors_min'), // Percentage with Bachelor's+
  educationBachelorsMax: real('education_bachelors_max'),
  employmentRateMin: real('employment_rate_min'),
  employmentRateMax: real('employment_rate_max'),
  homeValueMin: real('home_value_min'),
  homeValueMax: real('home_value_max'),

  // Criterion weights (0-1 scale, null = equal weighting)
  weights: jsonb('weights').default(sql`'{}'`),

  // Metadata
  name: varchar('name', { length: 100 }), // Optional name for this target profile
  description: text('description'),
  isDefault: boolean('is_default').default(false), // Whether this is the user's default profile

  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('target_demographics_org_idx').on(table.orgId),
  userIdx: index('target_demographics_user_idx').on(table.userId),
  projectIdx: index('target_demographics_project_idx').on(table.projectId),
  defaultIdx: index('target_demographics_default_idx').on(table.orgId, table.userId, table.isDefault),
}));

export const insertTargetDemographicsSchema = createInsertSchema(targetDemographics).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type TargetDemographics = typeof targetDemographics.$inferSelect;
export type InsertTargetDemographics = z.infer<typeof insertTargetDemographicsSchema>;

// ============================================================================
// PE FUND MANAGEMENT
// Fund lifecycle tracking with committed capital, allocations, investor accounts,
// cash flow ledger, waterfall distributions, and fund-level IRR/TVPI calculations
// ============================================================================

export const fundStatusEnum = pgEnum("fund_status", ["raising", "investing", "harvesting", "closed", "liquidated"]);
export const fundInvestorTypeEnum = pgEnum("fund_investor_type", ["gp", "lp", "co_invest", "feeder", "fund_of_funds", "anchor"]);
export const capitalMovementTypeEnum = pgEnum("capital_movement_type", ["call", "contribution", "distribution", "recycling", "return_of_capital", "fee", "expense"]);
export const waterfallStyleEnum = pgEnum("waterfall_style", ["european", "american", "deal_by_deal"]);

// Funds - Master fund entity for PE/real estate funds
export const funds = pgTable('funds', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Fund identity
  name: text('name').notNull(),
  shortName: varchar('short_name', { length: 50 }),
  description: text('description'),
  fundNumber: integer('fund_number'), // e.g., "Fund III"
  status: fundStatusEnum('status').notNull().default('raising'),

  // Fund sizing
  targetSize: decimal('target_size', { precision: 18, scale: 2 }),
  hardCap: decimal('hard_cap', { precision: 18, scale: 2 }),
  committedCapital: decimal('committed_capital', { precision: 18, scale: 2 }).default('0'),
  calledCapital: decimal('called_capital', { precision: 18, scale: 2 }).default('0'),
  distributedCapital: decimal('distributed_capital', { precision: 18, scale: 2 }).default('0'),
  recycledCapital: decimal('recycled_capital', { precision: 18, scale: 2 }).default('0'),

  // Fund timeline
  vintage: integer('vintage').notNull(), // Year of first close
  firstCloseDate: timestamp('first_close_date'),
  finalCloseDate: timestamp('final_close_date'),
  investmentPeriodYears: integer('investment_period_years').default(4),
  fundLifeYears: integer('fund_life_years').default(10),
  extensionYears: integer('extension_years').default(2),

  // Fees
  managementFeePct: decimal('management_fee_pct', { precision: 6, scale: 4 }).default('0.02'),
  managementFeeBase: text('management_fee_base').default('committed'), // 'committed', 'called', 'invested', 'nav'
  carriedInterestPct: decimal('carried_interest_pct', { precision: 6, scale: 4 }).default('0.20'),

  // Waterfall configuration (fund-level defaults)
  waterfallStyle: waterfallStyleEnum('waterfall_style').default('european'),
  preferredReturn: decimal('preferred_return', { precision: 8, scale: 4 }).default('0.08'),
  gpCatchUpPct: decimal('gp_catch_up_pct', { precision: 6, scale: 4 }).default('1.00'), // 100% catch-up until GP at promote %

  // Multi-tier promote structure (fund-level)
  promoteTiers: jsonb('promote_tiers').$type<{
    irrHurdle: number;
    gpSplit: number;
    lpSplit: number;
  }[]>().default([
    { irrHurdle: 0.08, gpSplit: 0.20, lpSplit: 0.80 },
    { irrHurdle: 0.12, gpSplit: 0.25, lpSplit: 0.75 },
    { irrHurdle: 0.18, gpSplit: 0.30, lpSplit: 0.70 },
  ]),

  // Recycling provisions
  recyclingAllowed: boolean('recycling_allowed').default(true),
  recyclingLimitPct: decimal('recycling_limit_pct', { precision: 6, scale: 4 }).default('0.25'), // % of committed
  recyclingPeriodMonths: integer('recycling_period_months').default(48),

  // Investment guidelines
  maxSingleInvestmentPct: decimal('max_single_investment_pct', { precision: 6, scale: 4 }).default('0.20'),
  minInvestmentSize: decimal('min_investment_size', { precision: 18, scale: 2 }),
  maxInvestmentSize: decimal('max_investment_size', { precision: 18, scale: 2 }),
  geographicFocus: text('geographic_focus'),
  sectorFocus: text('sector_focus'),

  // Performance metrics (denormalized for dashboard)
  grossIrr: decimal('gross_irr', { precision: 8, scale: 4 }),
  netIrr: decimal('net_irr', { precision: 8, scale: 4 }),
  grossMoic: decimal('gross_moic', { precision: 8, scale: 4 }),
  netMoic: decimal('net_moic', { precision: 8, scale: 4 }),
  tvpi: decimal('tvpi', { precision: 8, scale: 4 }), // Total Value to Paid-In
  dpi: decimal('dpi', { precision: 8, scale: 4 }), // Distributions to Paid-In
  rvpi: decimal('rvpi', { precision: 8, scale: 4 }), // Residual Value to Paid-In
  pme: decimal('pme', { precision: 8, scale: 4 }), // Public Market Equivalent

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('funds_org_idx').on(table.orgId),
  statusIdx: index('funds_status_idx').on(table.status),
  vintageIdx: index('funds_vintage_idx').on(table.vintage),
}));

// Fund Investors - LP/GP commitments and capital accounts
export const fundInvestors = pgTable('fund_investors', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  fundId: varchar('fund_id').notNull().references(() => funds.id, { onDelete: 'cascade' }),

  // Investor identity
  investorName: text('investor_name').notNull(),
  investorType: fundInvestorTypeEnum('investor_type').notNull(),
  legalEntityName: text('legal_entity_name'),
  taxId: varchar('tax_id', { length: 50 }),

  // CRM integration
  crmContactId: varchar('crm_contact_id').references(() => crmContacts.id),
  crmCompanyId: varchar('crm_company_id').references(() => crmCompanies.id),

  // Commitment
  commitmentAmount: decimal('commitment_amount', { precision: 18, scale: 2 }).notNull(),
  commitmentDate: timestamp('commitment_date'),
  commitmentPct: decimal('commitment_pct', { precision: 8, scale: 6 }), // % of total fund

  // Capital account (running balances)
  calledCapital: decimal('called_capital', { precision: 18, scale: 2 }).default('0'),
  unfundedCommitment: decimal('unfunded_commitment', { precision: 18, scale: 2 }),
  distributedCapital: decimal('distributed_capital', { precision: 18, scale: 2 }).default('0'),
  returnedCapital: decimal('return_of_capital', { precision: 18, scale: 2 }).default('0'),
  preferredReturnAccrued: decimal('preferred_return_accrued', { precision: 18, scale: 2 }).default('0'),
  preferredReturnPaid: decimal('preferred_return_paid', { precision: 18, scale: 2 }).default('0'),
  capitalAccountBalance: decimal('capital_account_balance', { precision: 18, scale: 2 }).default('0'),

  // Carried interest (for GPs)
  carriedInterestPct: decimal('carried_interest_pct', { precision: 8, scale: 4 }),
  carriedInterestEarned: decimal('carried_interest_earned', { precision: 18, scale: 2 }).default('0'),
  carriedInterestPaid: decimal('carried_interest_paid', { precision: 18, scale: 2 }).default('0'),

  // Side letter terms
  hasReducedFees: boolean('has_reduced_fees').default(false),
  feeDiscount: decimal('fee_discount', { precision: 6, scale: 4 }),
  hasMfn: boolean('has_mfn').default(false), // Most Favored Nation
  coInvestRights: text('co_invest_rights'), // 'pro_rata', 'negotiated', 'none'

  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('fund_investors_org_idx').on(table.orgId),
  fundIdx: index('fund_investors_fund_idx').on(table.fundId),
  typeIdx: index('fund_investors_type_idx').on(table.investorType),
}));

// Fund Deal Allocations - Link funds to modeling projects
export const fundDealAllocations = pgTable('fund_deal_allocations', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  fundId: varchar('fund_id').notNull().references(() => funds.id, { onDelete: 'cascade' }),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  // Allocation details
  allocationPct: decimal('allocation_pct', { precision: 8, scale: 6 }).notNull(), // Fund's share of deal
  allocatedEquity: decimal('allocated_equity', { precision: 18, scale: 2 }).notNull(),
  fundedAmount: decimal('funded_amount', { precision: 18, scale: 2 }).default('0'),

  // Basis tracking
  costBasis: decimal('cost_basis', { precision: 18, scale: 2 }),
  currentValue: decimal('current_value', { precision: 18, scale: 2 }),
  unrealizedGain: decimal('unrealized_gain', { precision: 18, scale: 2 }),
  realizedGain: decimal('realized_gain', { precision: 18, scale: 2 }).default('0'),

  // Deal-level returns
  dealIrr: decimal('deal_irr', { precision: 8, scale: 4 }),
  dealMoic: decimal('deal_moic', { precision: 8, scale: 4 }),

  // Timing
  investmentDate: timestamp('investment_date'),
  expectedExitDate: timestamp('expected_exit_date'),
  actualExitDate: timestamp('actual_exit_date'),
  exitStatus: varchar('exit_status', { length: 20 }).default('active'), // active, exited, written_off

  // Capital stack inheritance
  usesFundCapitalStack: boolean('uses_fund_capital_stack').default(true),
  capitalStackTemplateId: varchar('capital_stack_template_id').references(() => fundCapitalStackTemplates.id),

  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('fund_deal_allocations_org_idx').on(table.orgId),
  fundIdx: index('fund_deal_allocations_fund_idx').on(table.fundId),
  projectIdx: index('fund_deal_allocations_project_idx').on(table.modelingProjectId),
  uniqueFundProject: unique('fund_deal_allocations_unique').on(table.fundId, table.modelingProjectId),
}));

// Fund Capital Movements - Cash flow ledger for calls, contributions, distributions
export const fundCapitalMovements = pgTable('fund_capital_movements', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  fundId: varchar('fund_id').notNull().references(() => funds.id, { onDelete: 'cascade' }),
  fundInvestorId: varchar('fund_investor_id').references(() => fundInvestors.id, { onDelete: 'cascade' }),

  // Movement details
  movementType: capitalMovementTypeEnum('movement_type').notNull(),
  movementDate: timestamp('movement_date').notNull(),
  dueDate: timestamp('due_date'),

  // Amounts
  amount: decimal('amount', { precision: 18, scale: 2 }).notNull(),
  preferredReturn: decimal('preferred_return', { precision: 18, scale: 2 }).default('0'),
  returnOfCapital: decimal('return_of_capital', { precision: 18, scale: 2 }).default('0'),
  carriedInterest: decimal('carried_interest', { precision: 18, scale: 2 }).default('0'),

  // Deal attribution
  dealAllocationId: varchar('deal_allocation_id').references(() => fundDealAllocations.id),

  // Recycling tracking
  isRecyclable: boolean('is_recyclable').default(false),
  recycledAmount: decimal('recycled_amount', { precision: 18, scale: 2 }).default('0'),

  // Call specifics
  callNumber: integer('call_number'),
  callPurpose: text('call_purpose'), // 'investment', 'fees', 'expenses'

  // Status
  status: varchar('status', { length: 20 }).default('pending'), // pending, completed, cancelled

  description: text('description'),
  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('fund_capital_movements_org_idx').on(table.orgId),
  fundIdx: index('fund_capital_movements_fund_idx').on(table.fundId),
  investorIdx: index('fund_capital_movements_investor_idx').on(table.fundInvestorId),
  dateIdx: index('fund_capital_movements_date_idx').on(table.movementDate),
  typeIdx: index('fund_capital_movements_type_idx').on(table.movementType),
}));

// Fund Cash Flows - Consolidated dated cash flows for IRR calculation
export const fundCashFlows = pgTable('fund_cash_flows', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  fundId: varchar('fund_id').notNull().references(() => funds.id, { onDelete: 'cascade' }),

  // Cash flow details
  flowDate: timestamp('flow_date').notNull(),
  flowType: varchar('flow_type', { length: 20 }).notNull(), // 'inflow' or 'outflow'

  // Amounts (negative = outflow from investor, positive = inflow to investor)
  grossAmount: decimal('gross_amount', { precision: 18, scale: 2 }).notNull(),
  netAmount: decimal('net_amount', { precision: 18, scale: 2 }).notNull(),

  // Breakdowns
  investmentAmount: decimal('investment_amount', { precision: 18, scale: 2 }).default('0'),
  managementFees: decimal('management_fees', { precision: 18, scale: 2 }).default('0'),
  expenses: decimal('expenses', { precision: 18, scale: 2 }).default('0'),
  preferredReturn: decimal('preferred_return', { precision: 18, scale: 2 }).default('0'),
  returnOfCapital: decimal('return_of_capital', { precision: 18, scale: 2 }).default('0'),
  gainDistribution: decimal('gain_distribution', { precision: 18, scale: 2 }).default('0'),
  carriedInterest: decimal('carried_interest', { precision: 18, scale: 2 }).default('0'),

  // Running balances (for performance calculation)
  cumulativeContributions: decimal('cumulative_contributions', { precision: 18, scale: 2 }),
  cumulativeDistributions: decimal('cumulative_distributions', { precision: 18, scale: 2 }),
  runningNav: decimal('running_nav', { precision: 18, scale: 2 }),

  // Attribution
  dealAllocationId: varchar('deal_allocation_id').references(() => fundDealAllocations.id),
  capitalMovementId: varchar('capital_movement_id').references(() => fundCapitalMovements.id),

  description: text('description'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('fund_cash_flows_org_idx').on(table.orgId),
  fundIdx: index('fund_cash_flows_fund_idx').on(table.fundId),
  dateIdx: index('fund_cash_flows_date_idx').on(table.flowDate),
}));

// Fund Capital Stack Templates - Reusable capital structure for deals
export const fundCapitalStackTemplates = pgTable('fund_capital_stack_templates', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  fundId: varchar('fund_id').references(() => funds.id, { onDelete: 'cascade' }),

  name: text('name').notNull(),
  description: text('description'),
  isDefault: boolean('is_default').default(false),

  // Default leverage assumptions
  targetLtv: decimal('target_ltv', { precision: 6, scale: 4 }).default('0.65'),

  // Debt template
  debtTemplates: jsonb('debt_templates').$type<{
    name: string;
    trancheType: string;
    interestRate: number;
    termYears: number;
    amortizationYears: number | null;
    interestOnlyMonths: number;
    principalPct: number; // % of total debt
    priority: number;
  }[]>(),

  // Equity template
  equityTemplates: jsonb('equity_templates').$type<{
    name: string;
    layerType: string;
    investorType: string;
    ownershipPct: number;
    preferredReturn: number | null;
    preferredReturnType: string | null;
    isParticipating: boolean;
    waterfallPriority: number;
    promoteTiers?: { irrHurdle: number; gpSplit: number; lpSplit: number }[];
  }[]>(),

  // Waterfall configuration
  waterfallStyle: waterfallStyleEnum('waterfall_style').default('european'),
  preferredReturn: decimal('preferred_return', { precision: 8, scale: 4 }).default('0.08'),
  gpCatchUpPct: decimal('gp_catch_up_pct', { precision: 6, scale: 4 }).default('1.00'),
  promoteTiers: jsonb('promote_tiers').$type<{
    irrHurdle: number;
    gpSplit: number;
    lpSplit: number;
  }[]>(),

  createdBy: varchar('created_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('fund_capital_stack_templates_org_idx').on(table.orgId),
  fundIdx: index('fund_capital_stack_templates_fund_idx').on(table.fundId),
}));

// Fund Waterfall Calculations - Stored waterfall tier calculations
export const fundWaterfallCalculations = pgTable('fund_waterfall_calculations', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  fundId: varchar('fund_id').notNull().references(() => funds.id, { onDelete: 'cascade' }),

  calculationDate: timestamp('calculation_date').notNull(),
  periodEnd: timestamp('period_end'),

  // Total values
  totalContributions: decimal('total_contributions', { precision: 18, scale: 2 }),
  totalDistributions: decimal('total_distributions', { precision: 18, scale: 2 }),
  unrealizedValue: decimal('unrealized_value', { precision: 18, scale: 2 }),
  totalValue: decimal('total_value', { precision: 18, scale: 2 }),

  // Waterfall tiers
  returnOfCapital: decimal('return_of_capital', { precision: 18, scale: 2 }),
  preferredReturnAmount: decimal('preferred_return_amount', { precision: 18, scale: 2 }),
  gpCatchUp: decimal('gp_catch_up', { precision: 18, scale: 2 }),

  // Promote tier breakdown
  promoteTierBreakdown: jsonb('promote_tier_breakdown').$type<{
    tier: number;
    irrHurdle: number;
    lpAmount: number;
    gpAmount: number;
  }[]>(),

  // LP/GP split
  totalLpDistribution: decimal('total_lp_distribution', { precision: 18, scale: 2 }),
  totalGpDistribution: decimal('total_gp_distribution', { precision: 18, scale: 2 }),

  // Performance metrics
  grossIrr: decimal('gross_irr', { precision: 8, scale: 4 }),
  netIrr: decimal('net_irr', { precision: 8, scale: 4 }),
  tvpi: decimal('tvpi', { precision: 8, scale: 4 }),
  dpi: decimal('dpi', { precision: 8, scale: 4 }),
  rvpi: decimal('rvpi', { precision: 8, scale: 4 }),

  isLatest: boolean('is_latest').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('fund_waterfall_calculations_org_idx').on(table.orgId),
  fundIdx: index('fund_waterfall_calculations_fund_idx').on(table.fundId),
  dateIdx: index('fund_waterfall_calculations_date_idx').on(table.calculationDate),
  latestIdx: index('fund_waterfall_calculations_latest_idx').on(table.fundId, table.isLatest),
}));

// Insert schemas and types for Fund Management
export const insertFundSchema = createInsertSchema(funds).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateFundSchema = insertFundSchema.partial();
export type Fund = typeof funds.$inferSelect;
export type InsertFund = z.infer<typeof insertFundSchema>;
export type UpdateFund = z.infer<typeof updateFundSchema>;

export const insertFundInvestorSchema = createInsertSchema(fundInvestors).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateFundInvestorSchema = insertFundInvestorSchema.partial();
export type FundInvestor = typeof fundInvestors.$inferSelect;
export type InsertFundInvestor = z.infer<typeof insertFundInvestorSchema>;
export type UpdateFundInvestor = z.infer<typeof updateFundInvestorSchema>;

export const insertFundDealAllocationSchema = createInsertSchema(fundDealAllocations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateFundDealAllocationSchema = insertFundDealAllocationSchema.partial();
export type FundDealAllocation = typeof fundDealAllocations.$inferSelect;
export type InsertFundDealAllocation = z.infer<typeof insertFundDealAllocationSchema>;
export type UpdateFundDealAllocation = z.infer<typeof updateFundDealAllocationSchema>;

export const insertFundCapitalMovementSchema = createInsertSchema(fundCapitalMovements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateFundCapitalMovementSchema = insertFundCapitalMovementSchema.partial();
export type FundCapitalMovement = typeof fundCapitalMovements.$inferSelect;
export type InsertFundCapitalMovement = z.infer<typeof insertFundCapitalMovementSchema>;
export type UpdateFundCapitalMovement = z.infer<typeof updateFundCapitalMovementSchema>;

export const insertFundCashFlowSchema = createInsertSchema(fundCashFlows).omit({
  id: true,
  createdAt: true,
});
export type FundCashFlow = typeof fundCashFlows.$inferSelect;
export type InsertFundCashFlow = z.infer<typeof insertFundCashFlowSchema>;

export const insertFundCapitalStackTemplateSchema = createInsertSchema(fundCapitalStackTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateFundCapitalStackTemplateSchema = insertFundCapitalStackTemplateSchema.partial();
export type FundCapitalStackTemplate = typeof fundCapitalStackTemplates.$inferSelect;
export type InsertFundCapitalStackTemplate = z.infer<typeof insertFundCapitalStackTemplateSchema>;
export type UpdateFundCapitalStackTemplate = z.infer<typeof updateFundCapitalStackTemplateSchema>;

export const insertFundWaterfallCalculationSchema = createInsertSchema(fundWaterfallCalculations).omit({
  id: true,
  createdAt: true,
});
export type FundWaterfallCalculation = typeof fundWaterfallCalculations.$inferSelect;
export type InsertFundWaterfallCalculation = z.infer<typeof insertFundWaterfallCalculationSchema>;

// ============================================================================
// MarinaMatch - Deal Sourcing & Prospecting Module
// ============================================================================

// Enums for MarinaMatch
export const dealSourceTypeEnum = pgEnum("deal_source_type", ["broker", "marketplace", "direct", "referral", "owned_network", "web_scrape", "cold_outreach"]);
export const feedStatusEnum = pgEnum("feed_status", ["active", "paused", "error", "pending_setup"]);
export const mandateStatusEnum = pgEnum("mandate_status", ["active", "paused", "archived"]);
export const sourcedDealStatusEnum = pgEnum("sourced_deal_status", ["new", "reviewing", "qualified", "disqualified", "converted", "duplicate"]);
export const brokerTierEnum = pgEnum("broker_tier", ["platinum", "gold", "silver", "bronze", "new"]);
export const marinaTypeEnum = pgEnum("marina_type", ["wet_slips", "dry_storage", "full_service", "yacht_club", "boatyard", "mixed_use", "commercial"]);

// Deal Sources - External feed configurations (brokers, marketplaces, etc.)
export const dealSources = pgTable("deal_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  sourceType: dealSourceTypeEnum("source_type").notNull(),
  // Feed configuration
  feedUrl: text("feed_url"), // RSS/API endpoint
  apiKey: text("api_key"), // Encrypted API key if needed
  feedFormat: text("feed_format").default("rss"), // rss, json, xml
  // Broker/source info
  brokerCompany: text("broker_company"),
  brokerContact: text("broker_contact"),
  brokerEmail: text("broker_email"),
  brokerPhone: text("broker_phone"),
  // Status & sync
  status: feedStatusEnum("status").notNull().default("pending_setup"),
  lastSyncAt: timestamp("last_sync_at"),
  lastSyncStatus: text("last_sync_status"),
  syncErrorCount: integer("sync_error_count").default(0),
  // Settings
  autoImport: boolean("auto_import").notNull().default(false),
  dedupeEnabled: boolean("dedupe_enabled").notNull().default(true),
  minDealSize: decimal("min_deal_size", { precision: 18, scale: 2 }),
  maxDealSize: decimal("max_deal_size", { precision: 18, scale: 2 }),
  targetRegions: text("target_regions").array(),
  // Metrics
  totalDealsImported: integer("total_deals_imported").default(0),
  totalDealsConverted: integer("total_deals_converted").default(0),
  // Metadata
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("deal_sources_org_idx").on(table.orgId),
  statusIdx: index("deal_sources_status_idx").on(table.status),
}));

// Investment Mandates - Define investment thesis/criteria
export const investmentMandates = pgTable("investment_mandates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  description: text("description"),
  status: mandateStatusEnum("status").notNull().default("active"),
  // Deal size criteria
  minDealSize: decimal("min_deal_size", { precision: 18, scale: 2 }),
  maxDealSize: decimal("max_deal_size", { precision: 18, scale: 2 }),
  // Geographic criteria
  targetStates: text("target_states").array(),
  targetRegions: text("target_regions").array(), // e.g., "Gulf Coast", "Great Lakes"
  coastalPreference: text("coastal_preference"), // "ocean", "lake", "river", "any"
  // Marina type criteria
  targetMarinaTypes: text("target_marina_types").array(),
  // Operational criteria
  minSlipCount: integer("min_slip_count"),
  maxSlipCount: integer("max_slip_count"),
  minOccupancy: decimal("min_occupancy", { precision: 5, scale: 2 }),
  minRevenue: decimal("min_revenue", { precision: 18, scale: 2 }),
  minNoi: decimal("min_noi", { precision: 18, scale: 2 }),
  // Cap rate / valuation criteria
  minCapRate: decimal("min_cap_rate", { precision: 5, scale: 2 }),
  maxCapRate: decimal("max_cap_rate", { precision: 5, scale: 2 }),
  // Required amenities/features
  requiredAmenities: text("required_amenities").array(),
  excludedAttributes: text("excluded_attributes").array(), // Things to avoid
  // Priority & scoring weights
  priority: integer("priority").default(1), // 1 = highest
  sizeWeight: integer("size_weight").default(20), // % weight for scoring
  locationWeight: integer("location_weight").default(25),
  typeWeight: integer("type_weight").default(15),
  operationsWeight: integer("operations_weight").default(25),
  valuationWeight: integer("valuation_weight").default(15),
  // Fund association (optional)
  fundId: varchar("fund_id").references(() => funds.id),
  // Metadata
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("investment_mandates_org_idx").on(table.orgId),
  statusIdx: index("investment_mandates_status_idx").on(table.status),
  fundIdx: index("investment_mandates_fund_idx").on(table.fundId),
}));

// Broker Relationships - Track broker contacts and performance
export const brokerRelationships = pgTable("broker_relationships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  // Broker info
  companyName: text("company_name").notNull(),
  primaryContactName: text("primary_contact_name"),
  primaryContactEmail: text("primary_contact_email"),
  primaryContactPhone: text("primary_contact_phone"),
  website: text("website"),
  // Classification
  tier: brokerTierEnum("tier").notNull().default("new"),
  specializations: text("specializations").array(), // e.g., "marinas", "yacht clubs", "commercial"
  regions: text("regions").array(), // Geographic coverage
  // Relationship details
  relationshipStartDate: date("relationship_start_date"),
  lastContactDate: date("last_contact_date"),
  preferredContactMethod: text("preferred_contact_method").default("email"),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }), // Standard rate
  // Performance metrics
  totalDealsSubmitted: integer("total_deals_submitted").default(0),
  totalDealsConverted: integer("total_deals_converted").default(0),
  totalDealValue: decimal("total_deal_value", { precision: 18, scale: 2 }).default("0"),
  avgDealQuality: decimal("avg_deal_quality", { precision: 5, scale: 2 }), // 0-100 score
  // Notes & tracking
  notes: text("notes"),
  isActive: boolean("is_active").notNull().default(true),
  // Link to CRM contact if exists (stored as integer, FK added at DB level)
  crmContactId: integer("crm_contact_id"),
  // Broker Portal - shareable link for external deal submissions
  shareToken: varchar("share_token", { length: 64 }).unique(),
  portalEnabled: boolean("portal_enabled").notNull().default(false),
  portalLastAccessedAt: timestamp("portal_last_accessed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("broker_relationships_org_idx").on(table.orgId),
  tierIdx: index("broker_relationships_tier_idx").on(table.tier),
  activeIdx: index("broker_relationships_active_idx").on(table.isActive),
  shareTokenIdx: index("broker_relationships_share_token_idx").on(table.shareToken),
}));

// Sourced Deals - Incoming deals from feeds before conversion to CRM
export const sourcedDeals = pgTable("sourced_deals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  // Source tracking
  dealSourceId: varchar("deal_source_id").references(() => dealSources.id),
  brokerId: varchar("broker_id").references(() => brokerRelationships.id),
  externalId: text("external_id"), // ID from source system
  sourceUrl: text("source_url"), // Original listing URL
  // Status
  status: sourcedDealStatusEnum("status").notNull().default("new"),
  // Basic deal info
  propertyName: text("property_name").notNull(),
  propertyAddress: text("property_address"),
  city: text("city"),
  state: text("state"),
  zipCode: text("zip_code"),
  latitude: decimal("latitude", { precision: 10, scale: 6 }),
  longitude: decimal("longitude", { precision: 10, scale: 6 }),
  // Marina details
  marinaType: marinaTypeEnum("marina_type"),
  totalSlips: integer("total_slips"),
  wetSlips: integer("wet_slips"),
  dryStorage: integer("dry_storage"),
  // Financial info
  askingPrice: decimal("asking_price", { precision: 18, scale: 2 }),
  grossRevenue: decimal("gross_revenue", { precision: 18, scale: 2 }),
  noi: decimal("noi", { precision: 18, scale: 2 }),
  capRate: decimal("cap_rate", { precision: 5, scale: 2 }),
  pricePerSlip: decimal("price_per_slip", { precision: 18, scale: 2 }),
  // Amenities & features
  amenities: text("amenities").array(),
  description: text("description"),
  // Mandate matching
  mandateScores: jsonb("mandate_scores").$type<{
    mandateId: string;
    mandateName: string;
    score: number;
    breakdown: {
      size: number;
      location: number;
      type: number;
      operations: number;
      valuation: number;
    };
  }[]>(),
  bestMandateScore: decimal("best_mandate_score", { precision: 5, scale: 2 }),
  bestMandateId: varchar("best_mandate_id"),
  // Deduplication
  dedupeHash: text("dedupe_hash"), // Hash for detecting duplicates
  isDuplicate: boolean("is_duplicate").default(false),
  duplicateOfId: varchar("duplicate_of_id"),
  // Conversion tracking (stored as integer for legacy compatibility)
  convertedToDealId: integer("converted_to_deal_id"),
  convertedAt: timestamp("converted_at"),
  convertedBy: varchar("converted_by").references(() => users.id),
  // Review tracking
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  disqualificationReason: text("disqualification_reason"),
  // Metadata
  rawData: jsonb("raw_data"), // Original data from source
  isManual: boolean("is_manual").default(false), // True if submitted via broker/manual entry
  portalSubmissionId: varchar("portal_submission_id"), // Links to broker portal submission if applicable
  importedAt: timestamp("imported_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("sourced_deals_org_idx").on(table.orgId),
  sourceIdx: index("sourced_deals_source_idx").on(table.dealSourceId),
  statusIdx: index("sourced_deals_status_idx").on(table.status),
  brokerIdx: index("sourced_deals_broker_idx").on(table.brokerId),
  mandateScoreIdx: index("sourced_deals_mandate_score_idx").on(table.bestMandateScore),
  dedupeIdx: index("sourced_deals_dedupe_idx").on(table.dedupeHash),
  stateIdx: index("sourced_deals_state_idx").on(table.state),
}));

// Deal Attribution - Track how CRM deals were sourced
export const dealAttributions = pgTable("deal_attributions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  dealId: integer("deal_id").notNull(),
  // Attribution details
  sourceType: dealSourceTypeEnum("source_type").notNull(),
  dealSourceId: varchar("deal_source_id").references(() => dealSources.id),
  brokerId: varchar("broker_id").references(() => brokerRelationships.id),
  sourcedDealId: varchar("sourced_deal_id").references(() => sourcedDeals.id),
  // For referrals
  referredBy: text("referred_by"),
  referralContact: text("referral_contact"),
  // For direct/cold outreach
  outreachCampaignId: varchar("outreach_campaign_id"),
  initialContactDate: date("initial_contact_date"),
  // Commission tracking
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }),
  commissionAmount: decimal("commission_amount", { precision: 18, scale: 2 }),
  commissionPaid: boolean("commission_paid").default(false),
  commissionPaidDate: date("commission_paid_date"),
  // Notes
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("deal_attributions_org_idx").on(table.orgId),
  dealIdx: index("deal_attributions_deal_idx").on(table.dealId),
  sourceTypeIdx: index("deal_attributions_source_type_idx").on(table.sourceType),
  brokerIdx: index("deal_attributions_broker_idx").on(table.brokerId),
}));

// Broker Activity Log - Track interactions with brokers
export const brokerActivityLog = pgTable("broker_activity_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  brokerId: varchar("broker_id").notNull().references(() => brokerRelationships.id),
  // Activity details
  activityType: text("activity_type").notNull(), // "call", "email", "meeting", "deal_submitted", etc.
  activityDate: timestamp("activity_date").notNull().defaultNow(),
  subject: text("subject"),
  description: text("description"),
  // Associated deal if any
  sourcedDealId: varchar("sourced_deal_id").references(() => sourcedDeals.id),
  dealId: integer("deal_id").references(() => crmDeals.id),
  // User tracking
  performedBy: varchar("performed_by").references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("broker_activity_log_org_idx").on(table.orgId),
  brokerIdx: index("broker_activity_log_broker_idx").on(table.brokerId),
  dateIdx: index("broker_activity_log_date_idx").on(table.activityDate),
}));

// Broker Portal Submissions - Audit trail for external broker submissions
export const brokerPortalSubmissionStatusEnum = pgEnum("broker_portal_submission_status", ["pending", "approved", "rejected", "duplicate"]);
export const brokerPortalSubmissions = pgTable("broker_portal_submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  brokerId: varchar("broker_id").notNull().references(() => brokerRelationships.id),
  submissionToken: varchar("submission_token", { length: 64 }).notNull().unique(),
  status: brokerPortalSubmissionStatusEnum("status").notNull().default("pending"),
  // Submitted property data (before promotion to sourcedDeals)
  propertyName: text("property_name").notNull(),
  propertyAddress: text("property_address"),
  city: text("city"),
  state: text("state"),
  askingPrice: decimal("asking_price", { precision: 18, scale: 2 }),
  totalSlips: integer("total_slips"),
  grossRevenue: decimal("gross_revenue", { precision: 18, scale: 2 }),
  description: text("description"),
  contactName: text("contact_name"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  additionalNotes: text("additional_notes"),
  // Raw submission payload for audit
  rawPayload: jsonb("raw_payload"),
  // Review tracking
  reviewedBy: varchar("reviewed_by").references(() => users.id),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  // Links to promoted deal if approved
  promotedToSourcedDealId: varchar("promoted_to_sourced_deal_id").references(() => sourcedDeals.id),
  // Metadata
  submitterIp: text("submitter_ip"),
  submitterUserAgent: text("submitter_user_agent"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("broker_portal_submissions_org_idx").on(table.orgId),
  brokerIdx: index("broker_portal_submissions_broker_idx").on(table.brokerId),
  statusIdx: index("broker_portal_submissions_status_idx").on(table.status),
  tokenIdx: index("broker_portal_submissions_token_idx").on(table.submissionToken),
}));

// Insert schemas and types for MarinaMatch
export const insertDealSourceSchema = createInsertSchema(dealSources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateDealSourceSchema = insertDealSourceSchema.partial();
export type DealSource = typeof dealSources.$inferSelect;
export type InsertDealSource = z.infer<typeof insertDealSourceSchema>;
export type UpdateDealSource = z.infer<typeof updateDealSourceSchema>;

export const insertInvestmentMandateSchema = createInsertSchema(investmentMandates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateInvestmentMandateSchema = insertInvestmentMandateSchema.partial();
export type InvestmentMandate = typeof investmentMandates.$inferSelect;
export type InsertInvestmentMandate = z.infer<typeof insertInvestmentMandateSchema>;
export type UpdateInvestmentMandate = z.infer<typeof updateInvestmentMandateSchema>;

export const mandateCriteria = pgTable("mandate_criteria", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  mandateId: varchar("mandate_id").notNull().references(() => investmentMandates.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  criteriaType: varchar("criteria_type", { length: 50 }).notNull(),
  criteriaKey: varchar("criteria_key", { length: 100 }).notNull(),
  operator: varchar("operator", { length: 20 }).notNull().default("equals"),
  criteriaValue: text("criteria_value").notNull(),
  weight: integer("weight").default(10),
  isRequired: boolean("is_required").default(false),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  mandateIdx: index("mandate_criteria_mandate_idx").on(table.mandateId),
  orgIdx: index("mandate_criteria_org_idx").on(table.orgId),
}));

export const insertMandateCriteriaSchema = createInsertSchema(mandateCriteria).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMandateCriteriaSchema = insertMandateCriteriaSchema.partial();
export type MandateCriteria = typeof mandateCriteria.$inferSelect;
export type InsertMandateCriteria = z.infer<typeof insertMandateCriteriaSchema>;
export type UpdateMandateCriteria = z.infer<typeof updateMandateCriteriaSchema>;

export const insertBrokerRelationshipSchema = createInsertSchema(brokerRelationships).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateBrokerRelationshipSchema = insertBrokerRelationshipSchema.partial();
export type BrokerRelationship = typeof brokerRelationships.$inferSelect;
export type InsertBrokerRelationship = z.infer<typeof insertBrokerRelationshipSchema>;
export type UpdateBrokerRelationship = z.infer<typeof updateBrokerRelationshipSchema>;

export const insertSourcedDealSchema = createInsertSchema(sourcedDeals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  importedAt: true,
});
export const updateSourcedDealSchema = insertSourcedDealSchema.partial();
export type SourcedDeal = typeof sourcedDeals.$inferSelect;
export type InsertSourcedDeal = z.infer<typeof insertSourcedDealSchema>;
export type UpdateSourcedDeal = z.infer<typeof updateSourcedDealSchema>;

export const insertDealAttributionSchema = createInsertSchema(dealAttributions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateDealAttributionSchema = insertDealAttributionSchema.partial();
export type DealAttribution = typeof dealAttributions.$inferSelect;
export type InsertDealAttribution = z.infer<typeof insertDealAttributionSchema>;
export type UpdateDealAttribution = z.infer<typeof updateDealAttributionSchema>;

export const insertBrokerActivityLogSchema = createInsertSchema(brokerActivityLog).omit({
  id: true,
  createdAt: true,
});
export type BrokerActivityLog = typeof brokerActivityLog.$inferSelect;
export type InsertBrokerActivityLog = z.infer<typeof insertBrokerActivityLogSchema>;

export const insertBrokerPortalSubmissionSchema = createInsertSchema(brokerPortalSubmissions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateBrokerPortalSubmissionSchema = insertBrokerPortalSubmissionSchema.partial();
export type BrokerPortalSubmission = typeof brokerPortalSubmissions.$inferSelect;
export type InsertBrokerPortalSubmission = z.infer<typeof insertBrokerPortalSubmissionSchema>;
export type UpdateBrokerPortalSubmission = z.infer<typeof updateBrokerPortalSubmissionSchema>;

// ============================================================================
// MarinaMatch Intel - Scraped Listings & Investment Criteria
// ============================================================================

export const marinaListings = pgTable("marina_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  scope: varchar("scope", { length: 20 }).default("org").notNull(),
  requiredPack: varchar("required_pack", { length: 50 }),
  isCurated: boolean("is_curated").default(false),
  curatedByUserId: varchar("curated_by_user_id"),
  curatedAt: timestamp("curated_at"),
  sourcePlatform: varchar("source_platform", { length: 100 }).notNull(),
  sourceUrl: text("source_url").notNull(),
  sourceListingId: varchar("source_listing_id"),
  scrapeRunId: varchar("scrape_run_id"),
  dedupeHash: varchar("dedupe_hash", { length: 64 }).notNull(),
  title: text("title").notNull(),
  propertyName: text("property_name"),
  propertyAddress: text("property_address"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  zipCode: varchar("zip_code", { length: 20 }),
  region: varchar("region", { length: 100 }),
  latitude: numeric("latitude", { precision: 10, scale: 7 }),
  longitude: numeric("longitude", { precision: 10, scale: 7 }),
  marinaType: varchar("marina_type", { length: 50 }),
  propertyType: varchar("property_type", { length: 50 }),
  dealType: varchar("deal_type", { length: 50 }),
  totalSlips: integer("total_slips"),
  wetSlips: integer("wet_slips"),
  dryStorageSpaces: integer("dry_storage_spaces"),
  acreage: numeric("acreage", { precision: 10, scale: 2 }),
  waterFrontage: numeric("water_frontage", { precision: 10, scale: 2 }),
  hasFuel: boolean("has_fuel").default(false),
  hasShipStore: boolean("has_ship_store").default(false),
  hasRestaurant: boolean("has_restaurant").default(false),
  hasRepairShop: boolean("has_repair_shop").default(false),
  hasDryStorage: boolean("has_dry_storage").default(false),
  hasBoatRamp: boolean("has_boat_ramp").default(false),
  amenities: jsonb("amenities"),
  askingPrice: numeric("asking_price", { precision: 15, scale: 2 }),
  pricePerSlip: numeric("price_per_slip", { precision: 12, scale: 2 }),
  grossRevenue: numeric("gross_revenue", { precision: 15, scale: 2 }),
  noi: numeric("noi", { precision: 15, scale: 2 }),
  ebitda: numeric("ebitda", { precision: 15, scale: 2 }),
  capRate: numeric("cap_rate", { precision: 5, scale: 2 }),
  occupancyRate: numeric("occupancy_rate", { precision: 5, scale: 2 }),
  status: varchar("status", { length: 30 }).default("active"),
  isFeatured: boolean("is_featured").default(false),
  isReviewed: boolean("is_reviewed").default(false),
  reviewedBy: varchar("reviewed_by"),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  bestCriteriaId: varchar("best_criteria_id"),
  bestMatchScore: integer("best_match_score"),
  matchScores: jsonb("match_scores"),
  brokerName: text("broker_name"),
  brokerCompany: text("broker_company"),
  brokerPhone: varchar("broker_phone", { length: 50 }),
  brokerEmail: varchar("broker_email", { length: 255 }),
  attributionText: text("attribution_text"),
  originalDescription: text("original_description"),
  heroImageUrl: text("hero_image_url"),
  images: jsonb("images"),
  services: text("services").array(),
  tenantSummary: text("tenant_summary"),
  extractionConfidence: integer("extraction_confidence"),
  listingDate: timestamp("listing_date"),
  lastScrapedAt: timestamp("last_scraped_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("marina_listings_org_idx").on(table.orgId),
  sourceIdx: index("marina_listings_source_idx").on(table.sourcePlatform),
  statusIdx: index("marina_listings_status_idx").on(table.status),
  stateIdx: index("marina_listings_state_idx").on(table.state),
  dedupeHashIdx: uniqueIndex("marina_listings_dedupe_hash_idx").on(table.dedupeHash),
}));

export const investmentCriteriaProfiles = pgTable("investment_criteria_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  name: varchar("name", { length: 255 }).notNull().default("Default Investment Criteria"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  isDefault: boolean("is_default").default(false),
  minMatchScoreAlert: integer("min_match_score_alert").default(70),
  locationWeight: integer("location_weight").default(20),
  financialWeight: integer("financial_weight").default(25),
  operationalWeight: integer("operational_weight").default(15),
  sizeWeight: integer("size_weight").default(15),
  capitalWeight: integer("capital_weight").default(10),
  involvementWeight: integer("involvement_weight").default(5),
  capexWeight: integer("capex_weight").default(10),

  // Enhanced Alert Settings (from guidance docs)
  alertEnabled: boolean("alert_enabled").default(true),
  alertFrequency: varchar("alert_frequency", { length: 20 }).default("daily"), // instant, daily, weekly
  alertMaxListingsPerEmail: integer("alert_max_listings_per_email").default(20),

  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("criteria_profiles_org_idx").on(table.orgId),
}));

export const investmentCriteriaLocation = pgTable("investment_criteria_location", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  targetStates: text("target_states").array(),
  targetRegions: text("target_regions").array(),
  targetMetros: text("target_metros").array(),
  excludedStates: text("excluded_states").array(),
  maxDistanceFromCoast: integer("max_distance_from_coast"),
  preferIcwAccess: boolean("prefer_icw_access").default(false),
  preferOceanAccess: boolean("prefer_ocean_access").default(false),

  // Enhanced with must-have and importance (from guidance docs)
  geographyMustHave: boolean("geography_must_have").default(true),
  geographyImportance: integer("geography_importance").default(5), // 1-5 scale

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaFinancial = pgTable("investment_criteria_financial", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Price criteria with must-have and importance
  minAskingPrice: numeric("min_asking_price", { precision: 15, scale: 2 }),
  maxAskingPrice: numeric("max_asking_price", { precision: 15, scale: 2 }),
  priceMustHave: boolean("price_must_have").default(true),
  priceImportance: integer("price_importance").default(5), // 1-5 scale

  // Revenue criteria with metric type
  minGrossRevenue: numeric("min_gross_revenue", { precision: 15, scale: 2 }),
  maxGrossRevenue: numeric("max_gross_revenue", { precision: 15, scale: 2 }),
  revenueMetricType: varchar("revenue_metric_type", { length: 20 }).default("T12"), // T12, Average3Yr, ProFormaYear1
  revenueMustHave: boolean("revenue_must_have").default(false),
  revenueImportance: integer("revenue_importance").default(3),

  // Cap Rate with type selection
  minCapRate: numeric("min_cap_rate", { precision: 5, scale: 2 }),
  maxCapRate: numeric("max_cap_rate", { precision: 5, scale: 2 }),
  capRateType: varchar("cap_rate_type", { length: 20 }).default("T12"), // T12, ProFormaYear1, Stabilized
  capRateMustHave: boolean("cap_rate_must_have").default(false),
  capRateImportance: integer("cap_rate_importance").default(4),

  // EBITDA criteria
  minEbitda: numeric("min_ebitda", { precision: 15, scale: 2 }),
  maxEbitda: numeric("max_ebitda", { precision: 15, scale: 2 }),
  ebitdaMetricType: varchar("ebitda_metric_type", { length: 20 }).default("T12"),
  ebitdaMustHave: boolean("ebitda_must_have").default(false),
  ebitdaImportance: integer("ebitda_importance").default(3),

  // NOI criteria
  minNoi: numeric("min_noi", { precision: 15, scale: 2 }),
  maxNoi: numeric("max_noi", { precision: 15, scale: 2 }),
  noiMustHave: boolean("noi_must_have").default(false),
  noiImportance: integer("noi_importance").default(3),

  // Operating Margin (EBITDA/Revenue as decimal, e.g., 0.25 = 25%)
  minOperatingMargin: numeric("min_operating_margin", { precision: 5, scale: 4 }),
  maxOperatingMargin: numeric("max_operating_margin", { precision: 5, scale: 4 }),
  operatingMarginMustHave: boolean("operating_margin_must_have").default(false),
  operatingMarginImportance: integer("operating_margin_importance").default(4),

  // Price per slip criteria
  minPricePerSlip: numeric("min_price_per_slip", { precision: 12, scale: 2 }),
  maxPricePerSlip: numeric("max_price_per_slip", { precision: 12, scale: 2 }),
  pricePerSlipMustHave: boolean("price_per_slip_must_have").default(false),
  pricePerSlipImportance: integer("price_per_slip_importance").default(2),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaOperational = pgTable("investment_criteria_operational", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  targetMarinaTypes: text("target_marina_types").array(),
  targetPropertyTypes: text("target_property_types").array(),
  minOccupancyRate: numeric("min_occupancy_rate", { precision: 5, scale: 2 }),
  requireFuelDock: boolean("require_fuel_dock").default(false),
  requireShipStore: boolean("require_ship_store").default(false),
  requireRepairShop: boolean("require_repair_shop").default(false),
  requireRestaurant: boolean("require_restaurant").default(false),
  requireDryStorage: boolean("require_dry_storage").default(false),
  requireBoatRamp: boolean("require_boat_ramp").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaSize = pgTable("investment_criteria_size", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  minTotalSlips: integer("min_total_slips"),
  maxTotalSlips: integer("max_total_slips"),
  minWetSlips: integer("min_wet_slips"),
  maxWetSlips: integer("max_wet_slips"),
  minDryStorage: integer("min_dry_storage"),
  maxDryStorage: integer("max_dry_storage"),
  minAcreage: numeric("min_acreage", { precision: 10, scale: 2 }),
  maxAcreage: numeric("max_acreage", { precision: 10, scale: 2 }),
  minWaterFrontage: numeric("min_water_frontage", { precision: 10, scale: 2 }),
  maxWaterFrontage: numeric("max_water_frontage", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaCapital = pgTable("investment_criteria_capital", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  totalCapitalAvailable: numeric("total_capital_available", { precision: 15, scale: 2 }),
  maxEquityPerDeal: numeric("max_equity_per_deal", { precision: 15, scale: 2 }),
  targetLtvRatio: numeric("target_ltv_ratio", { precision: 5, scale: 2 }),
  preferredDebtType: varchar("preferred_debt_type", { length: 50 }),
  minCashOnCashReturn: numeric("min_cash_on_cash_return", { precision: 5, scale: 2 }),
  minIrrTarget: numeric("min_irr_target", { precision: 5, scale: 2 }),
  targetHoldPeriod: integer("target_hold_period"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaInvolvement = pgTable("investment_criteria_involvement", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  involvementLevel: varchar("involvement_level", { length: 30 }),
  requireManagementInPlace: boolean("require_management_in_place").default(false),
  willingToRelocate: boolean("willing_to_relocate").default(false),
  maxTravelDistance: integer("max_travel_distance"),
  hoursPerWeekAvailable: integer("hours_per_week_available"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const investmentCriteriaCapex = pgTable("investment_criteria_capex", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  deferredMaintenanceTolerance: varchar("deferred_maintenance_tolerance", { length: 30 }),
  maxCapexBudget: numeric("max_capex_budget", { precision: 15, scale: 2 }),
  capexAsPercentOfPurchase: numeric("capex_as_percent_of_purchase", { precision: 5, scale: 2 }),
  preferTurnkey: boolean("prefer_turnkey").default(true),
  willingToRenovate: boolean("willing_to_renovate").default(false),
  environmentalIssuesOk: boolean("environmental_issues_ok").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ============================================================================
// Storage Revenue Mix Criteria - Per guidance docs
// Allows user to define which departments count as "storage" and min/max % share
// ============================================================================
export const investmentCriteriaStorageMix = pgTable("investment_criteria_storage_mix", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Which departments to include in the "Storage" bucket
  // Default: Wet Slips, Lift Slips, Dry Racks, Moorings, Trailer Storage, Indoor Storage
  includedDepartments: jsonb("included_departments").default(sql`'["Wet Slips", "Lift Slips", "Dry Racks", "Moorings", "Trailer Storage", "Indoor Storage"]'::jsonb`),

  // Min/max % of total revenue from storage departments (0-1 as decimal)
  minStorageShare: numeric("min_storage_share", { precision: 5, scale: 4 }),
  maxStorageShare: numeric("max_storage_share", { precision: 5, scale: 4 }),

  // Hard filter or soft preference
  storageMixMustHave: boolean("storage_mix_must_have").default(true),
  storageMixImportance: integer("storage_mix_importance").default(5), // 1-5 scale

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ============================================================================
// Department Configuration - Exclusions, Preferences, Max Share Limits
// Per guidance docs: allow user to exclude, prefer, or cap certain revenue segments
// ============================================================================
export const investmentCriteriaDepartments = pgTable("investment_criteria_departments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Departments to exclude entirely (hard filter)
  // Example: ["Boat Sales", "F&B"]
  excludedDepartments: jsonb("excluded_departments").default(sql`'[]'::jsonb`),

  // Departments that increase score if present
  // Example: ["Fuel", "Ship Store"]
  preferredDepartments: jsonb("preferred_departments").default(sql`'[]'::jsonb`),

  // Max allowed revenue share per department (soft cap with score penalty)
  // Example: { "Boat Sales": 0.10, "F&B": 0.20 }
  maxSharePerDepartment: jsonb("max_share_per_department").default(sql`'{}'::jsonb`),

  // How strictly to enforce exclusions
  excludeMode: varchar("exclude_mode", { length: 20 }).default("reject"), // reject = hard, penalize = soft
  excludeThreshold: numeric("exclude_threshold", { precision: 5, scale: 4 }).default("0.01"), // Revenue % threshold to trigger exclusion

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ============================================================================
// Storage Types & Rates Criteria - Per guidance docs
// Define desired storage types and minimum rates per type
// ============================================================================
export const investmentCriteriaStorageTypes = pgTable("investment_criteria_storage_types", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  profileId: varchar("profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),

  // Desired storage types
  // Example: ["Wet Slips", "Lift Slips", "Dry Racks"]
  desiredTypes: jsonb("desired_types").default(sql`'["Wet Slips"]'::jsonb`),

  // Minimum total slip/storage count across all types
  minTotalSlips: integer("min_total_slips"),

  // Minimum rates per storage type (JSONB array of objects)
  // Example: [{ "type": "Wet Slips", "minRate": 18, "basis": "$/ft/month" }]
  storageRates: jsonb("storage_rates").default(sql`'[]'::jsonb`),

  // Scoring settings
  storageTypesMustHave: boolean("storage_types_must_have").default(false),
  storageTypesImportance: integer("storage_types_importance").default(3),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const marinaMatchGoals = pgTable("marina_match_goals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  goalType: varchar("goal_type", { length: 50 }).notNull(),
  goalName: varchar("goal_name", { length: 255 }).notNull(),
  targetValue: numeric("target_value", { precision: 15, scale: 2 }).notNull(),
  currentValue: numeric("current_value", { precision: 15, scale: 2 }).default("0"),
  timePeriod: varchar("time_period", { length: 30 }),
  startDate: date("start_date"),
  endDate: date("end_date"),
  priority: integer("priority").default(0),
  isPrimary: boolean("is_primary").default(false),
  displayFormat: varchar("display_format", { length: 30 }).default("number"),
  color: varchar("color", { length: 20 }),
  isActive: boolean("is_active").default(true),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("goals_org_idx").on(table.orgId),
}));

export const marinaMatchGoalProgress = pgTable("marina_match_goal_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  goalId: varchar("goal_id").notNull().references(() => marinaMatchGoals.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  recordedValue: numeric("recorded_value", { precision: 15, scale: 2 }).notNull(),
  recordedAt: timestamp("recorded_at").notNull().defaultNow(),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const marinaScrapeources = pgTable("marina_scrape_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  scope: varchar("scope", { length: 20 }).default("org").notNull(),
  isGlobalSource: boolean("is_global_source").default(false),
  platform: varchar("platform", { length: 100 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  baseUrl: text("base_url"),
  searchUrl: text("search_url"),
  config: jsonb("config"),
  rateLimitRpm: integer("rate_limit_rpm").default(30),
  respectRobotsTxt: boolean("respect_robots_txt").default(true),
  userAgent: varchar("user_agent", { length: 255 }).default("MarinaMatchBot/1.0"),
  isActive: boolean("is_active").default(true),
  isManaged: boolean("is_managed").default(false), // True for system-created default sources

  // Ingestion method configuration
  ingestionMethod: varchar("ingestion_method", { length: 30 }).default("scraping"), // api, feed, scraping, manual, rss

  // Search/filter configuration for marina listings
  propertyType: varchar("property_type", { length: 50 }).default("marina"),
  keywordsInclude: text("keywords_include").array().default(sql`ARRAY['marina', 'boatyard', 'yacht club', 'boat slip', 'dock', 'waterfront marina']`),
  keywordsExclude: text("keywords_exclude").array().default(sql`ARRAY['rv storage', 'self-storage', 'warehouse', 'mini storage']`),

  // Geography filters
  geographyStates: text("geography_states").array(), // Array of state abbreviations to filter
  geographyRegion: varchar("geography_region", { length: 100 }), // Optional region name
  geographyRadius: numeric("geography_radius", { precision: 10, scale: 2 }), // Radius in miles from center point

  // Price and size filters
  minPrice: numeric("min_price", { precision: 15, scale: 2 }),
  maxPrice: numeric("max_price", { precision: 15, scale: 2 }),
  minSlips: integer("min_slips"),
  maxSlips: integer("max_slips"),

  // Polling configuration
  pollingIntervalMinutes: integer("polling_interval_minutes").default(60),

  // Multi-page crawl configuration
  seedUrls: text("seed_urls").array(), // Multiple starting URLs for crawling
  crawlMode: varchar("crawl_mode", { length: 30 }).default("single"), // single, pagination, multi_seed, sitemap
  paginationSelector: varchar("pagination_selector", { length: 255 }), // CSS selector for "Next" button/link
  paginationUrlPattern: varchar("pagination_url_pattern", { length: 500 }), // URL pattern with {page} placeholder
  listingLinkSelector: varchar("listing_link_selector", { length: 255 }), // CSS selector to find listing detail links
  maxPagesPerRun: integer("max_pages_per_run").default(10), // Limit pages crawled per run
  maxCrawlDepth: integer("max_crawl_depth").default(1), // How many link levels to follow
  tokenBudgetPerRun: numeric("token_budget_per_run", { precision: 10, scale: 4 }).default("0.50"), // Max $ to spend on AI per run

  // Delta tracking for detecting new/updated listings
  lastSeenListingId: varchar("last_seen_listing_id", { length: 255 }),
  lastSeenContentHash: varchar("last_seen_content_hash", { length: 64 }),
  lastDeltaCheckAt: timestamp("last_delta_check_at"),

  // Source capabilities (what methods this source supports)
  capabilities: text("capabilities").array().default(sql`ARRAY['scraping']`), // api, scraping, rss, webhook, manual
  capabilityNotes: text("capability_notes"), // Notes about API access requirements, etc.

  // Scrape tracking
  lastScrapeAt: timestamp("last_scrape_at"),
  lastScrapeStatus: varchar("last_scrape_status", { length: 30 }),
  lastScrapeCount: integer("last_scrape_count"),
  totalListingsFound: integer("total_listings_found").default(0),

  // Source health tracking
  successCount: integer("success_count").default(0),
  failureCount: integer("failure_count").default(0),
  consecutiveFailures: integer("consecutive_failures").default(0),
  lastFailureReason: text("last_failure_reason"),
  healthStatus: varchar("health_status", { length: 20 }).default("unknown"), // unknown, healthy, warning, failing, disabled
  lastFetchMethod: varchar("last_fetch_method", { length: 20 }), // static, headless
  requiresJsRendering: boolean("requires_js_rendering").default(false), // Auto-learned preference

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("scrape_sources_org_idx").on(table.orgId),
}));

export const marinaScrapeRuns = pgTable("marina_scrape_runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  sourceId: varchar("source_id").references(() => marinaScrapeources.id, { onDelete: "set null" }),
  platform: varchar("platform", { length: 255 }).notNull(),
  status: varchar("status", { length: 30 }).notNull(),
  listingsFound: integer("listings_found").default(0),
  listingsNew: integer("listings_new").default(0),
  listingsUpdated: integer("listings_updated").default(0),
  listingsRemoved: integer("listings_removed").default(0),
  errorsCount: integer("errors_count").default(0),

  // Multi-page crawl tracking
  pagesCrawled: integer("pages_crawled").default(0),
  pagesSkipped: integer("pages_skipped").default(0),
  linksDiscovered: integer("links_discovered").default(0),
  tokensCost: numeric("tokens_cost", { precision: 10, scale: 4 }).default("0"), // Estimated $ spent on AI

  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  durationMs: integer("duration_ms"),
  errorMessage: text("error_message"),
  details: jsonb("details"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("scrape_runs_org_idx").on(table.orgId),
}));

export const marinaListingMatches = pgTable("marina_listing_matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  listingId: varchar("listing_id").notNull().references(() => marinaListings.id, { onDelete: "cascade" }),
  criteriaProfileId: varchar("criteria_profile_id").notNull().references(() => investmentCriteriaProfiles.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull(),
  overallScore: integer("overall_score").notNull(),
  locationScore: integer("location_score"),
  financialScore: integer("financial_score"),
  operationalScore: integer("operational_score"),
  sizeScore: integer("size_score"),
  capitalScore: integer("capital_score"),
  involvementScore: integer("involvement_score"),
  capexScore: integer("capex_score"),
  scoreBreakdown: jsonb("score_breakdown"),
  passesHardRequirements: boolean("passes_hard_requirements").default(true),
  disqualificationReasons: jsonb("disqualification_reasons"),
  calculatedAt: timestamp("calculated_at").notNull().defaultNow(),
}, (table) => ({
  listingIdx: index("listing_matches_listing_idx").on(table.listingId),
  profileIdx: index("listing_matches_profile_idx").on(table.criteriaProfileId),
}));

export const marinaMatchAlerts = pgTable("marina_match_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  orgId: varchar("org_id").notNull(),
  userId: varchar("user_id"),
  name: varchar("name", { length: 255 }).notNull(),
  criteriaProfileId: varchar("criteria_profile_id").references(() => investmentCriteriaProfiles.id, { onDelete: "set null" }),
  minMatchScore: integer("min_match_score").default(70),
  sendImmediately: boolean("send_immediately").default(true),
  digestFrequency: varchar("digest_frequency", { length: 20 }),
  notifyEmail: boolean("notify_email").default(true),
  notifyInApp: boolean("notify_in_app").default(true),
  emailAddresses: text("email_addresses").array(),
  isActive: boolean("is_active").default(true),
  lastSentAt: timestamp("last_sent_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  orgIdx: index("alerts_org_idx").on(table.orgId),
}));

export const marinaMatchAlertHistory = pgTable("marina_match_alert_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  alertId: varchar("alert_id").notNull().references(() => marinaMatchAlerts.id, { onDelete: "cascade" }),
  listingId: varchar("listing_id").references(() => marinaListings.id, { onDelete: "set null" }),
  orgId: varchar("org_id").notNull(),
  matchScore: integer("match_score").notNull(),
  sentAt: timestamp("sent_at").notNull().defaultNow(),
  channel: varchar("channel", { length: 20 }),
  status: varchar("status", { length: 20 }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas and types for MarinaMatch Intel
export const insertMarinaListingSchema = createInsertSchema(marinaListings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastScrapedAt: true,
});
export const updateMarinaListingSchema = insertMarinaListingSchema.partial();
export type MarinaListing = typeof marinaListings.$inferSelect;
export type InsertMarinaListing = z.infer<typeof insertMarinaListingSchema>;

export const insertInvestmentCriteriaProfileSchema = createInsertSchema(investmentCriteriaProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateInvestmentCriteriaProfileSchema = insertInvestmentCriteriaProfileSchema.partial();
export type InvestmentCriteriaProfile = typeof investmentCriteriaProfiles.$inferSelect;

// Export types for new criteria tables
export type InvestmentCriteriaLocation = typeof investmentCriteriaLocation.$inferSelect;
export type InvestmentCriteriaFinancial = typeof investmentCriteriaFinancial.$inferSelect;
export type InvestmentCriteriaOperational = typeof investmentCriteriaOperational.$inferSelect;
export type InvestmentCriteriaSize = typeof investmentCriteriaSize.$inferSelect;
export type InvestmentCriteriaCapital = typeof investmentCriteriaCapital.$inferSelect;
export type InvestmentCriteriaInvolvement = typeof investmentCriteriaInvolvement.$inferSelect;
export type InvestmentCriteriaCapex = typeof investmentCriteriaCapex.$inferSelect;
export type InvestmentCriteriaStorageMix = typeof investmentCriteriaStorageMix.$inferSelect;
export type InvestmentCriteriaDepartments = typeof investmentCriteriaDepartments.$inferSelect;
export type InvestmentCriteriaStorageTypes = typeof investmentCriteriaStorageTypes.$inferSelect;
export type MarinaListingMatch = typeof marinaListingMatches.$inferSelect;

export const insertMarinaMatchGoalSchema = createInsertSchema(marinaMatchGoals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMarinaMatchGoalSchema = insertMarinaMatchGoalSchema.partial();
export type MarinaMatchGoal = typeof marinaMatchGoals.$inferSelect;

export const insertMarinaScrapeSourceSchema = createInsertSchema(marinaScrapeources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMarinaScrapeSourceSchema = insertMarinaScrapeSourceSchema.partial();
export type MarinaScrapeSource = typeof marinaScrapeources.$inferSelect;

export const insertMarinaMatchAlertSchema = createInsertSchema(marinaMatchAlerts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateMarinaMatchAlertSchema = insertMarinaMatchAlertSchema.partial();
export type MarinaMatchAlert = typeof marinaMatchAlerts.$inferSelect;

// ============================================================================
// MarinaMatch Listing Feedback System
// Global feedback collection for AI training and listing quality improvement
// ============================================================================

export const listingFeedbackReasons = [
  "sold_closed",
  "under_contract", 
  "off_market",
  "duplicate_listing",
  "not_a_marina",
  "incorrect_information",
  "spam_or_fake",
  "broken_link",
  "other"
] as const;

export const marinaListingFeedback = pgTable("marina_listing_feedback", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  listingId: varchar("listing_id").notNull().references(() => marinaListings.id, { onDelete: "cascade" }),
  userId: varchar("user_id"),
  orgId: varchar("org_id"),
  reason: varchar("reason", { length: 50 }).notNull(),
  customReason: text("custom_reason"),
  details: text("details"),
  listingTitle: text("listing_title"),
  listingSource: varchar("listing_source", { length: 100 }),
  listingUrl: text("listing_url"),
  status: varchar("status", { length: 20 }).default("pending"),
  reviewedBy: varchar("reviewed_by"),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  aiPatternApplied: boolean("ai_pattern_applied").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  listingIdx: index("feedback_listing_idx").on(table.listingId),
  statusIdx: index("feedback_status_idx").on(table.status),
  reasonIdx: index("feedback_reason_idx").on(table.reason),
}));

export const marinaAiFilterPatterns = pgTable("marina_ai_filter_patterns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  patternType: varchar("pattern_type", { length: 50 }).notNull(),
  pattern: text("pattern").notNull(),
  reason: varchar("reason", { length: 50 }).notNull(),
  source: varchar("source", { length: 100 }),
  feedbackCount: integer("feedback_count").default(1),
  isActive: boolean("is_active").default(true),
  confidence: numeric("confidence", { precision: 5, scale: 2 }).default("1.00"),
  createdFromFeedbackId: varchar("created_from_feedback_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  typeIdx: index("ai_pattern_type_idx").on(table.patternType),
  activeIdx: index("ai_pattern_active_idx").on(table.isActive),
}));

export const userHiddenListings = pgTable("user_hidden_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  userId: varchar("user_id").notNull(),
  orgId: varchar("org_id").notNull(),
  listingId: varchar("listing_id").notNull().references(() => marinaListings.id, { onDelete: "cascade" }),
  reason: varchar("reason", { length: 50 }),
  hiddenAt: timestamp("hidden_at").notNull().defaultNow(),
}, (table) => ({
  userListingIdx: index("user_hidden_listing_idx").on(table.userId, table.listingId),
  orgListingIdx: index("org_hidden_listing_idx").on(table.orgId, table.listingId),
}));

export type UserHiddenListing = typeof userHiddenListings.$inferSelect;

export const insertListingFeedbackSchema = createInsertSchema(marinaListingFeedback).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});
export type ListingFeedback = typeof marinaListingFeedback.$inferSelect;
export type InsertListingFeedback = z.infer<typeof insertListingFeedbackSchema>;

export const insertAiFilterPatternSchema = createInsertSchema(marinaAiFilterPatterns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AiFilterPattern = typeof marinaAiFilterPatterns.$inferSelect;

// ============================================================================
// OM Builder Module (Offering Memorandum Builder)
// Tables for building and managing investment offering memorandums
// ============================================================================

export const omStatusEnum = pgEnum("om_status", ["draft", "review", "published", "archived"]);
export const omDocTypeEnum = pgEnum("om_doc_type", ["om", "executive_summary", "ic_memo", "pitch_deck"]);
export const omTemplateScopeEnum = pgEnum("om_template_scope", ["block", "page", "om"]);
export const omTemplateOwnerTypeEnum = pgEnum("om_template_owner_type", ["global", "org", "user"]);
export const omDatasetTypeEnum = pgEnum("om_dataset_type", ["underwriting", "sales_comps", "rent_comps", "market", "demographics", "custom"]);

export const oms = pgTable("oms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  projectId: varchar("project_id").notNull(),
  organizationId: varchar("organization_id"),
  dealId: varchar("deal_id").references(() => crmDeals.id, { onDelete: 'set null' }),
  modelingProjectId: varchar("modeling_project_id").references(() => modelingProjects.id, { onDelete: 'set null' }),
  name: text("name").notNull(),
  docType: omDocTypeEnum("doc_type").notNull().default('om'),
  status: omStatusEnum("status").notNull().default('draft'),
  version: integer("version").notNull().default(1),
  settings: jsonb("settings"),
  workingSnapshotJson: jsonb("working_snapshot_json"),
  publishedVersionId: varchar("published_version_id"),
  shareToken: varchar("share_token", { length: 64 }).unique(),
  brandKitId: varchar("brand_kit_id"),
  themeId: varchar("theme_id"),
  createdBy: varchar("created_by"),
  updatedBy: varchar("updated_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  projectIdx: index("oms_project_idx").on(table.projectId),
  orgIdx: index("oms_org_idx").on(table.organizationId),
  dealIdx: index("oms_deal_idx").on(table.dealId),
  modelingProjectIdx: index("oms_modeling_project_idx").on(table.modelingProjectId),
  shareTokenIdx: index("oms_share_token_idx").on(table.shareToken),
  themeIdx: index("oms_theme_idx").on(table.themeId),
}));

export const omPages = pgTable("om_pages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  omId: varchar("om_id").notNull().references(() => oms.id, { onDelete: 'cascade' }),
  title: text("title").notNull(),
  orderIndex: integer("order_index").notNull(),
  layout: jsonb("layout"),
  layoutId: varchar("layout_id"),
  pageMetadata: jsonb("page_metadata").$type<{
    backgroundColor?: string;
    backgroundImageUrl?: string;
    sectionTitle?: string;
    sectionNumber?: string;
  }>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  omIdx: index("om_pages_om_idx").on(table.omId),
  layoutIdx: index("om_pages_layout_idx").on(table.layoutId),
}));

export const omBlocks = pgTable("om_blocks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  pageId: varchar("page_id").notNull().references(() => omPages.id, { onDelete: 'cascade' }),
  type: text("type").notNull(),
  orderIndex: integer("order_index").notNull(),
  content: jsonb("content").notNull(),
  dataBinding: jsonb("data_binding"),
  style: jsonb("style"),
  aiMetadata: jsonb("ai_metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  pageIdx: index("om_blocks_page_idx").on(table.pageId),
}));

export const omTemplates = pgTable("om_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  ownerType: omTemplateOwnerTypeEnum("owner_type").notNull(),
  ownerId: varchar("owner_id"),
  name: text("name").notNull(),
  scope: omTemplateScopeEnum("scope").notNull(),
  category: text("category"),
  templateData: jsonb("template_data").notNull(),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  ownerIdx: index("om_templates_owner_idx").on(table.ownerType, table.ownerId),
  scopeIdx: index("om_templates_scope_idx").on(table.scope),
}));

export const omDatasets = pgTable("om_datasets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  projectId: varchar("project_id").notNull(),
  organizationId: varchar("organization_id"),
  name: text("name").notNull(),
  type: omDatasetTypeEnum("type").notNull(),
  sourceFileName: text("source_file_name"),
  data: jsonb("data").notNull(),
  sheetNames: text("sheet_names").array(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  projectIdx: index("om_datasets_project_idx").on(table.projectId),
  orgIdx: index("om_datasets_org_idx").on(table.organizationId),
}));

// ============================================================================
// OM Builder - Brand Kits
// ============================================================================
export const omBrandKits = pgTable("om_brand_kits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  organizationId: varchar("organization_id"),
  userId: varchar("user_id").notNull(),
  name: text("name").notNull(),
  tokens: jsonb("tokens").notNull().default({}),
  primaryColors: jsonb("primary_colors").$type<string[]>().default([]),
  secondaryColors: jsonb("secondary_colors").$type<string[]>().default([]),
  accentColors: jsonb("accent_colors").$type<string[]>().default([]),
  fontFamilies: jsonb("font_families").$type<{ heading: string; body: string; alt?: string }>(),
  logoAssetId: varchar("logo_asset_id"),
  markAssetId: varchar("mark_asset_id"),
  guidelines: text("guidelines"),
  autoImportedFromUrl: varchar("auto_imported_from_url"),
  sourceScanData: jsonb("source_scan_data"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("om_brand_kits_org_idx").on(table.organizationId),
  userIdx: index("om_brand_kits_user_idx").on(table.userId),
}));

// ============================================================================
// OM Builder - Document Versions
// ============================================================================
export const omDocumentVersions = pgTable("om_document_versions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  omId: varchar("om_id").notNull().references(() => oms.id, { onDelete: 'cascade' }),
  versionNumber: integer("version_number").notNull(),
  snapshotJson: jsonb("snapshot_json").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  changeSummary: text("change_summary"),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  omIdx: index("om_document_versions_om_idx").on(table.omId),
  versionIdx: index("om_document_versions_version_idx").on(table.omId, table.versionNumber),
}));

// ============================================================================
// OM Builder - Generated Documents (Deal-specific OM documents)
// ============================================================================
export const omDocumentStatusEnum = pgEnum("om_document_status", ["draft", "generating", "completed", "failed"]);

export const omDocuments = pgTable("om_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  dealId: varchar("deal_id").notNull().references(() => crmDeals.id, { onDelete: 'cascade' }),
  templateId: varchar("template_id").references(() => omTemplates.id, { onDelete: 'set null' }),
  title: text("title").notNull(),
  generatedAt: timestamp("generated_at").notNull().defaultNow(),
  pdfUrl: text("pdf_url"),
  status: omDocumentStatusEnum("status").notNull().default('draft'),
  metadata: jsonb("metadata").$type<{
    propertyOverview?: Record<string, any>;
    financialSummary?: Record<string, any>;
    rentRoll?: Record<string, any>;
    operations?: Record<string, any>;
    generationOptions?: Record<string, any>;
  }>().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  dealIdx: index("om_documents_deal_idx").on(table.dealId),
  templateIdx: index("om_documents_template_idx").on(table.templateId),
  statusIdx: index("om_documents_status_idx").on(table.status),
}));

export const insertOmDocumentSchema = createInsertSchema(omDocuments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmDocumentSchema = insertOmDocumentSchema.partial();
export type InsertOmDocument = z.infer<typeof insertOmDocumentSchema>;
export type OmDocument = typeof omDocuments.$inferSelect;

// ============================================================================
// OM Builder - Assets
// ============================================================================
export const omAssets = pgTable("om_assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  userId: varchar("user_id").notNull(),
  organizationId: varchar("organization_id"),
  fileUrl: text("file_url").notNull(),
  mimeType: text("mime_type").notNull(),
  fileName: text("file_name").notNull(),
  sha256: text("sha256"),
  folder: varchar("folder", { length: 100 }),
  width: integer("width"),
  height: integer("height"),
  byteSize: integer("byte_size"),
  tags: jsonb("tags"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdx: index("om_assets_user_idx").on(table.userId),
  orgIdx: index("om_assets_org_idx").on(table.organizationId),
  sha256Idx: index("om_assets_sha256_idx").on(table.sha256),
  folderIdx: index("om_assets_folder_idx").on(table.folder),
}));

export const omPageThumbnails = pgTable("om_page_thumbnails", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  documentVersionId: varchar("document_version_id").notNull().references(() => omDocumentVersions.id, { onDelete: 'cascade' }),
  pageIndex: integer("page_index").notNull(),
  imageUrl: text("image_url").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  versionIdx: index("om_page_thumbnails_version_idx").on(table.documentVersionId),
}));

// ============================================================================
// OM Builder - Themes (Institutional-grade theme system)
// ============================================================================
export const omThemes = pgTable("om_themes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  name: text("name").notNull(),
  description: text("description"),
  organizationId: varchar("organization_id"),
  userId: varchar("user_id"),
  isDefault: boolean("is_default").notNull().default(false),
  isSystemDefault: boolean("is_system_default").notNull().default(false),
  baseThemeKey: varchar("base_theme_key", { length: 50 }),
  colors: jsonb("colors").$type<{
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    surface: string;
    text: string;
    textMuted: string;
    headerBackground: string;
    footerBackground: string;
    metricTileBackground: string;
    chartSeries: string[];
    mapOverlay: string;
  }>().notNull(),
  typography: jsonb("typography").$type<{
    fontFamilyDisplay: string;
    fontFamilyHeading: string;
    fontFamilyBody: string;
    fontSizes: {
      title: string;
      section: string;
      h1: string;
      h2: string;
      h3: string;
      body: string;
      disclaimer: string;
      metricValue: string;
      metricLabel: string;
    };
    fontWeights: {
      title: number;
      heading: number;
      body: number;
      bold: number;
    };
  }>().notNull(),
  branding: jsonb("branding").$type<{
    logoUrl?: string;
    watermarkUrl?: string;
    footerTextTemplate?: string;
    coverOverlayStyle?: 'solid' | 'gradient' | 'none';
    headerStyle?: 'minimal' | 'branded' | 'none';
  }>(),
  spacing: jsonb("spacing").$type<{
    defaultSpacingScale: number;
    defaultBorderRadius: string;
    cardShadow: 'none' | 'sm' | 'md' | 'lg';
    pageMargins: { top: number; right: number; bottom: number; left: number };
  }>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  orgIdx: index("om_themes_org_idx").on(table.organizationId),
  userIdx: index("om_themes_user_idx").on(table.userId),
  defaultIdx: index("om_themes_default_idx").on(table.isDefault),
}));

// ============================================================================
// OM Builder - Page Layouts (Reusable page layout templates)
// ============================================================================
export const omLayoutTypeEnum = pgEnum("om_layout_type", [
  'cover',
  'sectionDivider', 
  'execSummary',
  'financials',
  'market',
  'photos',
  'portfolio',
  'team',
  'disclaimer',
  'custom'
]);

export const omPageLayouts = pgTable("om_page_layouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()::text`),
  name: text("name").notNull(),
  description: text("description"),
  layoutType: omLayoutTypeEnum("layout_type").notNull(),
  themeId: varchar("theme_id").references(() => omThemes.id, { onDelete: 'set null' }),
  organizationId: varchar("organization_id"),
  userId: varchar("user_id"),
  isSystemDefault: boolean("is_system_default").notNull().default(false),
  thumbnail: text("thumbnail"),
  structure: jsonb("structure").$type<{
    gridColumns: number;
    gridRows?: number;
    gridGap: string;
    backgroundColor?: string;
    backgroundImageUrl?: string;
    placeholders: Array<{
      id: string;
      blockType: string;
      x: number;
      y: number;
      width: number;
      height: number;
      label?: string;
      styleHints?: Record<string, any>;
    }>;
  }>().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  typeIdx: index("om_page_layouts_type_idx").on(table.layoutType),
  orgIdx: index("om_page_layouts_org_idx").on(table.organizationId),
  themeIdx: index("om_page_layouts_theme_idx").on(table.themeId),
}));

export const insertOmSchema = createInsertSchema(oms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmSchema = insertOmSchema.partial();
export type Om = typeof oms.$inferSelect;
export type InsertOm = z.infer<typeof insertOmSchema>;

export const insertOmPageSchema = createInsertSchema(omPages).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmPageSchema = insertOmPageSchema.partial();
export type OmPage = typeof omPages.$inferSelect;
export type InsertOmPage = z.infer<typeof insertOmPageSchema>;

export const insertOmBlockSchema = createInsertSchema(omBlocks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmBlockSchema = insertOmBlockSchema.partial();
export type OmBlock = typeof omBlocks.$inferSelect;
export type InsertOmBlock = z.infer<typeof insertOmBlockSchema>;

export const insertOmTemplateSchema = createInsertSchema(omTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmTemplateSchema = insertOmTemplateSchema.partial();
export type OmTemplate = typeof omTemplates.$inferSelect;
export type InsertOmTemplate = z.infer<typeof insertOmTemplateSchema>;

export const insertOmDatasetSchema = createInsertSchema(omDatasets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmDatasetSchema = insertOmDatasetSchema.partial();
export type OmDataset = typeof omDatasets.$inferSelect;
export type InsertOmDataset = z.infer<typeof insertOmDatasetSchema>;

export const insertOmBrandKitSchema = createInsertSchema(omBrandKits).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmBrandKitSchema = insertOmBrandKitSchema.partial();
export type OmBrandKit = typeof omBrandKits.$inferSelect;
export type InsertOmBrandKit = z.infer<typeof insertOmBrandKitSchema>;

export const insertOmDocumentVersionSchema = createInsertSchema(omDocumentVersions).omit({
  id: true,
  createdAt: true,
});
export type OmDocumentVersion = typeof omDocumentVersions.$inferSelect;
export type InsertOmDocumentVersion = z.infer<typeof insertOmDocumentVersionSchema>;

export const insertOmAssetSchema = createInsertSchema(omAssets).omit({
  id: true,
  createdAt: true,
});
export type OmAsset = typeof omAssets.$inferSelect;
export type InsertOmAsset = z.infer<typeof insertOmAssetSchema>;

export const insertOmPageThumbnailSchema = createInsertSchema(omPageThumbnails).omit({
  id: true,
  createdAt: true,
});
export type OmPageThumbnail = typeof omPageThumbnails.$inferSelect;
export type InsertOmPageThumbnail = z.infer<typeof insertOmPageThumbnailSchema>;

export const insertOmThemeSchema = createInsertSchema(omThemes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmThemeSchema = insertOmThemeSchema.partial();
export type OmTheme = typeof omThemes.$inferSelect;
export type InsertOmTheme = z.infer<typeof insertOmThemeSchema>;

export const insertOmPageLayoutSchema = createInsertSchema(omPageLayouts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateOmPageLayoutSchema = insertOmPageLayoutSchema.partial();
export type OmPageLayout = typeof omPageLayouts.$inferSelect;
export type InsertOmPageLayout = z.infer<typeof insertOmPageLayoutSchema>;

// ============================================================================
// MODELING SCENARIOS / CASES SYSTEM
// User-defined N cases with separate assumptions and lease-up data
// ============================================================================

// Enum for addback period types
export const addbackPeriodTypeEnum = pgEnum("addback_period_type", ["monthly", "yearly"]);

// Enum for addback scope
export const addbackScopeEnum = pgEnum("addback_scope", ["line_item", "category", "month_cell"]);

// Enum for scenario template scope
export const scenarioTemplateScopeEnum = pgEnum("scenario_template_scope", ["global", "org", "user"]);

// ============================================================================
// GLOBAL SCENARIO TEMPLATES
// Reusable scenario templates that can be applied across any project
// ============================================================================

export const modelingScenarioTemplates = pgTable("modeling_scenario_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").references(() => organizations.id), // Nullable for global templates
  createdBy: varchar("created_by").notNull().references(() => users.id),

  name: text("name").notNull(), // e.g., "Base Case", "Aggressive Growth", "Conservative"
  description: text("description"),
  scope: scenarioTemplateScopeEnum("scope").notNull().default("org"), // global/org/user
  color: varchar("color", { length: 50 }).default("blue"),

  // Core assumptions
  revenueGrowthRate: decimal("revenue_growth_rate", { precision: 8, scale: 4 }),
  expenseGrowthRate: decimal("expense_growth_rate", { precision: 8, scale: 4 }),
  exitCapRate: decimal("exit_cap_rate", { precision: 8, scale: 4 }),
  occupancyRate: decimal("occupancy_rate", { precision: 8, scale: 4 }),
  discountRate: decimal("discount_rate", { precision: 8, scale: 4 }),
  holdPeriodYears: integer("hold_period_years"),

  // Lease-up assumptions (stored as JSON for flexibility)
  leaseUpSchedule: jsonb("lease_up_schedule").default(sql`'[]'`),

  // Additional custom assumptions as JSON
  customAssumptions: jsonb("custom_assumptions").default(sql`'{}'`),

  // Metadata
  isSystem: boolean("is_system").notNull().default(false), // System-provided templates
  usageCount: integer("usage_count").notNull().default(0), // Track popularity

  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("scenario_templates_org_idx").on(table.orgId),
  scopeIdx: index("scenario_templates_scope_idx").on(table.scope),
  nameIdx: index("scenario_templates_name_idx").on(table.name),
}));

// Modeling Cases - Individual case definitions for a modeling project
export const modelingCases = pgTable("modeling_cases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),

  name: text("name").notNull(), // e.g., "Base Case", "Aggressive", "Conservative"
  description: text("description"),
  color: text("color"), // Color identifier for UI display (e.g., "blue", "green", "orange")
  sortOrder: integer("sort_order").notNull().default(0),
  isDefault: boolean("is_default").notNull().default(false), // One case per project is the default
  isEnabled: boolean("is_enabled").notNull().default(true),

  // Core assumptions stored directly on the case for quick access
  revenueGrowthRate: decimal("revenue_growth_rate", { precision: 8, scale: 4 }), // e.g., 0.03 = 3%
  expenseGrowthRate: decimal("expense_growth_rate", { precision: 8, scale: 4 }),
  exitCapRate: decimal("exit_cap_rate", { precision: 8, scale: 4 }),
  occupancyRate: decimal("occupancy_rate", { precision: 8, scale: 4 }),
  discountRate: decimal("discount_rate", { precision: 8, scale: 4 }),
  holdPeriodYears: integer("hold_period_years"),

  // Lease-up assumptions (stored as JSON for flexibility)
  leaseUpSchedule: jsonb("lease_up_schedule").default(sql`'[]'`), // Array of { month: number, occupancy: number }

  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectIdx: index("modeling_cases_project_idx").on(table.projectId),
  orgIdx: index("modeling_cases_org_idx").on(table.orgId),
  sortOrderIdx: index("modeling_cases_sort_order_idx").on(table.projectId, table.sortOrder),
}));

// Case Assumptions - Extended key-value pairs for additional assumptions per case
export const modelingCaseAssumptions = pgTable("modeling_case_assumptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  caseId: varchar("case_id").notNull().references(() => modelingCases.id, { onDelete: 'cascade' }),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),

  key: text("key").notNull(), // e.g., "vacancy_rate", "expense_ratio", etc.
  value: text("value").notNull(),
  valueType: text("value_type").notNull().default("number"), // "number", "percentage", "currency", "text"
  category: text("category"), // Group assumptions by category

  // Period-specific values (for monthly/yearly overrides)
  period: text("period"), // "monthly" or "yearly" or null for global
  month: integer("month"), // 1-12 if monthly
  year: integer("year"), // Year number if yearly

  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  caseIdx: index("modeling_case_assumptions_case_idx").on(table.caseId),
  projectIdx: index("modeling_case_assumptions_project_idx").on(table.projectId),
  keyIdx: index("modeling_case_assumptions_key_idx").on(table.caseId, table.key),
}));

// ============================================================================
// ADDBACKS SYSTEM
// Per-line-item addback flags and values
// ============================================================================

// Modeling Addbacks - Addback flags per line item
export const modelingAddbacks = pgTable("modeling_addbacks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  caseId: varchar("case_id").references(() => modelingCases.id, { onDelete: 'cascade' }), // Nullable if applies to all cases
  orgId: varchar("org_id").notNull().references(() => organizations.id),

  lineItemKey: text("line_item_key").notNull(), // Identifier for the P&L line item
  lineItemLabel: text("line_item_label").notNull(), // Display label for the line item
  category: text("category"), // Revenue/Expense/Other
  department: text("department"), // Marina department (Storage, Fuel, Ship's Store, etc.)

  periodType: addbackPeriodTypeEnum("period_type").notNull().default("yearly"), // "monthly" or "yearly"
  isActive: boolean("is_active").notNull().default(true),
  notes: text("notes"),
  scope: addbackScopeEnum("scope").notNull().default("line_item"),
  reason: text("reason"),
  addbackMonth: integer("addback_month"),
  addbackYear: integer("addback_year"),

  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectIdx: index("modeling_addbacks_project_idx").on(table.projectId),
  caseIdx: index("modeling_addbacks_case_idx").on(table.caseId),
  orgIdx: index("modeling_addbacks_org_idx").on(table.orgId),
  lineItemIdx: index("modeling_addbacks_line_item_idx").on(table.projectId, table.lineItemKey),
}));

// Addback Values - Period-specific addback amounts
export const modelingAddbackValues = pgTable("modeling_addback_values", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  addbackId: varchar("addback_id").notNull().references(() => modelingAddbacks.id, { onDelete: 'cascade' }),

  year: integer("year").notNull(), // Year number (1-based for projection years, or actual year)
  month: integer("month"), // 1-12 for monthly, null for yearly
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  addbackIdx: index("modeling_addback_values_addback_idx").on(table.addbackId),
  periodIdx: index("modeling_addback_values_period_idx").on(table.addbackId, table.year, table.month),
}));

// ============================================================================
// P&L LINE ITEM OVERRIDES
// Department moves and line item exclusions for Historical P&L and Pro Forma
// ============================================================================

export const pnlOverrideTypeEnum = pgEnum("pnl_override_type", ["department", "exclude"]);

export const modelingPnlOverrides = pgTable("modeling_pnl_overrides", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  lineItemKey: text("line_item_key").notNull(),
  category: text("category"),
  overrideType: pnlOverrideTypeEnum("override_type").notNull(),
  overrideDepartment: text("override_department"),
  overrideCategory: text("override_category"),
  isActive: boolean("is_active").notNull().default(true),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectIdx: index("modeling_pnl_overrides_project_idx").on(table.projectId),
  orgIdx: index("modeling_pnl_overrides_org_idx").on(table.orgId),
  lineItemIdx: index("modeling_pnl_overrides_line_item_idx").on(table.projectId, table.lineItemKey),
  uniqueOverride: unique("modeling_pnl_overrides_unique").on(table.projectId, table.lineItemKey, table.overrideType),
}));

// ============================================================================
// DUE DILIGENCE FEES TRACKING
// Track fees paid to third-parties and deal team members
// ============================================================================

// DD Fee category enum
export const ddFeeCategoryEnum = pgEnum("dd_fee_category", [
  "legal", "accounting", "consulting", "inspection", "appraisal", 
  "environmental", "survey", "title", "lender", "broker", "other"
]);

// Due Diligence Fees - Track fees paid to contacts/companies
export const ddFees = pgTable("dd_fees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: 'cascade' }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),

  // Link to CRM entities (at least one should be set)
  contactId: varchar("contact_id").references(() => crmContacts.id),
  companyId: varchar("company_id").references(() => crmCompanies.id),

  // Optional link to DD task
  taskId: varchar("task_id").references(() => tasks.id, { onDelete: 'set null' }),

  // Fee details
  category: ddFeeCategoryEnum("category").notNull().default("other"),
  description: text("description"),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  dateIncurred: date("date_incurred"),
  datePaid: date("date_paid"),
  isPaid: boolean("is_paid").notNull().default(false),

  // Invoice/payment tracking
  invoiceNumber: text("invoice_number"),
  paymentMethod: text("payment_method"),
  notes: text("notes"),

  // Allocation (optional DD phase)
  phase: text("phase"), // e.g., "Initial DD", "Extended DD", "Closing"

  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectIdx: index("dd_fees_project_idx").on(table.projectId),
  orgIdx: index("dd_fees_org_idx").on(table.orgId),
  contactIdx: index("dd_fees_contact_idx").on(table.contactId),
  companyIdx: index("dd_fees_company_idx").on(table.companyId),
  taskIdx: index("dd_fees_task_idx").on(table.taskId),
  categoryIdx: index("dd_fees_category_idx").on(table.projectId, table.category),
}));

// DD Fees Relations
export const ddFeesRelations = relations(ddFees, ({ one }) => ({
  project: one(projects, {
    fields: [ddFees.projectId],
    references: [projects.id],
  }),
  organization: one(organizations, {
    fields: [ddFees.orgId],
    references: [organizations.id],
  }),
  contact: one(crmContacts, {
    fields: [ddFees.contactId],
    references: [crmContacts.id],
  }),
  company: one(crmCompanies, {
    fields: [ddFees.companyId],
    references: [crmCompanies.id],
  }),
  task: one(tasks, {
    fields: [ddFees.taskId],
    references: [tasks.id],
  }),
  creator: one(users, {
    fields: [ddFees.createdBy],
    references: [users.id],
  }),
}));

// DD Fees Insert/Select schemas
export const insertDdFeeSchema = createInsertSchema(ddFees).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateDdFeeSchema = insertDdFeeSchema.partial();
export type DdFee = typeof ddFees.$inferSelect;
export type InsertDdFee = z.infer<typeof insertDdFeeSchema>;

// ============================================================================
// CRM LISTS FEATURE
// User-defined lists for Contacts, Companies, Properties
// ============================================================================

// CRM List entity type enum
export const crmListEntityTypeEnum = pgEnum("crm_list_entity_type", ["contact", "company", "property"]);

// CRM Lists - User-defined list definitions
export const crmLists = pgTable("crm_lists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  createdBy: varchar("created_by").notNull().references(() => users.id),

  name: text("name").notNull(),
  description: text("description"),
  color: text("color"), // Optional color for visual identification
  icon: text("icon"), // Optional icon name

  // Which entity types can be added to this list
  allowedEntityTypes: text("allowed_entity_types").array().default(sql`ARRAY['contact', 'company', 'property']::text[]`),

  isArchived: boolean("is_archived").notNull().default(false),

  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("crm_lists_org_idx").on(table.orgId),
  createdByIdx: index("crm_lists_created_by_idx").on(table.createdBy),
  nameIdx: index("crm_lists_name_idx").on(table.orgId, table.name),
}));

// CRM List Items - Entity membership in lists
export const crmListItems = pgTable("crm_list_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  listId: varchar("list_id").notNull().references(() => crmLists.id, { onDelete: 'cascade' }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),

  entityType: crmListEntityTypeEnum("entity_type").notNull(),
  entityId: varchar("entity_id").notNull(), // ID of the contact/company/property

  addedBy: varchar("added_by").notNull().references(() => users.id),
  addedAt: timestamp("added_at").defaultNow().notNull(),
  notes: text("notes"),
}, (table) => ({
  listIdx: index("crm_list_items_list_idx").on(table.listId),
  orgIdx: index("crm_list_items_org_idx").on(table.orgId),
  entityIdx: index("crm_list_items_entity_idx").on(table.entityType, table.entityId),
  uniqueListEntity: index("crm_list_items_unique").on(table.listId, table.entityType, table.entityId),
}));

// ============================================================================
// MODELING SCENARIO TEMPLATES - RELATIONS
// ============================================================================

export const modelingScenarioTemplatesRelations = relations(modelingScenarioTemplates, ({ one }) => ({
  organization: one(organizations, {
    fields: [modelingScenarioTemplates.orgId],
    references: [organizations.id],
  }),
  creator: one(users, {
    fields: [modelingScenarioTemplates.createdBy],
    references: [users.id],
  }),
}));

// ============================================================================
// MODELING CASES - RELATIONS
// ============================================================================

export const modelingCasesRelations = relations(modelingCases, ({ one, many }) => ({
  project: one(modelingProjects, {
    fields: [modelingCases.projectId],
    references: [modelingProjects.id],
  }),
  organization: one(organizations, {
    fields: [modelingCases.orgId],
    references: [organizations.id],
  }),
  creator: one(users, {
    fields: [modelingCases.createdBy],
    references: [users.id],
  }),
  assumptions: many(modelingCaseAssumptions),
  addbacks: many(modelingAddbacks),
}));

export const modelingCaseAssumptionsRelations = relations(modelingCaseAssumptions, ({ one }) => ({
  case: one(modelingCases, {
    fields: [modelingCaseAssumptions.caseId],
    references: [modelingCases.id],
  }),
  project: one(modelingProjects, {
    fields: [modelingCaseAssumptions.projectId],
    references: [modelingProjects.id],
  }),
}));

export const modelingAddbacksRelations = relations(modelingAddbacks, ({ one, many }) => ({
  project: one(modelingProjects, {
    fields: [modelingAddbacks.projectId],
    references: [modelingProjects.id],
  }),
  case: one(modelingCases, {
    fields: [modelingAddbacks.caseId],
    references: [modelingCases.id],
  }),
  organization: one(organizations, {
    fields: [modelingAddbacks.orgId],
    references: [organizations.id],
  }),
  values: many(modelingAddbackValues),
}));

export const modelingAddbackValuesRelations = relations(modelingAddbackValues, ({ one }) => ({
  addback: one(modelingAddbacks, {
    fields: [modelingAddbackValues.addbackId],
    references: [modelingAddbacks.id],
  }),
}));

export const crmListsRelations = relations(crmLists, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [crmLists.orgId],
    references: [organizations.id],
  }),
  creator: one(users, {
    fields: [crmLists.createdBy],
    references: [users.id],
  }),
  items: many(crmListItems),
}));

export const crmListItemsRelations = relations(crmListItems, ({ one }) => ({
  list: one(crmLists, {
    fields: [crmListItems.listId],
    references: [crmLists.id],
  }),
  organization: one(organizations, {
    fields: [crmListItems.orgId],
    references: [organizations.id],
  }),
  addedByUser: one(users, {
    fields: [crmListItems.addedBy],
    references: [users.id],
  }),
}));

// ============================================================================
// MODELING CASES - INSERT/SELECT SCHEMAS
// ============================================================================

// Scenario Templates
export const insertModelingScenarioTemplateSchema = createInsertSchema(modelingScenarioTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  usageCount: true,
});
export const updateModelingScenarioTemplateSchema = insertModelingScenarioTemplateSchema.partial();
export type ModelingScenarioTemplate = typeof modelingScenarioTemplates.$inferSelect;
export type InsertModelingScenarioTemplate = z.infer<typeof insertModelingScenarioTemplateSchema>;

// Modeling Cases
export const insertModelingCaseSchema = createInsertSchema(modelingCases).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateModelingCaseSchema = insertModelingCaseSchema.partial();
export type ModelingCase = typeof modelingCases.$inferSelect;
export type InsertModelingCase = z.infer<typeof insertModelingCaseSchema>;

export const insertModelingCaseAssumptionSchema = createInsertSchema(modelingCaseAssumptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type ModelingCaseAssumption = typeof modelingCaseAssumptions.$inferSelect;
export type InsertModelingCaseAssumption = z.infer<typeof insertModelingCaseAssumptionSchema>;

export const insertModelingAddbackSchema = createInsertSchema(modelingAddbacks).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateModelingAddbackSchema = insertModelingAddbackSchema.partial();
export type ModelingAddback = typeof modelingAddbacks.$inferSelect;
export type InsertModelingAddback = z.infer<typeof insertModelingAddbackSchema>;

export const insertModelingAddbackValueSchema = createInsertSchema(modelingAddbackValues).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type ModelingAddbackValue = typeof modelingAddbackValues.$inferSelect;
export type InsertModelingAddbackValue = z.infer<typeof insertModelingAddbackValueSchema>;

// ============================================================================
// DISPLAY NAME OVERRIDES - Project-level and org-level name customization
// ============================================================================

export const nameOverrideScopeEnum = pgEnum("name_override_scope", ["department", "line_item"]);

export const modelingNameOverrides = pgTable("modeling_name_overrides", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  scope: nameOverrideScopeEnum("scope").notNull(),
  originalName: text("original_name").notNull(),
  displayName: text("display_name").notNull(),
  category: text("category"),
  department: text("department"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectIdx: index("name_overrides_project_idx").on(table.projectId),
  orgIdx: index("name_overrides_org_idx").on(table.orgId),
  lookupIdx: index("name_overrides_lookup_idx").on(table.projectId, table.scope, table.originalName),
}));

export const orgPnlDisplayDefaults = pgTable("org_pnl_display_defaults", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  scope: nameOverrideScopeEnum("scope").notNull(),
  originalName: text("original_name").notNull(),
  displayName: text("display_name").notNull(),
  category: text("category"),
  department: text("department"),
  isActive: boolean("is_active").default(true).notNull(),
  timesUsed: integer("times_used").default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("org_display_defaults_org_idx").on(table.orgId),
  lookupIdx: index("org_display_defaults_lookup_idx").on(table.orgId, table.scope, table.originalName),
}));

export const insertModelingNameOverrideSchema = createInsertSchema(modelingNameOverrides).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type ModelingNameOverride = typeof modelingNameOverrides.$inferSelect;
export type InsertModelingNameOverride = z.infer<typeof insertModelingNameOverrideSchema>;

export const insertOrgPnlDisplayDefaultSchema = createInsertSchema(orgPnlDisplayDefaults).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OrgPnlDisplayDefault = typeof orgPnlDisplayDefaults.$inferSelect;
export type InsertOrgPnlDisplayDefault = z.infer<typeof insertOrgPnlDisplayDefaultSchema>;

export const insertCrmListSchema = createInsertSchema(crmLists).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateCrmListSchema = insertCrmListSchema.partial();
export type CrmList = typeof crmLists.$inferSelect;
export type InsertCrmList = z.infer<typeof insertCrmListSchema>;

export const insertCrmListItemSchema = createInsertSchema(crmListItems).omit({
  id: true,
  addedAt: true,
});
export type CrmListItem = typeof crmListItems.$inferSelect;
export type InsertCrmListItem = z.infer<typeof insertCrmListItemSchema>;

// ============================================================================
// DockTalk 2.0 Schema Integration
// Re-export all DockTalk tables, types, and schemas from docktalk-schema.ts
// This makes them discoverable to Drizzle migrations while keeping schemas modular
// ============================================================================
export * from "./docktalk-schema";

// ============================================================================
// Financial Kernel Schema Integration
// Re-export all Financial Kernel tables, types, and schemas
// This provides the canonical financial data model for integrations platform
// ============================================================================
export * from "./finance-kernel-schema";

// ============================================================================
// Institutional Analytics Schema Integration
// Re-export all Analytics tables, types, and KPI definitions
// This provides multi-asset class performance metrics and benchmarking
// ============================================================================
export * from "./analytics-schema";

// ============================================================================
// DEAL WORKSPACES - UNIFIED HUB FOR MODELING, DD, AND VDR
// ============================================================================

export const workspaceRoleEnum = pgEnum('workspace_role', ['buyer', 'seller', 'broker', 'lender', 'consultant']);
export const workspaceStatusEnum = pgEnum('workspace_status', ['active', 'pending', 'under_contract', 'due_diligence', 'closing', 'closed', 'dead', 'on_hold']);

export const dealWorkspaces = pgTable('deal_workspaces', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Core workspace info
  name: text('name').notNull(),
  description: text('description'),

  // Role/persona for this workspace
  role: workspaceRoleEnum('role').notNull().default('buyer'),
  status: workspaceStatusEnum('status').notNull().default('active'),

  // Linked entities - the unified hub
  dealId: varchar('deal_id').references(() => crmDeals.id),
  modelingProjectId: varchar('modeling_project_id').references(() => modelingProjects.id),
  ddProjectId: varchar('dd_project_id').references(() => projects.id),
  propertyId: varchar('property_id').references(() => crmProperties.id),

  // Key metrics for dashboard display
  targetPrice: decimal('target_price', { precision: 15, scale: 2 }),
  expectedCloseDate: date('expected_close_date'),
  priority: text('priority').default('medium'),

  // Activity tracking
  lastActivityAt: timestamp('last_activity_at'),
  lastActivityType: text('last_activity_type'),
  lastActivityDescription: text('last_activity_description'),

  // Counters for quick reference
  openDdTasks: integer('open_dd_tasks').default(0),
  totalDdTasks: integer('total_dd_tasks').default(0),
  pendingDocuments: integer('pending_documents').default(0),

  // Metadata
  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  archivedAt: timestamp('archived_at'),
}, (table) => ({
  orgIdx: index('deal_workspaces_org_idx').on(table.orgId),
  statusIdx: index('deal_workspaces_status_idx').on(table.status),
  roleIdx: index('deal_workspaces_role_idx').on(table.role),
  dealIdx: index('deal_workspaces_deal_idx').on(table.dealId),
  modelingIdx: index('deal_workspaces_modeling_idx').on(table.modelingProjectId),
  ddProjectIdx: index('deal_workspaces_dd_project_idx').on(table.ddProjectId),
}));

export const dealWorkspacesRelations = relations(dealWorkspaces, ({ one }) => ({
  organization: one(organizations, {
    fields: [dealWorkspaces.orgId],
    references: [organizations.id],
  }),
  creator: one(users, {
    fields: [dealWorkspaces.createdBy],
    references: [users.id],
  }),
  deal: one(crmDeals, {
    fields: [dealWorkspaces.dealId],
    references: [crmDeals.id],
  }),
  modelingProject: one(modelingProjects, {
    fields: [dealWorkspaces.modelingProjectId],
    references: [modelingProjects.id],
  }),
  ddProject: one(projects, {
    fields: [dealWorkspaces.ddProjectId],
    references: [projects.id],
  }),
  property: one(crmProperties, {
    fields: [dealWorkspaces.propertyId],
    references: [crmProperties.id],
  }),
}));

export const insertDealWorkspaceSchema = createInsertSchema(dealWorkspaces).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateDealWorkspaceSchema = insertDealWorkspaceSchema.partial();
export type DealWorkspace = typeof dealWorkspaces.$inferSelect;
export type InsertDealWorkspace = z.infer<typeof insertDealWorkspaceSchema>;

// Re-export Listing Ingestion V2 schema
export * from '../server/listings/ingestion_v2/schema';

// ============================================================================
// Hardened P&L Pipeline Schema Integration
// Re-export all P&L ingestion tables, types, and schemas
// This provides the hardened document-to-fact pipeline with full provenance
// ============================================================================
export * from './pnl-pipeline-schema';

// ============================================================================
// Financial COA Module Schema
// Self-contained P&L parsing and mapping module with COA categories, segments, and aliases
// ============================================================================
export * from './financial-coa-schema';

// ============================================================================
// Capital Markets Schema
// Forward-looking yield curves for SOFR, Treasury rates, and floating-rate debt modeling
// ============================================================================
export * from './capital-markets-schema';

// ============================================================================
// SLA-Driven Task Routing
// Deadline tracking, auto-assignment, and escalation for tasks
// ============================================================================

export const slaConfigStatusEnum = pgEnum('sla_config_status', ['active', 'inactive']);
export const slaTargetTypeEnum = pgEnum('sla_target_type', ['dd_task', 'crm_task', 'activity', 'all']);
export const slaEscalationStatusEnum = pgEnum('sla_escalation_status', ['pending', 'notified', 'resolved', 'ignored']);

export const slaConfigs = pgTable('sla_configs', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  description: text('description'),
  targetType: slaTargetTypeEnum('target_type').notNull().default('all'),

  // Matching criteria (JSON for flexibility)
  matchCriteria: jsonb('match_criteria').$type<{
    taskTypes?: string[];
    priorities?: string[];
    categories?: string[];
    dealStages?: string[];
  }>().default({}),

  // SLA thresholds (in hours)
  warningThresholdHours: integer('warning_threshold_hours').notNull().default(24),
  criticalThresholdHours: integer('critical_threshold_hours').notNull().default(48),
  breachThresholdHours: integer('breach_threshold_hours').notNull().default(72),

  // Escalation chain (user IDs in order)
  escalationChain: text('escalation_chain').array().default(sql`'{}'`),
  escalationDelayHours: integer('escalation_delay_hours').notNull().default(4),

  // Auto-assignment rules
  autoAssignEnabled: boolean('auto_assign_enabled').notNull().default(false),
  autoAssignRules: jsonb('auto_assign_rules').$type<{
    roundRobin?: boolean;
    assigneePool?: string[];
    assignByWorkload?: boolean;
    assignByExpertise?: string[];
  }>().default({}),

  status: slaConfigStatusEnum('status').notNull().default('active'),
  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('sla_configs_org_idx').on(table.orgId),
  statusIdx: index('sla_configs_status_idx').on(table.status),
  targetTypeIdx: index('sla_configs_target_type_idx').on(table.targetType),
}));

export const slaTracking = pgTable('sla_tracking', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  slaConfigId: varchar('sla_config_id').notNull().references(() => slaConfigs.id, { onDelete: 'cascade' }),

  // The entity being tracked
  entityType: text('entity_type').notNull(), // 'dd_task', 'crm_task', 'activity'
  entityId: varchar('entity_id').notNull(),

  // SLA timing
  slaStartTime: timestamp('sla_start_time').notNull(),
  slaDueTime: timestamp('sla_due_time').notNull(),
  warningTime: timestamp('warning_time'),
  criticalTime: timestamp('critical_time'),

  // Current status
  currentStatus: text('current_status').notNull().default('on_track'), // on_track, warning, critical, breached
  currentEscalationLevel: integer('current_escalation_level').notNull().default(0),

  // Resolution
  resolvedAt: timestamp('resolved_at'),
  resolvedBy: varchar('resolved_by').references(() => users.id),
  resolutionNotes: text('resolution_notes'),

  // Assignment
  currentAssigneeId: varchar('current_assignee_id').references(() => users.id),
  previousAssigneeId: varchar('previous_assignee_id').references(() => users.id),

  // Metrics
  timeToFirstResponse: integer('time_to_first_response'), // minutes
  totalResolutionTime: integer('total_resolution_time'), // minutes
  escalationCount: integer('escalation_count').notNull().default(0),
  reassignmentCount: integer('reassignment_count').notNull().default(0),

  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  slaConfigIdx: index('sla_tracking_config_idx').on(table.slaConfigId),
  entityIdx: index('sla_tracking_entity_idx').on(table.entityType, table.entityId),
  statusIdx: index('sla_tracking_status_idx').on(table.currentStatus),
  dueTimeIdx: index('sla_tracking_due_time_idx').on(table.slaDueTime),
  assigneeIdx: index('sla_tracking_assignee_idx').on(table.currentAssigneeId),
}));

export const slaEscalations = pgTable('sla_escalations', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  slaTrackingId: varchar('sla_tracking_id').notNull().references(() => slaTracking.id, { onDelete: 'cascade' }),
  escalationLevel: integer('escalation_level').notNull(),
  escalatedToId: varchar('escalated_to_id').notNull().references(() => users.id),
  escalatedById: varchar('escalated_by_id').references(() => users.id), // null if auto-escalated
  reason: text('reason').notNull(),
  status: slaEscalationStatusEnum('status').notNull().default('pending'),
  notifiedAt: timestamp('notified_at'),
  respondedAt: timestamp('responded_at'),
  responseNotes: text('response_notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  trackingIdx: index('sla_escalations_tracking_idx').on(table.slaTrackingId),
  escalatedToIdx: index('sla_escalations_to_idx').on(table.escalatedToId),
  statusIdx: index('sla_escalations_status_idx').on(table.status),
}));

export const slaAssignmentHistory = pgTable('sla_assignment_history', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  slaTrackingId: varchar('sla_tracking_id').notNull().references(() => slaTracking.id, { onDelete: 'cascade' }),
  fromUserId: varchar('from_user_id').references(() => users.id),
  toUserId: varchar('to_user_id').notNull().references(() => users.id),
  assignmentReason: text('assignment_reason').notNull(), // 'auto_assign', 'manual', 'escalation', 'workload_balance'
  assignedAt: timestamp('assigned_at').defaultNow().notNull(),
  assignedBy: varchar('assigned_by').references(() => users.id), // null if auto-assigned
}, (table) => ({
  trackingIdx: index('sla_assignment_history_tracking_idx').on(table.slaTrackingId),
  toUserIdx: index('sla_assignment_history_to_idx').on(table.toUserId),
}));

export const slaConfigsRelations = relations(slaConfigs, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [slaConfigs.orgId],
    references: [organizations.id],
  }),
  creator: one(users, {
    fields: [slaConfigs.createdBy],
    references: [users.id],
  }),
  trackings: many(slaTracking),
}));

export const slaTrackingRelations = relations(slaTracking, ({ one, many }) => ({
  config: one(slaConfigs, {
    fields: [slaTracking.slaConfigId],
    references: [slaConfigs.id],
  }),
  currentAssignee: one(users, {
    fields: [slaTracking.currentAssigneeId],
    references: [users.id],
  }),
  resolver: one(users, {
    fields: [slaTracking.resolvedBy],
    references: [users.id],
  }),
  escalations: many(slaEscalations),
  assignmentHistory: many(slaAssignmentHistory),
}));

export const slaEscalationsRelations = relations(slaEscalations, ({ one }) => ({
  tracking: one(slaTracking, {
    fields: [slaEscalations.slaTrackingId],
    references: [slaTracking.id],
  }),
  escalatedTo: one(users, {
    fields: [slaEscalations.escalatedToId],
    references: [users.id],
    relationName: 'escalatedTo',
  }),
  escalatedBy: one(users, {
    fields: [slaEscalations.escalatedById],
    references: [users.id],
    relationName: 'escalatedBy',
  }),
}));

export const slaAssignmentHistoryRelations = relations(slaAssignmentHistory, ({ one }) => ({
  tracking: one(slaTracking, {
    fields: [slaAssignmentHistory.slaTrackingId],
    references: [slaTracking.id],
  }),
  fromUser: one(users, {
    fields: [slaAssignmentHistory.fromUserId],
    references: [users.id],
    relationName: 'fromUser',
  }),
  toUser: one(users, {
    fields: [slaAssignmentHistory.toUserId],
    references: [users.id],
    relationName: 'toUser',
  }),
  assignedBy: one(users, {
    fields: [slaAssignmentHistory.assignedBy],
    references: [users.id],
    relationName: 'assignedBy',
  }),
}));

export const insertSlaConfigSchema = createInsertSchema(slaConfigs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateSlaConfigSchema = insertSlaConfigSchema.partial();
export type SlaConfig = typeof slaConfigs.$inferSelect;
export type InsertSlaConfig = z.infer<typeof insertSlaConfigSchema>;

export const insertSlaTrackingSchema = createInsertSchema(slaTracking).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type SlaTracking = typeof slaTracking.$inferSelect;
export type InsertSlaTracking = z.infer<typeof insertSlaTrackingSchema>;

export const insertSlaEscalationSchema = createInsertSchema(slaEscalations).omit({
  id: true,
  createdAt: true,
});
export type SlaEscalation = typeof slaEscalations.$inferSelect;
export type InsertSlaEscalation = z.infer<typeof insertSlaEscalationSchema>;

export const insertSlaAssignmentHistorySchema = createInsertSchema(slaAssignmentHistory).omit({
  id: true,
  assignedAt: true,
});
export type SlaAssignmentHistory = typeof slaAssignmentHistory.$inferSelect;
export type InsertSlaAssignmentHistory = z.infer<typeof insertSlaAssignmentHistorySchema>;

// ================================
// CRM Comment Threads & Notifications (Phase 3A)
// ================================

export const crmCommentThreads = pgTable('crm_comment_threads', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  entityType: text('entity_type').notNull(), // 'deal', 'contact', 'company', 'lead', 'property', 'task'
  entityId: varchar('entity_id').notNull(),
  subject: text('subject'),
  status: text('status').notNull().default('open'), // 'open', 'resolved', 'archived'
  isPinned: boolean('is_pinned').default(false),
  createdBy: varchar('created_by').notNull().references(() => users.id),
  resolvedBy: varchar('resolved_by').references(() => users.id),
  resolvedAt: timestamp('resolved_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('crm_comment_threads_org_idx').on(table.orgId),
  entityIdx: index('crm_comment_threads_entity_idx').on(table.entityType, table.entityId),
  statusIdx: index('crm_comment_threads_status_idx').on(table.status),
}));

export const crmComments = pgTable('crm_comments', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  threadId: varchar('thread_id').notNull().references(() => crmCommentThreads.id, { onDelete: 'cascade' }),
  parentCommentId: varchar('parent_comment_id'), // For nested replies
  content: text('content').notNull(),
  contentHtml: text('content_html'), // Rendered HTML with mentions
  mentions: jsonb('mentions').default([]), // Array of { userId, displayName, startIdx, endIdx }
  attachments: jsonb('attachments').default([]), // Array of { name, url, type, size }
  isEdited: boolean('is_edited').default(false),
  createdBy: varchar('created_by').notNull().references(() => users.id),
  editedAt: timestamp('edited_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  threadIdx: index('crm_comments_thread_idx').on(table.threadId),
  parentIdx: index('crm_comments_parent_idx').on(table.parentCommentId),
  createdByIdx: index('crm_comments_created_by_idx').on(table.createdBy),
}));

export const crmNotifications = pgTable('crm_notifications', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  userId: varchar('user_id').notNull().references(() => users.id), // Recipient
  type: text('type').notNull(), // 'mention', 'reply', 'thread_update', 'assignment', 'deadline', 'red_flag', 'escalation'
  title: text('title').notNull(),
  message: text('message'),
  entityType: text('entity_type'), // 'deal', 'comment', 'task', 'red_flag', 'sla'
  entityId: varchar('entity_id'),
  threadId: varchar('thread_id').references(() => crmCommentThreads.id),
  commentId: varchar('comment_id').references(() => crmComments.id),
  triggeredBy: varchar('triggered_by').references(() => users.id), // Who caused this notification
  isRead: boolean('is_read').default(false),
  readAt: timestamp('read_at'),
  emailSent: boolean('email_sent').default(false),
  emailSentAt: timestamp('email_sent_at'),
  metadata: jsonb('metadata').default({}),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('crm_notifications_org_idx').on(table.orgId),
  userIdx: index('crm_notifications_user_idx').on(table.userId),
  typeIdx: index('crm_notifications_type_idx').on(table.type),
  readIdx: index('crm_notifications_read_idx').on(table.isRead),
}));

export const crmNotificationPreferences = pgTable('crm_notification_preferences', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar('user_id').notNull().references(() => users.id),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  notificationType: text('notification_type').notNull(), // 'mention', 'reply', 'deadline', 'red_flag', etc.
  inApp: boolean('in_app').default(true),
  email: boolean('email').default(true),
  emailDigest: text('email_digest').default('instant'), // 'instant', 'hourly', 'daily', 'never'
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  userOrgTypeIdx: index('crm_notif_prefs_user_org_type_idx').on(table.userId, table.orgId, table.notificationType),
}));

export const crmCommentThreadsRelations = relations(crmCommentThreads, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [crmCommentThreads.orgId],
    references: [organizations.id],
  }),
  creator: one(users, {
    fields: [crmCommentThreads.createdBy],
    references: [users.id],
    relationName: 'threadCreator',
  }),
  resolver: one(users, {
    fields: [crmCommentThreads.resolvedBy],
    references: [users.id],
    relationName: 'threadResolver',
  }),
  comments: many(crmComments),
  notifications: many(crmNotifications),
}));

export const crmCommentsRelations = relations(crmComments, ({ one, many }) => ({
  thread: one(crmCommentThreads, {
    fields: [crmComments.threadId],
    references: [crmCommentThreads.id],
  }),
  parentComment: one(crmComments, {
    fields: [crmComments.parentCommentId],
    references: [crmComments.id],
    relationName: 'parentComment',
  }),
  replies: many(crmComments, { relationName: 'parentComment' }),
  creator: one(users, {
    fields: [crmComments.createdBy],
    references: [users.id],
  }),
  notifications: many(crmNotifications),
}));

export const crmNotificationsRelations = relations(crmNotifications, ({ one }) => ({
  organization: one(organizations, {
    fields: [crmNotifications.orgId],
    references: [organizations.id],
  }),
  user: one(users, {
    fields: [crmNotifications.userId],
    references: [users.id],
    relationName: 'notificationRecipient',
  }),
  triggerer: one(users, {
    fields: [crmNotifications.triggeredBy],
    references: [users.id],
    relationName: 'notificationTriggerer',
  }),
  thread: one(crmCommentThreads, {
    fields: [crmNotifications.threadId],
    references: [crmCommentThreads.id],
  }),
  comment: one(crmComments, {
    fields: [crmNotifications.commentId],
    references: [crmComments.id],
  }),
}));

export const crmNotificationPreferencesRelations = relations(crmNotificationPreferences, ({ one }) => ({
  user: one(users, {
    fields: [crmNotificationPreferences.userId],
    references: [users.id],
  }),
  organization: one(organizations, {
    fields: [crmNotificationPreferences.orgId],
    references: [organizations.id],
  }),
}));

export const insertCrmCommentThreadSchema = createInsertSchema(crmCommentThreads).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateCrmCommentThreadSchema = insertCrmCommentThreadSchema.partial();
export type CrmCommentThread = typeof crmCommentThreads.$inferSelect;
export type InsertCrmCommentThread = z.infer<typeof insertCrmCommentThreadSchema>;

export const insertCrmCommentSchema = createInsertSchema(crmComments).omit({
  id: true,
  createdAt: true,
});
export const updateCrmCommentSchema = insertCrmCommentSchema.partial();
export type CrmComment = typeof crmComments.$inferSelect;
export type InsertCrmComment = z.infer<typeof insertCrmCommentSchema>;

export const insertCrmNotificationSchema = createInsertSchema(crmNotifications).omit({
  id: true,
  createdAt: true,
});
export type CrmNotification = typeof crmNotifications.$inferSelect;
export type InsertCrmNotification = z.infer<typeof insertCrmNotificationSchema>;

export const insertCrmNotificationPreferencesSchema = createInsertSchema(crmNotificationPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type CrmNotificationPreference = typeof crmNotificationPreferences.$inferSelect;
export type InsertCrmNotificationPreference = z.infer<typeof insertCrmNotificationPreferencesSchema>;

// CRM Note types
export type CrmNote = typeof crmNotes.$inferSelect;
export const insertCrmNoteSchema = createInsertSchema(crmNotes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCrmNote = z.infer<typeof insertCrmNoteSchema>;

export type CrmAssociation = typeof crmAssociations.$inferSelect;
export const insertCrmAssociationSchema = createInsertSchema(crmAssociations).omit({
  id: true,
  createdAt: true,
});
export type InsertCrmAssociation = z.infer<typeof insertCrmAssociationSchema>;

// ================================================================================
// RENT ROLL ANALYSIS V2 TYPES (Aliases for module compatibility)
// ================================================================================

// Type aliases for RRA module compatibility
export type MarinaLocation = RraMarinaLocation;
export type InsertMarinaLocation = InsertRraMarinaLocation;

// Lease with tenant data (for display)
export type LeaseWithTenant = RraLease & {
  tenant: RraTenant;
  lineItems?: RraLeaseLineItem[];
};

// Rent Roll Table Configuration
export interface RentRollColumnConfig {
  id: string;
  label: string;
  visible: boolean;
  order: number;
  sortable: boolean;
  align?: 'left' | 'center' | 'right';
  width?: number;
}

export interface RentRollColumnSort {
  columnId: string | null;
  direction: 'asc' | 'desc' | null;
}

export interface RentRollTableConfig {
  columns: RentRollColumnConfig[];
  sort: RentRollColumnSort;
  version?: number;
}

export const RENT_ROLL_CONFIG_VERSION = 12;

export const DEFAULT_RENT_ROLL_COLUMNS: RentRollColumnConfig[] = [
  { id: 'tenant', label: 'Tenant', visible: true, order: 0, sortable: true, align: 'left' },
  { id: 'commencement', label: 'Commencement', visible: true, order: 1, sortable: true, align: 'left' },
  { id: 'expiration', label: 'Expiration', visible: true, order: 2, sortable: true, align: 'left' },
  { id: 'daysUntilExpiration', label: 'Days to Expire', visible: true, order: 3, sortable: true, align: 'right' },
  { id: 'monthlyRent', label: 'Monthly Rent', visible: true, order: 4, sortable: true, align: 'right' },
  { id: 'ratePerFtMo', label: '$/ft./mo.', visible: false, order: 5, sortable: true, align: 'right' },
  { id: 'ratePerFtYr', label: '$/ft./yr.', visible: false, order: 6, sortable: true, align: 'right' },
  { id: 'ratePerFtSeason', label: '$/ft/season', visible: false, order: 7, sortable: true, align: 'right' },
  { id: 'baseRent2', label: 'Base Rent 2', visible: false, order: 8, sortable: true, align: 'right' },
  { id: 'baseRent3', label: 'Base Rent 3', visible: false, order: 9, sortable: true, align: 'right' },
  { id: 'customerTotal', label: 'Customer Total', visible: false, order: 10, sortable: true, align: 'right' },
  { id: 'seasonSummary', label: 'Season Summary', visible: false, order: 11, sortable: false, align: 'left' },
  { id: 'lineItems', label: 'Fee Breakdown', visible: false, order: 12, sortable: false, align: 'left' },
  { id: 'term', label: 'Term', visible: true, order: 13, sortable: true, align: 'center' },
  { id: 'location', label: 'Location', visible: true, order: 14, sortable: true, align: 'left' },
  { id: 'unitNumber', label: 'Unit/Slip #', visible: false, order: 15, sortable: true, align: 'left' },
  { id: 'storageType', label: 'Storage Type', visible: false, order: 16, sortable: true, align: 'left' },
  { id: 'slipStatus', label: 'Slip Status', visible: false, order: 17, sortable: true, align: 'center' },
  { id: 'rateType', label: 'Rate Type', visible: false, order: 18, sortable: true, align: 'left' },
  { id: 'contractTerm', label: 'Contract Term', visible: false, order: 19, sortable: true, align: 'left' },
  { id: 'boatType', label: 'Boat Type', visible: false, order: 20, sortable: true, align: 'left' },
  { id: 'boatLength', label: 'Boat Length', visible: true, order: 21, sortable: true, align: 'right' },
  { id: 'boatWidth', label: 'Boat Width', visible: false, order: 22, sortable: true, align: 'right' },
  { id: 'slipLength', label: 'Slip Length', visible: true, order: 23, sortable: true, align: 'right' },
  { id: 'slipWidth', label: 'Slip Width', visible: true, order: 24, sortable: true, align: 'right' },
  { id: 'slipUtilization', label: 'Slip Utilization', visible: true, order: 25, sortable: true, align: 'right' },
  { id: 'boat', label: 'Boat', visible: true, order: 26, sortable: true, align: 'left' },
  { id: 'numMonths', label: '# Months', visible: true, order: 27, sortable: true, align: 'right' },
  { id: 'totalStorageRevenue', label: 'Total Storage Revenue', visible: true, order: 28, sortable: true, align: 'right' },
  { id: 'totalContractValue', label: 'Total Contract Value', visible: true, order: 29, sortable: true, align: 'right' },
  { id: 'leaseOnFile', label: 'Lease On File', visible: false, order: 30, sortable: true, align: 'center' },
  { id: 'coiOnFile', label: 'COI On File', visible: false, order: 31, sortable: true, align: 'center' },
  { id: 'coiExpiration', label: 'COI Expiration', visible: false, order: 32, sortable: true, align: 'left' },
  { id: 'additionalCharge1', label: "Add'l Charge 1", visible: false, order: 33, sortable: true, align: 'right' },
  { id: 'additionalCharge2', label: "Add'l Charge 2", visible: false, order: 34, sortable: true, align: 'right' },
  { id: 'additionalCharge3', label: "Add'l Charge 3", visible: false, order: 35, sortable: true, align: 'right' },
  { id: 'isLiveaboard', label: 'Liveaboard', visible: false, order: 36, sortable: true, align: 'center' },
  { id: 'electricCharge', label: 'Electric Charge', visible: false, order: 37, sortable: true, align: 'right' },
  { id: 'liveaboardRate', label: 'Liveaboard Rate', visible: false, order: 38, sortable: true, align: 'right' },
  { id: 'waterCharge', label: 'Water Charge', visible: false, order: 39, sortable: true, align: 'right' },
  { id: 'sewerCharge', label: 'Sewer Charge', visible: false, order: 40, sortable: true, align: 'right' },
  { id: 'pumpoutCharge', label: 'Pumpout Charge', visible: false, order: 41, sortable: true, align: 'right' },
  { id: 'taxesCharge', label: 'Taxes', visible: false, order: 42, sortable: true, align: 'right' },
  { id: 'discount', label: 'Discount', visible: false, order: 43, sortable: true, align: 'right' },
  { id: 'status', label: 'Status', visible: true, order: 44, sortable: true, align: 'center' },
  { id: 'actions', label: 'Actions', visible: true, order: 45, sortable: false, align: 'right' },
];

// Note: Scenario type already defined at line 11933 as ShipStoreScenario

// Report types for Rent Roll module
export interface ReportFilters {
  projectIds?: string[];
  startDate?: string;
  endDate?: string;
  storageTypes?: string[];
  contractTerms?: string[];
  status?: string[];
}

export interface ReportOptions {
  includeCharts?: boolean;
  includeRawData?: boolean;
  groupBy?: 'project' | 'storageType' | 'contractTerm' | 'month';
  sortBy?: string;
  sortDirection?: 'asc' | 'desc';
}

export interface ReportData {
  title: string;
  generatedAt: string;
  filters: ReportFilters;
  metrics: Record<string, number | string>;
  data: Record<string, unknown>[];
  charts?: Record<string, unknown>[];
}

// SavedReport type - use placeholder until RRA saved reports table is created
export interface SavedReport {
  id: string;
  orgId: string;
  name: string;
  reportType: string;
  filters: ReportFilters;
  options: ReportOptions;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}
export type InsertSavedReport = Omit<SavedReport, 'id' | 'createdAt' | 'updatedAt'>;

// ParsedImportRow for bulk import
export interface ParsedImportRow {
  rowNumber: number;
  data: Record<string, unknown>;
  errors?: string[];
  warnings?: string[];
}
// ================================================================================
// MARINALYTICS - Portfolio Company & Operating Metrics Analytics
// ================================================================================

// Metric category enum for organizing metrics
export const marinalyticsMetricCategoryEnum = pgEnum("marinalytics_metric_category", [
  "revenue", "occupancy", "fuel", "ancillary", "labor", "operating_expense", 
  "margin", "customer", "maintenance", "capital"
]);

// Metric unit enum
export const marinalyticsMetricUnitEnum = pgEnum("marinalytics_metric_unit", [
  "percentage", "currency", "days", "count", "ratio", "currency_per_foot", 
  "currency_per_slip", "currency_per_sqft"
]);

// Benchmark cohort type
export const marinalyticsCohortTypeEnum = pgEnum("marinalytics_cohort_type", [
  "all", "region", "size", "property_type", "capital_partner"
]);

// Metric definitions - standard metrics that can be tracked
export const marinalyticsMetricDefinitions = pgTable("marinalytics_metric_definitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  metricKey: varchar("metric_key", { length: 100 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: marinalyticsMetricCategoryEnum("category").notNull(),
  unit: marinalyticsMetricUnitEnum("unit").notNull(),
  calculationFormula: text("calculation_formula"),
  isSystem: boolean("is_system").default(true),
  displayOrder: integer("display_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Operator profiles - extended profile for portfolio companies
export const marinalyticsOperatorProfiles = pgTable("marinalytics_operator_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  companyId: varchar("company_id").notNull().references(() => crmCompanies.id, { onDelete: 'cascade' }),
  capitalPartner: varchar("capital_partner", { length: 255 }),
  focusSegments: text("focus_segments").array(), // wet slips, dry storage, yacht clubs, etc.
  primaryRegions: text("primary_regions").array(), // geographic focus areas
  totalMarinaCount: integer("total_marina_count").default(0),
  totalSlipCount: integer("total_slip_count").default(0),
  totalLinearFeet: integer("total_linear_feet").default(0),
  acquisitionStartYear: integer("acquisition_start_year"),
  preferredBenchmarkCohorts: jsonb("preferred_benchmark_cohorts"), // cohort IDs for comparison
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Metric snapshots - actual metric values for operators/properties
export const marinalyticsMetricSnapshots = pgTable("marinalytics_metric_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  operatorProfileId: varchar("operator_profile_id").references(() => marinalyticsOperatorProfiles.id, { onDelete: 'cascade' }),
  propertyId: varchar("property_id").references(() => crmProperties.id, { onDelete: 'cascade' }),
  metricKey: varchar("metric_key", { length: 100 }).notNull(),
  periodStart: date("period_start").notNull(),
  periodEnd: date("period_end").notNull(),
  value: decimal("value", { precision: 15, scale: 4 }).notNull(),
  sourceType: varchar("source_type", { length: 50 }), // manual, pnl_import, calculated
  confidence: varchar("confidence", { length: 20 }).default("high"), // low, medium, high
  sourceDocumentId: varchar("source_document_id"),
  notes: text("notes"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").references(() => users.id),
});

// Benchmark sets - industry benchmarks for comparison
export const marinalyticsBenchmarkSets = pgTable("marinalytics_benchmark_sets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").references(() => organizations.id), // null for system-wide benchmarks
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  cohortType: marinalyticsCohortTypeEnum("cohort_type").notNull(),
  cohortValue: varchar("cohort_value", { length: 255 }), // e.g., "Southeast", "Large (>200 slips)"
  metricKey: varchar("metric_key", { length: 100 }).notNull(),
  p10: decimal("p10", { precision: 15, scale: 4 }), // 10th percentile
  p25: decimal("p25", { precision: 15, scale: 4 }), // 25th percentile
  p50: decimal("p50", { precision: 15, scale: 4 }), // median
  p75: decimal("p75", { precision: 15, scale: 4 }), // 75th percentile
  p90: decimal("p90", { precision: 15, scale: 4 }), // 90th percentile
  mean: decimal("mean", { precision: 15, scale: 4 }),
  sampleSize: integer("sample_size").default(0),
  periodYear: integer("period_year"),
  isSystem: boolean("is_system").default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Capital partners table - track institutional investors
export const marinalyticsCapitalPartners = pgTable("marinalytics_capital_partners", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 100 }), // PE, Family Office, REIT, Private, Strategic
  aum: decimal("aum", { precision: 15, scale: 2 }), // Assets under management
  marinaFocusPercentage: decimal("marina_focus_percentage", { precision: 5, scale: 2 }),
  headquarters: varchar("headquarters", { length: 255 }),
  website: varchar("website", { length: 500 }),
  foundedYear: integer("founded_year"),
  notes: text("notes"),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const marinalyticsOperatorProfilesRelations = relations(marinalyticsOperatorProfiles, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [marinalyticsOperatorProfiles.orgId],
    references: [organizations.id],
  }),
  company: one(crmCompanies, {
    fields: [marinalyticsOperatorProfiles.companyId],
    references: [crmCompanies.id],
  }),
  metricSnapshots: many(marinalyticsMetricSnapshots),
}));

export const marinalyticsMetricSnapshotsRelations = relations(marinalyticsMetricSnapshots, ({ one }) => ({
  organization: one(organizations, {
    fields: [marinalyticsMetricSnapshots.orgId],
    references: [organizations.id],
  }),
  operatorProfile: one(marinalyticsOperatorProfiles, {
    fields: [marinalyticsMetricSnapshots.operatorProfileId],
    references: [marinalyticsOperatorProfiles.id],
  }),
  property: one(crmProperties, {
    fields: [marinalyticsMetricSnapshots.propertyId],
    references: [crmProperties.id],
  }),
  creator: one(users, {
    fields: [marinalyticsMetricSnapshots.createdBy],
    references: [users.id],
  }),
}));

export const marinalyticsBenchmarkSetsRelations = relations(marinalyticsBenchmarkSets, ({ one }) => ({
  organization: one(organizations, {
    fields: [marinalyticsBenchmarkSets.orgId],
    references: [organizations.id],
  }),
}));

export const marinalyticsCapitalPartnersRelations = relations(marinalyticsCapitalPartners, ({ one }) => ({
  organization: one(organizations, {
    fields: [marinalyticsCapitalPartners.orgId],
    references: [organizations.id],
  }),
}));

// Insert/Select schemas
export const insertMarinalyticsMetricDefinitionSchema = createInsertSchema(marinalyticsMetricDefinitions).omit({
  id: true,
  createdAt: true,
});
export type MarinalyticsMetricDefinition = typeof marinalyticsMetricDefinitions.$inferSelect;
export type InsertMarinalyticsMetricDefinition = z.infer<typeof insertMarinalyticsMetricDefinitionSchema>;

export const insertMarinalyticsOperatorProfileSchema = createInsertSchema(marinalyticsOperatorProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type MarinalyticsOperatorProfile = typeof marinalyticsOperatorProfiles.$inferSelect;
export type InsertMarinalyticsOperatorProfile = z.infer<typeof insertMarinalyticsOperatorProfileSchema>;

export const insertMarinalyticsMetricSnapshotSchema = createInsertSchema(marinalyticsMetricSnapshots).omit({
  id: true,
  createdAt: true,
});
export type MarinalyticsMetricSnapshot = typeof marinalyticsMetricSnapshots.$inferSelect;
export type InsertMarinalyticsMetricSnapshot = z.infer<typeof insertMarinalyticsMetricSnapshotSchema>;

export const insertMarinalyticsBenchmarkSetSchema = createInsertSchema(marinalyticsBenchmarkSets).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type MarinalyticsBenchmarkSet = typeof marinalyticsBenchmarkSets.$inferSelect;
export type InsertMarinalyticsBenchmarkSet = z.infer<typeof insertMarinalyticsBenchmarkSetSchema>;

export const insertMarinalyticsCapitalPartnerSchema = createInsertSchema(marinalyticsCapitalPartners).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type MarinalyticsCapitalPartner = typeof marinalyticsCapitalPartners.$inferSelect;
export type InsertMarinalyticsCapitalPartner = z.infer<typeof insertMarinalyticsCapitalPartnerSchema>;

// Standard marina operating metrics seed data
export const MARINALYTICS_STANDARD_METRICS = [
  { metricKey: 'slip_revenue_per_foot', name: 'Slip Revenue per Linear Foot', category: 'revenue', unit: 'currency_per_foot' },
  { metricKey: 'occupancy_rate', name: 'Occupancy Rate', category: 'occupancy', unit: 'percentage' },
  { metricKey: 'transient_mix', name: 'Transient vs Annual Mix', category: 'occupancy', unit: 'percentage' },
  { metricKey: 'fuel_gross_margin', name: 'Fuel Gross Margin', category: 'fuel', unit: 'percentage' },
  { metricKey: 'fuel_gallons_per_slip', name: 'Fuel Gallons per Slip', category: 'fuel', unit: 'count' },
  { metricKey: 'ancillary_revenue_share', name: 'Ancillary Revenue Share', category: 'ancillary', unit: 'percentage' },
  { metricKey: 'ship_store_revenue_per_slip', name: 'Ship Store Revenue per Slip', category: 'ancillary', unit: 'currency_per_slip' },
  { metricKey: 'labor_to_revenue', name: 'Labor to Revenue Ratio', category: 'labor', unit: 'percentage' },
  { metricKey: 'opex_per_slip', name: 'Operating Expense per Slip', category: 'operating_expense', unit: 'currency_per_slip' },
  { metricKey: 'utilities_per_slip', name: 'Utilities per Slip', category: 'operating_expense', unit: 'currency_per_slip' },
  { metricKey: 'maintenance_per_slip', name: 'Maintenance per Slip', category: 'maintenance', unit: 'currency_per_slip' },
  { metricKey: 'ebitda_margin', name: 'EBITDA Margin', category: 'margin', unit: 'percentage' },
  { metricKey: 'noi_margin', name: 'NOI Margin', category: 'margin', unit: 'percentage' },
  { metricKey: 'gross_margin', name: 'Gross Margin', category: 'margin', unit: 'percentage' },
  { metricKey: 'customer_retention', name: 'Customer Retention Rate', category: 'customer', unit: 'percentage' },
  { metricKey: 'ar_aging_days', name: 'AR Aging Days', category: 'customer', unit: 'days' },
  { metricKey: 'capex_per_foot', name: 'CapEx per Linear Foot', category: 'capital', unit: 'currency_per_foot' },
  { metricKey: 'service_dept_margin', name: 'Service Department Gross Margin', category: 'margin', unit: 'percentage' },
] as const;

// ============================================================================
// RRA NEW TABLE TYPES - Types for rraPeriods, rraProjectDetailsConfig, rraPnlRackRevenue
// ============================================================================

export type RraPeriod = typeof rraPeriods.$inferSelect;
export type InsertRraPeriod = typeof rraPeriods.$inferInsert;
export type RraProjectDetailsConfig = typeof rraProjectDetailsConfig.$inferSelect;
export type InsertRraProjectDetailsConfig = typeof rraProjectDetailsConfig.$inferInsert;
export type RraPnlRackRevenue = typeof rraPnlRackRevenue.$inferSelect;
export type InsertRraPnlRackRevenue = typeof rraPnlRackRevenue.$inferInsert;

// ============================================================================
// RENT ROLL V2 SERVICE ALIASES - Compatibility layer for rentRollService.ts
// These map expected imports to existing RRA tables (only non-conflicting exports)
// ============================================================================

// Table aliases - map short names to RRA-prefixed tables
export const tenants = rraTenants;
export const periods = rraPeriods;
export const projectDetailsConfig = rraProjectDetailsConfig;
export const pnlRackRevenue = rraPnlRackRevenue;

// Type aliases - map short type names to RRA types
export type Tenant = RraTenant;
export type Period = RraPeriod;
export type InsertTenant = InsertRraTenant;

// ============================================================================
// OPSSOS - Unified Inbox, Automations, Tasks, Statements, Integrations
// ============================================================================

// OpsOS Enums
export const opssosConversationStatusEnum = pgEnum("opssos_conversation_status", ["open", "snoozed", "closed"]);
export const opssosMessageDirectionEnum = pgEnum("opssos_message_direction", ["in", "out", "note"]);
export const opssosMessageStatusEnum = pgEnum("opssos_message_status", ["draft", "scheduled", "sent", "failed"]);
export const opssosAutomationRunStatusEnum = pgEnum("opssos_automation_run_status", ["pending", "running", "completed", "failed"]);
export const opssosScheduledJobStatusEnum = pgEnum("opssos_scheduled_job_status", ["queued", "running", "done", "failed"]);
export const opssosTaskStatusEnum = pgEnum("opssos_task_status", ["todo", "doing", "done"]);
export const opssosStatementStatusEnum = pgEnum("opssos_statement_status", ["draft", "published"]);
export const opssosExportFormatEnum = pgEnum("opssos_export_format", ["xlsx", "pdf", "zip"]);
export const opssosWebhookDeliveryStatusEnum = pgEnum("opssos_webhook_delivery_status", ["pending", "sent", "failed"]);

// Inbox - Conversations
export const opssosConversations = pgTable("opssos_conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  contactId: varchar("contact_id").references(() => crmContacts.id),
  dealId: varchar("deal_id").references(() => crmDeals.id),
  assetId: varchar("asset_id"),
  channel: text("channel").default("internal").notNull(),
  status: opssosConversationStatusEnum("status").default("open").notNull(),
  assignedUserId: varchar("assigned_user_id").references(() => users.id),
  lastMessageAt: timestamp("last_message_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_conversations_org_idx").on(table.orgId),
  statusIdx: index("opssos_conversations_status_idx").on(table.orgId, table.status),
  assignedIdx: index("opssos_conversations_assigned_idx").on(table.orgId, table.assignedUserId),
}));

// Inbox - Messages
export const opssosMessages = pgTable("opssos_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  conversationId: varchar("conversation_id").notNull().references(() => opssosConversations.id, { onDelete: "cascade" }),
  direction: opssosMessageDirectionEnum("direction").notNull(),
  body: text("body").notNull(),
  provider: text("provider"),
  providerMessageId: text("provider_message_id"),
  scheduledFor: timestamp("scheduled_for"),
  sentAt: timestamp("sent_at"),
  status: opssosMessageStatusEnum("status").default("sent").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  conversationIdx: index("opssos_messages_conversation_idx").on(table.conversationId),
  orgIdx: index("opssos_messages_org_idx").on(table.orgId),
}));

// Message Templates
export const opssosMessageTemplates = pgTable("opssos_message_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  groupName: text("group_name").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_message_templates_org_idx").on(table.orgId),
}));

// Automation Rules
export const opssosAutomationRules = pgTable("opssos_automation_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  triggerType: text("trigger_type").notNull(),
  conditions: jsonb("conditions").default([]),
  actions: jsonb("actions").default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_automation_rules_org_idx").on(table.orgId),
  enabledIdx: index("opssos_automation_rules_enabled_idx").on(table.orgId, table.enabled),
}));

// Automation Runs
export const opssosAutomationRuns = pgTable("opssos_automation_runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  ruleId: varchar("rule_id").notNull().references(() => opssosAutomationRules.id, { onDelete: "cascade" }),
  status: opssosAutomationRunStatusEnum("status").default("pending").notNull(),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  finishedAt: timestamp("finished_at"),
  log: jsonb("log").default([]),
  errorText: text("error_text"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  ruleIdx: index("opssos_automation_runs_rule_idx").on(table.ruleId),
  orgIdx: index("opssos_automation_runs_org_idx").on(table.orgId),
}));

// Scheduled Jobs
export const opssosScheduledJobs = pgTable("opssos_scheduled_jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  type: text("type").notNull(),
  payload: jsonb("payload").default({}),
  runAt: timestamp("run_at").notNull(),
  status: opssosScheduledJobStatusEnum("status").default("queued").notNull(),
  attempts: integer("attempts").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_scheduled_jobs_org_idx").on(table.orgId),
  statusRunAtIdx: index("opssos_scheduled_jobs_status_run_at_idx").on(table.status, table.runAt),
}));

// Tasks
export const opssosTasks = pgTable("opssos_tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  dealId: varchar("deal_id").references(() => crmDeals.id),
  assetId: varchar("asset_id"),
  assignedUserId: varchar("assigned_user_id").references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  status: opssosTaskStatusEnum("status").default("todo").notNull(),
  dueAt: timestamp("due_at"),
  costCents: integer("cost_cents"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_tasks_org_idx").on(table.orgId),
  statusIdx: index("opssos_tasks_status_idx").on(table.orgId, table.status),
  assignedIdx: index("opssos_tasks_assigned_idx").on(table.orgId, table.assignedUserId),
  dealIdx: index("opssos_tasks_deal_idx").on(table.dealId),
}));

// Checklist Templates
export const opssosChecklistTemplates = pgTable("opssos_checklist_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  items: jsonb("items").default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_checklist_templates_org_idx").on(table.orgId),
}));

// Task Checklists
export const opssosTaskChecklists = pgTable("opssos_task_checklists", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  taskId: varchar("task_id").notNull().references(() => opssosTasks.id, { onDelete: "cascade" }),
  items: jsonb("items").default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  taskIdx: index("opssos_task_checklists_task_idx").on(table.taskId),
}));

// Statement Templates
export const opssosStatementTemplates = pgTable("opssos_statement_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  ownerContactId: varchar("owner_contact_id").references(() => crmContacts.id),
  filters: jsonb("filters").default({}),
  columns: jsonb("columns").default([]),
  totals: jsonb("totals").default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_statement_templates_org_idx").on(table.orgId),
}));

// Statements
export const opssosStatements = pgTable("opssos_statements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  templateId: varchar("template_id").notNull().references(() => opssosStatementTemplates.id),
  periodStart: date("period_start").notNull(),
  periodEnd: date("period_end").notNull(),
  status: opssosStatementStatusEnum("status").default("draft").notNull(),
  generatedAt: timestamp("generated_at").defaultNow().notNull(),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_statements_org_idx").on(table.orgId),
  templateIdx: index("opssos_statements_template_idx").on(table.templateId),
}));

// Statement Exports
export const opssosStatementExports = pgTable("opssos_statement_exports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  statementId: varchar("statement_id").notNull().references(() => opssosStatements.id, { onDelete: "cascade" }),
  format: opssosExportFormatEnum("format").notNull(),
  fileUrl: text("file_url").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  statementIdx: index("opssos_statement_exports_statement_idx").on(table.statementId),
}));

// Integrations
export const opssosIntegrations = pgTable("opssos_integrations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  provider: text("provider").notNull(),
  status: text("status").default("inactive").notNull(),
  credentialsEncrypted: text("credentials_encrypted"),
  settings: jsonb("settings").default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_integrations_org_idx").on(table.orgId),
  providerIdx: index("opssos_integrations_provider_idx").on(table.orgId, table.provider),
}));

// Webhooks
export const opssosWebhooks = pgTable("opssos_webhooks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  url: text("url").notNull(),
  secret: text("secret"),
  enabled: boolean("enabled").default(true).notNull(),
  eventTypes: jsonb("event_types").default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("opssos_webhooks_org_idx").on(table.orgId),
  enabledIdx: index("opssos_webhooks_enabled_idx").on(table.orgId, table.enabled),
}));

// Webhook Deliveries
export const opssosWebhookDeliveries = pgTable("opssos_webhook_deliveries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  webhookId: varchar("webhook_id").notNull().references(() => opssosWebhooks.id, { onDelete: "cascade" }),
  eventType: text("event_type").notNull(),
  payload: jsonb("payload").default({}),
  status: opssosWebhookDeliveryStatusEnum("status").default("pending").notNull(),
  responseCode: integer("response_code"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  webhookIdx: index("opssos_webhook_deliveries_webhook_idx").on(table.webhookId),
  orgIdx: index("opssos_webhook_deliveries_org_idx").on(table.orgId),
}));

// OpsOS Types
export type OpssosConversation = typeof opssosConversations.$inferSelect;
export type InsertOpssosConversation = typeof opssosConversations.$inferInsert;
export type OpssosMessage = typeof opssosMessages.$inferSelect;
export type InsertOpssosMessage = typeof opssosMessages.$inferInsert;
export type OpssosMessageTemplate = typeof opssosMessageTemplates.$inferSelect;
export type InsertOpssosMessageTemplate = typeof opssosMessageTemplates.$inferInsert;
export type OpssosAutomationRule = typeof opssosAutomationRules.$inferSelect;
export type InsertOpssosAutomationRule = typeof opssosAutomationRules.$inferInsert;
export type OpssosAutomationRun = typeof opssosAutomationRuns.$inferSelect;
export type InsertOpssosAutomationRun = typeof opssosAutomationRuns.$inferInsert;
export type OpssosScheduledJob = typeof opssosScheduledJobs.$inferSelect;
export type InsertOpssosScheduledJob = typeof opssosScheduledJobs.$inferInsert;
export type OpssosTask = typeof opssosTasks.$inferSelect;
export type InsertOpssosTask = typeof opssosTasks.$inferInsert;
export type OpssosChecklistTemplate = typeof opssosChecklistTemplates.$inferSelect;
export type InsertOpssosChecklistTemplate = typeof opssosChecklistTemplates.$inferInsert;
export type OpssosTaskChecklist = typeof opssosTaskChecklists.$inferSelect;
export type InsertOpssosTaskChecklist = typeof opssosTaskChecklists.$inferInsert;
export type OpssosStatementTemplate = typeof opssosStatementTemplates.$inferSelect;
export type InsertOpssosStatementTemplate = typeof opssosStatementTemplates.$inferInsert;
export type OpssosStatement = typeof opssosStatements.$inferSelect;
export type InsertOpssosStatement = typeof opssosStatements.$inferInsert;
export type OpssosStatementExport = typeof opssosStatementExports.$inferSelect;
export type InsertOpssosStatementExport = typeof opssosStatementExports.$inferInsert;
export type OpssosIntegration = typeof opssosIntegrations.$inferSelect;
export type InsertOpssosIntegration = typeof opssosIntegrations.$inferInsert;
export type OpssosWebhook = typeof opssosWebhooks.$inferSelect;
export type InsertOpssosWebhook = typeof opssosWebhooks.$inferInsert;
export type OpssosWebhookDelivery = typeof opssosWebhookDeliveries.$inferSelect;
export type InsertOpssosWebhookDelivery = typeof opssosWebhookDeliveries.$inferInsert;

// ============================================================================
// INDUSTRY STANDARDS - Global curated benchmarks and metrics
// ============================================================================

export const industryStandards = pgTable("industry_standards", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").references(() => organizations.id), // null for global standards

  // Core fields
  name: text("name").notNull(),
  category: text("category").notNull(), // "occupancy", "revenue", "expenses", "cap_rates", "valuations", "rates"
  subCategory: text("sub_category"), // e.g., "wet_slip_rates", "dry_storage_rates"

  // Geographic/Market scope
  region: text("region"), // "Northeast", "Southeast", "Gulf Coast", etc.
  state: text("state"),
  waterType: text("water_type"), // "Coastal", "Lake", "River"
  marketSize: text("market_size"), // "Major Metro", "Secondary", "Tertiary"

  // Metric values
  metricValue: decimal("metric_value", { precision: 12, scale: 4 }),
  metricUnit: text("metric_unit"), // "percentage", "dollars", "dollars_per_foot", "dollars_per_slip"
  lowRange: decimal("low_range", { precision: 12, scale: 4 }),
  highRange: decimal("high_range", { precision: 12, scale: 4 }),

  // Time period
  effectiveYear: integer("effective_year"),
  effectiveQuarter: integer("effective_quarter"), // 1-4

  // Data source
  dataSource: text("data_source"), // "MarinaMatch Research", "NMMA", "Industry Survey"
  sampleSize: integer("sample_size"),
  confidenceLevel: text("confidence_level"), // "high", "medium", "low"
  sourceNotes: text("source_notes"),

  // Access control
  scope: dataScopeEnum("scope").default("global").notNull(),
  requiredPack: text("required_pack"), // "analytics_pro", "analysis", etc.
  isCurated: boolean("is_curated").default(true).notNull(),

  // Audit fields
  createdBy: varchar("created_by").references(() => users.id),
  updatedBy: varchar("updated_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  categoryIdx: index("industry_standards_category_idx").on(table.category),
  scopeIdx: index("industry_standards_scope_idx").on(table.scope, table.requiredPack),
  regionIdx: index("industry_standards_region_idx").on(table.region, table.state),
  yearIdx: index("industry_standards_year_idx").on(table.effectiveYear, table.effectiveQuarter),
}));

// ============================================
// Integrations Marketplace Schema
// ============================================

export const integrationAuthTypeEnum = pgEnum("integration_auth_type", ["oauth", "apiKey", "none"]);
export const integrationStatusEnum = pgEnum("integration_status", ["available", "connected", "pending", "error"]);

export const integrations = pgTable("integrations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  key: varchar("key").notNull().unique(),
  name: varchar("name").notNull(),
  description: text("description"),
  category: varchar("category").notNull().default("Marina PMS"),
  contexts: jsonb("contexts").$type<string[]>().default([]).notNull(),
  uiPlacements: jsonb("ui_placements").$type<string[]>().default([]).notNull(),
  authType: integrationAuthTypeEnum("auth_type").default("none").notNull(),
  websiteUrl: text("website_url"),
  iconUrl: text("icon_url"),
  logoColor: varchar("logo_color"),
  capabilities: jsonb("capabilities").$type<{
    dataRead: string[];
    dataWrite: string[];
    actions: string[];
    uiHooks: string[];
  }>().default({ dataRead: [], dataWrite: [], actions: [], uiHooks: [] }).notNull(),
  settingsSchema: jsonb("settings_schema").$type<{
    fields: Array<{
      key: string;
      label: string;
      type: "string" | "number" | "boolean" | "select" | "secret";
      required?: boolean;
      options?: Array<{ label: string; value: string }>;
      helpText?: string;
    }>;
  }>().default({ fields: [] }).notNull(),
  connectionGuide: jsonb("connection_guide").$type<{
    overview: string;
    prerequisites: string[];
    steps: Array<{ title: string; description: string; screenshot?: string }>;
    supportUrl?: string;
    apiDocsUrl?: string;
    estimatedTime: string;
  } | null>().default(null),
  dataMappings: jsonb("data_mappings").$type<Array<{
    sourceEntity: string;
    targetModule: string;
    targetEntity: string;
    fields: Array<{ source: string; target: string; transform?: string }>;
    syncDirection: "read" | "write" | "bidirectional";
    frequency: "realtime" | "hourly" | "daily" | "weekly" | "manual";
  }>>().default([]),
  migrationSupport: jsonb("migration_support").$type<{
    canExportAll: boolean;
    supportsHistoricalImport: boolean;
    migrationComplexity: "low" | "medium" | "high";
    estimatedMigrationDays: number;
  } | null>().default(null),
  isActive: boolean("is_active").default(true).notNull(),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  keyIdx: index("integrations_key_idx").on(table.key),
  categoryIdx: index("integrations_category_idx").on(table.category),
  contextsIdx: index("integrations_contexts_idx").on(table.contexts),
  activeIdx: index("integrations_active_idx").on(table.isActive),
}));

export const userIntegrations = pgTable("user_integrations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  orgId: varchar("org_id").references(() => organizations.id),
  integrationKey: varchar("integration_key").notNull().references(() => integrations.key),
  isConnected: boolean("is_connected").default(false).notNull(),
  encryptedAccessToken: text("encrypted_access_token"),
  encryptedRefreshToken: text("encrypted_refresh_token"),
  encryptedApiKey: text("encrypted_api_key"),
  tokenExpiresAt: timestamp("token_expires_at"),
  settings: jsonb("settings").$type<Record<string, any>>().default({}).notNull(),
  oauthState: text("oauth_state"),
  lastSyncAt: timestamp("last_sync_at"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  userIntegrationUnique: unique("user_integration_unique").on(table.userId, table.integrationKey),
  userIdx: index("user_integrations_user_idx").on(table.userId),
  orgIdx: index("user_integrations_org_idx").on(table.orgId),
  integrationKeyIdx: index("user_integrations_key_idx").on(table.integrationKey),
  connectedIdx: index("user_integrations_connected_idx").on(table.isConnected),
}));

export type Integration = typeof integrations.$inferSelect;
export type InsertIntegration = typeof integrations.$inferInsert;
export const insertIntegrationSchema = createInsertSchema(integrations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type UserIntegration = typeof userIntegrations.$inferSelect;
export type InsertUserIntegration = typeof userIntegrations.$inferInsert;
export const insertUserIntegrationSchema = createInsertSchema(userIntegrations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Integration Sync History - tracks detailed sync operations
export const integrationSyncTypeEnum = pgEnum("integration_sync_type", ["import", "export", "full_sync", "incremental", "migration"]);

export const integrationSyncHistory = pgTable("integration_sync_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  orgId: varchar("org_id").references(() => organizations.id),
  integrationKey: varchar("integration_key").notNull().references(() => integrations.key),
  syncType: integrationSyncTypeEnum("sync_type").default("full_sync").notNull(),
  status: integrationSyncStatusEnum("status").default("pending").notNull(),
  startedAt: timestamp("started_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
  recordsProcessed: integer("records_processed").default(0).notNull(),
  recordsCreated: integer("records_created").default(0).notNull(),
  recordsUpdated: integer("records_updated").default(0).notNull(),
  recordsDeleted: integer("records_deleted").default(0).notNull(),
  recordsFailed: integer("records_failed").default(0).notNull(),
  errorCount: integer("error_count").default(0).notNull(),
  errors: jsonb("errors").$type<Array<{code: string; message: string; entity?: string; timestamp: string}>>().default([]),
  metadata: jsonb("metadata").$type<Record<string, any>>().default({}),
  triggeredBy: varchar("triggered_by").default("manual").notNull(),
}, (table) => ({
  userIdx: index("sync_history_user_idx").on(table.userId),
  orgIdx: index("sync_history_org_idx").on(table.orgId),
  integrationKeyIdx: index("sync_history_integration_key_idx").on(table.integrationKey),
  startedAtIdx: index("sync_history_started_at_idx").on(table.startedAt),
  statusIdx: index("sync_history_status_idx").on(table.status),
}));

export type IntegrationSyncHistory = typeof integrationSyncHistory.$inferSelect;
export type InsertIntegrationSyncHistory = typeof integrationSyncHistory.$inferInsert;

// ============ ADMIN CUSTOMERS DASHBOARD ============

export const subscriptionStatusEnum = pgEnum("subscription_status", ["trialing", "active", "past_due", "canceled", "unpaid"]);
export const subscriptionIntervalEnum = pgEnum("subscription_interval", ["month", "year"]);

export const subscriptions = pgTable("subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  provider: text("provider").notNull().default("stripe"),
  planKey: text("plan_key"),
  planName: text("plan_name"),
  interval: subscriptionIntervalEnum("interval").notNull().default("month"),
  status: subscriptionStatusEnum("status").notNull().default("trialing"),
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
  mrrCents: integer("mrr_cents").notNull().default(0),
  providerCustomerId: text("provider_customer_id"),
  providerSubscriptionId: text("provider_subscription_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  userIdx: index("subscriptions_user_idx").on(table.userId),
  orgIdx: index("subscriptions_org_idx").on(table.orgId),
  statusIdx: index("subscriptions_status_idx").on(table.status),
}));

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

export const adminAuditLog = pgTable("admin_audit_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  adminUserId: varchar("admin_user_id").notNull().references(() => users.id),
  action: text("action").notNull(),
  targetUserId: varchar("target_user_id").references(() => users.id),
  metadataJson: jsonb("metadata_json").$type<Record<string, any>>().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  adminIdx: index("admin_audit_admin_idx").on(table.adminUserId),
  targetIdx: index("admin_audit_target_idx").on(table.targetUserId),
  createdAtIdx: index("admin_audit_created_at_idx").on(table.createdAt),
}));

export const insertAdminAuditLogSchema = createInsertSchema(adminAuditLog).omit({
  id: true,
  createdAt: true,
});
export type InsertAdminAuditLog = z.infer<typeof insertAdminAuditLogSchema>;
export type AdminAuditLog = typeof adminAuditLog.$inferSelect;

export const customerNotes = pgTable("customer_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  adminUserId: varchar("admin_user_id").notNull().references(() => users.id),
  note: text("note").notNull(),
  tags: text("tags").array().default(sql`'{}'`),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userIdx: index("customer_notes_user_idx").on(table.userId),
}));

export const insertCustomerNoteSchema = createInsertSchema(customerNotes).omit({
  id: true,
  createdAt: true,
});
export type InsertCustomerNote = z.infer<typeof insertCustomerNoteSchema>;
export type CustomerNote = typeof customerNotes.$inferSelect;
export const insertIntegrationSyncHistorySchema = createInsertSchema(integrationSyncHistory).omit({
  id: true,
  startedAt: true,
});

// Integration Sync Metrics - aggregated sync statistics
export const integrationSyncMetrics = pgTable("integration_sync_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  orgId: varchar("org_id").references(() => organizations.id),
  integrationKey: varchar("integration_key").notNull().references(() => integrations.key),
  totalRecordsImported: integer("total_records_imported").default(0).notNull(),
  totalRecordsExported: integer("total_records_exported").default(0).notNull(),
  totalSyncs: integer("total_syncs").default(0).notNull(),
  successfulSyncs: integer("successful_syncs").default(0).notNull(),
  failedSyncs: integer("failed_syncs").default(0).notNull(),
  lastSyncAt: timestamp("last_sync_at"),
  lastSuccessfulSyncAt: timestamp("last_successful_sync_at"),
  nextScheduledSync: timestamp("next_scheduled_sync"),
  healthScore: integer("health_score").default(100).notNull(),
  averageSyncDurationMs: integer("average_sync_duration_ms").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  userIntegrationUnique: unique("sync_metrics_unique").on(table.userId, table.integrationKey, table.orgId),
  userIdx: index("sync_metrics_user_idx").on(table.userId),
  orgIdx: index("sync_metrics_org_idx").on(table.orgId),
  integrationKeyIdx: index("sync_metrics_key_idx").on(table.integrationKey),
}));

export type IntegrationSyncMetrics = typeof integrationSyncMetrics.$inferSelect;
export type InsertIntegrationSyncMetrics = typeof integrationSyncMetrics.$inferInsert;
export const insertIntegrationSyncMetricsSchema = createInsertSchema(integrationSyncMetrics).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Industry Standards Types
export type IndustryStandard = typeof industryStandards.$inferSelect;
export type InsertIndustryStandard = typeof industryStandards.$inferInsert;
export const insertIndustryStandardSchema = createInsertSchema(industryStandards).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// ═══════════════════════════════════════════════════════════════════════
// COA-Based Financial Normalization Engine Tables
// ═══════════════════════════════════════════════════════════════════════

// 1. MM Standard Accounts - Canonical category targets
export const mmStandardAccounts = pgTable('mm_standard_accounts', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  categoryGroup: text('category_group').notNull(),
  category: text('category').notNull(),
  subCategory: text('sub_category'),
  assetClassTag: text('asset_class_tag').notNull().default('Marina'),
  sortOrder: integer('sort_order').default(0),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  categoryGroupAssetIdx: index('mm_std_acct_group_asset_idx').on(table.categoryGroup, table.assetClassTag),
}));

export type MmStandardAccount = typeof mmStandardAccounts.$inferSelect;
export const insertMmStandardAccountSchema = createInsertSchema(mmStandardAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertMmStandardAccount = z.infer<typeof insertMmStandardAccountSchema>;

// 2. Chart of Accounts - User-imported COA
export const chartOfAccounts = pgTable('chart_of_accounts', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  source: text('source').notNull(),
  externalSystem: text('external_system'),
  externalAccountId: text('external_account_id'),
  accountNumber: text('account_number'),
  accountName: text('account_name').notNull(),
  accountType: text('account_type').notNull(),
  detailType: text('detail_type'),
  parentExternalId: text('parent_external_id'),
  parentId: varchar('parent_id'),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  orgIdx: index('coa_org_idx').on(table.orgId),
  externalIdx: index('coa_external_idx').on(table.orgId, table.externalAccountId),
}));

export type ChartOfAccount = typeof chartOfAccounts.$inferSelect;
export const insertChartOfAccountSchema = createInsertSchema(chartOfAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountSchema>;

// 3. COA Mapping - COA → Standard Account mapping
export const coaMapping = pgTable('coa_mapping', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  coaAccountId: varchar('coa_account_id').notNull().references(() => chartOfAccounts.id, { onDelete: 'cascade' }),
  mmStandardAccountId: varchar('mm_standard_account_id').notNull().references(() => mmStandardAccounts.id),
  confidenceScore: numeric('confidence_score', { precision: 5, scale: 2 }).default('0'),
  mappingSource: text('mapping_source').notNull(),
  notes: text('notes'),
  locked: boolean('locked').default(true),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  orgCoaUnique: unique('coa_mapping_org_coa_unique').on(table.orgId, table.coaAccountId),
  orgIdx: index('coa_mapping_org_idx').on(table.orgId),
  coaAccountIdx: index('coa_mapping_coa_idx').on(table.coaAccountId),
  mmStdAcctIdx: index('coa_mapping_std_acct_idx').on(table.mmStandardAccountId),
}));

export type CoaMapping = typeof coaMapping.$inferSelect;
export const insertCoaMappingSchema = createInsertSchema(coaMapping).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCoaMapping = z.infer<typeof insertCoaMappingSchema>;

// 4. COA Mapping Suggestions - AI/rule suggestion staging
export const coaMappingSuggestions = pgTable('coa_mapping_suggestions', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  coaAccountId: varchar('coa_account_id').notNull().references(() => chartOfAccounts.id, { onDelete: 'cascade' }),
  suggestedMmStandardAccountId: varchar('suggested_mm_standard_account_id').notNull().references(() => mmStandardAccounts.id),
  confidenceScore: numeric('confidence_score', { precision: 5, scale: 2 }).default('0'),
  rationale: text('rationale'),
  status: text('status').notNull().default('pending'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  orgIdx: index('coa_suggestions_org_idx').on(table.orgId),
  coaAccountIdx: index('coa_suggestions_coa_idx').on(table.coaAccountId),
  statusIdx: index('coa_suggestions_status_idx').on(table.status),
}));

export type CoaMappingSuggestion = typeof coaMappingSuggestions.$inferSelect;
export const insertCoaMappingSuggestionSchema = createInsertSchema(coaMappingSuggestions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertCoaMappingSuggestion = z.infer<typeof insertCoaMappingSuggestionSchema>;

// 5. Financial Line Items Normalized - Normalized output
export const financialLineItemsNormalized = pgTable('financial_line_items_normalized', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  projectId: varchar('project_id').references(() => modelingProjects.id),
  sourceDocId: varchar('source_doc_id').references(() => docIntelUploads.id),
  periodStart: date('period_start').notNull(),
  periodEnd: date('period_end').notNull(),
  currency: text('currency').default('USD'),
  coaAccountId: varchar('coa_account_id').references(() => chartOfAccounts.id),
  rawCategoryName: text('raw_category_name'),
  rawLineName: text('raw_line_name').notNull(),
  amount: numeric('amount', { precision: 14, scale: 2 }).notNull(),
  mmStandardAccountId: varchar('mm_standard_account_id').references(() => mmStandardAccounts.id),
  categoryGroup: text('category_group'),
  profitCenterTag: text('profit_center_tag'),
  confidenceScore: numeric('confidence_score', { precision: 5, scale: 2 }).default('0'),
  classificationSource: text('classification_source').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  orgPeriodIdx: index('flin_org_period_idx').on(table.orgId, table.periodStart),
  projectPeriodIdx: index('flin_project_period_idx').on(table.projectId, table.periodStart),
  stdAcctPeriodIdx: index('flin_std_acct_period_idx').on(table.mmStandardAccountId, table.periodStart),
}));

export type FinancialLineItemNormalized = typeof financialLineItemsNormalized.$inferSelect;
export const insertFinancialLineItemNormalizedSchema = createInsertSchema(financialLineItemsNormalized).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertFinancialLineItemNormalized = z.infer<typeof insertFinancialLineItemNormalizedSchema>;

// 6. COA Audit Log - Audit trail
export const coaAuditLog = pgTable('coa_audit_log', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  userId: varchar('user_id').references(() => users.id),
  action: text('action').notNull(),
  entityType: text('entity_type').notNull(),
  entityId: varchar('entity_id'),
  metadata: jsonb('metadata'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('coa_audit_org_idx').on(table.orgId),
  actionIdx: index('coa_audit_action_idx').on(table.action),
  entityTypeIdx: index('coa_audit_entity_type_idx').on(table.entityType),
}));

export type CoaAuditLog = typeof coaAuditLog.$inferSelect;
export const insertCoaAuditLogSchema = createInsertSchema(coaAuditLog).omit({
  id: true,
  createdAt: true,
});
export type InsertCoaAuditLog = z.infer<typeof insertCoaAuditLogSchema>;

// OpsOS Insert Schemas (Zod-based validation)
export const insertOpssosConversationSchema = createInsertSchema(opssosConversations).omit({
  id: true,
  createdAt: true,
  lastMessageAt: true,
});
export const insertOpssosMessageSchema = createInsertSchema(opssosMessages).omit({
  id: true,
  createdAt: true,
  sentAt: true,
});
export const insertOpssosMessageTemplateSchema = createInsertSchema(opssosMessageTemplates).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosAutomationRuleSchema = createInsertSchema(opssosAutomationRules).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosAutomationRunSchema = createInsertSchema(opssosAutomationRuns).omit({
  id: true,
  createdAt: true,
  startedAt: true,
  finishedAt: true,
});
export const insertOpssosScheduledJobSchema = createInsertSchema(opssosScheduledJobs).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosTaskSchema = createInsertSchema(opssosTasks).omit({
  id: true,
  createdAt: true,
});

// =============================================
// Custom Catalog Items (Unified Profit Centers & Amenities)
// =============================================

export const customCatalogItems = pgTable("custom_catalog_items", {
  id: varchar("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  orgId: varchar("org_id").notNull(),
  type: text("type").notNull(), // 'profit_center' | 'amenity'
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon").default('store'),
  category: text("category"), // for profit_center: core/ancillary/specialty; for amenity: facility/utility/recreation/convenience
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => [
  index("custom_catalog_org_type_idx").on(table.orgId, table.type),
]);

export const insertCustomCatalogItemSchema = createInsertSchema(customCatalogItems).omit({
  id: true,
  createdAt: true,
});

export type CustomCatalogItem = typeof customCatalogItems.$inferSelect;
export type InsertCustomCatalogItem = z.infer<typeof insertCustomCatalogItemSchema>;

export const insertOpssosChecklistTemplateSchema = createInsertSchema(opssosChecklistTemplates).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosTaskChecklistSchema = createInsertSchema(opssosTaskChecklists).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosStatementTemplateSchema = createInsertSchema(opssosStatementTemplates).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosStatementSchema = createInsertSchema(opssosStatements).omit({
  id: true,
  createdAt: true,
  generatedAt: true,
  publishedAt: true,
});
export const insertOpssosStatementExportSchema = createInsertSchema(opssosStatementExports).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosIntegrationSchema = createInsertSchema(opssosIntegrations).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosWebhookSchema = createInsertSchema(opssosWebhooks).omit({
  id: true,
  createdAt: true,
});
export const insertOpssosWebhookDeliverySchema = createInsertSchema(opssosWebhookDeliveries).omit({
  id: true,
  createdAt: true,
});

// =====================
// COMMERCIAL TENANTS MODULE
// =====================

// Enums for commercial lease types and structures
export const leaseTypeEnum = pgEnum("lease_type", ["nnn", "modified_gross", "full_service", "absolute_net", "double_net"]);
export const escalationTypeEnum = pgEnum("escalation_type", ["fixed_dollar", "fixed_percent", "cpi", "fair_market_value", "none"]);
export const rentStructureEnum = pgEnum("rent_structure", ["base_only", "base_plus_percentage", "percentage_only"]);
export const tenantStatusEnum = pgEnum("tenant_status", ["active", "pending", "expired", "terminated", "month_to_month"]);


// New enums for institutional-grade commercial tenant fields
export const tenantTypeEnum = pgEnum("tenant_type", ["national", "regional", "local", "mom_pop"]);
export const assetClassTemplateEnum = pgEnum("asset_class_template", ["retail", "office", "industrial", "marina", "mixed_use", "other"]);
export const abatementTimingEnum = pgEnum("abatement_timing", ["upfront", "spread", "custom"]);
export const recoveryStructureEnum = pgEnum("recovery_structure", ["nnn", "base_year_stop", "expense_stop", "mod_gross"]);
export const utilitiesResponsibilityEnum = pgEnum("utilities_responsibility", ["landlord", "tenant", "submetered"]);
export const optionTypeEnum = pgEnum("option_type", ["renewal", "expansion", "termination", "rofr", "rofo", "other"]);
export const rentResetMethodEnum = pgEnum("rent_reset_method", ["fixed_pct", "fixed_amt", "cpi", "fmv", "tbd"]);
export const tiStructureTypeEnum = pgEnum("ti_structure_type", ["landlord", "tenant", "shared"]);
export const commissionTypeEnum = pgEnum("commission_type", ["pct_total_rent", "pct_base_year", "flat"]);
export const commissionTimingEnum = pgEnum("commission_timing", ["upfront", "spread", "custom"]);
// Commercial Tenants - Main tenant/lease records
export const commercialTenants = pgTable('commercial_tenants', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),

  // Link to marina/modeling project
  modelingProjectId: varchar('modeling_project_id').references(() => modelingProjects.id, { onDelete: 'cascade' }),
  marinaId: varchar('marina_id'), // For owned marinas
  ddProjectId: varchar('dd_project_id').references(() => projects.id), // Link to DD project for underwriting

  // Basic Tenant Information
  tenantName: text('tenant_name').notNull(),
  tradeName: text('trade_name'), // DBA name if different
  contactName: text('contact_name'),
  contactEmail: text('contact_email'),
  contactPhone: text('contact_phone'),

  // Space Information
  suiteNumber: text('suite_number'),
  squareFootage: decimal('square_footage', { precision: 12, scale: 2 }),
  proRataShare: decimal('pro_rata_share', { precision: 8, scale: 4 }), // Percentage (e.g., 12.5000%)
  permittedUse: text('permitted_use'),
  useRestrictions: text('use_restrictions'),

  // Lease Dates
  leaseExecutionDate: date('lease_execution_date'),
  leaseCommencementDate: date('lease_commencement_date').notNull(),
  rentStartDate: date('rent_start_date'),
  leaseExpirationDate: date('lease_expiration_date').notNull(),

  // Lease Structure
  leaseType: leaseTypeEnum('lease_type').notNull().default('nnn'),
  rentStructure: rentStructureEnum('rent_structure').notNull().default('base_only'),
  tenantStatus: tenantStatusEnum('tenant_status').notNull().default('active'),

  // Base Rent
  currentBaseRent: decimal('current_base_rent', { precision: 15, scale: 2 }), // Annual amount
  baseRentPerSF: decimal('base_rent_per_sf', { precision: 10, scale: 2 }), // Per SF per year
  rentFreePeriodMonths: integer('rent_free_period_months').default(0),

  // Rent Escalations
  escalationType: escalationTypeEnum('escalation_type').default('fixed_percent'),
  escalationRate: decimal('escalation_rate', { precision: 6, scale: 4 }), // e.g., 0.0300 = 3%
  escalationAmount: decimal('escalation_amount', { precision: 10, scale: 2 }), // Fixed dollar increase per SF
  escalationFrequency: integer('escalation_frequency').default(12), // Months between escalations
  nextEscalationDate: date('next_escalation_date'),
  cpiIndex: text('cpi_index'), // e.g., "CPI-U All Urban Consumers"
  cpiFloor: decimal('cpi_floor', { precision: 6, scale: 4 }), // Minimum CPI increase
  cpiCeiling: decimal('cpi_ceiling', { precision: 6, scale: 4 }), // Maximum CPI increase

  // Security Deposit
  securityDeposit: decimal('security_deposit', { precision: 15, scale: 2 }),
  letterOfCreditAmount: decimal('letter_of_credit_amount', { precision: 15, scale: 2 }),
  guarantorName: text('guarantor_name'),
  guarantorType: text('guarantor_type'), // Personal, corporate, etc.

  // Percentage Rent (Retail-specific)
  percentageRentRate: decimal('percentage_rent_rate', { precision: 6, scale: 4 }), // e.g., 0.0600 = 6%
  naturalBreakpoint: decimal('natural_breakpoint', { precision: 18, scale: 2 }), // Calculated: base rent / %
  artificialBreakpoint: decimal('artificial_breakpoint', { precision: 18, scale: 2 }), // Negotiated
  salesReportingFrequency: text('sales_reporting_frequency'), // Monthly, quarterly, annually
  lastReportedSales: decimal('last_reported_sales', { precision: 18, scale: 2 }),
  lastReportedSalesDate: date('last_reported_sales_date'),
  auditRights: boolean('audit_rights').default(false),

  // NNN / Operating Expenses
  estimatedCamPerSF: decimal('estimated_cam_per_sf', { precision: 10, scale: 2 }),
  estimatedTaxPerSF: decimal('estimated_tax_per_sf', { precision: 10, scale: 2 }),
  estimatedInsurancePerSF: decimal('estimated_insurance_per_sf', { precision: 10, scale: 2 }),
  totalEstimatedNNN: decimal('total_estimated_nnn', { precision: 15, scale: 2 }), // Annual
  camCapPercent: decimal('cam_cap_percent', { precision: 6, scale: 4 }), // Annual increase cap
  baseYearExpenses: decimal('base_year_expenses', { precision: 15, scale: 2 }), // For modified gross
  baseYear: integer('base_year'), // Year for expense stops
  controllableCamCap: decimal('controllable_cam_cap', { precision: 6, scale: 4 }),
  excludedCamItems: text('excluded_cam_items').array(), // Items tenant doesn't pay
  adminFeePercent: decimal('admin_fee_percent', { precision: 6, scale: 4 }), // Management fee on CAM

  // Renewal Options
  renewalOptions: integer('renewal_options').default(0), // Number of options
  renewalTermYears: integer('renewal_term_years'), // Length of each renewal
  renewalNoticeMonths: integer('renewal_notice_months'), // Notice period required
  renewalRentTerms: text('renewal_rent_terms'), // FMV, fixed increase, etc.

  // Termination Rights
  hasTerminationOption: boolean('has_termination_option').default(false),
  terminationOptionDate: date('termination_option_date'),
  terminationFee: decimal('termination_fee', { precision: 15, scale: 2 }),
  terminationNoticeMonths: integer('termination_notice_months'),

  // Expansion Rights
  hasExpansionOption: boolean('has_expansion_option').default(false),
  rofrSquareFootage: decimal('rofr_square_footage', { precision: 12, scale: 2 }), // Right of first refusal SF
  expansionNoticeMonths: integer('expansion_notice_months'),

  // Co-Tenancy (Retail-specific)
  hasOpeningCoTenancy: boolean('has_opening_co_tenancy').default(false),
  openingCoTenancyRequirements: text('opening_co_tenancy_requirements'),
  hasOperatingCoTenancy: boolean('has_operating_co_tenancy').default(false),
  operatingCoTenancyRequirements: text('operating_co_tenancy_requirements'),
  coTenancyRemedies: text('co_tenancy_remedies'), // Rent reduction, termination, etc.

  // Operating Requirements
  requiredOperatingHours: text('required_operating_hours'),
  canGoDark: boolean('can_go_dark').default(false),
  exclusiveUseClause: text('exclusive_use_clause'),
  signageRights: text('signage_rights'),
  parkingSpaces: integer('parking_spaces'),

  // TI Allowance
  tiAllowance: decimal('ti_allowance', { precision: 15, scale: 2 }),
  tiAllowancePerSF: decimal('ti_allowance_per_sf', { precision: 10, scale: 2 }),
  tiDeliveryCondition: text('ti_delivery_condition'), // Shell, turnkey, etc.

  // Maintenance Responsibilities
  tenantMaintenance: text('tenant_maintenance').array(), // HVAC, interior, etc.
  landlordMaintenance: text('landlord_maintenance').array(), // Roof, structure, etc.
  hvacResponsibility: text('hvac_responsibility'), // Tenant or landlord

  // Insurance Requirements
  requiredLiabilityLimit: decimal('required_liability_limit', { precision: 15, scale: 2 }),
  requiredPropertyLimit: decimal('required_property_limit', { precision: 15, scale: 2 }),

  // Document references
  leaseDocumentId: varchar('lease_document_id'), // VDR document reference
  originalLeasePageRef: text('original_lease_page_ref'), // Page numbers for abstracted items

  // Import/parse metadata
  importSource: text('import_source'), // manual, pdf_parse, excel_import
  parseConfidence: decimal('parse_confidence', { precision: 5, scale: 2 }), // AI confidence score
  needsReview: boolean('needs_review').default(false),
  reviewedAt: timestamp('reviewed_at'),
  reviewedBy: varchar('reviewed_by').references(() => users.id),

  // Notes and custom fields
  notes: text('notes'),
  customFields: jsonb('custom_fields').default(sql`'{}'`),


  // --- Institutional-grade fields (migration-v2) ---
  tenantType: tenantTypeEnum('tenant_type'),
  industry: text('industry'),
  tenantWebsite: text('tenant_website'),
  spaceType: text('space_type'),
  building: text('building'),
  possessionDate: date('possession_date'),
  assetClassTemplate: assetClassTemplateEnum('asset_class_template').default('other'),
  advancedModeEnabled: boolean('advanced_mode_enabled').default(false),
  billingFrequency: billingFrequencyEnum('billing_frequency').default('monthly'),
  abatementTiming: abatementTimingEnum('abatement_timing').default('upfront'),
  breakpointType: text('breakpoint_type').default('natural'),
  trueUpMonth: integer('true_up_month'),
  recoveryStructure: recoveryStructureEnum('recovery_structure').default('nnn'),
  reconMonth: integer('recon_month'),
  utilitiesResponsibility: utilitiesResponsibilityEnum('utilities_responsibility').default('tenant'),
  tiStructure: tiStructureTypeEnum('ti_structure').default('landlord'),
  commissionType: commissionTypeEnum('commission_type'),
  commissionValue: decimal('commission_value', { precision: 10, scale: 2 }),
  commissionTiming: commissionTimingEnum('commission_timing').default('upfront'),
  amortizeTi: boolean('amortize_ti').default(false),
  amortizationTermMonths: integer('amortization_term_months'),
  amortizationRate: decimal('amortization_rate', { precision: 6, scale: 4 }),
  internalRiskRating: integer('internal_risk_rating'),
  underwritingNotes: text('underwriting_notes'),
  assignmentClause: boolean('assignment_clause').default(false),
  subleaseClause: boolean('sublease_clause').default(false),
  additionalInsured: boolean('additional_insured').default(false),
  glLimits: text('gl_limits'),
  createdByRole: text('created_by_role'),
  // Audit
  createdBy: varchar('created_by').notNull().references(() => users.id),
  updatedBy: varchar('updated_by').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('commercial_tenants_org_idx').on(table.orgId),
  modelingProjectIdx: index('commercial_tenants_modeling_project_idx').on(table.modelingProjectId),
  marinaIdx: index('commercial_tenants_marina_idx').on(table.marinaId),
  tenantNameIdx: index('commercial_tenants_tenant_name_idx').on(table.tenantName),
  statusIdx: index('commercial_tenants_status_idx').on(table.tenantStatus),
  expirationIdx: index('commercial_tenants_expiration_idx').on(table.leaseExpirationDate),
}));

// Commercial Tenant Rent Schedule - Multi-year rent projections
export const commercialTenantRentSchedule = pgTable('commercial_tenant_rent_schedule', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar('tenant_id').notNull().references(() => commercialTenants.id, { onDelete: 'cascade' }),

  periodStart: date('period_start').notNull(),
  periodEnd: date('period_end').notNull(),
  yearNumber: integer('year_number').notNull(), // 1, 2, 3, etc.

  baseRentAnnual: decimal('base_rent_annual', { precision: 15, scale: 2 }),
  baseRentMonthly: decimal('base_rent_monthly', { precision: 15, scale: 2 }),
  baseRentPerSF: decimal('base_rent_per_sf', { precision: 10, scale: 2 }),

  estimatedPercentageRent: decimal('estimated_percentage_rent', { precision: 15, scale: 2 }),
  estimatedNNNAnnual: decimal('estimated_nnn_annual', { precision: 15, scale: 2 }),
  totalRentAnnual: decimal('total_rent_annual', { precision: 15, scale: 2 }),

  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  tenantIdx: index('rent_schedule_tenant_idx').on(table.tenantId),
  periodIdx: index('rent_schedule_period_idx').on(table.periodStart, table.periodEnd),
}));

// Commercial Tenant Amendments - Track lease modifications
export const commercialTenantAmendments = pgTable('commercial_tenant_amendments', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar('tenant_id').notNull().references(() => commercialTenants.id, { onDelete: 'cascade' }),

  amendmentNumber: integer('amendment_number').notNull(),
  effectiveDate: date('effective_date').notNull(),
  executionDate: date('execution_date'),

  amendmentType: text('amendment_type'), // Extension, rent modification, space change, etc.
  summary: text('summary').notNull(),
  changedFields: jsonb('changed_fields').default(sql`'{}'`), // Field name -> old/new values

  documentId: varchar('document_id'), // VDR reference
  notes: text('notes'),

  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  tenantIdx: index('amendments_tenant_idx').on(table.tenantId),
  dateIdx: index('amendments_date_idx').on(table.effectiveDate),
}));

// Commercial Tenant Scenarios - For Valuator modeling flexibility
export const commercialTenantScenarios = pgTable('commercial_tenant_scenarios', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar('tenant_id').notNull().references(() => commercialTenants.id, { onDelete: 'cascade' }),
  modelingProjectId: varchar('modeling_project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),

  scenarioName: text('scenario_name').notNull(), // Base Case, Aggressive, Conservative, Custom
  caseType: text('case_type').notNull().default('custom'), // base, aggressive, conservative, custom

  // Override values for this scenario (null = use base lease values)
  overrideBaseRent: decimal('override_base_rent', { precision: 15, scale: 2 }),
  overrideEscalationRate: decimal('override_escalation_rate', { precision: 6, scale: 4 }),
  overridePercentageRent: decimal('override_percentage_rent', { precision: 6, scale: 4 }),
  overrideNNNPerSF: decimal('override_nnn_per_sf', { precision: 10, scale: 2 }),
  overrideVacancyRate: decimal('override_vacancy_rate', { precision: 6, scale: 4 }),

  // Renewal assumptions
  assumeRenewal: boolean('assume_renewal').default(true),
  renewalProbability: decimal('renewal_probability', { precision: 5, scale: 2 }), // e.g., 75%
  renewalRentBumpPercent: decimal('renewal_rent_bump_percent', { precision: 6, scale: 4 }),

  // Downtime assumptions
  releaseDowntimeMonths: integer('release_downtime_months').default(6),
  releaseCommissionPercent: decimal('release_commission_percent', { precision: 6, scale: 4 }),
  releaseTIPerSF: decimal('release_ti_per_sf', { precision: 10, scale: 2 }),

  notes: text('notes'),
  isActive: boolean('is_active').default(true),

  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  tenantIdx: index('tenant_scenarios_tenant_idx').on(table.tenantId),
  projectIdx: index('tenant_scenarios_project_idx').on(table.modelingProjectId),
  caseTypeIdx: index('tenant_scenarios_case_type_idx').on(table.caseType),
}));

// Commercial Tenant Options - Repeatable lease options (renewal, expansion, termination, ROFR, etc.)
export const commercialTenantOptions = pgTable('commercial_tenant_options', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar('tenant_id').notNull().references(() => commercialTenants.id, { onDelete: 'cascade' }),
  optionType: optionTypeEnum('option_type').notNull().default('renewal'),
  noticeMonths: integer('notice_months'),
  optionTermMonths: integer('option_term_months'),
  rentResetMethod: rentResetMethodEnum('rent_reset_method').default('tbd'),
  rentResetValue: decimal('rent_reset_value', { precision: 10, scale: 4 }),
  effectiveDate: date('effective_date'),
  conditions: text('conditions'),
  assumeInUnderwriting: boolean('assume_in_underwriting').default(false),
  sortOrder: integer('sort_order').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  tenantIdx: index('tenant_options_tenant_idx').on(table.tenantId),
}));


// Import types and validation schemas
export const insertCommercialTenantSchema = createInsertSchema(commercialTenants).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const insertCommercialTenantRentScheduleSchema = createInsertSchema(commercialTenantRentSchedule).omit({
  id: true,
  createdAt: true,
});
export const insertCommercialTenantAmendmentSchema = createInsertSchema(commercialTenantAmendments).omit({
  id: true,
  createdAt: true,
});
export const insertCommercialTenantScenarioSchema = createInsertSchema(commercialTenantScenarios).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type CommercialTenant = typeof commercialTenants.$inferSelect;
export type InsertCommercialTenant = z.infer<typeof insertCommercialTenantSchema>;
export type CommercialTenantRentSchedule = typeof commercialTenantRentSchedule.$inferSelect;
export type InsertCommercialTenantRentSchedule = z.infer<typeof insertCommercialTenantRentScheduleSchema>;
export type CommercialTenantAmendment = typeof commercialTenantAmendments.$inferSelect;
export type InsertCommercialTenantAmendment = z.infer<typeof insertCommercialTenantAmendmentSchema>;
export type CommercialTenantScenario = typeof commercialTenantScenarios.$inferSelect;
export type InsertCommercialTenantScenario = z.infer<typeof insertCommercialTenantScenarioSchema>;

export const insertCommercialTenantOptionSchema = createInsertSchema(commercialTenantOptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type CommercialTenantOption = typeof commercialTenantOptions.$inferSelect;
export type InsertCommercialTenantOption = z.infer<typeof insertCommercialTenantOptionSchema>;

// ============================================================================
// User Tour Progress - Track page tour completion and preferences
// ============================================================================

export const userTourProgress = pgTable("user_tour_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  tourId: varchar("tour_id", { length: 100 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("completed"), // completed, skipped, in_progress
  lastStepIndex: integer("last_step_index").default(0),
  totalSteps: integer("total_steps"),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => ({
  userTourUnique: unique().on(table.userId, table.tourId),
  userIdIdx: index("user_tour_progress_user_id_idx").on(table.userId),
}));

export const insertUserTourProgressSchema = createInsertSchema(userTourProgress).omit({
  id: true,
  completedAt: true,
  createdAt: true,
});
export type UserTourProgress = typeof userTourProgress.$inferSelect;
export type InsertUserTourProgress = z.infer<typeof insertUserTourProgressSchema>;

// ============================================================================
// Analytics Report Schedules - For scheduled email reports
// ============================================================================

export const reportFrequencyEnum = pgEnum("report_frequency", ["daily", "weekly", "monthly"]);

export const analyticsReportSchedules = pgTable("analytics_report_schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  reportType: varchar("report_type", { length: 100 }).notNull(), // unified, crm, dd, modeling, operations
  name: varchar("name", { length: 255 }).notNull(),
  frequency: reportFrequencyEnum("frequency").notNull(),
  dayOfWeek: integer("day_of_week"), // 0-6 for weekly (Sunday = 0)
  dayOfMonth: integer("day_of_month"), // 1-31 for monthly
  timeOfDay: time("time_of_day").notNull().default('09:00:00'),
  timezone: varchar("timezone", { length: 100 }).notNull().default('America/New_York'),
  recipients: text("recipients").array().notNull().default(sql`'{}'`), // Array of email addresses
  filters: jsonb("filters").default(sql`'{}'`), // JSON object with filter settings
  includeCharts: boolean("include_charts").notNull().default(true),
  isActive: boolean("is_active").notNull().default(true),
  lastRunAt: timestamp("last_run_at"),
  nextRunAt: timestamp("next_run_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  userIdx: index("analytics_report_schedules_user_idx").on(table.userId),
  orgIdx: index("analytics_report_schedules_org_idx").on(table.orgId),
  nextRunIdx: index("analytics_report_schedules_next_run_idx").on(table.nextRunAt),
}));

export const insertAnalyticsReportScheduleSchema = createInsertSchema(analyticsReportSchedules).omit({
  id: true,
  lastRunAt: true,
  nextRunAt: true,
  createdAt: true,
  updatedAt: true,
});
export type AnalyticsReportSchedule = typeof analyticsReportSchedules.$inferSelect;
export type InsertAnalyticsReportSchedule = z.infer<typeof insertAnalyticsReportScheduleSchema>;

// Replit Auth models

// ============================================================================
// OPERATIONS + VALUATOR DUAL-CONTEXT ARCHITECTURE
// Portfolios, Marinas, Actuals (ops_*), Assumptions (asmp_*), Import Events
// ============================================================================

// Ownership Status Enum - Determines data context
export const ownershipStatusEnum = pgEnum("ownership_status", ["OWNED", "DEAL"]);

// Import Scope Enum - For import operations
export const importScopeEnum = pgEnum("import_scope", [
  "ALL", "FUEL", "SHIP_STORE", "SERVICE", "TENANTS", "RENTALS", "CLUB", "BOAT_SALES", "BOOKKEEPING"
]);

// Data Source Enum - Track where data came from
export const opsDataSourceEnum = pgEnum("ops_data_source", ["MANUAL", "CSV_IMPORT", "INTEGRATION", "QBO"]);

// Valuator Project Type Enum
export const valuatorProjectTypeEnum = pgEnum("valuator_project_type", ["OWNED", "ACQUISITION", "BROKER_LISTING"]);

// ============================================================================
// Portfolios - Grouping for owned marinas
// ============================================================================
export const opsPortfolios = pgTable("ops_portfolios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  description: text("description"),
  currency: varchar("currency", { length: 3 }).default("USD"),
  timezone: varchar("timezone", { length: 50 }).default("America/New_York"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("ops_portfolios_user_idx").on(table.userId),
  orgIdx: index("ops_portfolios_org_idx").on(table.orgId),
}));

// ============================================================================
// Marinas - Properties within portfolios
// ============================================================================
export const opsMarinas = pgTable("ops_marinas", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  portfolioId: varchar("portfolio_id").notNull().references(() => opsPortfolios.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  name: text("name").notNull(),
  address: text("address"),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 50 }),
  zip: varchar("zip", { length: 20 }),
  country: varchar("country", { length: 50 }).default("USA"),
  ownershipStatus: ownershipStatusEnum("ownership_status").notNull().default("OWNED"),
  // Operational info
  totalSlips: integer("total_slips").default(0),
  totalDryStorage: integer("total_dry_storage").default(0),
  totalSqft: integer("total_sqft").default(0),
  seasonStartMonth: integer("season_start_month").default(4), // April
  seasonEndMonth: integer("season_end_month").default(10), // October
  // Integration hooks
  integrationId: varchar("integration_id"), // Link to marina integration
  lastSyncAt: timestamp("last_sync_at"),
  isActive: boolean("is_active").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  portfolioIdx: index("ops_marinas_portfolio_idx").on(table.portfolioId),
  orgIdx: index("ops_marinas_org_idx").on(table.orgId),
  ownershipIdx: index("ops_marinas_ownership_idx").on(table.ownershipStatus),
}));

// ============================================================================
// OPS_FUEL_TRANSACTIONS - Supports dual context: Operations (marinaId) and Valuator (modelingProjectId)
// ============================================================================
export const opsFuelTransactions = pgTable("ops_fuel_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  modelingProjectId: varchar("modeling_project_id").references(() => modelingProjects.id, { onDelete: "cascade" }),
  txnDate: date("txn_date").notNull(),
  fuelType: varchar("fuel_type", { length: 50 }).notNull(), // diesel, ethanol, rec90, etc.
  gallons: decimal("gallons", { precision: 12, scale: 4 }).notNull(),
  grossSales: decimal("gross_sales", { precision: 14, scale: 2 }).notNull(),
  cogs: decimal("cogs", { precision: 14, scale: 2 }).notNull(),
  vendor: varchar("vendor", { length: 100 }),
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaDateIdx: index("ops_fuel_marina_date_idx").on(table.marinaId, table.txnDate),
  orgIdx: index("ops_fuel_org_idx").on(table.orgId),
  modelingProjectIdx: index("ops_fuel_modeling_project_idx").on(table.modelingProjectId),
}));

// ============================================================================
// OPS_SHIP_STORE_SALES - Supports dual context: Operations (marinaId) and Valuator (modelingProjectId)
// ============================================================================
export const opsShipStoreSales = pgTable("ops_ship_store_sales", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  modelingProjectId: varchar("modeling_project_id").references(() => modelingProjects.id, { onDelete: "cascade" }),
  txnDate: date("txn_date").notNull(),
  category: varchar("category", { length: 100 }).notNull(), // parts, accessories, apparel, etc.
  grossSales: decimal("gross_sales", { precision: 14, scale: 2 }).notNull(),
  cogs: decimal("cogs", { precision: 14, scale: 2 }).notNull(),
  txnCount: integer("txn_count").default(1),
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaDateIdx: index("ops_ship_store_marina_date_idx").on(table.marinaId, table.txnDate),
  orgIdx: index("ops_ship_store_org_idx").on(table.orgId),
  modelingProjectIdx: index("ops_ship_store_modeling_project_idx").on(table.modelingProjectId),
}));

// ============================================================================
// OPS_SERVICE_WORK_ORDERS - Service department actuals
// ============================================================================
export const opsServiceWorkOrders = pgTable("ops_service_work_orders", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  modelingProjectId: varchar("modeling_project_id").references(() => modelingProjects.id, { onDelete: "cascade" }),
  openDate: date("open_date").notNull(),
  closeDate: date("close_date"),
  laborRevenue: decimal("labor_revenue", { precision: 14, scale: 2 }).default("0"),
  partsRevenue: decimal("parts_revenue", { precision: 14, scale: 2 }).default("0"),
  cogs: decimal("cogs", { precision: 14, scale: 2 }).default("0"),
  status: varchar("status", { length: 20 }).default("open"),
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaOpenIdx: index("ops_service_marina_open_idx").on(table.marinaId, table.openDate),
  orgIdx: index("ops_service_org_idx").on(table.orgId),
  modelingProjectIdx: index("ops_service_modeling_project_idx").on(table.modelingProjectId),
}));
// ============================================================================
// OPS_BOAT_RENTALS - Boat rental actuals
export const opsBoatRentals = pgTable("ops_boat_rentals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  modelingProjectId: varchar("modeling_project_id").references(() => modelingProjects.id, { onDelete: "cascade" }),
  rentalDate: date("rental_date").notNull(),
  hours: decimal("hours", { precision: 8, scale: 2 }).notNull(),
  grossSales: decimal("gross_sales", { precision: 14, scale: 2 }).notNull(),
  channel: varchar("channel", { length: 50 }),
  boatType: varchar("boat_type", { length: 100 }),
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaDateIdx: index("ops_boat_rentals_marina_date_idx").on(table.marinaId, table.rentalDate),
  orgIdx: index("ops_boat_rentals_org_idx").on(table.orgId),
  modelingProjectIdx: index("ops_boat_rentals_modeling_project_idx").on(table.modelingProjectId),
}));

// ============================================================================
// OPS_BOAT_CLUB_MEMBERSHIPS - Boat club membership actuals
// ============================================================================
export const opsBoatClubMemberships = pgTable("ops_boat_club_memberships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").notNull().references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  memberId: varchar("member_id", { length: 100 }).notNull(),
  memberName: text("member_name"),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  tier: varchar("tier", { length: 50 }), // standard, premium, vip
  monthlyDues: decimal("monthly_dues", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 20 }).default("active"), // active, paused, cancelled
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaIdx: index("ops_boat_club_marina_idx").on(table.marinaId),
  orgIdx: index("ops_boat_club_org_idx").on(table.orgId),
}));

// ============================================================================
// OPS_BOAT_SALES - Boat sales actuals
// ============================================================================
export const opsBoatSales = pgTable("ops_boat_sales", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").notNull().references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  saleDate: date("sale_date").notNull(),
  makeModel: varchar("make_model", { length: 200 }).notNull(),
  grossSales: decimal("gross_sales", { precision: 14, scale: 2 }).notNull(),
  cogs: decimal("cogs", { precision: 14, scale: 2 }).default("0"),
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaDateIdx: index("ops_boat_sales_marina_date_idx").on(table.marinaId, table.saleDate),
  orgIdx: index("ops_boat_sales_org_idx").on(table.orgId),
}));

// ============================================================================
// OPS_COMMERCIAL_LEASES - Commercial tenant lease actuals
// ============================================================================
export const opsCommercialLeases = pgTable("ops_commercial_leases", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").notNull().references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  tenantName: text("tenant_name").notNull(),
  unit: varchar("unit", { length: 50 }),
  sqft: integer("sqft").default(0),
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  baseRent: decimal("base_rent", { precision: 12, scale: 2 }).notNull(),
  cam: decimal("cam", { precision: 10, scale: 2 }).default("0"),
  percentRent: decimal("percent_rent", { precision: 10, scale: 2 }).default("0"),
  status: varchar("status", { length: 20 }).default("active"), // active, expired, terminated
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaIdx: index("ops_commercial_leases_marina_idx").on(table.marinaId),
  orgIdx: index("ops_commercial_leases_org_idx").on(table.orgId),
}));

// ============================================================================
// OPS_BOOKKEEPING_GL - General ledger actuals
// ============================================================================
export const opsBookkeepingGl = pgTable("ops_bookkeeping_gl", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").notNull().references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodStart: date("period_start").notNull(),
  periodEnd: date("period_end").notNull(),
  accountName: text("account_name").notNull(),
  accountType: varchar("account_type", { length: 50 }).notNull(), // revenue, expense, asset, liability
  amount: decimal("amount", { precision: 14, scale: 2 }).notNull(),
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaPeriodIdx: index("ops_bookkeeping_marina_period_idx").on(table.marinaId, table.periodStart),
  orgIdx: index("ops_bookkeeping_org_idx").on(table.orgId),
}));

// ============================================================================
// ASMP_FUEL - Fuel assumptions per valuator project
// ============================================================================
export const asmpFuel = pgTable("asmp_fuel", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(), // YYYY-MM-01
  gallons: decimal("gallons", { precision: 12, scale: 4 }),
  avgRetailPrice: decimal("avg_retail_price", { precision: 8, scale: 4 }),
  avgCostPrice: decimal("avg_cost_price", { precision: 8, scale: 4 }),
  marginPct: decimal("margin_pct", { precision: 6, scale: 4 }),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  seasonalIndex: decimal("seasonal_index", { precision: 6, scale: 4 }).default("1.0"),
  // Computed outputs (denormalized for efficiency)
  revenue: decimal("revenue", { precision: 14, scale: 2 }),
  cogs: decimal("cogs", { precision: 14, scale: 2 }),
  grossProfit: decimal("gross_profit", { precision: 14, scale: 2 }),
  // Audit
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }), // ACTUALS, TEMPLATE, MANUAL
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_fuel_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// ASMP_SHIP_STORE - Ship store assumptions per valuator project
// ============================================================================
export const asmpShipStore = pgTable("asmp_ship_store", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  revenue: decimal("revenue", { precision: 14, scale: 2 }),
  cogsPct: decimal("cogs_pct", { precision: 6, scale: 4 }),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  seasonalIndex: decimal("seasonal_index", { precision: 6, scale: 4 }).default("1.0"),
  txnCount: integer("txn_count"),
  avgTicket: decimal("avg_ticket", { precision: 10, scale: 2 }),
  // Computed
  cogs: decimal("cogs", { precision: 14, scale: 2 }),
  grossProfit: decimal("gross_profit", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_ship_store_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// ASMP_SERVICE - Service department assumptions
// ============================================================================
export const asmpService = pgTable("asmp_service", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  laborRevenue: decimal("labor_revenue", { precision: 14, scale: 2 }),
  partsRevenue: decimal("parts_revenue", { precision: 14, scale: 2 }),
  cogsPct: decimal("cogs_pct", { precision: 6, scale: 4 }),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  workOrderCount: integer("work_order_count"),
  // Computed
  totalRevenue: decimal("total_revenue", { precision: 14, scale: 2 }),
  cogs: decimal("cogs", { precision: 14, scale: 2 }),
  grossProfit: decimal("gross_profit", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_service_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// ASMP_COMMERCIAL_TENANTS - Commercial tenant assumptions
// ============================================================================
export const asmpCommercialTenants = pgTable("asmp_commercial_tenants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  tenantCount: integer("tenant_count"),
  totalSqft: integer("total_sqft"),
  occupiedSqft: integer("occupied_sqft"),
  avgRentPerSqft: decimal("avg_rent_per_sqft", { precision: 8, scale: 2 }),
  occupancyPct: decimal("occupancy_pct", { precision: 6, scale: 4 }),
  otherIncome: decimal("other_income", { precision: 12, scale: 2 }),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  // Computed
  baseRentRevenue: decimal("base_rent_revenue", { precision: 14, scale: 2 }),
  camRevenue: decimal("cam_revenue", { precision: 14, scale: 2 }),
  totalRevenue: decimal("total_revenue", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_tenants_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// ASMP_BOAT_RENTALS - Boat rental assumptions
// ============================================================================
export const asmpBoatRentals = pgTable("asmp_boat_rentals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  hours: decimal("hours", { precision: 10, scale: 2 }),
  avgRatePerHour: decimal("avg_rate_per_hour", { precision: 10, scale: 2 }),
  utilizationPct: decimal("utilization_pct", { precision: 6, scale: 4 }),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  // Computed
  revenue: decimal("revenue", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_boat_rentals_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// ASMP_BOAT_CLUB - Boat club assumptions
// ============================================================================
export const asmpBoatClub = pgTable("asmp_boat_club", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  memberCount: integer("member_count"),
  avgMonthlyDues: decimal("avg_monthly_dues", { precision: 10, scale: 2 }),
  churnPct: decimal("churn_pct", { precision: 6, scale: 4 }),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  // Computed
  monthlyRecurringRevenue: decimal("mrr", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_boat_club_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// ASMP_BOAT_SALES - Boat sales assumptions
// ============================================================================
export const asmpBoatSales = pgTable("asmp_boat_sales", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  units: integer("units"),
  avgSalePrice: decimal("avg_sale_price", { precision: 14, scale: 2 }),
  marginPct: decimal("margin_pct", { precision: 6, scale: 4 }),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  // Computed
  revenue: decimal("revenue", { precision: 14, scale: 2 }),
  cogs: decimal("cogs", { precision: 14, scale: 2 }),
  grossProfit: decimal("gross_profit", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_boat_sales_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// ASMP_BOOKKEEPING - Bookkeeping assumptions (simplified bridge)
// ============================================================================
export const asmpBookkeeping = pgTable("asmp_bookkeeping", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  revenueTotalOverride: decimal("revenue_total_override", { precision: 14, scale: 2 }),
  expenseTotalOverride: decimal("expense_total_override", { precision: 14, scale: 2 }),
  noiOverride: decimal("noi_override", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_bookkeeping_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// OPS_PARKING_LOT - Parking lot revenue actuals
// ============================================================================
export const opsParkingLot = pgTable("ops_parking_lot", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marinaId: varchar("marina_id").references(() => opsMarinas.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  modelingProjectId: varchar("modeling_project_id").references(() => modelingProjects.id, { onDelete: "cascade" }),
  txnDate: date("txn_date").notNull(),
  rateType: varchar("rate_type", { length: 30 }).notNull(),
  spacesUsed: integer("spaces_used").notNull().default(1),
  hours: decimal("hours", { precision: 8, scale: 2 }),
  grossRevenue: decimal("gross_revenue", { precision: 14, scale: 2 }).notNull(),
  dayType: varchar("day_type", { length: 20 }).default("weekday"),
  source: opsDataSourceEnum("source").default("MANUAL"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  marinaDateIdx: index("ops_parking_lot_marina_date_idx").on(table.marinaId, table.txnDate),
  orgIdx: index("ops_parking_lot_org_idx").on(table.orgId),
  modelingProjectIdx: index("ops_parking_lot_modeling_project_idx").on(table.modelingProjectId),
}));

// ============================================================================
// ASMP_PARKING_LOT - Parking lot assumptions for modeling
// ============================================================================
export const asmpParkingLot = pgTable("asmp_parking_lot", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  periodMonth: date("period_month").notNull(),
  totalSpaces: integer("total_spaces"),
  coveredSpaces: integer("covered_spaces"),
  uncoveredSpaces: integer("uncovered_spaces"),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }),
  dailyRate: decimal("daily_rate", { precision: 10, scale: 2 }),
  monthlyRate: decimal("monthly_rate", { precision: 10, scale: 2 }),
  eventRate: decimal("event_rate", { precision: 10, scale: 2 }),
  weekdayOccupancyPct: decimal("weekday_occupancy_pct", { precision: 6, scale: 4 }),
  weekendOccupancyPct: decimal("weekend_occupancy_pct", { precision: 6, scale: 4 }),
  monthlyPassCount: integer("monthly_pass_count"),
  growthPct: decimal("growth_pct", { precision: 6, scale: 4 }),
  revenue: decimal("revenue", { precision: 14, scale: 2 }),
  importedAt: timestamp("imported_at"),
  importSource: varchar("import_source", { length: 20 }),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectMonthIdx: index("asmp_parking_lot_project_month_idx").on(table.projectId, table.periodMonth),
  projectMonthUnique: unique().on(table.projectId, table.periodMonth),
}));

// ============================================================================
// OPS_IMPORT_EVENTS - Track imports from actuals to assumptions
// ============================================================================
export const opsImportEvents = pgTable("ops_import_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  marinaId: varchar("marina_id").notNull().references(() => opsMarinas.id),
  orgId: varchar("org_id").notNull().references(() => organizations.id),
  scope: importScopeEnum("scope").notNull(),
  rangeStart: date("range_start").notNull(),
  rangeEnd: date("range_end").notNull(),
  overwrite: boolean("overwrite").default(false),
  rowsWritten: integer("rows_written").default(0),
  monthsAffected: integer("months_affected").default(0),
  durationMs: integer("duration_ms"),
  status: varchar("status", { length: 20 }).default("completed"), // pending, completed, failed
  errorMessage: text("error_message"),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  projectIdx: index("ops_import_events_project_idx").on(table.projectId),
  projectCreatedIdx: index("ops_import_events_project_created_idx").on(table.projectId, table.createdAt),
}));

// ============================================================================
// VALUATOR PROJECT EXTENSION - Add project type and marina link
// Note: This is added as a new table to avoid modifying existing modelingProjects
// ============================================================================
export const valuatorProjectContext = pgTable("valuator_project_context", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }).unique(),
  marinaId: varchar("marina_id").references(() => opsMarinas.id),
  projectType: valuatorProjectTypeEnum("project_type").notNull().default("ACQUISITION"),
  defaultDataSource: varchar("default_data_source", { length: 20 }).default("ASSUMPTIONS"), // ACTUALS or ASSUMPTIONS
  lastImportAt: timestamp("last_import_at"),
  assumptionsCoverageMonths: integer("assumptions_coverage_months").default(0),
  orgId: varchar("org_id").references(() => organizations.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  projectIdx: index("valuator_context_project_idx").on(table.projectId),
  marinaIdx: index("valuator_context_marina_idx").on(table.marinaId),
}));

// ============================================================================
// Insert Schemas and Types
// ============================================================================
export const insertOpsPortfolioSchema = createInsertSchema(opsPortfolios).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsPortfolio = typeof opsPortfolios.$inferSelect;
export type InsertOpsPortfolio = z.infer<typeof insertOpsPortfolioSchema>;

export const insertOpsMarinaSchema = createInsertSchema(opsMarinas).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsMarina = typeof opsMarinas.$inferSelect;
export type InsertOpsMarina = z.infer<typeof insertOpsMarinaSchema>;

export const insertOpsFuelTransactionSchema = createInsertSchema(opsFuelTransactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsFuelTransaction = typeof opsFuelTransactions.$inferSelect;
export type InsertOpsFuelTransaction = z.infer<typeof insertOpsFuelTransactionSchema>;

export const insertOpsShipStoreSaleSchema = createInsertSchema(opsShipStoreSales).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsShipStoreSale = typeof opsShipStoreSales.$inferSelect;
export type InsertOpsShipStoreSale = z.infer<typeof insertOpsShipStoreSaleSchema>;

export const insertOpsServiceWorkOrderSchema = createInsertSchema(opsServiceWorkOrders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsServiceWorkOrder = typeof opsServiceWorkOrders.$inferSelect;
export type InsertOpsServiceWorkOrder = z.infer<typeof insertOpsServiceWorkOrderSchema>;

export const insertOpsBoatRentalSchema = createInsertSchema(opsBoatRentals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsBoatRental = typeof opsBoatRentals.$inferSelect;
export type InsertOpsBoatRental = z.infer<typeof insertOpsBoatRentalSchema>;

export const insertOpsBoatClubMembershipSchema = createInsertSchema(opsBoatClubMemberships).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsBoatClubMembership = typeof opsBoatClubMemberships.$inferSelect;
export type InsertOpsBoatClubMembership = z.infer<typeof insertOpsBoatClubMembershipSchema>;

export const insertOpsBoatSaleSchema = createInsertSchema(opsBoatSales).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsBoatSale = typeof opsBoatSales.$inferSelect;
export type InsertOpsBoatSale = z.infer<typeof insertOpsBoatSaleSchema>;

export const insertOpsCommercialLeaseSchema = createInsertSchema(opsCommercialLeases).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsCommercialLease = typeof opsCommercialLeases.$inferSelect;
export type InsertOpsCommercialLease = z.infer<typeof insertOpsCommercialLeaseSchema>;

export const insertOpsBookkeepingGlSchema = createInsertSchema(opsBookkeepingGl).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsBookkeepingGl = typeof opsBookkeepingGl.$inferSelect;
export type InsertOpsBookkeepingGl = z.infer<typeof insertOpsBookkeepingGlSchema>;

export const insertAsmpFuelSchema = createInsertSchema(asmpFuel).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpFuel = typeof asmpFuel.$inferSelect;
export type InsertAsmpFuel = z.infer<typeof insertAsmpFuelSchema>;

export const insertAsmpShipStoreSchema = createInsertSchema(asmpShipStore).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpShipStore = typeof asmpShipStore.$inferSelect;
export type InsertAsmpShipStore = z.infer<typeof insertAsmpShipStoreSchema>;

export const insertAsmpServiceSchema = createInsertSchema(asmpService).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpService = typeof asmpService.$inferSelect;
export type InsertAsmpService = z.infer<typeof insertAsmpServiceSchema>;

export const insertAsmpCommercialTenantsSchema = createInsertSchema(asmpCommercialTenants).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpCommercialTenants = typeof asmpCommercialTenants.$inferSelect;
export type InsertAsmpCommercialTenants = z.infer<typeof insertAsmpCommercialTenantsSchema>;

export const insertAsmpBoatRentalsSchema = createInsertSchema(asmpBoatRentals).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpBoatRentals = typeof asmpBoatRentals.$inferSelect;
export type InsertAsmpBoatRentals = z.infer<typeof insertAsmpBoatRentalsSchema>;

export const insertAsmpBoatClubSchema = createInsertSchema(asmpBoatClub).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpBoatClub = typeof asmpBoatClub.$inferSelect;
export type InsertAsmpBoatClub = z.infer<typeof insertAsmpBoatClubSchema>;

export const insertAsmpBoatSalesSchema = createInsertSchema(asmpBoatSales).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpBoatSales = typeof asmpBoatSales.$inferSelect;
export type InsertAsmpBoatSales = z.infer<typeof insertAsmpBoatSalesSchema>;

export const insertAsmpBookkeepingSchema = createInsertSchema(asmpBookkeeping).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpBookkeeping = typeof asmpBookkeeping.$inferSelect;
export type InsertAsmpBookkeeping = z.infer<typeof insertAsmpBookkeepingSchema>;

export const insertOpsParkingLotSchema = createInsertSchema(opsParkingLot).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type OpsParkingLot = typeof opsParkingLot.$inferSelect;
export type InsertOpsParkingLot = z.infer<typeof insertOpsParkingLotSchema>;

export const insertAsmpParkingLotSchema = createInsertSchema(asmpParkingLot).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type AsmpParkingLot = typeof asmpParkingLot.$inferSelect;
export type InsertAsmpParkingLot = z.infer<typeof insertAsmpParkingLotSchema>;

export const insertOpsImportEventSchema = createInsertSchema(opsImportEvents).omit({
  id: true,
  createdAt: true,
});
export type OpsImportEvent = typeof opsImportEvents.$inferSelect;
export type InsertOpsImportEvent = z.infer<typeof insertOpsImportEventSchema>;

export const insertValuatorProjectContextSchema = createInsertSchema(valuatorProjectContext).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type ValuatorProjectContext = typeof valuatorProjectContext.$inferSelect;
export type InsertValuatorProjectContext = z.infer<typeof insertValuatorProjectContextSchema>;

export * from "./models/auth";

// ============================================================================
// DOCKTALK_KEYWORD_BANK - Configurable keywords for article filtering
// ============================================================================
export const docktalkKeywordCategoryEnum = pgEnum('docktalk_keyword_category', [
  'marina',
  'investment', 
  'operations',
  'macro',
  'regulatory',
  'required'  // Keywords that MUST appear for article to be included
]);

export const docktalkKeywordBank = pgTable('docktalk_keyword_bank', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  keyword: varchar("keyword", { length: 100 }).notNull(),
  category: docktalkKeywordCategoryEnum("category").notNull().default('marina'),
  weight: integer("weight").notNull().default(5), // Scoring weight (1-10)
  isActive: boolean("is_active").notNull().default(true),
  isRequired: boolean("is_required").notNull().default(false), // If true, article must match at least one required keyword
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('docktalk_keyword_bank_org_idx').on(table.orgId),
  categoryIdx: index('docktalk_keyword_bank_category_idx').on(table.category),
  keywordIdx: index('docktalk_keyword_bank_keyword_idx').on(table.keyword),
}));

// ============================================================================
// DOCKTALK_SCORING_CONFIG - Global scoring configuration per organization
// ============================================================================
export const docktalkScoringConfig = pgTable('docktalk_scoring_config', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().unique().references(() => organizations.id, { onDelete: "cascade" }),
  minimumScore: integer("minimum_score").notNull().default(40), // Minimum score to include article (0-100)
  requireKeywordMatch: boolean("require_keyword_match").notNull().default(true), // Require at least one keyword match
  requireRequiredKeyword: boolean("require_required_keyword").notNull().default(true), // Require at least one "required" category keyword
  marinaWeight: integer("marina_weight").notNull().default(8),
  investmentWeight: integer("investment_weight").notNull().default(5),
  operationsWeight: integer("operations_weight").notNull().default(4),
  macroWeight: integer("macro_weight").notNull().default(3),
  regulatoryWeight: integer("regulatory_weight").notNull().default(3),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('docktalk_scoring_config_org_idx').on(table.orgId),
}));

// Insert/Select schemas for keyword bank
export const insertDocktalkKeywordBankSchema = createInsertSchema(docktalkKeywordBank).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertDocktalkKeywordBank = z.infer<typeof insertDocktalkKeywordBankSchema>;
export type DocktalkKeywordBank = typeof docktalkKeywordBank.$inferSelect;

// Insert/Select schemas for scoring config
export const insertDocktalkScoringConfigSchema = createInsertSchema(docktalkScoringConfig).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertDocktalkScoringConfig = z.infer<typeof insertDocktalkScoringConfigSchema>;
export type DocktalkScoringConfig = typeof docktalkScoringConfig.$inferSelect;

// ============================================================================
// AI USAGE TRACKING - Track AI API calls and costs
// ============================================================================
export const aiUsageTracking = pgTable('ai_usage_tracking', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull(),
  userId: varchar("user_id").notNull(),
  operationType: text("operation_type").notNull(), // 'chat', 'rag', 'document_parse', 'summary', 'embedding'
  provider: text("provider").notNull(), // 'openai', 'anthropic'
  model: text("model").notNull(),
  inputTokens: integer("input_tokens").notNull().default(0),
  outputTokens: integer("output_tokens").notNull().default(0),
  estimatedCostCents: integer("estimated_cost_cents").notNull(),
  metadata: jsonb("metadata").default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgDateIdx: index('ai_usage_tracking_org_date_idx').on(table.orgId, table.createdAt),
  userDateIdx: index('ai_usage_tracking_user_date_idx').on(table.userId, table.createdAt),
}));

// ============================================================================
// AI SPENDING LIMITS - Monthly spending caps per organization
// ============================================================================
export const aiSpendingLimits = pgTable('ai_spending_limits', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().unique(),
  monthlyLimitCents: integer("monthly_limit_cents").notNull().default(10000), // $100 default
  currentMonthSpendCents: integer("current_month_spend_cents").notNull().default(0),
  lastResetAt: timestamp("last_reset_at").defaultNow().notNull(),
  hardLimitReachedAt: timestamp("hard_limit_reached_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('ai_spending_limits_org_idx').on(table.orgId),
}));

// Insert/Select schemas for AI tracking
export type AiUsageTracking = typeof aiUsageTracking.$inferSelect;
export type InsertAiUsageTracking = typeof aiUsageTracking.$inferInsert;
export type AiSpendingLimits = typeof aiSpendingLimits.$inferSelect;

// ============================================================================
// LINE ITEM LEARNING RULES - Learning from user confirmations
// ============================================================================
export const confidenceTierEnum = ['high', 'medium', 'low'] as const;
export type ConfidenceTier = (typeof confidenceTierEnum)[number];
export const ruleSourceEnum = ['user_confirmed', 'bulk_import', 'admin_override'] as const;
export type RuleSource = (typeof ruleSourceEnum)[number];

export const lineItemLearningRules = pgTable('line_item_learning_rules', {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id").notNull(),
  marinaId: varchar("marina_id"),
  normalizedLineItem: text("normalized_line_item").notNull(),
  originalLineItem: text("original_line_item"),
  category: text("category").notNull(),
  subcategory: text("subcategory"),
  department: text("department"),
  confidenceTier: text("confidence_tier").notNull().$type<ConfidenceTier>().default('high'),
  source: text("source").notNull().$type<RuleSource>().default('user_confirmed'),
  createdByUserId: varchar("created_by_user_id"),
  timesUsed: integer("times_used").notNull().default(0),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => ({
  tenantIdIdx: index('line_item_rules_tenant_id_idx').on(table.tenantId),
  tenantMarinaIdx: index('line_item_rules_tenant_marina_idx').on(table.tenantId, table.marinaId),
  normalizedLineItemIdx: index('line_item_rules_normalized_idx').on(table.normalizedLineItem),
  categoryIdx: index('line_item_rules_category_idx').on(table.category),
}));

export type LineItemLearningRule = typeof lineItemLearningRules.$inferSelect;
export type NewLineItemLearningRule = typeof lineItemLearningRules.$inferInsert;
export const insertLineItemLearningRuleSchema = createInsertSchema(lineItemLearningRules);
export const upsertLearningRuleSchema = z.object({
  tenantId: z.string(),
  marinaId: z.string().nullable().optional(),
  normalizedLineItem: z.string().min(1),
  originalLineItem: z.string().optional(),
  category: z.string().min(1),
  subcategory: z.string().nullable().optional(),
  department: z.string().nullable().optional(),
  confidenceTier: z.enum(confidenceTierEnum).default('high'),
  source: z.enum(ruleSourceEnum).default('user_confirmed'),
  createdByUserId: z.string().optional(),
});
export type UpsertLearningRuleInput = z.infer<typeof upsertLearningRuleSchema>;

// Commercial Tenants
export * from "../db/schema-commercial-tenants";

// ============================================
// PHASE 1: MODELING TIMELINE ENGINE
// ============================================

// Enums for timeline configuration
export const projectionStartRuleEnum = pgEnum('projection_start_rule', [
  'acq_close_year',
  'next_full_calendar_year',
  'ttm_plus_one_month'
]);

export const stabilizedNoiModeEnum = pgEnum('stabilized_noi_mode', [
  'fixed_year',
  'user_set',
  'post_ramp'
]);

export const irrDisplayPreferenceEnum = pgEnum('irr_display_preference', [
  'monthly',
  'annualized'
]);

// Seasonality Profiles
export const seasonalityProfiles = pgTable('seasonality_profiles', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  name: text('name').notNull(),
  description: text('description'),
  isDefault: boolean('is_default').default(false),
  isSystem: boolean('is_system').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const seasonalityProfileMonths = pgTable('seasonality_profile_months', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar('profile_id').notNull().references(() => seasonalityProfiles.id, { onDelete: 'cascade' }),
  month: integer('month').notNull(),
  occupancyMultiplier: decimal('occupancy_multiplier', { precision: 5, scale: 4 }).default('1.0'),
  rateMultiplier: decimal('rate_multiplier', { precision: 5, scale: 4 }).default('1.0'),
  revenueMultiplier: decimal('revenue_multiplier', { precision: 5, scale: 4 }).default('1.0'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// Scenario Assumption Payloads (versioned, validated)
export const scenarioAssumptionPayloads = pgTable('scenario_assumption_payloads', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  projectId: varchar('project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  scenarioId: varchar('scenario_id').notNull(),
  scenarioVersionId: varchar('scenario_version_id').notNull().references(() => modelingScenarioVersions.id, { onDelete: 'cascade' }),
  payload: jsonb('payload').notNull(),
  payloadSchemaVersion: integer('payload_schema_version').notNull().default(1),
  payloadHash: text('payload_hash'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// Scenario Audit Logs (institutional compliance)
export const scenarioAuditLogs = pgTable('scenario_audit_logs', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  projectId: varchar('project_id').notNull().references(() => modelingProjects.id, { onDelete: 'cascade' }),
  scenarioId: varchar('scenario_id'),
  scenarioVersionId: varchar('scenario_version_id'),
  userId: varchar('user_id').references(() => users.id),
  eventType: text('event_type').notNull(),
  summary: text('summary'),
  diffJson: jsonb('diff_json'),
  payloadHash: text('payload_hash'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

// ============================================================================
// RELATIONSHIP INTELLIGENCE TABLES
// ============================================================================

// Contact Deal Roles - links contacts to deals with specific roles
export const contactDealRoles = pgTable("contact_deal_roles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").references(() => organizations.id, { onDelete: "cascade" }),
  contactId: varchar("contact_id").notNull().references(() => crmContacts.id, { onDelete: "cascade" }),
  companyId: varchar("company_id").references(() => crmCompanies.id, { onDelete: "set null" }),
  dealId: varchar("deal_id").notNull().references(() => crmDeals.id, { onDelete: "cascade" }),
  roleOnDeal: contactRoleEnum("role_on_deal"),
  dealSide: dealSideEnum("deal_side"),
  isPrimaryForDeal: boolean("is_primary_for_deal").default(false).notNull(),
  volumeAttributionMode: volumeAttributionModeEnum("volume_attribution_mode").default("all_linked").notNull(),
  feeCreditingMode: feeCreditingModeEnum("fee_crediting_mode").default("contact").notNull(),
  splitPctContact: numeric("split_pct_contact", { precision: 5, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("contact_deal_roles_org_idx").on(table.orgId),
  contactIdx: index("contact_deal_roles_contact_idx").on(table.contactId),
  dealIdx: index("contact_deal_roles_deal_idx").on(table.dealId),
}));

// Deal Financial Events - tracks fees, commissions, waivers
export const dealFinancialEvents = pgTable("deal_financial_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").references(() => organizations.id, { onDelete: "cascade" }),
  dealId: varchar("deal_id").notNull().references(() => crmDeals.id, { onDelete: "cascade" }),
  eventType: financialEventTypeEnum("event_type").notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  direction: financialEventDirectionEnum("direction").notNull(),
  appliesToContactId: varchar("applies_to_contact_id").references(() => crmContacts.id, { onDelete: "set null" }),
  appliesToCompanyId: varchar("applies_to_company_id").references(() => crmCompanies.id, { onDelete: "set null" }),
  notes: text("notes"),
  eventDate: date("event_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("deal_financial_events_org_idx").on(table.orgId),
  dealIdx: index("deal_financial_events_deal_idx").on(table.dealId),
  contactIdx: index("deal_financial_events_contact_idx").on(table.appliesToContactId),
}));

// Contact Metrics Snapshot - cached performance metrics
export const contactMetricsSnapshot = pgTable("contact_metrics_snapshot", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").references(() => organizations.id, { onDelete: "cascade" }),
  contactId: varchar("contact_id").notNull().references(() => crmContacts.id, { onDelete: "cascade" }),
  timeframeKey: varchar("timeframe_key", { length: 20 }).notNull(),
  metrics: jsonb("metrics").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Types
export type SeasonalityProfile = typeof seasonalityProfiles.$inferSelect;
export type InsertSeasonalityProfile = typeof seasonalityProfiles.$inferInsert;
export type SeasonalityProfileMonth = typeof seasonalityProfileMonths.$inferSelect;
export type InsertSeasonalityProfileMonth = typeof seasonalityProfileMonths.$inferInsert;
export type ScenarioAssumptionPayload = typeof scenarioAssumptionPayloads.$inferSelect;
export type InsertScenarioAssumptionPayload = typeof scenarioAssumptionPayloads.$inferInsert;
export type ScenarioAuditLog = typeof scenarioAuditLogs.$inferSelect;
export type InsertScenarioAuditLog = typeof scenarioAuditLogs.$inferInsert;
// ============================================================================
// MODELING STANDALONE RENT ROLL - For prospective property evaluation
// ============================================================================

// Storage type enum for modeling rent roll (mirrors RRA)
export const modelingStorageTypeEnum = pgEnum("modeling_storage_type", [
  "Wet Slip",
  "Dry Storage",
  "Dry Rack",
  "Dry Stack",
  "Mooring",
  "Trailer Storage",
  "Lift Storage",
  "Other"
]);

// Status enum for modeling rent roll units
export const modelingUnitStatusEnum = pgEnum("modeling_unit_status", [
  "occupied",
  "vacant",
  "reserved",
  "maintenance"
]);

// Modeling Rent Roll Units - Standalone storage units for prospective properties
export const modelingRentRollUnits = pgTable("modeling_rent_roll_units", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  modelingProjectId: varchar("modeling_project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }),
  
  // Unit identification
  unitNumber: text("unit_number").notNull(),
  storageType: modelingStorageTypeEnum("storage_type").notNull().default("Wet Slip"),
  status: modelingUnitStatusEnum("status").notNull().default("occupied"),
  
  // Physical dimensions
  length: numeric("length", { precision: 10, scale: 2 }),
  width: numeric("width", { precision: 10, scale: 2 }),
  squareFeet: numeric("square_feet", { precision: 10, scale: 2 }),
  
  // Location within marina
  dock: text("dock"),
  section: text("section"),
  
  // Pricing
  monthlyRent: numeric("monthly_rent", { precision: 14, scale: 2 }).notNull().default("0"),
  annualRent: numeric("annual_rent", { precision: 14, scale: 2 }),
  
  // Tenant info (if occupied)
  tenantName: text("tenant_name"),
  boatName: text("boat_name"),
  boatLength: numeric("boat_length", { precision: 10, scale: 2 }),
  boatType: text("boat_type"),
  
  // Lease terms
  leaseStartDate: date("lease_start_date"),
  leaseEndDate: date("lease_end_date"),
  isMonthToMonth: boolean("is_month_to_month").default(false),
  
  // Additional charges
  electricCharge: numeric("electric_charge", { precision: 14, scale: 2 }).default("0"),
  waterCharge: numeric("water_charge", { precision: 14, scale: 2 }).default("0"),
  otherCharges: numeric("other_charges", { precision: 14, scale: 2 }).default("0"),
  isLiveaboard: boolean("is_liveaboard").default(false),
  liveaboardRate: numeric("liveaboard_rate", { precision: 14, scale: 2 }).default("0"),
  sewerCharge: numeric("sewer_charge", { precision: 14, scale: 2 }).default("0"),
  pumpoutCharge: numeric("pumpout_charge", { precision: 14, scale: 2 }).default("0"),
  taxesCharge: numeric("taxes_charge", { precision: 14, scale: 2 }).default("0"),
  
  // Notes
  notes: text("notes"),
  
  // Metadata
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  createdBy: varchar("created_by").references(() => users.id),
}, (table) => ({
  orgIdx: index("modeling_rent_roll_units_org_idx").on(table.orgId),
  projectIdx: index("modeling_rent_roll_units_project_idx").on(table.modelingProjectId),
  storageTypeIdx: index("modeling_rent_roll_units_storage_type_idx").on(table.storageType),
  statusIdx: index("modeling_rent_roll_units_status_idx").on(table.status),
  uniqueUnit: unique("modeling_rent_roll_units_unique").on(table.modelingProjectId, table.unitNumber),
}));

// Modeling Rent Roll Project Configuration
export const modelingRentRollConfig = pgTable("modeling_rent_roll_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  modelingProjectId: varchar("modeling_project_id").notNull().references(() => modelingProjects.id, { onDelete: "cascade" }).unique(),
  
  // Data source mode
  dataSourceMode: text("data_source_mode").notNull().default("standalone"), // "standalone" | "linked" | "hybrid"
  
  // If linked, reference to Operations RRA location
  linkedRraLocationId: varchar("linked_rra_location_id").references(() => rraMarinaLocations.id, { onDelete: "set null" }),
  
  // Sync settings (for linked mode)
  autoSyncEnabled: boolean("auto_sync_enabled").default(false),
  lastSyncAt: timestamp("last_sync_at"),
  
  // Occupancy assumptions (for pro forma)
  assumedOccupancyRate: numeric("assumed_occupancy_rate", { precision: 5, scale: 2 }).default("90.00"),
  assumedAnnualRentGrowth: numeric("assumed_annual_rent_growth", { precision: 5, scale: 2 }).default("3.00"),
  
  // Unit type rate assumptions (JSON for flexibility)
  rateAssumptions: jsonb("rate_assumptions").default(sql`'{}'`),
  
  // Metadata
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  orgIdx: index("modeling_rent_roll_config_org_idx").on(table.orgId),
  projectIdx: index("modeling_rent_roll_config_project_idx").on(table.modelingProjectId),
}));

// Insert schemas and types
export const insertModelingRentRollUnitSchema = createInsertSchema(modelingRentRollUnits).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateModelingRentRollUnitSchema = insertModelingRentRollUnitSchema.partial().omit({ orgId: true, modelingProjectId: true });
export type ModelingRentRollUnit = typeof modelingRentRollUnits.$inferSelect;
export type InsertModelingRentRollUnit = typeof modelingRentRollUnits.$inferInsert;

export const insertModelingRentRollConfigSchema = createInsertSchema(modelingRentRollConfig).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export const updateModelingRentRollConfigSchema = insertModelingRentRollConfigSchema.partial().omit({ orgId: true, modelingProjectId: true });
export type ModelingRentRollConfig = typeof modelingRentRollConfig.$inferSelect;
export type InsertModelingRentRollConfig = typeof modelingRentRollConfig.$inferInsert;

// Relations for modeling rent roll
export const modelingRentRollUnitsRelations = relations(modelingRentRollUnits, ({ one }) => ({
  organization: one(organizations, {
    fields: [modelingRentRollUnits.orgId],
    references: [organizations.id],
  }),
  modelingProject: one(modelingProjects, {
    fields: [modelingRentRollUnits.modelingProjectId],
    references: [modelingProjects.id],
  }),
  createdByUser: one(users, {
    fields: [modelingRentRollUnits.createdBy],
    references: [users.id],
  }),
}));

export const modelingRentRollConfigRelations = relations(modelingRentRollConfig, ({ one }) => ({
  organization: one(organizations, {
    fields: [modelingRentRollConfig.orgId],
    references: [organizations.id],
  }),
  modelingProject: one(modelingProjects, {
    fields: [modelingRentRollConfig.modelingProjectId],
    references: [modelingProjects.id],
  }),
  linkedRraLocation: one(rraMarinaLocations, {
    fields: [modelingRentRollConfig.linkedRraLocationId],
    references: [rraMarinaLocations.id],
  }),
}));


// ============================================================================
// ENHANCED DEBT MODELING SCHEMA
// Multi-Loan Structures, Blended Analysis, and Cash Flow Integration
// ============================================================================

// Loan Purpose - Categorizes how debt is used in the capital stack
export const loanPurposeEnum = pgEnum("loan_purpose", [
  "acquisition",
  "construction", 
  "bridge",
  "permanent",
  "refinancing",
  "mezzanine",
  "preferred_equity",
  "line_of_credit"
]);

// Prepayment Penalty Types
export const prepaymentPenaltyTypeEnum = pgEnum("prepayment_penalty_type", [
  "none",
  "declining_balance",     // % of balance, declining over time
  "yield_maintenance",     // Make-whole based on treasury spread
  "defeasance",           // Replace collateral with treasuries
  "step_down",            // Fixed % that steps down annually
  "lockout",              // No prepayment allowed for period
  "custom"
]);

// DSCR Test Frequency
export const dscrTestFrequencyEnum = pgEnum("dscr_test_frequency", [
  "monthly",
  "quarterly",
  "semi_annual",
  "annual",
  "at_closing",
  "at_maturity"
]);

// Loan Structures - Groups multiple loans together for blended analysis
export const loanStructures = pgTable('loan_structures', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  capitalStackId: varchar('capital_stack_id').notNull().references(() => capitalStacks.id, { onDelete: 'cascade' }),
  modelingProjectId: varchar('modeling_project_id').references(() => modelingProjects.id),
  
  name: text('name').notNull(),
  description: text('description'),
  
  // Structure Type
  structureType: text('structure_type').notNull().default('single'), // 'single', 'combined', 'sequential', 'layered'
  
  // For combined structures - blended metrics
  totalDebtAmount: decimal('total_debt_amount', { precision: 18, scale: 2 }),
  blendedInterestRate: decimal('blended_interest_rate', { precision: 8, scale: 4 }),
  blendedTermMonths: integer('blended_term_months'),
  combinedLtv: decimal('combined_ltv', { precision: 8, scale: 4 }),
  totalAnnualDebtService: decimal('total_annual_debt_service', { precision: 18, scale: 2 }),
  
  // Comparison mode data
  isComparisonMode: boolean('is_comparison_mode').default(false),
  
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  createdBy: varchar('created_by').references(() => users.id),
}, (table) => ({
  orgIdx: index('loan_structures_org_idx').on(table.orgId),
  capitalStackIdx: index('loan_structures_capital_stack_idx').on(table.capitalStackId),
  projectIdx: index('loan_structures_project_idx').on(table.modelingProjectId),
}));

// Enhanced Loan Details - Extends debtTranches with advanced features
export const loanDetails = pgTable('loan_details', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  debtTrancheId: varchar('debt_tranche_id').notNull().references(() => debtTranches.id, { onDelete: 'cascade' }).unique(),
  loanStructureId: varchar('loan_structure_id').references(() => loanStructures.id, { onDelete: 'set null' }),
  
  // Loan Purpose
  loanPurpose: loanPurposeEnum('loan_purpose').notNull().default('acquisition'),
  
  // Lender Information
  lenderName: text('lender_name'),
  lenderType: text('lender_type'), // 'bank', 'life_company', 'debt_fund', 'cmbs', 'agency', 'credit_union', 'private'
  lenderContact: text('lender_contact'),
  
  // LTV Tracking
  ltvAtOrigination: decimal('ltv_at_origination', { precision: 8, scale: 4 }),
  maxLtv: decimal('max_ltv', { precision: 8, scale: 4 }),
  
  // Exit Fees (detailed)
  exitFeeType: text('exit_fee_type'), // 'flat', 'percentage', 'sliding', 'none'
  exitFeeAmount: decimal('exit_fee_amount', { precision: 18, scale: 2 }),
  exitFeePct: decimal('exit_fee_pct', { precision: 8, scale: 4 }),
  exitFeeExpiresMonth: integer('exit_fee_expires_month'), // Month after which exit fee no longer applies
  
  // Prepayment Penalty Structure
  prepaymentPenaltyType: prepaymentPenaltyTypeEnum('prepayment_penalty_type').default('none'),
  prepaymentLockoutMonths: integer('prepayment_lockout_months').default(0),
  prepaymentSchedule: jsonb('prepayment_schedule').$type<{
    yearStart: number;
    yearEnd: number;
    penaltyPct: number;
  }[]>(), // Step-down schedule
  yieldMaintenanceSpread: decimal('yield_maintenance_spread', { precision: 8, scale: 4 }), // Spread over treasury for YM calc
  
  // DSCR Covenant Testing
  dscrMinimum: decimal('dscr_minimum', { precision: 8, scale: 4 }).default('1.20'),
  dscrTestFrequency: dscrTestFrequencyEnum('dscr_test_frequency').default('quarterly'),
  dscrTestStartMonth: integer('dscr_test_start_month').default(1), // When DSCR testing begins
  dscrCashTrap: decimal('dscr_cash_trap', { precision: 8, scale: 4 }), // Below this, excess cash trapped
  
  // Debt Yield Requirements
  debtYieldMinimum: decimal('debt_yield_minimum', { precision: 8, scale: 4 }),
  
  // Construction/Draw Features
  isDrawLoan: boolean('is_draw_loan').default(false),
  drawSchedule: jsonb('draw_schedule').$type<{
    month: number;
    drawAmount: number;
    description: string;
  }[]>(),
  constructionPeriodMonths: integer('construction_period_months'),
  
  // Loan Transitions (Bridge to Perm, etc.)
  transitionsToLoanId: varchar('transitions_to_loan_id'), // ID of successor loan
  transitionMonth: integer('transition_month'), // When transition occurs
  transitionType: text('transition_type'), // 'refinance', 'conversion', 'payoff'
  
  // Interest Rate Details
  isFloatingRate: boolean('is_floating_rate').default(false),
  floatingRateIndex: text('floating_rate_index'), // 'SOFR', 'Prime', 'Treasury'
  floatingRateSpreadBps: integer('floating_rate_spread_bps'),
  rateCap: decimal('rate_cap', { precision: 8, scale: 4 }),
  rateFloor: decimal('rate_floor', { precision: 8, scale: 4 }),
  
  // Extension Options
  extensionOptions: jsonb('extension_options').$type<{
    optionNumber: number;
    durationMonths: number;
    feePct: number;
    conditions: string;
  }[]>(),
  
  // Recourse
  isRecourse: boolean('is_recourse').default(false),
  recoursePercentage: decimal('recourse_percentage', { precision: 8, scale: 4 }),
  recourseDescription: text('recourse_description'),
  
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('loan_details_org_idx').on(table.orgId),
  debtTrancheIdx: index('loan_details_debt_tranche_idx').on(table.debtTrancheId),
  structureIdx: index('loan_details_structure_idx').on(table.loanStructureId),
}));

// Monthly Loan Schedule - Tracks loan balance and payments over time
export const monthlyLoanSchedule = pgTable('monthly_loan_schedule', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  debtTrancheId: varchar('debt_tranche_id').notNull().references(() => debtTranches.id, { onDelete: 'cascade' }),
  capitalStackId: varchar('capital_stack_id').notNull().references(() => capitalStacks.id, { onDelete: 'cascade' }),
  
  // Period Information
  periodMonth: integer('period_month').notNull(), // 1-indexed month in loan term
  periodYear: integer('period_year').notNull(),
  periodDate: date('period_date').notNull(),
  
  // Balance Tracking
  beginningBalance: decimal('beginning_balance', { precision: 18, scale: 2 }).notNull(),
  endingBalance: decimal('ending_balance', { precision: 18, scale: 2 }).notNull(),
  
  // Payment Breakdown
  scheduledPayment: decimal('scheduled_payment', { precision: 18, scale: 2 }).notNull(),
  principalPayment: decimal('principal_payment', { precision: 18, scale: 2 }).notNull(),
  interestPayment: decimal('interest_payment', { precision: 18, scale: 2 }).notNull(),
  
  // Interest Rate (for floating rate tracking)
  interestRate: decimal('interest_rate', { precision: 8, scale: 4 }).notNull(),
  
  // Status
  isInterestOnly: boolean('is_interest_only').default(false),
  isDrawPeriod: boolean('is_draw_period').default(false),
  drawAmount: decimal('draw_amount', { precision: 18, scale: 2 }),
  
  // Prepayment
  prepaymentAmount: decimal('prepayment_amount', { precision: 18, scale: 2 }),
  prepaymentPenalty: decimal('prepayment_penalty', { precision: 18, scale: 2 }),
  
  // DSCR at this period
  periodNoi: decimal('period_noi', { precision: 18, scale: 2 }),
  periodDscr: decimal('period_dscr', { precision: 8, scale: 4 }),
  dscrPassFail: boolean('dscr_pass_fail'),
  
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('monthly_loan_schedule_org_idx').on(table.orgId),
  debtTrancheIdx: index('monthly_loan_schedule_debt_tranche_idx').on(table.debtTrancheId),
  capitalStackIdx: index('monthly_loan_schedule_capital_stack_idx').on(table.capitalStackId),
  periodIdx: index('monthly_loan_schedule_period_idx').on(table.periodYear, table.periodMonth),
}));

// DSCR Test Results - Tracks covenant testing outcomes
export const dscrTestResults = pgTable('dscr_test_results', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  debtTrancheId: varchar('debt_tranche_id').notNull().references(() => debtTranches.id, { onDelete: 'cascade' }),
  capitalStackId: varchar('capital_stack_id').notNull().references(() => capitalStacks.id, { onDelete: 'cascade' }),
  
  testDate: date('test_date').notNull(),
  testPeriod: text('test_period').notNull(), // 'Q1 2025', '2025', etc.
  
  // Inputs
  trailingNoi: decimal('trailing_noi', { precision: 18, scale: 2 }).notNull(),
  annualDebtService: decimal('annual_debt_service', { precision: 18, scale: 2 }).notNull(),
  
  // Result
  calculatedDscr: decimal('calculated_dscr', { precision: 8, scale: 4 }).notNull(),
  requiredDscr: decimal('required_dscr', { precision: 8, scale: 4 }).notNull(),
  passedTest: boolean('passed_test').notNull(),
  
  // Cure info
  cushionAmount: decimal('cushion_amount', { precision: 18, scale: 2 }), // How much above/below minimum
  cushionPct: decimal('cushion_pct', { precision: 8, scale: 4 }),
  
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('dscr_test_results_org_idx').on(table.orgId),
  debtTrancheIdx: index('dscr_test_results_debt_tranche_idx').on(table.debtTrancheId),
  testDateIdx: index('dscr_test_results_test_date_idx').on(table.testDate),
}));

// Loan Comparison Scenarios - For side-by-side loan analysis
export const loanComparisonScenarios = pgTable('loan_comparison_scenarios', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  modelingProjectId: varchar('modeling_project_id').references(() => modelingProjects.id, { onDelete: 'cascade' }),
  capitalStackId: varchar('capital_stack_id').references(() => capitalStacks.id),
  
  name: text('name').notNull(),
  description: text('description'),
  
  // Scenario loans (references to debt tranches being compared)
  scenarioLoans: jsonb('scenario_loans').$type<{
    debtTrancheId: string;
    label: string; // 'Option A', 'Option B', etc.
    isSelected: boolean; // Is this the preferred option?
  }[]>(),
  
  // Comparison metrics (calculated)
  comparisonMetrics: jsonb('comparison_metrics').$type<{
    loanId: string;
    totalInterestPaid: number;
    totalPayments: number;
    effectiveRate: number;
    monthlyPayment: number;
    breakEvenMonth: number;
  }[]>(),
  
  selectedLoanId: varchar('selected_loan_id'), // Preferred loan option
  
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
  createdBy: varchar('created_by').references(() => users.id),
}, (table) => ({
  orgIdx: index('loan_comparison_scenarios_org_idx').on(table.orgId),
  projectIdx: index('loan_comparison_scenarios_project_idx').on(table.modelingProjectId),
}));

// Insert schemas
export const insertLoanStructureSchema = createInsertSchema(loanStructures).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertLoanDetailsSchema = createInsertSchema(loanDetails).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMonthlyLoanScheduleSchema = createInsertSchema(monthlyLoanSchedule).omit({
  id: true,
  createdAt: true,
});

export const insertDscrTestResultSchema = createInsertSchema(dscrTestResults).omit({
  id: true,
  createdAt: true,
});

export const insertLoanComparisonScenarioSchema = createInsertSchema(loanComparisonScenarios).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type LoanStructure = typeof loanStructures.$inferSelect;
export type InsertLoanStructure = z.infer<typeof insertLoanStructureSchema>;
export type LoanDetails = typeof loanDetails.$inferSelect;
export type InsertLoanDetails = z.infer<typeof insertLoanDetailsSchema>;
export type MonthlyLoanSchedule = typeof monthlyLoanSchedule.$inferSelect;
export type InsertMonthlyLoanSchedule = z.infer<typeof insertMonthlyLoanScheduleSchema>;
export type DscrTestResult = typeof dscrTestResults.$inferSelect;
export type InsertDscrTestResult = z.infer<typeof insertDscrTestResultSchema>;
export type LoanComparisonScenario = typeof loanComparisonScenarios.$inferSelect;
export type InsertLoanComparisonScenario = z.infer<typeof insertLoanComparisonScenarioSchema>;

export const wizardDrafts = pgTable("wizard_drafts", {
  id: text("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  wizardType: text("wizard_type").notNull(),
  status: text("status").notNull().default("draft"),
  currentStepId: text("current_step_id").notNull().default("welcome"),
  completedStepIds: jsonb("completed_step_ids").$type<string[]>().default([]),
  payload: jsonb("payload").$type<Record<string, any>>().default({}),
  version: text("version").notNull().default("1"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type WizardDraft = typeof wizardDrafts.$inferSelect;
export type NewWizardDraft = typeof wizardDrafts.$inferInsert;
export * from "./payroll-schema";
export * from './pnl-pipeline-schema';
// P&L Pipeline tables
export * from './pnl-pipeline-schema';
/**
 * Deal Workspace Schema Additions
 * 
 * INSTRUCTIONS: Append this content to the bottom of shared/schema.ts
 * (above the zod schema exports section).
 * 
 * These are ONLY the new tables. Existing tables (deal_workspaces, vdr_folders,
 * vdr_documents, tasks, projects, vdrAuditLogs) are reused as-is.
 * The migration SQL adds columns to those existing tables.
 */

// ─── New Enums ───────────────────────────────────────────────────────────────

export const wsMemberRoleEnum = pgEnum('ws_member_role', [
  'owner_admin', 'internal_member', 'buyer', 'seller', 'broker',
  'lender', 'attorney', 'accountant', 'consultant', 'viewer',
]);

export const wsInviteStatusEnum = pgEnum('ws_invite_status', [
  'pending', 'accepted', 'declined', 'revoked',
]);

export const wsAccessPolicyEnum = pgEnum('ws_access_policy', [
  'auto_approve', 'manual_approve',
]);

export const wsCaExecutionStatusEnum = pgEnum('ws_ca_execution_status', [
  'executed', 'pending_review', 'rejected',
]);

export const wsMilestoneTypeEnum = pgEnum('ws_milestone_type', [
  'dd_start', 'dd_expiration', 'closing', 'financing_contingency',
  'inspection_deadline', 'custom',
]);

export const wsMilestoneStatusEnum = pgEnum('ws_milestone_status', [
  'upcoming', 'due_soon', 'overdue', 'completed',
]);

export const wsDdPermissionEnum = pgEnum('ws_dd_permission', [
  'none', 'view', 'edit', 'admin',
]);

export const wsSecurityLevelEnum = pgEnum('ws_security_level', [
  'public', 'confidential', 'restricted',
]);

// ─── Workspace Members ───────────────────────────────────────────────────────

export const workspaceMembers = pgTable('workspace_members', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar('workspace_id').notNull().references(() => dealWorkspaces.id, { onDelete: 'cascade' }),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  userId: varchar('user_id').references(() => users.id),
  email: varchar('email', { length: 255 }),
  displayName: varchar('display_name', { length: 255 }),
  role: wsMemberRoleEnum('role').notNull().default('viewer'),
  vdrPermission: vdrPermissionLevelEnum('vdr_permission').notNull().default('no_access'),
  ddPermission: wsDdPermissionEnum('dd_permission').notNull().default('none'),
  inviteStatus: wsInviteStatusEnum('invite_status').notNull().default('pending'),
  invitedBy: varchar('invited_by'),
  invitedAt: timestamp('invited_at').notNull().defaultNow(),
  acceptedAt: timestamp('accepted_at'),
  revokedAt: timestamp('revoked_at'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  workspaceIdx: index('wm_workspace_idx').on(table.workspaceId),
  userIdx: index('wm_user_idx').on(table.userId),
  orgIdx: index('wm_org_idx').on(table.orgId),
}));

// ─── Confidentiality Agreements ──────────────────────────────────────────────

export const confidentialityAgreements = pgTable('confidentiality_agreements', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar('workspace_id').notNull().references(() => dealWorkspaces.id, { onDelete: 'cascade' }),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  version: varchar('version', { length: 20 }).notNull().default('1.0.0'),
  title: text('title').notNull(),
  bodyHtml: text('body_html').notNull(),
  accessPolicy: wsAccessPolicyEnum('access_policy').notNull().default('auto_approve'),
  isActive: boolean('is_active').notNull().default(true),
  createdBy: varchar('created_by').notNull().references(() => users.id),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  workspaceIdx: index('ca_workspace_idx').on(table.workspaceId),
}));

// ─── Agreement Executions ────────────────────────────────────────────────────

export const agreementExecutions = pgTable('agreement_executions', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar('workspace_id').notNull().references(() => dealWorkspaces.id, { onDelete: 'cascade' }),
  agreementId: varchar('agreement_id').notNull().references(() => confidentialityAgreements.id, { onDelete: 'cascade' }),
  memberId: varchar('member_id'),
  email: varchar('email', { length: 255 }),
  userId: varchar('user_id'),
  status: wsCaExecutionStatusEnum('status').notNull().default('executed'),
  executedAt: timestamp('executed_at').notNull().defaultNow(),
  ipAddress: varchar('ip_address', { length: 45 }),
  userAgent: text('user_agent'),
  notes: text('notes'),
  reviewedBy: varchar('reviewed_by'),
  reviewedAt: timestamp('reviewed_at'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  workspaceIdx: index('ae_workspace_idx').on(table.workspaceId),
  agreementIdx: index('ae_agreement_idx').on(table.agreementId),
  userIdx: index('ae_user_idx').on(table.userId),
}));

// ─── DD Milestones ───────────────────────────────────────────────────────────

export const ddMilestones = pgTable('dd_milestones', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar('workspace_id').notNull().references(() => dealWorkspaces.id, { onDelete: 'cascade' }),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  type: wsMilestoneTypeEnum('type').notNull(),
  title: text('title').notNull(),
  dueDate: timestamp('due_date').notNull(),
  status: wsMilestoneStatusEnum('status').notNull().default('upcoming'),
  notes: text('notes'),
  calendarEventId: varchar('calendar_event_id', { length: 255 }),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  workspaceIdx: index('dm_workspace_idx').on(table.workspaceId),
  dueIdx: index('dm_due_idx').on(table.dueDate),
}));

// ─── Type exports ────────────────────────────────────────────────────────────

export type WorkspaceMember = typeof workspaceMembers.$inferSelect;
export type InsertWorkspaceMember = typeof workspaceMembers.$inferInsert;
export type ConfidentialityAgreement = typeof confidentialityAgreements.$inferSelect;
export type AgreementExecution = typeof agreementExecutions.$inferSelect;
export type DdMilestone = typeof ddMilestones.$inferSelect;
/**
 * DD Checklist Engine Schema Additions
 * INSTRUCTIONS: Append to the bottom of shared/schema.ts
 */

// ─── DD Checklist Enums ──────────────────────────────────────────────────────

export const ddChecklistStatusEnum = pgEnum('dd_checklist_status', ['active', 'archived']);
export const ddRequestTypeEnum = pgEnum('dd_request_type', ['document', 'data', 'answer', 'site_access', 'verification', 'other']);
export const ddRequestStatusEnum = pgEnum('dd_request_status', ['open', 'requested', 'in_progress', 'provided', 'reviewing', 'approved', 'rejected', 'waived', 'blocked']);
export const ddInternalStatusEnum = pgEnum('dd_internal_status', ['not_started', 'in_progress', 'waiting_on_seller', 'waiting_on_third_party', 'done']);
export const ddCommentVisibilityEnum = pgEnum('dd_comment_visibility', ['internal', 'external', 'all']);
export const ddHistoryActionEnum = pgEnum('dd_history_action', ['created', 'edited', 'status_changed', 'deadline_changed', 'assigned', 'file_linked', 'file_unlinked', 'commented', 'section_moved', 'item_moved']);
export const ddTemplateAssetClassEnum = pgEnum('dd_template_asset_class', ['general_cre', 'marina', 'multifamily', 'office', 'retail', 'industrial', 'hotel', 'self_storage', 'mhp_rv', 'car_wash', 'laundromat', 'business_acquisition']);
export const ddInviteScopeEnum = pgEnum('dd_invite_scope', ['data_room', 'checklist', 'both']);
export const ddPermissionPresetEnum = pgEnum('dd_permission_preset', ['seller_upload', 'broker_coordinator', 'buyer_viewer', 'lender_viewer', 'custom']);

// ─── DD Checklists ───────────────────────────────────────────────────────────

export const ddChecklists = pgTable('dd_checklists', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  workspaceId: varchar('workspace_id').notNull().references(() => dealWorkspaces.id, { onDelete: 'cascade' }),
  ddProjectId: varchar('dd_project_id').references(() => projects.id),
  orgId: varchar('org_id').notNull(),
  name: text('name').notNull().default('DD Request List'),
  status: ddChecklistStatusEnum('status').notNull().default('active'),
  sellerCanMarkProvided: boolean('seller_can_mark_provided').notNull().default(true),
  sellerCanChangeStatus: boolean('seller_can_change_status').notNull().default(false),
  requireReviewerApproval: boolean('require_reviewer_approval').notNull().default(false),
  autoProvidedOnUpload: boolean('auto_provided_on_upload').notNull().default(true),
  autoReminders: boolean('auto_reminders').notNull().default(false),
  lockAfterClosing: boolean('lock_after_closing').notNull().default(false),
  caRequiredForChecklist: boolean('ca_required_for_checklist').notNull().default(false),
  createdByUserId: varchar('created_by_user_id').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  workspaceIdx: index('ddc_workspace_idx').on(table.workspaceId),
}));

// ─── DD Checklist Sections ───────────────────────────────────────────────────

export const ddChecklistSections = pgTable('dd_checklist_sections', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  checklistId: varchar('checklist_id').notNull().references(() => ddChecklists.id, { onDelete: 'cascade' }),
  sortOrder: integer('sort_order').notNull().default(0),
  title: text('title').notNull(),
  description: text('description'),
  isCollapsedByDefault: boolean('is_collapsed_by_default').notNull().default(false),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  checklistIdx: index('ddcs_checklist_idx').on(table.checklistId),
}));

// ─── DD Checklist Items ──────────────────────────────────────────────────────

export const ddChecklistItems = pgTable('dd_checklist_items', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  sectionId: varchar('section_id').notNull().references(() => ddChecklistSections.id, { onDelete: 'cascade' }),
  sortOrder: integer('sort_order').notNull().default(0),
  title: text('title').notNull(),
  requestText: text('request_text'),
  subCategory: text('sub_category'),
  priority: integer('priority').notNull().default(2),
  requestType: ddRequestTypeEnum('request_type').notNull().default('document'),
  status: ddRequestStatusEnum('status').notNull().default('open'),
  internalStatus: ddInternalStatusEnum('internal_status').notNull().default('not_started'),
  dueDate: date('due_date'),
  milestoneAnchor: varchar('milestone_anchor', { length: 30 }),
  dueOffsetDays: integer('due_offset_days'),
  customMilestoneId: varchar('custom_milestone_id').references(() => ddMilestones.id),
  assignedToMemberId: varchar('assigned_to_member_id'),
  reviewerMemberId: varchar('reviewer_member_id'),
  requestedFromMemberId: varchar('requested_from_member_id'),
  tags: text('tags').array(),
  sellerNotes: text('seller_notes'),
  internalNotes: text('internal_notes'),
  templateKey: varchar('template_key', { length: 100 }),
  hasPeriods: boolean("has_periods").notNull().default(false),
  periodConfig: jsonb("period_config"),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  sectionIdx: index('ddci_section_idx').on(table.sectionId),
  statusIdx: index('ddci_status_idx').on(table.status),
  assignedIdx: index('ddci_assigned_idx').on(table.assignedToMemberId),
}));

// ─── DD Checklist Item Files ─────────────────────────────────────────────────

export const ddChecklistItemFiles = pgTable('dd_checklist_item_files', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  itemId: varchar('item_id').notNull().references(() => ddChecklistItems.id, { onDelete: 'cascade' }),
  documentId: varchar('document_id').notNull().references(() => vdrDocuments.id),
  addedByMemberId: varchar('added_by_member_id'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  itemIdx: index('ddcif_item_idx').on(table.itemId),
}));

// ─── DD Checklist Item Comments ──────────────────────────────────────────────

export const ddChecklistItemComments = pgTable('dd_checklist_item_comments', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  itemId: varchar('item_id').notNull().references(() => ddChecklistItems.id, { onDelete: 'cascade' }),
  memberId: varchar('member_id').references(() => workspaceMembers.id),
  userId: varchar('user_id'),
  visibility: ddCommentVisibilityEnum('visibility').notNull().default('all'),
  body: text('body').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  itemIdx: index('ddcic_item_idx').on(table.itemId),
}));

// ─── DD Checklist Item History ───────────────────────────────────────────────

export const ddChecklistItemHistory = pgTable('dd_checklist_item_history', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  itemId: varchar('item_id').notNull().references(() => ddChecklistItems.id, { onDelete: 'cascade' }),
  actorMemberId: varchar('actor_member_id'),
  actorUserId: varchar('actor_user_id'),
  action: ddHistoryActionEnum('action').notNull(),
  meta: jsonb('meta').default(sql`'{}'`),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  itemIdx: index('ddcih_item_idx').on(table.itemId),
  createdIdx: index('ddcih_created_idx').on(table.createdAt),
}));


// ─── Type Exports ────────────────────────────────────────────────────────────

export type DdChecklist = typeof ddChecklists.$inferSelect;
export type DdChecklistSection = typeof ddChecklistSections.$inferSelect;
export type DdChecklistItem = typeof ddChecklistItems.$inferSelect;
export type DdChecklistItemFile = typeof ddChecklistItemFiles.$inferSelect;
export type DdChecklistItemComment = typeof ddChecklistItemComments.$inferSelect;
export type DdChecklistItemHistoryEntry = typeof ddChecklistItemHistory.$inferSelect;

// ─── DD Checklist Item Periods ───────────────────────────────────────────────
export const ddChecklistItemPeriods = pgTable("dd_checklist_item_periods", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  itemId: varchar("item_id").notNull().references(() => ddChecklistItems.id, { onDelete: "cascade" }),
  periodType: varchar("period_type", { length: 20 }).notNull(),
  periodLabel: text("period_label").notNull(),
  periodSort: integer("period_sort").notNull().default(0),
  isReceived: boolean("is_received").notNull().default(false),
  receivedAt: timestamp("received_at"),
  receivedBy: varchar("received_by").references(() => users.id),
  fileId: varchar("file_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (table) => ({
  itemIdx: index("ddcip_item_idx2").on(table.itemId),
}));
export type DdChecklistItemPeriod = typeof ddChecklistItemPeriods.$inferSelect;
export type DdChecklistTemplate = typeof ddChecklistTemplates.$inferSelect;

// ─── DD Section Defaults ────────────────────────────────────────────────────
export const ddSectionDefaults = pgTable('dd_section_defaults', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  title: text('title').notNull(),
  isBuiltin: boolean('is_builtin').notNull().default(false),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => ({
  titleIdx: index('ddsd_title_idx').on(table.title),
}));
export type DdSectionDefault = typeof ddSectionDefaults.$inferSelect;

// ================================================================================
// RETURNS - Institutional-Grade Return Tracking & Analytics
// ================================================================================

export const returnsLedgerBucketEnum = pgEnum('returns_ledger_bucket', [
  'ACQUISITION',
  'EQUITY_CONTRIBUTION',
  'LOAN_PROCEEDS',
  'OPERATING_CASHFLOW',
  'CAPEX',
  'DEBT_SERVICE_INTEREST',
  'DEBT_SERVICE_PRINCIPAL',
  'REFI_PROCEEDS',
  'SALE_PROCEEDS',
  'SALE_COSTS',
  'LOAN_PAYOFF',
  'FEES_OTHER',
]);

export const returnsLedgerSourceEnum = pgEnum('returns_ledger_source', [
  'MODEL',
  'QBO',
  'UPLOAD',
  'MANUAL',
]);

export const returnsValuationSourceEnum = pgEnum('returns_valuation_source', [
  'MODEL',
  'MANUAL',
  'APPRAISAL',
  'MARKET_INDEX',
]);

export const returnsFrequencyEnum = pgEnum('returns_frequency', ['MONTHLY']);

export const returnsLedger = pgTable('returns_ledger', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  userId: varchar('user_id').notNull().references(() => users.id),
  propertyId: varchar('property_id'),
  dealId: varchar('deal_id'),
  modelId: varchar('model_id'),
  scenarioId: varchar('scenario_id'),
  asOfDate: date('as_of_date').notNull(),
  frequency: returnsFrequencyEnum('frequency').notNull().default('MONTHLY'),
  bucket: returnsLedgerBucketEnum('bucket').notNull(),
  amount: decimal('amount', { precision: 14, scale: 2 }).notNull(),
  source: returnsLedgerSourceEnum('source').notNull().default('MANUAL'),
  memo: text('memo'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('returns_ledger_org_idx').on(table.orgId),
  userIdx: index('returns_ledger_user_idx').on(table.userId),
  modelIdx: index('returns_ledger_model_idx').on(table.modelId),
  propertyIdx: index('returns_ledger_property_idx').on(table.propertyId),
  dateIdx: index('returns_ledger_date_idx').on(table.asOfDate),
}));

export const insertReturnsLedgerSchema = createInsertSchema(returnsLedger).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type ReturnsLedgerEntry = typeof returnsLedger.$inferSelect;
export type InsertReturnsLedgerEntry = z.infer<typeof insertReturnsLedgerSchema>;

export const returnsValuation = pgTable('returns_valuation', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  userId: varchar('user_id').notNull().references(() => users.id),
  propertyId: varchar('property_id'),
  modelId: varchar('model_id'),
  scenarioId: varchar('scenario_id'),
  asOfDate: date('as_of_date').notNull(),
  marketValue: decimal('market_value', { precision: 14, scale: 2 }).notNull(),
  valueSource: returnsValuationSourceEnum('value_source').notNull().default('MANUAL'),
  notes: text('notes'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('returns_valuation_org_idx').on(table.orgId),
  modelIdx: index('returns_valuation_model_idx').on(table.modelId),
  propertyIdx: index('returns_valuation_property_idx').on(table.propertyId),
  dateIdx: index('returns_valuation_date_idx').on(table.asOfDate),
}));

export const insertReturnsValuationSchema = createInsertSchema(returnsValuation).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type ReturnsValuationEntry = typeof returnsValuation.$inferSelect;
export type InsertReturnsValuationEntry = z.infer<typeof insertReturnsValuationSchema>;

export const loanBalanceTimeline = pgTable('loan_balance_timeline', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  userId: varchar('user_id').notNull().references(() => users.id),
  propertyId: varchar('property_id'),
  modelId: varchar('model_id'),
  scenarioId: varchar('scenario_id'),
  asOfDate: date('as_of_date').notNull(),
  loanBalance: decimal('loan_balance', { precision: 14, scale: 2 }).notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => ({
  orgIdx: index('loan_balance_timeline_org_idx').on(table.orgId),
  modelIdx: index('loan_balance_timeline_model_idx').on(table.modelId),
  propertyIdx: index('loan_balance_timeline_property_idx').on(table.propertyId),
  dateIdx: index('loan_balance_timeline_date_idx').on(table.asOfDate),
}));

export const insertLoanBalanceTimelineSchema = createInsertSchema(loanBalanceTimeline).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type LoanBalanceTimelineEntry = typeof loanBalanceTimeline.$inferSelect;
export type InsertLoanBalanceTimelineEntry = z.infer<typeof insertLoanBalanceTimelineSchema>;
// ============================================================
// EXIT STRATEGY STUDIO V2 — Schema Additions
// ============================================================

export const exitStudioAssetClassEnum = pgEnum("exit_studio_asset_class", [
  "marina", "golf", "multifamily", "retail", "office", "mob",
  "str", "hotel", "sfr", "duplex", "mall", "industrial",
  "data_center", "business",
]);

export const exitStudioStatusEnum = pgEnum("exit_studio_status", [
  "draft", "final", "locked",
]);

export const exitStudioEventTypeEnum = pgEnum("exit_studio_event_type", [
  "create", "update_inputs", "recompute", "export",
  "lock", "unlock", "compare", "allocation_recompute", "migration",
]);

export const exitScenarioResultsV2 = pgTable('exit_scenario_results_v2', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  scenarioId: varchar('scenario_id').notNull().references(() => exitScenarios.id, { onDelete: 'cascade' }),
  computedAt: timestamp('computed_at').defaultNow().notNull(),
  inputsChecksum: text('inputs_checksum').notNull(),
  outputsJson: jsonb('outputs_json').notNull(),
  engineVersion: text('engine_version').notNull(),
}, (table) => ({
  scenarioChecksumIdx: uniqueIndex('exit_results_v2_scenario_checksum_idx')
    .on(table.scenarioId, table.inputsChecksum, table.engineVersion),
  scenarioIdx: index('exit_results_v2_scenario_idx').on(table.scenarioId),
}));

export const exitScenarioEvents = pgTable('exit_scenario_events', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  scenarioId: varchar('scenario_id').notNull().references(() => exitScenarios.id, { onDelete: 'cascade' }),
  eventType: exitStudioEventTypeEnum('event_type').notNull(),
  payloadJson: jsonb('payload_json'),
  userId: varchar('user_id').references(() => users.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  scenarioIdx: index('exit_events_scenario_idx').on(table.scenarioId),
  eventTypeIdx: index('exit_events_type_idx').on(table.eventType),
  createdAtIdx: index('exit_events_created_idx').on(table.createdAt),
}));

export const exitScenarioKpis = pgTable('exit_scenario_kpis', {
  scenarioId: varchar('scenario_id').primaryKey().references(() => exitScenarios.id, { onDelete: 'cascade' }),
  computedAt: timestamp('computed_at').defaultNow().notNull(),
  salePrice: decimal('sale_price', { precision: 18, scale: 2 }),
  amountRealized: decimal('amount_realized', { precision: 18, scale: 2 }),
  adjustedBasis: decimal('adjusted_basis', { precision: 18, scale: 2 }),
  realizedGain: decimal('realized_gain', { precision: 18, scale: 2 }),
  recognizedGain: decimal('recognized_gain', { precision: 18, scale: 2 }),
  deferredGain: decimal('deferred_gain', { precision: 18, scale: 2 }),
  bootTotal: decimal('boot_total', { precision: 18, scale: 2 }),
  bootCash: decimal('boot_cash', { precision: 18, scale: 2 }),
  bootMortgage: decimal('boot_mortgage', { precision: 18, scale: 2 }),
  bootNonLikeKind: decimal('boot_non_like_kind', { precision: 18, scale: 2 }),
  taxTotal: decimal('tax_total', { precision: 18, scale: 2 }),
  taxFederal: decimal('tax_federal', { precision: 18, scale: 2 }),
  taxState: decimal('tax_state', { precision: 18, scale: 2 }),
  taxNiit: decimal('tax_niit', { precision: 18, scale: 2 }),
  afterTaxCashNow: decimal('after_tax_cash_now', { precision: 18, scale: 2 }),
  afterTaxCashTotal: decimal('after_tax_cash_total', { precision: 18, scale: 2 }),
  afterTaxNpv: decimal('after_tax_npv', { precision: 18, scale: 2 }),
  lpIrr: decimal('lp_irr', { precision: 10, scale: 6 }),
  gpIrr: decimal('gp_irr', { precision: 10, scale: 6 }),
  lpEquityMultiple: decimal('lp_equity_multiple', { precision: 10, scale: 4 }),
  gpEquityMultiple: decimal('gp_equity_multiple', { precision: 10, scale: 4 }),
  promoteEarned: decimal('promote_earned', { precision: 18, scale: 2 }),
  strategiesActive: jsonb('strategies_active'),
  hasRecaptureExposure: boolean('has_recapture_exposure').default(false),
  hasTradeDown: boolean('has_trade_down').default(false),
  advisorReviewRequired: boolean('advisor_review_required').default(false),
  assetClass: text('asset_class'),
}, (table) => ({
  assetClassIdx: index('exit_kpis_asset_class_idx').on(table.assetClass),
  salePriceIdx: index('exit_kpis_sale_price_idx').on(table.salePrice),
  afterTaxIdx: index('exit_kpis_after_tax_idx').on(table.afterTaxCashNow),
}));

export const assetClassAssumptionSets = pgTable('asset_class_assumption_sets', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').references(() => organizations.id),
  assetClass: text('asset_class').notNull(),
  name: text('name').notNull(),
  assumptionsJson: jsonb('assumptions_json').notNull(),
  sourceNotes: text('source_notes'),
  isDefault: boolean('is_default').default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  assetClassIdx: index('assumption_sets_asset_class_idx').on(table.assetClass),
  orgIdx: index('assumption_sets_org_idx').on(table.orgId),
}));

// ============================================================================
// BUDGETING MODULE
// ============================================================================

export const budgetTypeEnum = pgEnum("budget_type", ["OPERATING_PL", "BALANCE_SHEET", "CASHFLOW"]);
export const budgetScopeTypeEnum = pgEnum("budget_scope_type", ["PORTFOLIO", "MARINA"]);
export const budgetStatusEnum = pgEnum("budget_status", ["DRAFT", "LOCKED", "ARCHIVED"]);
export const budgetDimensionTypeEnum = pgEnum("budget_dimension_type", ["NONE", "MARINA", "DEPARTMENT", "PROFIT_CENTER"]);
export const budgetLineTypeEnum = pgEnum("budget_line_type", ["REVENUE", "COGS", "OPEX", "OTHER_INCOME", "OTHER_EXPENSE"]);
export const actualsSourceEnum = pgEnum("actuals_source", ["SEED", "QBO", "UPLOAD", "MANUAL"]);
export const budgetTargetComparatorEnum = pgEnum("budget_target_comparator", ["GTE", "LTE"]);

export const budgets = pgTable('budgets', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar('user_id').notNull().references(() => users.id),
  orgId: varchar('org_id').references(() => organizations.id),
  name: text('name').notNull(),
  fiscalYear: integer('fiscal_year').notNull(),
  type: budgetTypeEnum('type').notNull().default('OPERATING_PL'),
  scopeType: budgetScopeTypeEnum('scope_type').notNull().default('PORTFOLIO'),
  scopeMarinaId: varchar('scope_marina_id'),
  currency: text('currency').notNull().default('USD'),
  status: budgetStatusEnum('status').notNull().default('DRAFT'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  userIdx: index('budgets_user_idx').on(table.userId),
  orgIdx: index('budgets_org_idx').on(table.orgId),
  yearIdx: index('budgets_year_idx').on(table.fiscalYear),
}));

export type Budget = typeof budgets.$inferSelect;
export const insertBudgetSchema = createInsertSchema(budgets).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBudget = z.infer<typeof insertBudgetSchema>;

export const budgetVersions = pgTable('budget_versions', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  budgetId: varchar('budget_id').notNull().references(() => budgets.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  description: text('description'),
  isPrimary: boolean('is_primary').notNull().default(false),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  budgetIdx: index('budget_versions_budget_idx').on(table.budgetId),
}));

export type BudgetVersion = typeof budgetVersions.$inferSelect;
export const insertBudgetVersionSchema = createInsertSchema(budgetVersions).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBudgetVersion = z.infer<typeof insertBudgetVersionSchema>;

export const budgetDimensions = pgTable('budget_dimensions', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  budgetId: varchar('budget_id').notNull().references(() => budgets.id, { onDelete: 'cascade' }),
  dimensionType: budgetDimensionTypeEnum('dimension_type').notNull(),
  enabled: boolean('enabled').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export type BudgetDimension = typeof budgetDimensions.$inferSelect;
export const insertBudgetDimensionSchema = createInsertSchema(budgetDimensions).omit({ id: true, createdAt: true });
export type InsertBudgetDimension = z.infer<typeof insertBudgetDimensionSchema>;

export const budgetLines = pgTable('budget_lines', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  budgetVersionId: varchar('budget_version_id').notNull().references(() => budgetVersions.id, { onDelete: 'cascade' }),
  sortOrder: integer('sort_order').notNull().default(0),
  lineType: budgetLineTypeEnum('line_type').notNull(),
  accountKey: text('account_key').notNull(),
  displayName: text('display_name').notNull(),
  parentAccountKey: text('parent_account_key'),
  dimensionMarinaId: varchar('dimension_marina_id'),
  dimensionDepartment: text('dimension_department'),
  dimensionProfitCenter: text('dimension_profit_center'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  versionIdx: index('budget_lines_version_idx').on(table.budgetVersionId),
  accountIdx: index('budget_lines_account_idx').on(table.accountKey),
}));

export type BudgetLine = typeof budgetLines.$inferSelect;
export const insertBudgetLineSchema = createInsertSchema(budgetLines).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBudgetLine = z.infer<typeof insertBudgetLineSchema>;

export const budgetAmounts = pgTable('budget_amounts', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  budgetLineId: varchar('budget_line_id').notNull().references(() => budgetLines.id, { onDelete: 'cascade' }),
  periodStart: date('period_start').notNull(),
  amount: decimal('amount', { precision: 14, scale: 2 }).notNull().default('0'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  lineIdx: index('budget_amounts_line_idx').on(table.budgetLineId),
  periodIdx: index('budget_amounts_period_idx').on(table.periodStart),
  uniqueLinePeriod: uniqueIndex('budget_amounts_line_period_uniq').on(table.budgetLineId, table.periodStart),
}));

export type BudgetAmount = typeof budgetAmounts.$inferSelect;
export const insertBudgetAmountSchema = createInsertSchema(budgetAmounts).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBudgetAmount = z.infer<typeof insertBudgetAmountSchema>;

export const actualsFacts = pgTable('actuals_facts', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar('user_id').notNull().references(() => users.id),
  orgId: varchar('org_id').references(() => organizations.id),
  periodStart: date('period_start').notNull(),
  lineType: budgetLineTypeEnum('line_type').notNull(),
  accountKey: text('account_key').notNull(),
  dimensionMarinaId: varchar('dimension_marina_id'),
  dimensionDepartment: text('dimension_department'),
  dimensionProfitCenter: text('dimension_profit_center'),
  amount: decimal('amount', { precision: 14, scale: 2 }).notNull().default('0'),
  source: actualsSourceEnum('source').notNull().default('SEED'),
  sourceRef: text('source_ref'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  userIdx: index('actuals_facts_user_idx').on(table.userId),
  orgIdx: index('actuals_facts_org_idx').on(table.orgId),
  periodIdx: index('actuals_facts_period_idx').on(table.periodStart),
  accountIdx: index('actuals_facts_account_idx').on(table.accountKey),
  marinaIdx: index('actuals_facts_marina_idx').on(table.dimensionMarinaId),
}));

export type ActualsFact = typeof actualsFacts.$inferSelect;
export const insertActualsFactSchema = createInsertSchema(actualsFacts).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertActualsFact = z.infer<typeof insertActualsFactSchema>;

export const budgetTargets = pgTable('budget_targets', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar('user_id').notNull().references(() => users.id),
  orgId: varchar('org_id').references(() => organizations.id),
  fiscalYear: integer('fiscal_year').notNull(),
  scopeType: budgetScopeTypeEnum('scope_type').notNull().default('PORTFOLIO'),
  scopeMarinaId: varchar('scope_marina_id'),
  kpiKey: text('kpi_key').notNull(),
  targetValue: decimal('target_value', { precision: 10, scale: 4 }).notNull(),
  comparator: budgetTargetComparatorEnum('comparator').notNull().default('GTE'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  userIdx: index('budget_targets_user_idx').on(table.userId),
  orgIdx: index('budget_targets_org_idx').on(table.orgId),
  yearIdx: index('budget_targets_year_idx').on(table.fiscalYear),
}));

export type BudgetTarget = typeof budgetTargets.$inferSelect;
export const insertBudgetTargetSchema = createInsertSchema(budgetTargets).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBudgetTarget = z.infer<typeof insertBudgetTargetSchema>;
// ============================================================================
// TAX & DISTRIBUTIONS MODULE (Phase A — Scaffold)
// ============================================================================

export const twFilingTypeEnum = pgEnum("tw_filing_type", ["individual", "corporation", "partnership", "trust", "reit", "other"]);
export const twTaxModeEnum = pgEnum("tw_tax_mode", ["flat", "split", "advanced"]);
export const twTaxTimingEnum = pgEnum("tw_tax_timing", ["monthly", "quarterly", "annual"]);
export const twTaxInteractionModeEnum = pgEnum("tw_tax_interaction_mode", ["waterfall_pre_tax", "waterfall_after_tax", "tax_distribution_layer"]);
export const twPartnerRoleEnum = pgEnum("tw_partner_role", ["lp", "gp", "co_gp", "mezz", "other"]);
export const twEntityTypeEnum = pgEnum("tw_entity_type", ["individual", "entity"]);
export const twWaterfallTemplateEnum = pgEnum("tw_waterfall_template", ["straight_split", "pref_catchup", "irr_hurdles", "custom"]);
export const twTierTypeEnum = pgEnum("tw_tier_type", ["return_of_capital", "preferred_return", "catch_up", "split", "tax_distribution"]);
export const twDepreciationMethodEnum = pgEnum("tw_depreciation_method", ["manual", "simple_building_life", "schedule"]);

export const taxProfiles = pgTable('tax_profiles', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar('user_id').notNull().references(() => users.id),
  name: text('name').notNull(),
  filingType: twFilingTypeEnum('filing_type').notNull().default('individual'),
  jurisdictionCountry: text('jurisdiction_country').notNull().default('US'),
  jurisdictionState: text('jurisdiction_state'),
  effectiveTaxRate: decimal('effective_tax_rate', { precision: 8, scale: 6 }),
  ordinaryRate: decimal('ordinary_rate', { precision: 8, scale: 6 }),
  ltcgRate: decimal('ltcg_rate', { precision: 8, scale: 6 }),
  recaptureRate: decimal('recapture_rate', { precision: 8, scale: 6 }),
  niitRate: decimal('niit_rate', { precision: 8, scale: 6 }),
  stateRate: decimal('state_rate', { precision: 8, scale: 6 }),
  localRate: decimal('local_rate', { precision: 8, scale: 6 }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  userIdx: index('tax_profiles_user_idx').on(table.userId),
}));

export type TaxProfile = typeof taxProfiles.$inferSelect;
export const insertTaxProfileSchema = createInsertSchema(taxProfiles).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTaxProfile = z.infer<typeof insertTaxProfileSchema>;

export const projectTaxSettings = pgTable('project_tax_settings', {
  projectId: varchar('project_id').primaryKey().references(() => projects.id, { onDelete: 'cascade' }),
  enabled: boolean('enabled').notNull().default(false),
  taxMode: twTaxModeEnum('tax_mode').notNull().default('flat'),
  taxTiming: twTaxTimingEnum('tax_timing').notNull().default('annual'),
  taxInteractionMode: twTaxInteractionModeEnum('tax_interaction_mode').notNull().default('waterfall_pre_tax'),
  defaultTaxProfileId: varchar('default_tax_profile_id').references(() => taxProfiles.id),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export type ProjectTaxSettings = typeof projectTaxSettings.$inferSelect;
export const insertProjectTaxSettingsSchema = createInsertSchema(projectTaxSettings).omit({ createdAt: true, updatedAt: true });
export type InsertProjectTaxSettings = z.infer<typeof insertProjectTaxSettingsSchema>;

export const projectPartners = pgTable('project_partners', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar('project_id').notNull().references(() => projects.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  role: twPartnerRoleEnum('role').notNull().default('lp'),
  entityType: twEntityTypeEnum('entity_type').notNull().default('individual'),
  taxProfileId: varchar('tax_profile_id').references(() => taxProfiles.id),
  ownershipPercent: decimal('ownership_percent', { precision: 8, scale: 4 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  projectIdx: index('project_partners_project_idx').on(table.projectId),
}));

export type ProjectPartner = typeof projectPartners.$inferSelect;
export const insertProjectPartnerSchema = createInsertSchema(projectPartners).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertProjectPartner = z.infer<typeof insertProjectPartnerSchema>;

export const projectEquityContributions = pgTable('project_equity_contributions', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar('project_id').notNull().references(() => projects.id, { onDelete: 'cascade' }),
  partnerId: varchar('partner_id').notNull().references(() => projectPartners.id, { onDelete: 'cascade' }),
  date: date('date').notNull(),
  amountCents: decimal('amount_cents', { precision: 18, scale: 0 }).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  projectIdx: index('equity_contributions_project_idx').on(table.projectId),
  partnerIdx: index('equity_contributions_partner_idx').on(table.partnerId),
}));

export type ProjectEquityContribution = typeof projectEquityContributions.$inferSelect;
export const insertProjectEquityContributionSchema = createInsertSchema(projectEquityContributions).omit({ id: true, createdAt: true });
export type InsertProjectEquityContribution = z.infer<typeof insertProjectEquityContributionSchema>;

export const waterfallConfigs = pgTable('waterfall_configs', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar('project_id').notNull().references(() => projects.id, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  templateType: twWaterfallTemplateEnum('template_type').notNull().default('straight_split'),
  isActive: boolean('is_active').notNull().default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  projectIdx: index('waterfall_configs_project_idx').on(table.projectId),
}));

export type WaterfallConfig = typeof waterfallConfigs.$inferSelect;
export const insertWaterfallConfigSchema = createInsertSchema(waterfallConfigs).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertWaterfallConfig = z.infer<typeof insertWaterfallConfigSchema>;

export const waterfallTiers = pgTable('waterfall_tiers', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  waterfallConfigId: varchar('waterfall_config_id').notNull().references(() => waterfallConfigs.id, { onDelete: 'cascade' }),
  tierOrder: integer('tier_order').notNull(),
  tierType: twTierTypeEnum('tier_type').notNull(),
  prefRate: decimal('pref_rate', { precision: 8, scale: 6 }),
  catchUpTargetGpShare: decimal('catch_up_target_gp_share', { precision: 8, scale: 6 }),
  irrHurdle: decimal('irr_hurdle', { precision: 8, scale: 6 }),
  equityMultipleHurdle: decimal('equity_multiple_hurdle', { precision: 8, scale: 4 }),
  lpSplit: decimal('lp_split', { precision: 8, scale: 4 }),
  gpSplit: decimal('gp_split', { precision: 8, scale: 4 }),
  notes: text('notes'),
}, (table) => ({
  configIdx: index('waterfall_tiers_config_idx').on(table.waterfallConfigId),
}));

export type WaterfallTier = typeof waterfallTiers.$inferSelect;
export const insertWaterfallTierSchema = createInsertSchema(waterfallTiers).omit({ id: true });
export type InsertWaterfallTier = z.infer<typeof insertWaterfallTierSchema>;

export const projectTaxInputs = pgTable('project_tax_inputs', {
  projectId: varchar('project_id').primaryKey().references(() => projects.id, { onDelete: 'cascade' }),
  annualDepreciationCents: decimal('annual_depreciation_cents', { precision: 18, scale: 0 }),
  depreciationMethod: twDepreciationMethodEnum('depreciation_method').notNull().default('manual'),
  buildingBasisCents: decimal('building_basis_cents', { precision: 18, scale: 0 }),
  buildingLifeYears: integer('building_life_years'),
  bonusDepreciationPercent: decimal('bonus_depreciation_percent', { precision: 8, scale: 6 }),
  amortizationAnnualCents: decimal('amortization_annual_cents', { precision: 18, scale: 0 }),
  interestDeductible: boolean('interest_deductible').notNull().default(true),
  saleCostBasisCents: decimal('sale_cost_basis_cents', { precision: 18, scale: 0 }),
  accumulatedDepreciationCents: decimal('accumulated_depreciation_cents', { precision: 18, scale: 0 }),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export type ProjectTaxInputs = typeof projectTaxInputs.$inferSelect;
export const insertProjectTaxInputsSchema = createInsertSchema(projectTaxInputs).omit({ createdAt: true, updatedAt: true });
export type InsertProjectTaxInputs = z.infer<typeof insertProjectTaxInputsSchema>;

// ============================================
// Universal Capacity Utilization Module
// ============================================

export const utilAssetClassEnum = pgEnum("util_asset_class", ["marina", "hotel", "rv_park", "storage_unit", "industrial", "parking"]);
export const utilOfflineScopeEnum = pgEnum("util_offline_scope", ["unit", "band", "unit_type", "property"]);
export const utilOfflineReasonEnum = pgEnum("util_offline_reason", ["dredging", "storm", "repair", "upgrade", "power_outage", "condemnation", "owner_use", "other"]);
export const utilSnapshotModeEnum = pgEnum("util_snapshot_mode", ["contracted", "physical"]);

export const utilInventoryUnits = pgTable('util_inventory_units', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull(),
  assetClass: utilAssetClassEnum('asset_class').notNull().default('marina'),
  unitCode: varchar('unit_code', { length: 50 }).notNull(),
  unitType: varchar('unit_type', { length: 50 }).notNull(),
  bandKey: varchar('band_key', { length: 20 }),
  lengthFt: decimal('length_ft', { precision: 8, scale: 2 }),
  widthFt: decimal('width_ft', { precision: 8, scale: 2 }),
  depthFt: decimal('depth_ft', { precision: 8, scale: 2 }),
  sqft: decimal('sqft', { precision: 10, scale: 2 }),
  capacityAttributes: jsonb('capacity_attributes').$type<Record<string, any>>().default({}),
  isAvailable: boolean('is_available').default(true).notNull(),
  isOffline: boolean('is_offline').default(false).notNull(),
  offlineReasonCode: varchar('offline_reason_code', { length: 50 }),
  sourceTable: varchar('source_table', { length: 50 }),
  sourceId: varchar('source_id'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('util_inv_org_idx').on(table.orgId),
  propertyTypeIdx: index('util_inv_property_type_idx').on(table.propertyId, table.unitType),
  propertyIdx: index('util_inv_property_idx').on(table.propertyId),
  assetClassIdx: index('util_inv_asset_class_idx').on(table.assetClass),
  bandIdx: index('util_inv_band_idx').on(table.bandKey),
  sourceIdx: index('util_inv_source_idx').on(table.sourceTable, table.sourceId),
}));

export const utilOccupancyEvents = pgTable('util_occupancy_events', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull(),
  unitId: varchar('unit_id').notNull().references(() => utilInventoryUnits.id, { onDelete: 'cascade' }),
  unitType: varchar('unit_type', { length: 50 }).notNull(),
  leaseId: varchar('lease_id'),
  tenantId: varchar('tenant_id'),
  startDate: date('start_date').notNull(),
  endDate: date('end_date'),
  status: varchar('status', { length: 30 }).notNull().default('active'),
  isContracted: boolean('is_contracted').default(true).notNull(),
  ratePlan: jsonb('rate_plan').$type<Record<string, any>>(),
  priceTerms: jsonb('price_terms').$type<Record<string, any>>(),
  monthlyRevenue: decimal('monthly_revenue', { precision: 12, scale: 2 }).notNull().default('0'),
  annualRevenue: decimal('annual_revenue', { precision: 14, scale: 2 }).notNull().default('0'),
  sourceTable: varchar('source_table', { length: 50 }),
  sourceId: varchar('source_id'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('util_occ_org_idx').on(table.orgId),
  propertyTypeIdx: index('util_occ_property_type_idx').on(table.propertyId, table.unitType),
  propertyDatesIdx: index('util_occ_property_dates_idx').on(table.propertyId, table.startDate, table.endDate),
  unitIdx: index('util_occ_unit_idx').on(table.unitId),
  statusIdx: index('util_occ_status_idx').on(table.status),
  sourceIdx: index('util_occ_source_idx').on(table.sourceTable, table.sourceId),
}));

export const utilOfflineBlocks = pgTable('util_offline_blocks', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull(),
  scopeType: utilOfflineScopeEnum('scope_type').notNull().default('unit'),
  scopeKey: varchar('scope_key', { length: 100 }).notNull(),
  unitId: varchar('unit_id').references(() => utilInventoryUnits.id, { onDelete: 'cascade' }),
  startDate: date('start_date').notNull(),
  endDate: date('end_date'),
  reasonCode: utilOfflineReasonEnum('reason_code').notNull().default('other'),
  estimatedRevenueLoss: decimal('estimated_revenue_loss', { precision: 14, scale: 2 }),
  reasonDescription: text('reason_description'),
  createdBy: varchar('created_by'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('util_offline_org_idx').on(table.orgId),
  propertyIdx: index('util_offline_property_idx').on(table.propertyId),
  scopeIdx: index('util_offline_scope_idx').on(table.scopeType, table.scopeKey),
  unitIdx: index('util_offline_unit_idx').on(table.unitId),
  datesIdx: index('util_offline_dates_idx').on(table.startDate, table.endDate),
}));

export const utilSnapshots = pgTable('util_snapshots', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull(),
  assetClass: utilAssetClassEnum('asset_class').notNull().default('marina'),
  periodStart: date('period_start').notNull(),
  periodEnd: date('period_end').notNull(),
  unitType: varchar('unit_type', { length: 50 }),
  bandKey: varchar('band_key', { length: 20 }),
  mode: utilSnapshotModeEnum('mode').notNull().default('contracted'),
  totalUnits: integer('total_units').notNull().default(0),
  occupiedUnits: integer('occupied_units').notNull().default(0),
  offlineUnits: integer('offline_units').notNull().default(0),
  availableUnits: integer('available_units').notNull().default(0),
  unitUtilPct: decimal('unit_util_pct', { precision: 7, scale: 4 }).notNull().default('0'),
  totalCapacity: decimal('total_capacity', { precision: 12, scale: 2 }).notNull().default('0'),
  occupiedCapacity: decimal('occupied_capacity', { precision: 12, scale: 2 }).notNull().default('0'),
  offlineCapacity: decimal('offline_capacity', { precision: 12, scale: 2 }).notNull().default('0'),
  weightedUtilPct: decimal('weighted_util_pct', { precision: 7, scale: 4 }).notNull().default('0'),
  revenue: decimal('revenue', { precision: 14, scale: 2 }).notNull().default('0'),
  revenuePerAvailCapTime: decimal('revenue_per_avail_cap_time', { precision: 10, scale: 4 }).notNull().default('0'),
  offlineCapacityTime: decimal('offline_capacity_time', { precision: 14, scale: 2 }).notNull().default('0'),
  churnMoveIns: integer('churn_move_ins').default(0),
  churnMoveOuts: integer('churn_move_outs').default(0),
  metadata: jsonb('metadata').$type<Record<string, any>>().default({}),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('util_snap_org_idx').on(table.orgId),
  propertyPeriodIdx: index('util_snap_property_period_idx').on(table.propertyId, table.periodStart, table.periodEnd),
  lookupIdx: uniqueIndex('util_snap_lookup_idx').on(table.propertyId, table.periodStart, table.periodEnd, table.unitType, table.bandKey, table.mode),
  assetClassIdx: index('util_snap_asset_class_idx').on(table.assetClass),
  modeIdx: index('util_snap_mode_idx').on(table.mode),
}));

export const insertUtilInventoryUnitSchema = createInsertSchema(utilInventoryUnits).omit({ id: true, createdAt: true, updatedAt: true });
export const selectUtilInventoryUnitSchema = createSelectSchema(utilInventoryUnits);
export type InsertUtilInventoryUnit = z.infer<typeof insertUtilInventoryUnitSchema>;
export type UtilInventoryUnit = typeof utilInventoryUnits.$inferSelect;

export const insertUtilOccupancyEventSchema = createInsertSchema(utilOccupancyEvents).omit({ id: true, createdAt: true, updatedAt: true });
export const selectUtilOccupancyEventSchema = createSelectSchema(utilOccupancyEvents);
export type InsertUtilOccupancyEvent = z.infer<typeof insertUtilOccupancyEventSchema>;
export type UtilOccupancyEvent = typeof utilOccupancyEvents.$inferSelect;

export const insertUtilOfflineBlockSchema = createInsertSchema(utilOfflineBlocks).omit({ id: true, createdAt: true, updatedAt: true });
export const selectUtilOfflineBlockSchema = createSelectSchema(utilOfflineBlocks);
export type InsertUtilOfflineBlock = z.infer<typeof insertUtilOfflineBlockSchema>;
export type UtilOfflineBlock = typeof utilOfflineBlocks.$inferSelect;

export const insertUtilSnapshotSchema = createInsertSchema(utilSnapshots).omit({ id: true, createdAt: true });
export const selectUtilSnapshotSchema = createSelectSchema(utilSnapshots);
export type InsertUtilSnapshot = z.infer<typeof insertUtilSnapshotSchema>;
export type UtilSnapshot = typeof utilSnapshots.$inferSelect;

export const utilPresenceSourceEnum = pgEnum("util_presence_source", ["ais", "camera", "sensor", "manual", "wifi", "bluetooth"]);

export const utilPresenceEvents = pgTable('util_presence_events', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull(),
  unitId: varchar('unit_id').notNull().references(() => utilInventoryUnits.id, { onDelete: 'cascade' }),
  unitType: varchar('unit_type', { length: 50 }).notNull(),
  timestampStart: timestamp('timestamp_start').notNull(),
  timestampEnd: timestamp('timestamp_end'),
  source: utilPresenceSourceEnum('source').notNull().default('manual'),
  confidence: decimal('confidence', { precision: 5, scale: 4 }).default('1.0000'),
  metadata: jsonb('metadata').$type<Record<string, any>>().default({}),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('util_presence_org_idx').on(table.orgId),
  propertyIdx: index('util_presence_property_idx').on(table.propertyId),
  unitIdx: index('util_presence_unit_idx').on(table.unitId),
  propertyDatesIdx: index('util_presence_property_dates_idx').on(table.propertyId, table.timestampStart, table.timestampEnd),
  sourceIdx: index('util_presence_source_idx').on(table.source),
}));

export const insertUtilPresenceEventSchema = createInsertSchema(utilPresenceEvents).omit({ id: true, createdAt: true });
export const selectUtilPresenceEventSchema = createSelectSchema(utilPresenceEvents);
export type InsertUtilPresenceEvent = z.infer<typeof insertUtilPresenceEventSchema>;
export type UtilPresenceEvent = typeof utilPresenceEvents.$inferSelect;

// ── Phase 5: Waitlist & Turn Management ──

export const waitlistStatusEnum = pgEnum("waitlist_status", ["active", "paused", "closed"]);
export const waitlistEntryStatusEnum = pgEnum("waitlist_entry_status", ["waiting", "offered", "accepted", "declined", "expired", "cancelled"]);
export const waitlistOfferStatusEnum = pgEnum("waitlist_offer_status", ["pending", "accepted", "declined", "expired", "cancelled"]);

export const waitlists = pgTable('waitlists', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull(),
  unitType: varchar('unit_type', { length: 50 }).notNull(),
  bandKey: varchar('band_key', { length: 20 }),
  name: varchar('name', { length: 200 }).notNull(),
  status: waitlistStatusEnum('status').notNull().default('active'),
  constraints: jsonb('constraints').$type<Record<string, any>>().default({}),
  maxEntries: integer('max_entries'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('wl_org_idx').on(table.orgId),
  propertyIdx: index('wl_property_idx').on(table.propertyId),
  propertyTypeIdx: index('wl_property_type_idx').on(table.propertyId, table.unitType),
  propertyBandIdx: index('wl_property_band_idx').on(table.propertyId, table.unitType, table.bandKey),
  statusIdx: index('wl_status_idx').on(table.status),
}));

export const waitlistEntries = pgTable('waitlist_entries', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  waitlistId: varchar('waitlist_id').notNull().references(() => waitlists.id, { onDelete: 'cascade' }),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  contactName: varchar('contact_name', { length: 200 }).notNull(),
  contactEmail: varchar('contact_email', { length: 200 }),
  contactPhone: varchar('contact_phone', { length: 50 }),
  contactId: varchar('contact_id'),
  boatLengthFt: decimal('boat_length_ft', { precision: 8, scale: 2 }),
  boatBeamFt: decimal('boat_beam_ft', { precision: 8, scale: 2 }),
  boatDraftFt: decimal('boat_draft_ft', { precision: 8, scale: 2 }),
  boatName: varchar('boat_name', { length: 200 }),
  preferredBandKey: varchar('preferred_band_key', { length: 20 }),
  notes: text('notes'),
  priority: integer('priority').notNull().default(0),
  position: integer('position').notNull().default(0),
  status: waitlistEntryStatusEnum('status').notNull().default('waiting'),
  joinedAt: timestamp('joined_at').defaultNow().notNull(),
  offeredAt: timestamp('offered_at'),
  resolvedAt: timestamp('resolved_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  waitlistIdx: index('wle_waitlist_idx').on(table.waitlistId),
  orgIdx: index('wle_org_idx').on(table.orgId),
  statusIdx: index('wle_status_idx').on(table.status),
  positionIdx: index('wle_position_idx').on(table.waitlistId, table.position),
  contactIdx: index('wle_contact_idx').on(table.contactId),
}));

export const waitlistOffers = pgTable('waitlist_offers', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  entryId: varchar('entry_id').notNull().references(() => waitlistEntries.id, { onDelete: 'cascade' }),
  waitlistId: varchar('waitlist_id').notNull().references(() => waitlists.id, { onDelete: 'cascade' }),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  unitId: varchar('unit_id').notNull(),
  unitCode: varchar('unit_code', { length: 50 }),
  status: waitlistOfferStatusEnum('status').notNull().default('pending'),
  offeredAt: timestamp('offered_at').defaultNow().notNull(),
  expiresAt: timestamp('expires_at'),
  respondedAt: timestamp('responded_at'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  entryIdx: index('wlo_entry_idx').on(table.entryId),
  waitlistIdx: index('wlo_waitlist_idx').on(table.waitlistId),
  orgIdx: index('wlo_org_idx').on(table.orgId),
  statusIdx: index('wlo_status_idx').on(table.status),
  unitIdx: index('wlo_unit_idx').on(table.unitId),
}));

export const insertWaitlistSchema = createInsertSchema(waitlists).omit({ id: true, createdAt: true, updatedAt: true });
export const selectWaitlistSchema = createSelectSchema(waitlists);
export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
export type Waitlist = typeof waitlists.$inferSelect;

export const insertWaitlistEntrySchema = createInsertSchema(waitlistEntries).omit({ id: true, createdAt: true, updatedAt: true });
export const selectWaitlistEntrySchema = createSelectSchema(waitlistEntries);
export type InsertWaitlistEntry = z.infer<typeof insertWaitlistEntrySchema>;
export type WaitlistEntry = typeof waitlistEntries.$inferSelect;

export const insertWaitlistOfferSchema = createInsertSchema(waitlistOffers).omit({ id: true, createdAt: true, updatedAt: true });
export const selectWaitlistOfferSchema = createSelectSchema(waitlistOffers);
export type InsertWaitlistOffer = z.infer<typeof insertWaitlistOfferSchema>;
export type WaitlistOffer = typeof waitlistOffers.$inferSelect;

// ── Phase 7: Pricing Ladder Recommendations ──

export const pricingRuleStatusEnum = pgEnum("pricing_rule_status", ["active", "paused", "archived"]);
export const pricingRecStatusEnum = pgEnum("pricing_rec_status", ["pending", "accepted", "dismissed", "implemented"]);
export const pricingRecActionEnum = pgEnum("pricing_rec_action", ["increase", "decrease", "hold"]);

export const pricingRules = pgTable('pricing_rules', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  name: varchar('name', { length: 200 }).notNull(),
  description: text('description'),
  status: pricingRuleStatusEnum('status').notNull().default('active'),
  priority: integer('priority').notNull().default(0),
  unitType: varchar('unit_type', { length: 50 }),
  bandKey: varchar('band_key', { length: 20 }),
  conditions: jsonb('conditions').$type<{
    metric: string;
    operator: 'gt' | 'gte' | 'lt' | 'lte' | 'eq';
    value: number;
    windowDays?: number;
  }[]>().notNull(),
  action: pricingRecActionEnum('action').notNull().default('increase'),
  adjustmentPct: decimal('adjustment_pct', { precision: 8, scale: 2 }).notNull().default('5'),
  cooldownDays: integer('cooldown_days').notNull().default(90),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('pr_org_idx').on(table.orgId),
  statusIdx: index('pr_status_idx').on(table.status),
}));

export const pricingRecommendations = pgTable('pricing_recommendations', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar('org_id').notNull().references(() => organizations.id),
  propertyId: varchar('property_id').notNull(),
  ruleId: varchar('rule_id').notNull().references(() => pricingRules.id, { onDelete: 'cascade' }),
  unitType: varchar('unit_type', { length: 50 }),
  bandKey: varchar('band_key', { length: 20 }),
  action: pricingRecActionEnum('action').notNull(),
  adjustmentPct: decimal('adjustment_pct', { precision: 8, scale: 2 }).notNull(),
  status: pricingRecStatusEnum('status').notNull().default('pending'),
  drivers: jsonb('drivers').$type<{
    metric: string;
    currentValue: number;
    threshold: number;
    operator: string;
    windowDays?: number;
    satisfied: boolean;
  }[]>().notNull(),
  summary: text('summary').notNull(),
  evaluatedAt: timestamp('evaluated_at').defaultNow().notNull(),
  resolvedAt: timestamp('resolved_at'),
  resolvedBy: varchar('resolved_by'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  orgIdx: index('prec_org_idx').on(table.orgId),
  propertyIdx: index('prec_property_idx').on(table.propertyId),
  ruleIdx: index('prec_rule_idx').on(table.ruleId),
  statusIdx: index('prec_status_idx').on(table.status),
  propertyStatusIdx: index('prec_property_status_idx').on(table.propertyId, table.status),
}));

export const insertPricingRuleSchema = createInsertSchema(pricingRules).omit({ id: true, createdAt: true, updatedAt: true });
export const selectPricingRuleSchema = createSelectSchema(pricingRules);
export type InsertPricingRule = z.infer<typeof insertPricingRuleSchema>;
export type PricingRule = typeof pricingRules.$inferSelect;

export const insertPricingRecommendationSchema = createInsertSchema(pricingRecommendations).omit({ id: true, createdAt: true, updatedAt: true });
export const selectPricingRecommendationSchema = createSelectSchema(pricingRecommendations);
export type InsertPricingRecommendation = z.infer<typeof insertPricingRecommendationSchema>;
export type PricingRecommendation = typeof pricingRecommendations.$inferSelect;

// ============================================
// COA Taxonomy & Mapping Engine Schema
// ============================================

export const coaAssetClassEnum = pgEnum('coa_asset_class', ['MARINA', 'MULTIFAMILY', 'STR', 'SELF_STORAGE', 'RETAIL', 'OFFICE', 'LAUNDROMAT', 'OTHER']);
export const coaStatementTypeEnum = pgEnum('coa_statement_type', ['REVENUE', 'COGS', 'OPEX', 'OTHER']);
export const coaMappingMethodEnum = pgEnum('coa_mapping_method', ['EXACT_ALIAS', 'RULES', 'EMBEDDING', 'LLM', 'MANUAL']);
export const coaReviewStatusEnum = pgEnum('coa_review_status', ['AUTO_MAPPED', 'NEEDS_REVIEW', 'APPROVED', 'OVERRIDDEN', 'DISMISSED']);
export const coaRuleTypeEnum = pgEnum('coa_rule_type', ['KEYWORD', 'REGEX', 'VENDOR', 'CLASS_LOCATION', 'COMPOSITE']);
export const coaAliasSourceEnum = pgEnum('coa_alias_source', ['USER_CONFIRMATION', 'ADMIN_SEED']);
export const coaMappingActionEnum = pgEnum('coa_mapping_action', ['AUTO_MAP', 'APPROVE', 'OVERRIDE', 'BULK_APPROVE', 'DISMISS']);

export const taxonomyPacks = pgTable('coa_taxonomy_packs', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  assetClass: coaAssetClassEnum('asset_class'),
  name: text('name').notNull(),
  version: text('version').default('1.0.0'),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export type TaxonomyPack = typeof taxonomyPacks.$inferSelect;
export const insertTaxonomyPackSchema = createInsertSchema(taxonomyPacks).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTaxonomyPack = z.infer<typeof insertTaxonomyPackSchema>;

export const coaProfitCenters = pgTable('coa_profit_centers', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  packId: varchar('pack_id').notNull().references(() => taxonomyPacks.id),
  code: text('code').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  parentId: varchar('parent_id').references((): any => coaProfitCenters.id),
  sortOrder: integer('sort_order').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export type CoaProfitCenter = typeof coaProfitCenters.$inferSelect;
export const insertCoaProfitCenterSchema = createInsertSchema(coaProfitCenters).omit({ id: true, createdAt: true });
export type InsertCoaProfitCenter = z.infer<typeof insertCoaProfitCenterSchema>;

export const coaSubCenters = pgTable('coa_sub_centers', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  packId: varchar('pack_id').notNull().references(() => taxonomyPacks.id),
  profitCenterId: varchar('profit_center_id').notNull().references(() => coaProfitCenters.id),
  code: text('code').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  sortOrder: integer('sort_order').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export type CoaSubCenter = typeof coaSubCenters.$inferSelect;
export const insertCoaSubCenterSchema = createInsertSchema(coaSubCenters).omit({ id: true, createdAt: true });
export type InsertCoaSubCenter = z.infer<typeof insertCoaSubCenterSchema>;

export const coaCanonicalAccounts = pgTable('coa_canonical_accounts', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  packId: varchar('pack_id').notNull().references(() => taxonomyPacks.id),
  profitCenterId: varchar('profit_center_id').notNull().references(() => coaProfitCenters.id),
  subCenterId: varchar('sub_center_id').references(() => coaSubCenters.id),
  code: text('code').notNull(),
  statementType: coaStatementTypeEnum('statement_type').notNull(),
  name: text('name').notNull(),
  description: text('description'),
  keywords: text('keywords').array(),
  drivers: text('drivers').array(),
  isActive: boolean('is_active').default(true),
  sortOrder: integer('sort_order').default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  packStatementIdx: index('coa_canonical_pack_statement_idx').on(table.packId, table.statementType),
}));

export type CoaCanonicalAccount = typeof coaCanonicalAccounts.$inferSelect;
export const insertCoaCanonicalAccountSchema = createInsertSchema(coaCanonicalAccounts).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCoaCanonicalAccount = z.infer<typeof insertCoaCanonicalAccountSchema>;

export const coaGlobalAliases = pgTable('coa_global_aliases', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  packId: varchar('pack_id').notNull().references(() => taxonomyPacks.id),
  rawLabel: text('raw_label').notNull(),
  normalizedLabel: text('normalized_label').notNull(),
  canonicalAccountId: varchar('canonical_account_id').notNull().references(() => coaCanonicalAccounts.id),
  confidenceHint: numeric('confidence_hint', { precision: 5, scale: 2 }).default('0.90'),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  packNormalizedIdx: index('coa_global_alias_pack_normalized_idx').on(table.packId, table.normalizedLabel),
}));

export type CoaGlobalAlias = typeof coaGlobalAliases.$inferSelect;
export const insertCoaGlobalAliasSchema = createInsertSchema(coaGlobalAliases).omit({ id: true, createdAt: true });
export type InsertCoaGlobalAlias = z.infer<typeof insertCoaGlobalAliasSchema>;

export const coaUserAliases = pgTable('coa_user_aliases', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar('user_id').notNull(),
  orgId: varchar('org_id').notNull(),
  packId: varchar('pack_id').notNull().references(() => taxonomyPacks.id),
  rawLabel: text('raw_label').notNull(),
  normalizedLabel: text('normalized_label').notNull(),
  canonicalAccountId: varchar('canonical_account_id').notNull().references(() => coaCanonicalAccounts.id),
  profitCenterId: varchar('profit_center_id').notNull().references(() => coaProfitCenters.id),
  subCenterId: varchar('sub_center_id').references(() => coaSubCenters.id),
  createdFrom: coaAliasSourceEnum('created_from').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  orgNormalizedIdx: index('coa_user_alias_org_normalized_idx').on(table.orgId, table.normalizedLabel),
}));

export type CoaUserAlias = typeof coaUserAliases.$inferSelect;
export const insertCoaUserAliasSchema = createInsertSchema(coaUserAliases).omit({ id: true, createdAt: true });
export type InsertCoaUserAlias = z.infer<typeof insertCoaUserAliasSchema>;

export const coaMappingRules = pgTable('coa_mapping_rules', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  packId: varchar('pack_id').notNull().references(() => taxonomyPacks.id),
  name: text('name').notNull(),
  priority: integer('priority').default(100),
  ruleType: coaRuleTypeEnum('rule_type').notNull(),
  pattern: text('pattern').notNull(),
  excludes: text('excludes'),
  requiredFields: text('required_fields').array(),
  outputCanonicalAccountId: varchar('output_canonical_account_id').notNull().references(() => coaCanonicalAccounts.id),
  outputProfitCenterId: varchar('output_profit_center_id').notNull().references(() => coaProfitCenters.id),
  outputSubCenterId: varchar('output_sub_center_id').references(() => coaSubCenters.id),
  baseConfidence: numeric('base_confidence', { precision: 5, scale: 2 }).default('0.85'),
  explanationTemplate: text('explanation_template'),
  isActive: boolean('is_active').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
}, (table) => ({
  packPriorityIdx: index('coa_mapping_rules_pack_priority_idx').on(table.packId, table.priority),
}));

export type CoaMappingRule = typeof coaMappingRules.$inferSelect;
export const insertCoaMappingRuleSchema = createInsertSchema(coaMappingRules).omit({ id: true, createdAt: true });
export type InsertCoaMappingRule = z.infer<typeof insertCoaMappingRuleSchema>;

export const coaMappedLineItems = pgTable('coa_mapped_line_items', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  extractedItemId: varchar('extracted_item_id').notNull().unique().references(() => docIntelExtractedItems.id, { onDelete: 'cascade' }),
  packId: varchar('pack_id').notNull().references(() => taxonomyPacks.id),
  canonicalAccountId: varchar('canonical_account_id').notNull().references(() => coaCanonicalAccounts.id),
  profitCenterId: varchar('profit_center_id').notNull().references(() => coaProfitCenters.id),
  subCenterId: varchar('sub_center_id').references(() => coaSubCenters.id),
  confidence: numeric('confidence', { precision: 5, scale: 4 }).notNull(),
  method: coaMappingMethodEnum('method').notNull(),
  explanation: text('explanation'),
  candidates: jsonb('candidates'),
  reviewedStatus: coaReviewStatusEnum('reviewed_status').notNull().default('NEEDS_REVIEW'),
  reviewedByUserId: varchar('reviewed_by_user_id'),
  reviewedAt: timestamp('reviewed_at'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
}, (table) => ({
  extractedItemIdx: index('coa_mapped_extracted_item_idx').on(table.extractedItemId),
  reviewedStatusIdx: index('coa_mapped_reviewed_status_idx').on(table.reviewedStatus),
}));

export type CoaMappedLineItem = typeof coaMappedLineItems.$inferSelect;
export const insertCoaMappedLineItemSchema = createInsertSchema(coaMappedLineItems).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCoaMappedLineItem = z.infer<typeof insertCoaMappedLineItemSchema>;

export const coaMappingAuditLog = pgTable('coa_mapping_audit_log', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar('user_id'),
  orgId: varchar('org_id'),
  extractedItemId: varchar('extracted_item_id'),
  oldMapping: jsonb('old_mapping'),
  newMapping: jsonb('new_mapping'),
  action: coaMappingActionEnum('action').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export type CoaMappingAuditLog = typeof coaMappingAuditLog.$inferSelect;
export const insertCoaMappingAuditLogSchema = createInsertSchema(coaMappingAuditLog).omit({ id: true, createdAt: true });
export type InsertCoaMappingAuditLog = z.infer<typeof insertCoaMappingAuditLogSchema>;

// ============================================
// DEBT ENGINE - Phase 1 (Single Loan)
// ============================================

export const loanTypeEnum = pgEnum('loan_type', ['acquisition', 'bridge', 'perm']);
export const loanStructureEnum = pgEnum('loan_structure', ['senior', 'mezz']);
export const rateTypeEnum = pgEnum('rate_type', ['fixed', 'floating']);
export const indexTypeEnum = pgEnum('index_type', ['sofr', 'treasury', 'prime']);
export const loanAmountTypeEnum = pgEnum('loan_amount_type', ['amount', 'ltc', 'ltv']);
export const prepayTypeEnum = pgEnum('prepay_type', ['none', 'stepdown', 'yield_maint', 'defeasance']);

export const loans = pgTable('loans', {
  id: varchar('id').primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar('project_id').notNull(),
  orgId: varchar('org_id').notNull(),
  ordinal: integer('ordinal').default(1).notNull(),
  loanName: text('loan_name').default('Acquisition Loan').notNull(),
  loanType: loanTypeEnum('loan_type').default('acquisition').notNull(),
  structure: loanStructureEnum('structure').default('senior').notNull(),
  startDate: varchar('start_date'),
  termMonths: integer('term_months').default(60).notNull(),
  amortMonths: integer('amort_months').default(300).notNull(),
  interestOnlyMonths: integer('interest_only_months').default(0).notNull(),
  rateType: rateTypeEnum('rate_type').default('fixed').notNull(),
  fixedRate: numeric('fixed_rate'),
  indexType: indexTypeEnum('index_type'),
  spreadBps: integer('spread_bps'),
  indexFloorBps: integer('index_floor_bps'),
  initialIndexBps: integer('initial_index_bps'),
  loanAmountType: loanAmountTypeEnum('loan_amount_type').default('amount').notNull(),
  loanAmount: numeric('loan_amount').notNull(),
  capitalizeOriginationFees: boolean('capitalize_origination_fees').default(false).notNull(),
  originationFeePct: numeric('origination_fee_pct'),
  underwritingFee: numeric('underwriting_fee'),
  legalFee: numeric('legal_fee'),
  appraisalFee: numeric('appraisal_fee'),
