# MarinaMatch Platform Map
**Master context document — read by ALL agents at the start of every session.**
_Last manually updated: March 2026_

---

## Platform Identity

MarinaMatch (also called Marinalytics) is an **institutional-grade multi-asset commercial real estate investment and management platform**. It is NOT just a marina tool — it supports 55+ asset classes across CRE and operating businesses.

**Stack:** React/TypeScript (Vite) · Node.js/Express · PostgreSQL · Drizzle ORM  
**Hosting:** Replit  
**Auth:** Session-based (req.session.userId)  
**Multi-tenant:** All queries scoped by `org_id`  
**Test org:** `cd3719c3-ef82-4ccc-acb9-261c80fb64b4`  
**Test project:** `6b3a9021-f393-489d-9274-321ac76eae08` (STR asset class)

---

## Design System

- **Colors:** Deep Marine Blue (`#0A2342`), Maritime Steel (`#4A6FA5`), Harbor Teal (`#2DD4BF`)
- **Typography:** Inter (UI) + Roboto Mono (numbers/data)
- **Component patterns:** Three-column CrmRecordPage, MM-UI modal system, KPI chip headers
- **Never introduce** new UI libraries without checking package.json first

---

## Critical Technical Rules (apply to ALL agents)

| Rule | Detail |
|---|---|
| **Never `npm run db:push`** | Always use raw `pool.query()` or psql |
| **RLS tables** | `modeling_project_config`, `modeling_scenario_versions` — always raw pool.query() |
| **snake_case → camelCase** | Raw SQL returns snake_case — always map explicitly in routes |
| **Server restart** | Required after any new Express route — `pkill -f 'tsx server' && npm run dev &` |
| **Patching** | Use `node --input-type=module` heredoc scripts for file edits |
| **Git** | Commit after every successful agent task |

---

## Feature Area Map

### 1. FINANCIAL MODEL ENGINE
**Status:** Phase 3 complete. Frontend QA remaining. Feature gating pending billing.

#### 1a. Pro Forma (✅ Built)
- **Location:** `client/src/components/workspace/ProFormaTab.tsx`
- **Routes:** `/api/marinamatch/modeling-projects/:id/pro-forma`
- **What it does:** Revenue/expense projection engine, seasonality auto-derived, asset-class agnostic
- **Connections:** Feeds DCF, Monte Carlo, Multi-Year Projection, Exit Strategy

#### 1b. DCF / Valuation (✅ Built)
- **Location:** `client/src/components/workspace/DcfTab.tsx`
- **Routes:** `/api/marinamatch/modeling-projects/:id/dcf`
- **What it does:** Discounted cash flow consuming Pro Forma canonical output, XIRR consolidated
- **Connections:** Consumes Pro Forma → outputs to Decision Support, Deal Comparison

#### 1c. Multi-Year Pro Forma (✅ Built)
- **Verified:** Year 1 NOI $50,629 / Year 5 NOI $57,018 at 3% CAGR
- **Routes:** `/api/marinamatch/modeling-projects/:id/multi-year`
- **Connections:** Feeds DCF long-term view

#### 1d. Monte Carlo Simulation (✅ Built)
- **Location:** workspace tab
- **Connections:** Consumes Pro Forma assumptions, outputs to Decision Support

#### 1e. Decision Support (✅ Built)
- **Includes:** Tornado chart, attribution analysis, investment memo generator
- **Connections:** Consumes DCF + Monte Carlo outputs

#### 1f. Capital Stack / Debt Modeling (✅ Built)
- **Includes:** LTV/dollar toggle, DSCR timeline, multi-year debt service, projected closing date
- **Connections:** Feeds Pro Forma (debt service line), DCF (equity returns)

#### 1g. Exit Strategy Studio (✅ Built)
- **Includes:** Net Proceeds, DST Analysis, Waterfall (unified to canonical exit-scenario-engine)
- **Connections:** Consumes DCF terminal value, Capital Stack equity layers

#### 1h. Investment Criteria / Buy-Box (✅ Built)
- **Includes:** Weighted scoring, must-have criteria, per-criterion match breakdowns
- **Connections:** Feeds Deal Pipeline (auto-score inbound deals), Marketplace (filter)

#### 1i. Payroll Module (✅ Built — schema only)
- **Tables:** 30+ tables for payroll, burden profiles, department allocations
- **Status:** Schema built, UI NOT built yet
- **Connections:** Feeds Pro Forma operating expenses, feeds Reporting

#### 1j. Frontend Visual QA (🔲 TODO)
- **Task:** Visual QA pass across all FM tabs — check layout, empty states, number formatting
- **Priority:** Medium — do after CRM/Pipeline queue is complete

#### 1k. Feature Gating (🔲 TODO — blocked on Billing)
- **Task:** Gate premium FM features behind entitlements when billing is built
- **Blocked by:** Billing Engine (Feature 1.1 in gap spec)

---

### 2. CRM / DEAL PIPELINE
**Status:** Core built. Enhancement queue active.

#### 2a. CRM Record Pages (✅ Built)
- **Entities:** Contacts, Deals, Organizations, Activities (all four built)
- **Layout:** Three-column CrmRecordPage pattern
- **Routes:** `/api/marinamatch/crm/...`

#### 2b. Pipeline Board / Kanban (✅ Built)
- **Includes:** Drag-and-drop, stage management
- **Connections:** Deals link to Modeling Projects (Deal Room), Contacts, Organizations

#### 2c. Workflow Automation Engine (✅ Built)
- **Tables:** `workflow_rules`, `workflow_executions`, `workflow_tasks`, `workflow_notifications`
- **Trigger types:** 7 types (deal stage change, new contact, etc.)
- **Action types:** 7 executors (send email, create task, notify, etc.)
- **Routes:** `/api/marinamatch/workflow-rules`
- **Connections:** Triggers on CRM events → creates tasks/notifications

#### 2d. Deal Timeline / Gantt (🔲 TODO — Priority #2)
- **Spec needed:** Planner agent should spec this first
- **Connections:** Reads deal key_dates, pipeline stages, custom milestones

#### 2e. Deal Comparison (🔲 TODO — Priority #3)
- **Spec needed:** Planner agent
- **Connections:** Pulls from DCF outputs, Pro Forma, Capital Stack per deal

#### 2f. Key Dates on Kanban Cards (🔲 TODO — Priority #4)
- **Simple:** UI-only change to existing Kanban card component
- **Connections:** Reads existing deal date fields

#### 2g. Global Activity Log Polish (🔲 TODO — Priority #5)
- **Includes:** Better timestamps, filters by entity type/actor, pagination
- **Connections:** Reads `crm_activities` table

#### 2h. Email Send Integration (🔲 TODO — Priority #6)
- **Spec needed:** Planner agent
- **Connections:** Workflow Automation → sends via email provider (SendGrid or similar)

#### 2i. Relationship Intelligence / Preferred Network (✅ Built)
- **Includes:** Weighted scoring, badge system for key contacts
- **Connections:** Links contacts to deals, organizations

---

### 3. PROSPECTING / MARKETPLACE
**Status:** Core marketplace built. Scraping pipeline and enrichment incomplete.

#### 3a. Marketplace Listings (✅ Built)
- **Component:** `MarketplaceListings.tsx`
- **Features:** Filter sidebar, 3 view modes, source health strip, Add to Pipeline modal
- **Routes:** `/api/marinamatch/sourced-deals`
- **Connections:** "Add to Pipeline" creates a CRM deal, links to Investment Criteria scoring

#### 3b. Marina Property Intelligence Map (✅ Built)
- **Component:** Canvas heat map, A+–C grade markers, left sidebar list, right detail panel (4 tabs)
- **Tabs:** Overview, Financials, Demographics, Market
- **Routes:** Needs `/api/marinamatch/marina-properties` CRUD routes (partially implemented)
- **Tables:** `marina_properties`
- **Connections:** Links to Marketplace, links to Modeling Projects

#### 3c. Map Data Integration (🔲 TODO)
- **Needs:** Google Maps API geocoding, Mapbox GL JS for rendering
- **Data sources:** Census ACS, HUD data for demographics tab
- **Connections:** `marina_properties` DB table → map markers

#### 3d. Lead Enrichment Pipeline (🔲 TODO)
- **Task:** When a listing is added to pipeline, auto-enrich with owner data, public records, permit history
- **Connections:** Marketplace → CRM Contacts (auto-create owner contact)

#### 3e. Scraping Health Dashboard (🔲 TODO)
- **Task:** Monitor source health strip — show last scrape time, success rate, new listing count per source
- **Connections:** `sourced_deals` source metadata

---

### 4. AI ADVISOR / RAG SYSTEM
**Status:** Core files delivered. Integration incomplete.

#### 4a. Knowledge Base Service (✅ Built — needs integration)
- **File:** `knowledge-base-service.ts`
- **Features:** OpenAI embeddings, global anonymous knowledge pool
- **Known gaps:** Missing entity injection, no deal comparison in advisor, raw markdown rendering in UI

#### 4b. AI Assistant Routes + UI (✅ Built — needs integration)
- **Files:** Enhanced AI assistant service, routes, UI component
- **Connections:** Should read Deal Room context (current deal), Pro Forma outputs, CRM data

#### 4c. Entity Injection (🔲 TODO)
- **Task:** When user is in a Deal Room, inject that deal's data into AI context automatically
- **Connections:** Reads modeling_projects, crm_deals, pro forma outputs

#### 4d. Deal Comparison in AI Advisor (🔲 TODO)
- **Task:** Allow user to ask "compare this deal to X" — advisor pulls both deals' data
- **Connections:** DCF outputs, Pro Forma, Investment Criteria scores

#### 4e. Markdown Rendering Fix (🔲 TODO)
- **Task:** AI responses currently render raw markdown — add proper MD renderer to UI
- **Simple:** Add react-markdown or similar to the advisor chat component

---

### 5. DOCUMENT STUDIO / MARKETING PACKAGES
**Status:** Claude Code prompt written. Implementation not started.

#### 5a. IC / Deal Review Deck (🔲 TODO)
- **Template system:** `{{TOKEN}}` substitution, live data binding to Pro Forma/DCF outputs
- **Output formats:** PDF, HTML, JSON
- **Connections:** Reads modeling_projects → pro forma → DCF → Capital Stack

#### 5b. Offering Memorandum (🔲 TODO)
- **Template system:** Section-level modularity, same TOKEN system
- **Connections:** Same as IC Deck + property data from marina_properties

#### 5c. Document Template Engine (🔲 TODO)
- **Task:** Build the shared {{TOKEN}} substitution engine both IC Deck and OM use
- **Technical:** No auto-server-restart after route changes, raw pool.query() for config tables

#### 5d. PDF Generation Routes (🔲 TODO)
- **Routes:** `POST /api/marinamatch/documents/ic-deck`, `POST /api/marinamatch/documents/om`
- **Tech:** Python/reportlab or puppeteer for PDF generation
- **Connections:** Calls Pro Forma and DCF routes to build payload

---

### 6. REPORTING & ANALYTICS
**Status:** Not started.

#### 6a. Portfolio Dashboard (🔲 TODO)
- **Task:** Org-level view — all deals, aggregate NOI, total equity deployed, avg DSCR
- **Connections:** Rolls up all modeling_projects for org → Pro Forma + DCF outputs

#### 6b. Pipeline Analytics (🔲 TODO)
- **Task:** Deal velocity, win rate, avg days in stage, conversion funnel
- **Connections:** Reads crm_deals, crm_activities, pipeline stages

#### 6c. Payroll / Expense Reporting (🔲 TODO)
- **Blocked by:** Payroll UI (schema exists, UI not built)
- **Connections:** Payroll tables → Pro Forma operating expenses

---

### 7. BILLING / ENTITLEMENTS
**Status:** Entitlements system built (feature flags). Billing engine NOT built.

#### 7a. Entitlements System (✅ Built)
- **Includes:** Subscription-based feature flags, atomic feature modules, persona-based onboarding
- **Connections:** Guards premium features across all modules

#### 7b. Billing Engine (🔲 TODO — Gap Spec Feature 1.1)
- **Task:** Stripe integration, plan management, usage metering
- **Connections:** Entitlements system reads billing status to unlock features

---

### 8. INFRASTRUCTURE / PLATFORM
**Status:** Partially built.

#### 8a. Institutional Readiness (✅ Built)
- **Includes:** Security middleware, OpenTelemetry, API standards, health checks, DB indexing, error boundaries

#### 8b. P&L Parser v2 (✅ Built)
- **Includes:** pdfjs-dist geometry extraction, 6 validation checks, alias learning with weight-based confidence

#### 8c. Universal Asset Class Registry (✅ Built)
- **Includes:** 55+ asset classes via varchar-based registry (migrated from Postgres enums)

---

## Connectivity Matrix
**Every feature that touches another — agents must not build in isolation.**

```
Pro Forma ──────────────────┬──→ DCF
                            ├──→ Multi-Year Projection  
                            ├──→ Monte Carlo
                            └──→ Document Studio (IC Deck, OM)

DCF ────────────────────────┬──→ Decision Support
                            ├──→ Exit Strategy Studio
                            ├──→ Deal Comparison
                            └──→ AI Advisor (entity injection)

Capital Stack ──────────────┬──→ Pro Forma (debt service)
                            └──→ Exit Strategy (equity waterfall)

Investment Criteria ────────┬──→ Marketplace (auto-score listings)
                            └──→ Deal Pipeline (score deals on intake)

Marketplace ────────────────┬──→ CRM Pipeline (Add to Pipeline)
                            └──→ Marina Property Map (cross-reference)

Workflow Automation ────────┬──→ CRM events (trigger source)
                            ├──→ Email Send (action target)
                            └──→ Tasks/Notifications (action target)

AI Advisor ─────────────────┬──→ Deal Room context (entity injection)
                            ├──→ Pro Forma + DCF (data source)
                            └──→ Knowledge Base (RAG source)

Document Studio ────────────┬──→ Pro Forma (data binding)
                            ├──→ DCF (data binding)
                            └──→ Capital Stack (data binding)

Payroll ────────────────────→  Pro Forma (operating expense line)

Billing/Entitlements ───────→  All premium features (gate)
```

---

## Build Priority Order for Agents

When the queue is empty or the agent must self-direct, work in this order:

### Tier 1 — CRM/Pipeline (active priority queue)
1. ✅ Workflow Automation
2. 🔲 Deal Timeline/Gantt
3. 🔲 Deal Comparison
4. 🔲 Key Dates on Kanban
5. 🔲 Global Activity Log Polish
6. 🔲 Email Send Integration

### Tier 2 — AI Advisor Fixes
7. 🔲 Markdown rendering fix (quick win)
8. 🔲 Entity injection (deal context)
9. 🔲 Deal comparison in advisor

### Tier 3 — Document Studio
10. 🔲 Token substitution engine
11. 🔲 IC Deck template + PDF route
12. 🔲 Offering Memorandum template + PDF route

### Tier 4 — Prospecting Depth
13. 🔲 Map data integration (geocoding + Mapbox)
14. 🔲 Lead enrichment pipeline
15. 🔲 Scraping health dashboard

### Tier 5 — Reporting
16. 🔲 Portfolio dashboard
17. 🔲 Pipeline analytics
18. 🔲 Payroll UI

### Tier 6 — Platform / Billing
19. 🔲 Billing engine (Stripe)
20. 🔲 Financial model feature gating
21. 🔲 FM frontend visual QA

---

## What "Done" Means for MarinaMatch

A feature is only truly complete when:
- [ ] Backend route returns correct data (tested with curl)
- [ ] Frontend component renders without TS errors
- [ ] Connected to all modules in the Connectivity Matrix above
- [ ] Empty state handled (no blank screens)
- [ ] Works for test org `cd3719c3-ef82-4ccc-acb9-261c80fb64b4`
- [ ] Journal entry written
- [ ] No regressions in connected features
