# MarinaMatch Agent Task Queue
<!-- Orchestrator reads this file to determine next task -->
<!-- Format: - [type] [status] Description -->
<!-- Types: feature | migration | spec | test | audit -->
<!-- Status: todo | in-progress | done | failed | blocked -->

---

## 🔴 TIER 1 — CRM / DEAL PIPELINE (Active Priority)

- [spec] [todo] Write detailed build spec for Deal Timeline/Gantt view (CRM priority #2)
- [spec] [todo] Write detailed build spec for Deal Comparison workspace — pull DCF + Pro Forma per deal (CRM priority #3)
- [feature] [todo] Add key dates display to Kanban pipeline cards — created, expected close, next follow-up (CRM priority #4)
- [feature] [todo] Polish global activity log — timestamps, filters by entity type and actor, pagination (CRM priority #5)
- [spec] [todo] Spec out Email send integration for CRM Workflow Automation (CRM priority #6)

---

## 🟠 TIER 2 — AI ADVISOR / RAG FIXES

- [feature] [todo] Fix AI advisor markdown rendering — add react-markdown renderer to chat UI
- [spec] [todo] Spec entity injection for AI Advisor — auto-inject current Deal Room context into AI prompts
- [feature] [todo] Implement AI advisor entity injection — reads modeling_project, pro forma, DCF for current deal
- [spec] [todo] Spec deal comparison capability in AI Advisor — "compare this deal to X" query pattern

---

## 🟡 TIER 3 — DOCUMENT STUDIO / MARKETING PACKAGES

- [spec] [todo] Spec the shared token substitution engine for Document Studio
- [migration] [todo] Create document_templates and document_renders tables for Document Studio
- [feature] [todo] Build token substitution engine — Express route + token resolver pulling live Pro Forma and DCF data
- [spec] [todo] Spec IC Deal Review Deck — section layout, token map, PDF output route
- [feature] [todo] Build IC Deal Review Deck template + POST /api/marinamatch/documents/ic-deck PDF route
- [spec] [todo] Spec Offering Memorandum template — section modularity, token map, PDF output
- [feature] [todo] Build Offering Memorandum template + POST /api/marinamatch/documents/om PDF route
- [feature] [todo] Build Document Studio UI tab — InvestmentMaterialsTab.tsx with IC Deck and OM cards and generate buttons

---

## 🟢 TIER 4 — PROSPECTING / MARKETPLACE DEPTH

- [spec] [todo] Spec Marina Property Intelligence Map data integration — geocoding and Mapbox GL JS rendering
- [migration] [todo] Ensure marina_properties table has all required columns — lat/lng, investment grade, demographics JSON
- [feature] [todo] Implement CRUD routes for /api/marinamatch/marina-properties
- [feature] [todo] Wire Marina Property Map to live DB data — replace any stub or mock data
- [spec] [todo] Spec lead enrichment pipeline — when deal added from Marketplace, auto-create owner CRM contact
- [feature] [todo] Implement lead enrichment pipeline — Marketplace add-to-pipeline triggers auto CRM contact creation
- [feature] [todo] Build scraping health dashboard — source health strip with last scrape time, success rate, new listing count

---

## 🔵 TIER 5 — REPORTING & ANALYTICS

- [spec] [todo] Spec portfolio dashboard — org-level rollup of all deals: aggregate NOI, equity deployed, avg DSCR
- [migration] [todo] Create portfolio_snapshots table for caching portfolio rollup calculations
- [feature] [todo] Build portfolio dashboard page — reads all modeling_projects for org, rolls up Pro Forma and DCF outputs
- [spec] [todo] Spec pipeline analytics — deal velocity, win rate, avg days in stage, conversion funnel
- [feature] [todo] Build pipeline analytics tab in CRM — funnel chart, velocity metrics, stage conversion rates
- [spec] [todo] Spec payroll UI — P&L expense drill-down using existing 30+ payroll tables
- [feature] [todo] Build payroll module UI — department allocations, burden profiles, connects to Pro Forma opex line

---

## 🟣 TIER 6 — FINANCIAL MODEL POLISH

- [test] [todo] Visual QA pass on all Financial Model tabs — layout, empty states, number formatting, edge cases
- [spec] [todo] Spec financial model feature gating — which FM features gate behind which entitlement tiers
- [feature] [todo] Implement FM feature gating — guard premium tabs behind entitlements once billing is built

---

## ⚫ TIER 7 — PLATFORM / BILLING

- [spec] [todo] Spec Billing Engine — Stripe integration, plan management, usage metering (Gap Spec Feature 1.1)
- [migration] [todo] Create billing tables — subscriptions, invoices, usage_events, plan_entitlements
- [feature] [todo] Build Billing Engine — Stripe webhook handler, plan upgrade/downgrade, entitlement sync

---

## 🔍 AUDIT TASKS (run periodically)

- [audit] [todo] Full connectivity audit — verify every feature in Connectivity Matrix is wired end-to-end
- [audit] [todo] Empty state audit — check every page and tab for blank screen conditions
- [audit] [todo] API route inventory — list all /api/marinamatch/ routes and verify each has a UI entry point

---

## Completed

- [feature] [done] Workflow Automation engine — rules, executions, tasks, notifications tables and UI
- [feature] [done] MarketplaceListings.tsx — filter sidebar, 3 view modes, source health strip, Add to Pipeline modal
- [feature] [done] Marina Property Intelligence Map — canvas heat map, grade markers, 4-tab detail panel
- [feature] [done] AI Advisor knowledge-base-service.ts — embeddings, RAG, anonymous knowledge pool
- [feature] [done] CRM Record Pages — all 4 entity types, 3-column layout, 12 WIP components graduated
- [feature] [done] DCF Phase 3 — consumes canonical Pro Forma, Monte Carlo, Decision Support, 154/154 tests
- [feature] [done] Multi-Year Pro Forma — pure-function projection engine, verified NOI figures
- [feature] [done] Capital Stack — LTV/dollar toggle, DSCR timeline, projected closing date
- [feature] [done] Exit Strategy Studio — Net Proceeds, DST, Waterfall unified to canonical engine
- [feature] [done] Investment Criteria buy-box — weighted scoring, must-have criteria, match breakdowns
- [feature] [done] P&L Parser v2 — pdfjs-dist geometry extraction, alias learning
- [feature] [done] Payroll module schema — 30+ tables for payroll, burden profiles, department allocations
- [feature] [done] Entitlements system — subscription feature flags, persona-based onboarding
- [feature] [done] Institutional readiness — security middleware, OpenTelemetry, health checks, DB indexing

---

## Failed / Blocked

