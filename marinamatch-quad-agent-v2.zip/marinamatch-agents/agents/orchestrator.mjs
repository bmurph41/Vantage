#!/usr/bin/env node
// ============================================================
// MarinaMatch Quad Agent — Orchestrator
// Reads AGENT_QUEUE.md, picks next task, routes to correct agent
// Run: node ~/workspace/agents/orchestrator.mjs
// ============================================================

import { execSync, spawnSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WORKSPACE = path.resolve(__dirname, '..');
const AGENTS_DIR = __dirname;
const LOG_DIR = path.join(WORKSPACE, 'agent-logs');
const QUEUE_FILE = path.join(WORKSPACE, 'AGENT_QUEUE.md');
const STATUS_FILE = path.join(WORKSPACE, 'BUILD_STATUS.md');
const JOURNAL_FILE = path.join(WORKSPACE, 'MARINAMATCH_JOURNAL.md');
const PLATFORM_MAP_FILE = path.join(WORKSPACE, 'MARINAMATCH_PLATFORM_MAP.md');

// ── Logging ──────────────────────────────────────────────────
const timestamp = () => new Date().toISOString().replace('T', ' ').slice(0, 19);
const log = (msg) => {
  const line = `[${timestamp()}] ${msg}`;
  console.log(line);
  fs.appendFileSync(path.join(LOG_DIR, 'orchestrator.log'), line + '\n');
};

// ── Task Queue Parser ─────────────────────────────────────────
function parseQueue() {
  if (!fs.existsSync(QUEUE_FILE)) {
    log('ERROR: AGENT_QUEUE.md not found');
    process.exit(1);
  }

  const content = fs.readFileSync(QUEUE_FILE, 'utf8');
  const lines = content.split('\n');
  const tasks = [];

  for (const line of lines) {
    // Match: - [type] [status] Description
    const match = line.match(/^-\s+\[(\w+)\]\s+\[(\w+)\]\s+(.+)$/);
    if (match) {
      tasks.push({
        type: match[1].toLowerCase(),    // feature | migration | spec | test
        status: match[2].toLowerCase(),  // todo | in-progress | done | failed | blocked
        description: match[3].trim(),
        raw: line
      });
    }
  }

  return tasks;
}

function getNextTask(tasks) {
  // Pick first 'todo' task in order
  return tasks.find(t => t.status === 'todo') || null;
}

function markTaskStatus(task, newStatus, note = '') {
  let content = fs.readFileSync(QUEUE_FILE, 'utf8');
  const newLine = task.raw
    .replace(`[${task.status}]`, `[${newStatus}]`);
  content = content.replace(task.raw, newLine);

  if (newStatus === 'done') {
    // Move to Completed section
    content = content.replace(newLine, '');
    content = content.replace(
      '## Completed\n',
      `## Completed\n- [${task.type}] [done] ${task.description}${note ? ' — ' + note : ''}\n`
    );
  } else if (newStatus === 'failed') {
    content = content.replace(newLine, '');
    content = content.replace(
      '## Failed / Blocked\n',
      `## Failed / Blocked\n- [${task.type}] [failed] ${task.description} — ${note}\n`
    );
  }

  fs.writeFileSync(QUEUE_FILE, content);
}

// ── Agent Map ─────────────────────────────────────────────────
const AGENT_PROMPTS = {
  feature: path.join(AGENTS_DIR, 'builder-agent-prompt.md'),
  migration: path.join(AGENTS_DIR, 'db-agent-prompt.md'),
  spec: path.join(AGENTS_DIR, 'planner-agent-prompt.md'),
  test: path.join(AGENTS_DIR, 'qa-agent-prompt.md'),
  audit: path.join(AGENTS_DIR, 'audit-agent-prompt.md'),
};

// ── Build Status Writer ───────────────────────────────────────
function updateBuildStatus(task, result) {
  const status = `# MarinaMatch Build Status
_Last updated: ${timestamp()}_

## Last Agent Run
- Task type: ${task.type}
- Task: ${task.description}
- Result: ${result.success ? '✅ SUCCESS' : '❌ FAILED'}
- Duration: ${result.duration}s
${result.notes ? `- Notes: ${result.notes}` : ''}

## TypeScript Check
\`\`\`
${result.tsErrors || 'Not run this cycle'}
\`\`\`

## Test Results
\`\`\`
${result.testOutput || 'Not run this cycle'}
\`\`\`

## Agent Log (tail)
See agent-logs/ directory for full history.
`;
  fs.writeFileSync(STATUS_FILE, status);
}

// ── Run Claude Code Agent ─────────────────────────────────────
function runAgent(task) {
  const promptFile = AGENT_PROMPTS[task.type];

  if (!promptFile || !fs.existsSync(promptFile)) {
    log(`ERROR: No prompt file for task type '${task.type}'`);
    return { success: false, notes: 'Missing agent prompt file' };
  }

  const agentPrompt = fs.readFileSync(promptFile, 'utf8');
  const platformMap = fs.existsSync(PLATFORM_MAP_FILE)
    ? fs.readFileSync(PLATFORM_MAP_FILE, 'utf8').slice(0, 6000)
    : 'Platform map not found.';
  const journal = fs.existsSync(JOURNAL_FILE)
    ? fs.readFileSync(JOURNAL_FILE, 'utf8').slice(0, 8000) // first 8k chars
    : 'Journal not found.';

  const fullPrompt = `${agentPrompt}

---
## CURRENT TASK
${task.description}

## PLATFORM MAP (first 6000 chars)
${platformMap}

## JOURNAL CONTEXT (first 8000 chars)
${journal}
`;

  // Write prompt to temp file to avoid shell escaping issues
  const tempPromptFile = `/tmp/agent_prompt_${Date.now()}.md`;
  fs.writeFileSync(tempPromptFile, fullPrompt);

  const logFile = path.join(LOG_DIR, `${task.type}-${Date.now()}.log`);
  const startTime = Date.now();

  log(`Running ${task.type} agent for: "${task.description}"`);

  try {
    const result = spawnSync(
      'claude',
      ['--dangerously-skip-permissions', '-p', fullPrompt],
      {
        cwd: WORKSPACE,
        timeout: 15 * 60 * 1000, // 15 min max per agent run
        encoding: 'utf8',
        maxBuffer: 10 * 1024 * 1024,
      }
    );

    const duration = Math.round((Date.now() - startTime) / 1000);
    fs.writeFileSync(logFile, (result.stdout || '') + '\n' + (result.stderr || ''));

    if (result.status === 0) {
      log(`✅ Agent completed successfully in ${duration}s`);

      // Auto-commit if git is available
      try {
        execSync('git add -A && git commit -m "chore: agent run — ' + task.description.slice(0, 60) + '"', {
          cwd: WORKSPACE
        });
        log('✅ Changes committed to git');
      } catch (e) {
        log('⚠️  Git commit skipped (no changes or git not configured)');
      }

      return { success: true, duration, notes: 'See ' + logFile };
    } else {
      log(`❌ Agent exited with code ${result.status}`);
      return {
        success: false,
        duration,
        notes: (result.stderr || '').slice(0, 200)
      };
    }
  } catch (err) {
    const duration = Math.round((Date.now() - startTime) / 1000);
    log(`❌ Agent threw error: ${err.message}`);
    return { success: false, duration, notes: err.message.slice(0, 200) };
  } finally {
    fs.unlinkSync(tempPromptFile);
  }
}

// ── Run QA after feature/migration ───────────────────────────
function runQACheck() {
  log('Running post-task QA check...');
  const results = { tsErrors: '', testOutput: '' };

  try {
    execSync('npx tsc --noEmit 2>&1', { cwd: WORKSPACE, timeout: 60000 });
    results.tsErrors = 'No TypeScript errors ✅';
  } catch (e) {
    results.tsErrors = (e.stdout || e.message || '').slice(0, 500);
    log('⚠️  TypeScript errors detected — see BUILD_STATUS.md');
  }

  try {
    const testOut = execSync('npm test -- --passWithNoTests 2>&1', {
      cwd: WORKSPACE,
      timeout: 120000,
      encoding: 'utf8'
    });
    results.testOutput = testOut.slice(-500);
  } catch (e) {
    results.testOutput = (e.stdout || e.message || '').slice(0, 500);
    log('⚠️  Test failures detected — see BUILD_STATUS.md');
  }

  return results;
}

// ── Main ──────────────────────────────────────────────────────
async function main() {
  log('=== Orchestrator cycle start ===');

  const tasks = parseQueue();
  const nextTask = getNextTask(tasks);

  if (!nextTask) {
    log('No todo tasks in queue. Orchestrator idle.');
    process.exit(0);
  }

  log(`Next task: [${nextTask.type}] ${nextTask.description}`);
  markTaskStatus(nextTask, 'in-progress');

  const agentResult = runAgent(nextTask);

  // Run QA after feature or migration tasks
  let qaResults = {};
  if (['feature', 'migration'].includes(nextTask.type) && agentResult.success) {
    qaResults = runQACheck();
  }

  updateBuildStatus(nextTask, { ...agentResult, ...qaResults });

  if (agentResult.success) {
    markTaskStatus(nextTask, 'done', agentResult.notes);
    log(`✅ Task marked done: ${nextTask.description}`);
  } else {
    markTaskStatus(nextTask, 'failed', agentResult.notes);
    log(`❌ Task marked failed: ${nextTask.description}`);
  }

  log('=== Orchestrator cycle end ===');
}

main().catch(err => {
  log(`FATAL: ${err.message}`);
  process.exit(1);
});
