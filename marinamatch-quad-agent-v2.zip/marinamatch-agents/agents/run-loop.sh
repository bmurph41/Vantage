#!/bin/bash
# ============================================================
# MarinaMatch Quad Agent — Continuous Run Loop
# Runs orchestrator every N minutes indefinitely
# Usage: bash ~/workspace/agents/run-loop.sh [interval_minutes]
# Default interval: 10 minutes
# ============================================================

WORKSPACE=~/workspace
INTERVAL_MINUTES=${1:-10}
INTERVAL_SECONDS=$((INTERVAL_MINUTES * 60))
LOG="$WORKSPACE/agent-logs/run-loop.log"

mkdir -p "$WORKSPACE/agent-logs"

echo "[$(date '+%Y-%m-%d %H:%M:%S')] Run loop started (interval: ${INTERVAL_MINUTES}m)" | tee -a "$LOG"
echo "  Workspace: $WORKSPACE"
echo "  To stop: kill $$ or pkill -f run-loop.sh"
echo "  Logs: $LOG"
echo ""

cycle=1

while true; do
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] === Cycle $cycle ===" | tee -a "$LOG"

  # Check if there are any todo tasks before spawning agent
  TODO_COUNT=$(grep -c '\[todo\]' "$WORKSPACE/AGENT_QUEUE.md" 2>/dev/null || echo "0")

  if [ "$TODO_COUNT" -eq "0" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Queue empty — sleeping ${INTERVAL_MINUTES}m" | tee -a "$LOG"
  else
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] Found $TODO_COUNT todo task(s) — running orchestrator" | tee -a "$LOG"
    node "$WORKSPACE/agents/orchestrator.mjs" 2>&1 | tee -a "$LOG"
  fi

  echo "[$(date '+%Y-%m-%d %H:%M:%S')] Sleeping ${INTERVAL_MINUTES}m until next cycle..." | tee -a "$LOG"
  sleep "$INTERVAL_SECONDS"
  cycle=$((cycle + 1))
done
