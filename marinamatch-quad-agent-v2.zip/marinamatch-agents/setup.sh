#!/bin/bash
# ============================================================
# MarinaMatch Quad Agent System — One-Time Setup
# Run once from ~/workspace/: bash agents/setup.sh
# ============================================================

set -e

WORKSPACE=~/workspace
AGENTS_DIR="$WORKSPACE/agents"
LOG_DIR="$WORKSPACE/agent-logs"

echo "=========================================="
echo "  MarinaMatch Quad Agent — Setup"
echo "=========================================="

# 1. Verify Claude Code is installed
if ! command -v claude &> /dev/null; then
  echo "[setup] Installing Claude Code globally..."
  npm install -g @anthropic-ai/claude-code
else
  echo "[setup] ✓ Claude Code found: $(claude --version 2>/dev/null || echo 'installed')"
fi

# 2. Create log directory
mkdir -p "$LOG_DIR"
echo "[setup] ✓ Log directory: $LOG_DIR"

# 3. Create agent task queue if it doesn't exist
if [ ! -f "$WORKSPACE/AGENT_QUEUE.md" ]; then
  cat > "$WORKSPACE/AGENT_QUEUE.md" << 'EOF'
# MarinaMatch Agent Task Queue
<!-- Orchestrator reads this file to determine next task -->
<!-- Format: - [type] [status] Task description -->
<!-- Types: feature | migration | spec | test -->
<!-- Status: todo | in-progress | done | failed | blocked -->

## Priority Queue

- [spec] [todo] Write detailed build spec for Deal Timeline/Gantt view (priority #2)
- [spec] [todo] Write detailed build spec for Deal Comparison workspace feature (priority #3)
- [feature] [todo] Add key dates display to Kanban pipeline cards (priority #4)
- [feature] [todo] Polish global activity log — timestamps, filters, actor labels (priority #5)
- [spec] [todo] Spec out Email send integration for CRM (priority #6)

## Completed
<!-- Orchestrator moves done tasks here automatically -->

## Failed / Blocked
<!-- Orchestrator logs failures here with error context -->
EOF
  echo "[setup] ✓ Created AGENT_QUEUE.md"
else
  echo "[setup] ✓ AGENT_QUEUE.md already exists"
fi

# 4. Create BUILD_STATUS.md
cat > "$WORKSPACE/BUILD_STATUS.md" << 'EOF'
# MarinaMatch Build Status
_Last updated: never — run the orchestrator first_

## Current Health
- TypeScript errors: unknown
- Test results: unknown
- Last agent run: never
- Last task completed: none

## Agent Log (last 10 runs)
<!-- Orchestrator appends here -->
EOF
echo "[setup] ✓ Created BUILD_STATUS.md"

# 5. Make orchestrator executable
chmod +x "$AGENTS_DIR/orchestrator.mjs" 2>/dev/null || true
echo "[setup] ✓ Orchestrator ready"

# 6. Verify journal exists
if [ -f "$WORKSPACE/MARINAMATCH_JOURNAL.md" ]; then
  echo "[setup] ✓ MARINAMATCH_JOURNAL.md found"
else
  echo "[setup] ⚠️  WARNING: MARINAMATCH_JOURNAL.md not found at $WORKSPACE"
  echo "           Agents will still run but context will be limited."
fi

echo ""
echo "=========================================="
echo "  Setup complete!"
echo ""
echo "  To run ONE agent cycle manually:"
echo "    node ~/workspace/agents/orchestrator.mjs"
echo ""
echo "  To run continuously (background):"
echo "    bash ~/workspace/agents/run-loop.sh &"
echo ""
echo "  To check build status:"
echo "    cat ~/workspace/BUILD_STATUS.md"
echo "=========================================="
