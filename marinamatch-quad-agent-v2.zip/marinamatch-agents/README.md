# MarinaMatch Quad Agent System
**Four specialized Claude Code agents that build MarinaMatch while you're away.**

---

## File Structure

Drop these into your Replit workspace like this:

```
~/workspace/
├── AGENT_QUEUE.md          ← Task queue (edit this to add work)
├── BUILD_STATUS.md         ← Auto-generated health report (check on mobile)
├── MARINAMATCH_JOURNAL.md  ← Already exists — agents read this
│
└── agents/
    ├── setup.sh                    ← Run once to initialize
    ├── run-loop.sh                 ← Run to start continuous background builds
    ├── orchestrator.mjs            ← Main coordinator script
    ├── builder-agent-prompt.md     ← Feature implementation agent
    ├── qa-agent-prompt.md          ← Quality assurance agent
    ├── db-agent-prompt.md          ← Database/migration agent
    ├── planner-agent-prompt.md     ← Spec writing agent
    └── specs/                      ← Planner agent outputs go here (auto-created)
```

---

## Deployment Steps

### Step 1 — Upload files to Replit
In your Replit workspace shell, create the agents directory and upload all files:
```bash
mkdir -p ~/workspace/agents/specs
mkdir -p ~/workspace/agent-logs
```
Then copy each file into place (paste contents or use Replit's file upload).

### Step 2 — Run setup
```bash
cd ~/workspace
bash agents/setup.sh
```
This installs Claude Code globally (if not already installed), creates log directories, and initializes `BUILD_STATUS.md`.

### Step 3 — Verify Claude Code works
```bash
claude --version
```
If this fails, run: `npm install -g @anthropic-ai/claude-code`

### Step 4 — Test one cycle manually
```bash
node ~/workspace/agents/orchestrator.mjs
```
Watch the output. It should pick the first todo task, run the appropriate agent, and mark it done.

### Step 5 — Start continuous background loop
```bash
# Run with default 10-minute interval
bash ~/workspace/agents/run-loop.sh &

# Or customize interval (e.g., 30 minutes)
bash ~/workspace/agents/run-loop.sh 30 &
```

---

## Managing the Queue

### Add a new task
Edit `AGENT_QUEUE.md` and add a line under `## Priority Queue`:
```
- [feature] [todo] Your task description here
- [spec] [todo] Write spec for X feature
- [migration] [todo] Add Y column to Z table
- [test] [todo] Validate recent changes to X
```

### Reprioritize
Move lines up or down in the Priority Queue section — orchestrator always picks the first `[todo]`.

### Retry a failed task
Change `[failed]` back to `[todo]` in the Failed section, then move it back to Priority Queue.

### Pause the loop
```bash
pkill -f run-loop.sh
```

### Check what's happening right now
```bash
cat ~/workspace/BUILD_STATUS.md         # last build summary
tail -f ~/workspace/agent-logs/orchestrator.log  # live log stream
```

---

## The Four Agents

| Agent | Type tag | What it does |
|---|---|---|
| Builder | `feature` | Implements React/TypeScript/Express features |
| QA | `test` | Runs tsc, npm test, API smoke tests |
| DB | `migration` | Runs raw SQL migrations via pool.query() |
| Planner | `spec` | Writes detailed build specs for upcoming features |

---

## Key Rules Baked Into Every Agent

- **Never `npm run db:push`** — raw pool.query() only
- **Always read MARINAMATCH_JOURNAL.md first**
- **Always write a journal entry when done**
- **Git commit after every successful task**
- **QA runs automatically after feature and migration tasks**

---

## Checking Status From Your Phone

Browse to your Replit project and open:
```
~/workspace/BUILD_STATUS.md
```
This file is rewritten after every agent run with pass/fail, TS error count, and test results.

---

## Troubleshooting

**"claude: command not found"**
```bash
npm install -g @anthropic-ai/claude-code
```

**Agent runs but makes no changes**
- Check `~/workspace/agent-logs/` for the latest log file
- The agent may have found the task already done, or hit a context issue

**TS errors after agent run**
- They'll appear in BUILD_STATUS.md
- Add a `[feature] [todo] Fix TS errors from [task]` task to the queue

**Orchestrator picks wrong task**
- Check AGENT_QUEUE.md — make sure status is `[todo]` not `[in-progress]`
- If stuck in `[in-progress]`, manually change back to `[todo]`
