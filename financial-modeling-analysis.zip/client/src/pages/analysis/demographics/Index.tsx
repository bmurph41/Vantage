import { useState, useCallback, useRef, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Autocomplete, GoogleMap, Circle, Marker } from "@react-google-maps/api";
import { useGoogleMaps } from "@/lib/google-maps-provider";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/hooks/use-toast";
import { 
  TargetDemographicsForm, 
  SiteSuitabilityScore, 
  MarketTrendAnalysis, 
  PropertyComparisonPanel 
} from "@/components/demographics";
import type { TargetDemographics } from "@shared/schema";
import { 
  Users, 
  DollarSign, 
  MapPin, 
  BarChart3,
  Briefcase,
  Home,
  Search,
  GraduationCap,
  PieChart,
  CircleDot,
  Globe,
  X,
  Plus,
  Target,
  Activity,
  Clock,
  Car,
  Ruler,
  Settings,
  RefreshCw,
  Save,
  FolderOpen,
  Building2
} from "lucide-react";

interface ModelingProject {
  id: string;
  marinaName: string;
  city: string | null;
  state: string | null;
}

interface DemographicSummary {
  totalPopulation: number;
  totalMales?: number;
  totalFemales?: number;
  medianAge: number;
  medianAgeMale?: number;
  medianAgeFemale?: number;
  ageDistribution?: Record<string, number>;
  generationalCohorts?: Record<string, number>;
  medianHouseholdIncome: number;
  meanHouseholdIncome?: number;
  perCapitaIncome?: number;
  medianFamilyIncome?: number;
  incomeDistribution?: Record<string, number>;
  educationLevels?: Record<string, number>;
  employmentStats?: Record<string, number>;
  industryDistribution?: Record<string, number>;
  housingStats?: Record<string, number>;
  householdSize?: number;
  medianHomeValue?: number;
  raceEthnicity?: Record<string, number>;
  populationDensity?: number;
  geographicLevel?: string;
  fipsState?: string;
  fipsCounty?: string;
  fipsTract?: string;
}

interface LocationDemographicsResponse {
  location: { latitude: number; longitude: number; address?: string };
  radiusMiles: number | null;
  demographics: DemographicSummary;
  fetchedAt: string;
}

interface LocationTradeAreaConfig {
  distanceRings: number[];
  driveTimes: number[];
  analysisMode: 'distance' | 'drivetime';
}

interface SelectedLocation {
  address: string;
  latitude: number;
  longitude: number;
  label?: string;
  config: LocationTradeAreaConfig;
}

const formatCurrency = (value: number | null | undefined): string => {
  if (value === null || value === undefined) return "N/A";
  return `$${Math.round(value).toLocaleString('en-US')}`;
};

const formatNumber = (value: number | null | undefined): string => {
  if (value === null || value === undefined) return "N/A";
  return new Intl.NumberFormat('en-US').format(Math.round(value));
};

const formatPercent = (value: number | null | undefined): string => {
  if (value === null || value === undefined) return "N/A";
  return `${value.toFixed(2)}%`;
};

const formatLabel = (key: string): string => {
  const labelMap: Record<string, string> = {
    lessThanHighSchool: "Less Than High School",
    highSchool: "High School",
    someCollege: "Some College",
    bachelors: "Bachelor's Degree",
    graduate: "Graduate Degree",
    under25k: "Under $25K",
    "25kto50k": "$25K - $50K",
    "50kto75k": "$50K - $75K",
    "75kto100k": "$75K - $100K",
    "100kto150k": "$100K - $150K",
    over150k: "Over $150K",
    white: "White",
    black: "Black",
    asian: "Asian",
    hispanic: "Hispanic",
    americanIndian: "American Indian",
    pacificIslander: "Pacific Islander",
    twoOrMore: "Two or More Races",
    otherRace: "Other Race",
    agriculture: "Agriculture",
    construction: "Construction",
    manufacturing: "Manufacturing",
    wholesale: "Wholesale",
    retail: "Retail",
    transportation: "Transportation",
    information: "Information",
    finance: "Finance",
    professional: "Professional",
    education: "Education & Healthcare",
    arts: "Arts & Entertainment",
    otherServices: "Other Services",
    publicAdmin: "Public Administration",
  };
  
  if (labelMap[key]) return labelMap[key];
  
  return key
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, str => str.toUpperCase())
    .trim();
};

const getCategoryIcon = (category: string) => {
  switch (category) {
    case 'population': return <Users className="h-5 w-5" />;
    case 'income': return <DollarSign className="h-5 w-5" />;
    case 'employment': return <Briefcase className="h-5 w-5" />;
    case 'housing': return <Home className="h-5 w-5" />;
    default: return <Activity className="h-5 w-5" />;
  }
};

const getCategoryColor = (category: string) => {
  switch (category) {
    case 'population': return 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300';
    case 'income': return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
    case 'employment': return 'bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300';
    case 'housing': return 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300';
    default: return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300';
  }
};

function LocationDemographicsCard({ data, onRemove, label }: { 
  data: DemographicSummary; 
  onRemove?: () => void;
  label?: string;
}) {
  const stats = [
    { 
      label: "Population", 
      value: formatNumber(data.totalPopulation), 
      icon: Users, 
      color: "bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300" 
    },
    { 
      label: "Median Age", 
      value: data.medianAge ? `${data.medianAge.toFixed(1)} yrs` : "N/A", 
      icon: Users, 
      color: "bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300" 
    },
    { 
      label: "Median Income", 
      value: formatCurrency(data.medianHouseholdIncome), 
      icon: DollarSign, 
      color: "bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300" 
    },
    { 
      label: "Per Capita Income", 
      value: formatCurrency(data.perCapitaIncome), 
      icon: DollarSign, 
      color: "bg-emerald-100 dark:bg-emerald-900 text-emerald-600 dark:text-emerald-300" 
    },
    { 
      label: "Median Home Value", 
      value: formatCurrency(data.medianHomeValue), 
      icon: Home, 
      color: "bg-purple-100 dark:bg-purple-900 text-purple-600 dark:text-purple-300" 
    },
    { 
      label: "Household Size", 
      value: data.householdSize ? `${data.householdSize.toFixed(1)}` : "N/A", 
      icon: Home, 
      color: "bg-amber-100 dark:bg-amber-900 text-amber-600 dark:text-amber-300" 
    },
  ];

  return (
    <Card className="relative">
      {onRemove && (
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute top-2 right-2 h-6 w-6 z-10"
          onClick={onRemove}
          data-testid="button-remove-location"
        >
          <X className="h-4 w-4" />
        </Button>
      )}
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Target className="h-4 w-4 text-primary" />
          <CardTitle className="text-base">{label || "Location Demographics"}</CardTitle>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Badge variant="outline" className="text-xs">
            {data.geographicLevel === 'tract' ? 'Census Tract' : 
             data.geographicLevel === 'county' ? 'County' : 'State'} Level
          </Badge>
          {data.fipsState && (
            <span>FIPS: {data.fipsState}{data.fipsCounty ? `-${data.fipsCounty}` : ''}{data.fipsTract ? `-${data.fipsTract}` : ''}</span>
          )}
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {stats.map((stat, idx) => (
            <div key={idx} className={`p-3 rounded-lg ${stat.color} bg-opacity-10`}>
              <div className="flex items-center gap-2 mb-1">
                <stat.icon className="h-4 w-4" />
                <span className="text-xs text-muted-foreground">{stat.label}</span>
              </div>
              <div className="text-lg font-semibold">{stat.value}</div>
            </div>
          ))}
        </div>

        {data.educationLevels && Object.keys(data.educationLevels).length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              Education Attainment
            </h4>
            <div className="space-y-2">
              {Object.entries(data.educationLevels)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 5)
                .map(([level, value]) => {
                  const total = Object.values(data.educationLevels!).reduce((a, b) => a + b, 0);
                  const pct = total > 0 ? (value / total) * 100 : 0;
                  return (
                    <div key={level} className="flex items-center gap-2 text-xs">
                      <span className="w-40 truncate text-muted-foreground">{formatLabel(level)}</span>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary rounded-full" 
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <span className="w-14 text-right">{formatPercent(pct)}</span>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {data.incomeDistribution && Object.keys(data.incomeDistribution).length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Income Distribution
            </h4>
            <div className="space-y-2">
              {Object.entries(data.incomeDistribution)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 6)
                .map(([range, value]) => {
                  const total = Object.values(data.incomeDistribution!).reduce((a, b) => a + b, 0);
                  const pct = total > 0 ? (value / total) * 100 : 0;
                  return (
                    <div key={range} className="flex items-center gap-2 text-xs">
                      <span className="w-28 truncate text-muted-foreground">{formatLabel(range)}</span>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-green-500 rounded-full" 
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <span className="w-14 text-right">{formatPercent(pct)}</span>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {data.raceEthnicity && Object.keys(data.raceEthnicity).length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
              <PieChart className="h-4 w-4" />
              Race & Ethnicity
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {Object.entries(data.raceEthnicity)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 6)
                .map(([group, value]) => (
                  <div key={group} className="flex items-center justify-between">
                    <span className="text-muted-foreground truncate">{formatLabel(group)}</span>
                    <span className="font-medium">{formatPercent(value)}</span>
                  </div>
                ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function TradeAreaDemographicsDisplay({ data }: { data: DemographicSummary }) {
  const keyStats = [
    { label: "Population", value: formatNumber(data.totalPopulation), icon: Users, color: "text-blue-600" },
    { label: "Median Age", value: data.medianAge ? `${data.medianAge.toFixed(1)} yrs` : "N/A", icon: Users, color: "text-indigo-600" },
    { label: "Median Income", value: formatCurrency(data.medianHouseholdIncome), icon: DollarSign, color: "text-green-600" },
    { label: "Per Capita Income", value: formatCurrency(data.perCapitaIncome), icon: DollarSign, color: "text-emerald-600" },
    { label: "Home Value", value: formatCurrency(data.medianHomeValue), icon: Home, color: "text-purple-600" },
    { label: "Household Size", value: data.householdSize?.toFixed(1) || "N/A", icon: Home, color: "text-orange-600" },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {keyStats.map((stat, idx) => (
          <div key={idx} className="p-2 rounded-lg bg-muted/50">
            <div className="flex items-center gap-1 mb-1">
              <stat.icon className={`h-3 w-3 ${stat.color}`} />
              <span className="text-xs text-muted-foreground">{stat.label}</span>
            </div>
            <div className="text-sm font-semibold">{stat.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.educationLevels && Object.keys(data.educationLevels).length > 0 && (
          <div>
            <h5 className="text-xs font-medium mb-2 flex items-center gap-1">
              <GraduationCap className="h-3 w-3" />
              Education
            </h5>
            <div className="space-y-1">
              {Object.entries(data.educationLevels)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 4)
                .map(([level, value]) => {
                  const total = Object.values(data.educationLevels!).reduce((a, b) => a + b, 0);
                  const pct = total > 0 ? (value / total) * 100 : 0;
                  return (
                    <div key={level} className="flex items-center gap-2 text-xs">
                      <span className="w-28 truncate text-muted-foreground">{formatLabel(level)}</span>
                      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="w-12 text-right text-muted-foreground">{formatPercent(pct)}</span>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {data.incomeDistribution && Object.keys(data.incomeDistribution).length > 0 && (
          <div>
            <h5 className="text-xs font-medium mb-2 flex items-center gap-1">
              <DollarSign className="h-3 w-3" />
              Income Distribution
            </h5>
            <div className="space-y-1">
              {Object.entries(data.incomeDistribution)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 4)
                .map(([range, value]) => {
                  const total = Object.values(data.incomeDistribution!).reduce((a, b) => a + b, 0);
                  const pct = total > 0 ? (value / total) * 100 : 0;
                  return (
                    <div key={range} className="flex items-center gap-2 text-xs">
                      <span className="w-24 truncate text-muted-foreground">{formatLabel(range)}</span>
                      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-green-500 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="w-12 text-right text-muted-foreground">{formatPercent(pct)}</span>
                    </div>
                  );
                })}
            </div>
          </div>
        )}
      </div>

      {data.raceEthnicity && Object.keys(data.raceEthnicity).length > 0 && (
        <div>
          <h5 className="text-xs font-medium mb-2 flex items-center gap-1">
            <PieChart className="h-3 w-3" />
            Race & Ethnicity
          </h5>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-1 text-xs">
            {Object.entries(data.raceEthnicity)
              .sort(([,a], [,b]) => b - a)
              .slice(0, 6)
              .map(([group, value]) => (
                <div key={group} className="flex items-center justify-between">
                  <span className="text-muted-foreground truncate">{formatLabel(group)}</span>
                  <span className="font-medium">{formatPercent(value)}</span>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}

function AddressSearchInput({ 
  onSelect, 
  placeholder = "Enter an address...",
  className = ""
}: { 
  onSelect: (location: SelectedLocation) => void;
  placeholder?: string;
  className?: string;
}) {
  const autocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);
  const [inputValue, setInputValue] = useState("");
  
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  const { isLoaded, loadError } = useGoogleMaps();

  const onLoad = useCallback((autocomplete: google.maps.places.Autocomplete) => {
    autocompleteRef.current = autocomplete;
  }, []);

  const onPlaceChanged = useCallback(() => {
    if (autocompleteRef.current) {
      const place = autocompleteRef.current.getPlace();
      if (place?.geometry?.location) {
        onSelect({
          address: place.formatted_address || place.name || "",
          latitude: place.geometry.location.lat(),
          longitude: place.geometry.location.lng()
        });
        setInputValue(place.formatted_address || place.name || "");
      }
    }
  }, [onSelect]);

  if (!apiKey) {
    return (
      <div className={`relative ${className}`}>
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Google Maps API key required..."
          disabled
          className="pl-9"
          data-testid="input-address-search"
        />
      </div>
    );
  }

  if (loadError) {
    return (
      <div className={`relative ${className}`}>
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Error loading Google Maps..."
          disabled
          className="pl-9"
          data-testid="input-address-search"
        />
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className={`relative ${className}`}>
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground animate-pulse" />
        <Input
          type="text"
          placeholder="Loading..."
          disabled
          className="pl-9"
          data-testid="input-address-search"
        />
      </div>
    );
  }
  
  return (
    <div className={`relative ${className}`}>
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground z-10" />
      <Autocomplete
        onLoad={onLoad}
        onPlaceChanged={onPlaceChanged}
        options={{
          types: ["address"],
          componentRestrictions: { country: "us" },
          fields: ["formatted_address", "geometry", "name"]
        }}
      >
        <Input
          type="text"
          placeholder={placeholder}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="pl-9"
          data-testid="input-address-search"
        />
      </Autocomplete>
    </div>
  );
}

interface TradeAreaData {
  radiusMiles: number;
  label: string;
  type: 'distance' | 'drivetime';
  demographics: DemographicSummary | null;
  isLoading: boolean;
}

const DISTANCE_RINGS = [
  { value: 1, label: "1 Mile" },
  { value: 3, label: "3 Miles" },
  { value: 5, label: "5 Miles" },
  { value: 10, label: "10 Miles" },
];

const DRIVE_TIMES = [
  { value: 5, label: "5 Min", estimatedMiles: 2.5 },
  { value: 10, label: "10 Min", estimatedMiles: 5 },
  { value: 15, label: "15 Min", estimatedMiles: 8 },
  { value: 20, label: "20 Min", estimatedMiles: 12 },
];

const RING_COLORS = [
  { fill: 'rgba(59, 130, 246, 0.12)', stroke: '#3b82f6', name: 'Blue' },      // Innermost (smallest)
  { fill: 'rgba(16, 185, 129, 0.12)', stroke: '#10b981', name: 'Green' },     // 2nd ring
  { fill: 'rgba(245, 158, 11, 0.12)', stroke: '#f59e0b', name: 'Amber' },     // 3rd ring
  { fill: 'rgba(239, 68, 68, 0.12)', stroke: '#ef4444', name: 'Red' },        // 4th ring (outermost)
  { fill: 'rgba(139, 92, 246, 0.12)', stroke: '#8b5cf6', name: 'Purple' },    // 5th ring (if needed)
];

const LOCATION_COLORS = [
  '#3b82f6',
  '#10b981',
  '#f59e0b',
  '#ef4444',
  '#8b5cf6',
];

const mapContainerStyle = {
  width: '100%',
  height: '400px',
};

const defaultMapCenter = {
  lat: 39.8283,
  lng: -98.5795,
};

interface SavedLocation {
  id: string;
  address: string;
  latitude: number;
  longitude: number;
  label: string | null;
  analysisMode: string;
  distanceRings: number[];
  driveTimes: number[];
  sortOrder: number;
}

function LocationAnalysisSection() {
  const { toast } = useToast();
  const [selectedLocations, setSelectedLocations] = useState<SelectedLocation[]>([]);
  const [locationData, setLocationData] = useState<Map<string, Map<string, TradeAreaData>>>(new Map());
  
  const [defaultDistanceRings, setDefaultDistanceRings] = useState<number[]>([1]);
  const [defaultDriveTimes, setDefaultDriveTimes] = useState<number[]>([]);
  const [defaultAnalysisMode, setDefaultAnalysisMode] = useState<'distance' | 'drivetime'>('distance');
  
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [comparisonTradeAreas, setComparisonTradeAreas] = useState<Record<number, string>>({});
  const [targetDemographics, setTargetDemographics] = useState<TargetDemographics | null>(null);
  const [showAnalyticsPanel, setShowAnalyticsPanel] = useState(false);
  
  const [mainViewTab, setMainViewTab] = useState<'overview' | 'comparison'>('overview');
  const [activeLocationIndex, setActiveLocationIndex] = useState<number>(0);
  const [comparisonSelections, setComparisonSelections] = useState<number[]>([]);

  const { data: projects = [], isLoading: projectsLoading } = useQuery<ModelingProject[]>({
    queryKey: ['/api/modeling/projects'],
  });
  
  const { data: fetchedTargets } = useQuery<TargetDemographics | null>({
    queryKey: ['/api/target-demographics', selectedProjectId || 'default'],
    queryFn: async () => {
      const url = selectedProjectId 
        ? `/api/target-demographics?projectId=${selectedProjectId}` 
        : '/api/target-demographics';
      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        if (res.status === 404) return null;
        throw new Error('Failed to fetch target demographics');
      }
      return res.json();
    }
  });
  
  useEffect(() => {
    if (fetchedTargets !== undefined) {
      setTargetDemographics(fetchedTargets);
    }
  }, [fetchedTargets]);

  const { data: savedLocations, isLoading: locationsLoading } = useQuery<SavedLocation[]>({
    queryKey: ['/api/demographics/project-locations', selectedProjectId],
    enabled: !!selectedProjectId,
  });

  const saveLocationsMutation = useMutation({
    mutationFn: async () => {
      const locationsToSave = selectedLocations.map((loc, idx) => ({
        address: loc.address,
        lat: loc.latitude,
        lng: loc.longitude,
        label: loc.label,
        config: loc.config
      }));
      return apiRequest('POST', `/api/demographics/project-locations/${selectedProjectId}`, {
        locations: locationsToSave
      });
    },
    onSuccess: () => {
      setHasUnsavedChanges(false);
      queryClient.invalidateQueries({ queryKey: ['/api/demographics/project-locations', selectedProjectId] });
      toast({ title: 'Saved', description: 'Location configurations saved to project' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to save locations', variant: 'destructive' });
    }
  });

  const locationsLoadedRef = useRef<string | null>(null);
  const [pendingFetches, setPendingFetches] = useState<SelectedLocation[]>([]);
  
  useEffect(() => {
    if (!selectedProjectId) {
      locationsLoadedRef.current = null;
      return;
    }
    
    if (savedLocations === undefined) {
      return;
    }
    
    if (locationsLoadedRef.current === selectedProjectId) {
      return;
    }
    
    locationsLoadedRef.current = selectedProjectId;
    
    if (savedLocations.length > 0) {
      const loadedLocations: SelectedLocation[] = savedLocations.map(saved => ({
        address: saved.address,
        latitude: saved.latitude,
        longitude: saved.longitude,
        label: saved.label || undefined,
        config: {
          analysisMode: (saved.analysisMode as 'distance' | 'drivetime') || 'distance',
          distanceRings: saved.distanceRings || [1],
          driveTimes: saved.driveTimes || []
        }
      }));
      setSelectedLocations(loadedLocations);
      setLocationData(new Map());
      setHasUnsavedChanges(false);
      setPendingFetches(loadedLocations);
    } else {
      setSelectedLocations([]);
      setLocationData(new Map());
      setHasUnsavedChanges(false);
      setPendingFetches([]);
    }
  }, [savedLocations, selectedProjectId]);
  
  const fetchDemographicsMutation = useMutation({
    mutationFn: async ({ location, radiusMiles, tradeAreaKey }: { 
      location: SelectedLocation; 
      radiusMiles: number;
      tradeAreaKey: string;
    }) => {
      const response = await apiRequest('POST', '/api/demographics/location', {
        latitude: location.latitude,
        longitude: location.longitude,
        address: location.address,
        radiusMiles: radiusMiles
      });
      const data = await response.json() as LocationDemographicsResponse;
      return { location, data, tradeAreaKey };
    },
    onSuccess: ({ location, data, tradeAreaKey }) => {
      const locationKey = `${location.latitude},${location.longitude}`;
      setLocationData(prev => {
        const next = new Map(prev);
        const locationMap = next.get(locationKey) || new Map();
        const existingData = locationMap.get(tradeAreaKey);
        if (existingData) {
          locationMap.set(tradeAreaKey, {
            ...existingData,
            demographics: data.demographics,
            isLoading: false
          });
        }
        next.set(locationKey, locationMap);
        return next;
      });
    }
  });

  const fetchAllTradeAreas = useCallback(async (location: SelectedLocation) => {
    const locationKey = `${location.latitude},${location.longitude}`;
    const tradeAreas = new Map<string, TradeAreaData>();
    const config = location.config;
    
    if (config.analysisMode === 'distance') {
      config.distanceRings.forEach(miles => {
        const key = `distance-${miles}`;
        tradeAreas.set(key, {
          radiusMiles: miles,
          label: `${miles} Mile Radius`,
          type: 'distance',
          demographics: null,
          isLoading: true
        });
        fetchDemographicsMutation.mutate({ 
          location, 
          radiusMiles: miles, 
          tradeAreaKey: key 
        });
      });
    } else {
      for (const minutes of config.driveTimes) {
        const driveTime = DRIVE_TIMES.find(d => d.value === minutes);
        if (!driveTime) continue;
        
        const key = `drivetime-${minutes}`;
        
        let radiusMiles = driveTime.estimatedMiles;
        let radiusSource = 'estimate';
        
        try {
          const response = await fetch('/api/demographics/drivetime-radius', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({
              latitude: location.latitude,
              longitude: location.longitude,
              targetMinutes: minutes
            })
          });
          
          if (response.ok) {
            const data = await response.json();
            if (data.calculatedMiles) {
              radiusMiles = data.calculatedMiles;
              radiusSource = 'google_api';
            } else if (data.radiusMiles) {
              radiusMiles = data.radiusMiles;
            }
          }
        } catch (e) {
        }
        
        tradeAreas.set(key, {
          radiusMiles,
          label: `${minutes} Min Drive${radiusSource === 'google_api' ? '' : ' (est.)'}`,
          type: 'drivetime',
          demographics: null,
          isLoading: true
        });
        
        fetchDemographicsMutation.mutate({ 
          location, 
          radiusMiles, 
          tradeAreaKey: key 
        });
      }
    }
    
    setLocationData(prev => new Map(prev).set(locationKey, tradeAreas));
  }, [fetchDemographicsMutation]);

  useEffect(() => {
    if (pendingFetches.length > 0) {
      const locationsToFetch = [...pendingFetches];
      setPendingFetches([]);
      locationsToFetch.forEach(loc => {
        fetchAllTradeAreas(loc);
      });
    }
  }, [pendingFetches, fetchAllTradeAreas]);

  const handleAddLocation = useCallback((baseLocation: Omit<SelectedLocation, 'config' | 'label'>) => {
    if (selectedLocations.length >= 5) return;
    
    const hasSelection = defaultAnalysisMode === 'distance' 
      ? defaultDistanceRings.length > 0 
      : defaultDriveTimes.length > 0;
    
    if (!hasSelection) return;
    
    const exists = selectedLocations.some(
      l => l.latitude === baseLocation.latitude && l.longitude === baseLocation.longitude
    );
    if (exists) return;
    
    const newLocation: SelectedLocation = { 
      ...baseLocation, 
      label: `Location ${selectedLocations.length + 1}`,
      config: {
        distanceRings: [...defaultDistanceRings],
        driveTimes: [...defaultDriveTimes],
        analysisMode: defaultAnalysisMode
      }
    };
    setSelectedLocations(prev => [...prev, newLocation]);
    fetchAllTradeAreas(newLocation);
    if (selectedProjectId) setHasUnsavedChanges(true);
  }, [selectedLocations, defaultAnalysisMode, defaultDistanceRings, defaultDriveTimes, fetchAllTradeAreas, selectedProjectId]);

  const updateLocationConfig = useCallback((index: number, newConfig: LocationTradeAreaConfig) => {
    setSelectedLocations(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], config: newConfig };
      return updated;
    });
    
    const location = selectedLocations[index];
    if (location) {
      const updatedLocation = { ...location, config: newConfig };
      fetchAllTradeAreas(updatedLocation);
    }
    if (selectedProjectId) setHasUnsavedChanges(true);
  }, [selectedLocations, fetchAllTradeAreas, selectedProjectId]);

  const refetchLocation = useCallback((index: number) => {
    const location = selectedLocations[index];
    if (location) {
      fetchAllTradeAreas(location);
    }
  }, [selectedLocations, fetchAllTradeAreas]);

  const handleRemoveLocation = useCallback((index: number) => {
    const location = selectedLocations[index];
    const key = `${location.latitude},${location.longitude}`;
    setSelectedLocations(prev => prev.filter((_, i) => i !== index));
    setLocationData(prev => {
      const next = new Map(prev);
      next.delete(key);
      return next;
    });
    if (selectedProjectId) setHasUnsavedChanges(true);
  }, [selectedLocations, selectedProjectId]);

  const handleProjectChange = (projectId: string) => {
    if (hasUnsavedChanges) {
      if (!confirm('You have unsaved changes. Switch project anyway?')) {
        return;
      }
    }
    setSelectedProjectId(projectId);
    setSelectedLocations([]);
    setLocationData(new Map());
    setHasUnsavedChanges(false);
    setComparisonTradeAreas({});
  };
  
  useEffect(() => {
    if (selectedLocations.length === 0) {
      setComparisonTradeAreas({});
      return;
    }
    
    setComparisonTradeAreas(prevState => {
      const newState: Record<number, string> = {};
      let hasChanged = false;
      
      selectedLocations.forEach((loc, idx) => {
        const locKey = `${loc.latitude},${loc.longitude}`;
        const areaMap = locationData.get(locKey);
        
        if (!areaMap) {
          if (prevState[idx] !== undefined) {
            hasChanged = true;
          }
          return;
        }
        
        const loadedAreas = Array.from(areaMap.entries())
          .filter(([, ta]) => ta.demographics !== null && !ta.isLoading);
        
        if (loadedAreas.length === 0) {
          if (prevState[idx] !== undefined) {
            hasChanged = true;
          }
          return;
        }
        
        const sortedLoaded = loadedAreas.sort(([keyA], [keyB]) => {
          const partsA = keyA.split('-');
          const partsB = keyB.split('-');
          const valA = partsA.length > 1 ? parseFloat(partsA[1]) : 0;
          const valB = partsB.length > 1 ? parseFloat(partsB[1]) : 0;
          return (isNaN(valA) ? 0 : valA) - (isNaN(valB) ? 0 : valB);
        });
        
        const currentSelection = prevState[idx];
        const currentSelectionValid = currentSelection && 
          loadedAreas.some(([key]) => key === currentSelection);
        
        if (currentSelectionValid) {
          newState[idx] = currentSelection;
        } else {
          const firstKey = sortedLoaded[0][0];
          newState[idx] = firstKey;
          if (currentSelection !== firstKey) {
            hasChanged = true;
          }
        }
      });
      
      Object.keys(prevState).forEach(key => {
        const numKey = parseInt(key);
        if (numKey >= selectedLocations.length) {
          hasChanged = true;
        }
      });
      
      return hasChanged || Object.keys(newState).length !== Object.keys(prevState).length 
        ? newState 
        : prevState;
    });
  }, [selectedLocations, locationData]);

  const toggleDefaultDistanceRing = (miles: number) => {
    setDefaultDistanceRings(prev => {
      if (prev.includes(miles)) {
        return prev.filter(m => m !== miles);
      }
      return [...prev, miles].sort((a, b) => a - b);
    });
  };

  const toggleDefaultDriveTime = (minutes: number) => {
    setDefaultDriveTimes(prev => {
      if (prev.includes(minutes)) {
        return prev.filter(m => m !== minutes);
      }
      if (prev.length >= 3) return prev;
      return [...prev, minutes].sort((a, b) => a - b);
    });
  };

  const getLocationTradeAreas = (location: SelectedLocation): TradeAreaData[] => {
    const key = `${location.latitude},${location.longitude}`;
    const areaMap = locationData.get(key);
    if (!areaMap) return [];
    return Array.from(areaMap.values());
  };

  const handleTargetDemographicsSave = (saved: TargetDemographics) => {
    setTargetDemographics(saved);
  };
  
  const getComparisonLocationsData = () => {
    if (selectedLocations.length < 2) return [];
    return selectedLocations.map((loc, idx) => {
      const locKey = `${loc.latitude},${loc.longitude}`;
      const areaMap = locationData.get(locKey);
      const tradeAreasList = areaMap ? Array.from(areaMap.entries()).filter(([, ta]) => ta.demographics) : [];
      const sortedTradeAreas = [...tradeAreasList].sort(([keyA], [keyB]) => {
        const partsA = keyA.split('-');
        const partsB = keyB.split('-');
        const valA = partsA.length > 1 ? parseFloat(partsA[1]) : 0;
        const valB = partsB.length > 1 ? parseFloat(partsB[1]) : 0;
        return (isNaN(valA) ? 0 : valA) - (isNaN(valB) ? 0 : valB);
      });
      
      const defaultKey = sortedTradeAreas[0]?.[0] || '';
      const selectedKey = (comparisonTradeAreas[idx] && sortedTradeAreas.some(([k]) => k === comparisonTradeAreas[idx]))
        ? comparisonTradeAreas[idx]
        : defaultKey;
      const tradeArea = selectedKey && areaMap ? areaMap.get(selectedKey) : null;
      
      return {
        name: loc.label || loc.address.split(',')[0],
        address: loc.address,
        demographics: tradeArea?.demographics || null
      };
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-4 items-start">
        <Button
          variant={showAnalyticsPanel ? "default" : "outline"}
          size="sm"
          onClick={() => setShowAnalyticsPanel(!showAnalyticsPanel)}
          className="flex items-center gap-2"
          data-testid="button-toggle-analytics"
        >
          <Target className="h-4 w-4" />
          {showAnalyticsPanel ? "Hide Analytics" : "Show Analytics"}
        </Button>
        {targetDemographics && (
          <Badge variant="secondary" className="text-xs">
            Target profile configured
          </Badge>
        )}
      </div>
      
      {showAnalyticsPanel && (
        <div className="grid gap-6 lg:grid-cols-2">
          <TargetDemographicsForm
            projectId={selectedProjectId || undefined}
            initialData={targetDemographics || undefined}
            onSave={handleTargetDemographicsSave}
          />
          
          {selectedLocations.length > 0 && targetDemographics && (
            <div className="space-y-4">
              {selectedLocations.slice(0, 2).map((loc, idx) => {
                const locKey = `${loc.latitude},${loc.longitude}`;
                const areaMap = locationData.get(locKey);
                const tradeAreasList = areaMap ? Array.from(areaMap.entries()).filter(([, ta]) => ta.demographics) : [];
                const firstTradeArea = tradeAreasList[0]?.[1];
                
                if (!firstTradeArea?.demographics) return null;
                
                return (
                  <SiteSuitabilityScore
                    key={idx}
                    demographics={firstTradeArea.demographics as any}
                    targets={targetDemographics}
                    locationName={loc.label || loc.address.split(',')[0]}
                  />
                );
              })}
            </div>
          )}
        </div>
      )}
      
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-primary" />
              <CardTitle>Location-Based Demographics</CardTitle>
            </div>
            <div className="flex items-center gap-2">
              <Select value={selectedProjectId} onValueChange={handleProjectChange}>
                <SelectTrigger className="w-64" data-testid="select-project">
                  <Building2 className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Select a project to save locations" />
                </SelectTrigger>
                <SelectContent>
                  {projectsLoading ? (
                    <div className="px-2 py-1.5 text-sm text-muted-foreground">Loading projects...</div>
                  ) : projects.length === 0 ? (
                    <div className="px-2 py-1.5 text-sm text-muted-foreground">No projects found</div>
                  ) : (
                    projects.map(project => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.marinaName} {project.city ? `- ${project.city}, ${project.state}` : ''}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              
              {selectedProjectId && (
                <Button
                  variant={hasUnsavedChanges ? "default" : "outline"}
                  size="sm"
                  onClick={() => saveLocationsMutation.mutate()}
                  disabled={saveLocationsMutation.isPending || selectedLocations.length === 0}
                  data-testid="button-save-locations"
                >
                  {saveLocationsMutation.isPending ? (
                    <RefreshCw className="h-4 w-4 mr-1 animate-spin" />
                  ) : (
                    <Save className="h-4 w-4 mr-1" />
                  )}
                  {hasUnsavedChanges ? 'Save Changes' : 'Saved'}
                </Button>
              )}
            </div>
          </div>
          <CardDescription>
            Search for any U.S. address to analyze Census demographics with distance rings or drive times.
            {selectedProjectId && locationsLoading && (
              <span className="ml-2 text-primary">Loading saved locations...</span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <Label className="text-sm font-medium">Default Trade Area Settings (for new locations)</Label>
            <Tabs value={defaultAnalysisMode} onValueChange={(v) => setDefaultAnalysisMode(v as 'distance' | 'drivetime')}>
              <TabsList className="grid w-full grid-cols-2 max-w-md">
                <TabsTrigger value="distance" className="flex items-center gap-2" data-testid="tab-distance">
                  <Ruler className="h-4 w-4" />
                  Distance Rings
                </TabsTrigger>
                <TabsTrigger value="drivetime" className="flex items-center gap-2" data-testid="tab-drivetime">
                  <Car className="h-4 w-4" />
                  Drive Time
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="distance" className="mt-4">
                <div className="space-y-3">
                  <Label className="text-sm">Select Distance Rings</Label>
                  <div className="flex flex-wrap gap-4">
                    {DISTANCE_RINGS.map(ring => (
                      <label
                        key={ring.value}
                        htmlFor={`ring-${ring.value}`}
                        className={`flex items-center gap-2 px-3 py-2 rounded-md border cursor-pointer transition-colors ${
                          defaultDistanceRings.includes(ring.value)
                            ? 'bg-primary/10 border-primary text-primary'
                            : 'bg-background border-border hover:border-primary/50'
                        }`}
                      >
                        <Checkbox
                          id={`ring-${ring.value}`}
                          checked={defaultDistanceRings.includes(ring.value)}
                          onCheckedChange={() => toggleDefaultDistanceRing(ring.value)}
                          data-testid={`checkbox-distance-${ring.value}`}
                          className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                        />
                        <span className="text-sm font-medium">{ring.label}</span>
                      </label>
                    ))}
                  </div>
                  {defaultDistanceRings.length === 0 && (
                    <p className="text-xs text-amber-600">Select at least one distance ring</p>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="drivetime" className="mt-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm">Select Drive Times (up to 3)</Label>
                    <span className="text-xs text-muted-foreground">{defaultDriveTimes.length}/3 selected</span>
                  </div>
                  <div className="flex flex-wrap gap-4">
                    {DRIVE_TIMES.map(time => {
                      const isSelected = defaultDriveTimes.includes(time.value);
                      const isDisabled = !isSelected && defaultDriveTimes.length >= 3;
                      return (
                        <label
                          key={time.value}
                          htmlFor={`time-${time.value}`}
                          className={`flex items-center gap-2 px-3 py-2 rounded-md border cursor-pointer transition-colors ${
                            isDisabled 
                              ? 'opacity-50 cursor-not-allowed bg-muted'
                              : isSelected
                                ? 'bg-blue-50 border-blue-500 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                                : 'bg-background border-border hover:border-blue-300'
                          }`}
                        >
                          <Checkbox
                            id={`time-${time.value}`}
                            checked={isSelected}
                            onCheckedChange={() => toggleDefaultDriveTime(time.value)}
                            disabled={isDisabled}
                            data-testid={`checkbox-drivetime-${time.value}`}
                            className="data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
                          />
                          <span className="text-sm font-medium">{time.label}</span>
                          <span className="text-xs text-muted-foreground">(~{time.estimatedMiles} mi)</span>
                        </label>
                      );
                    })}
                  </div>
                  {defaultDriveTimes.length === 0 && (
                    <p className="text-xs text-amber-600">Select at least one drive time</p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Drive times are estimated based on typical suburban driving conditions (~30 mph average).
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          <div className="pt-4 border-t">
            <Label className="text-sm mb-2 block">Search Address</Label>
            <AddressSearchInput 
              onSelect={handleAddLocation}
              placeholder="Enter a property address..."
            />
          </div>

        </CardContent>
      </Card>

      {selectedLocations.length > 0 && (
        <Tabs value={mainViewTab} onValueChange={(v) => setMainViewTab(v as 'overview' | 'comparison')} className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="overview" className="flex items-center gap-2" data-testid="tab-overview">
              <MapPin className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="comparison" className="flex items-center gap-2" data-testid="tab-comparison">
              <BarChart3 className="h-4 w-4" />
              Comparison
              {selectedLocations.length >= 2 && (
                <Badge variant="secondary" className="ml-1 text-xs">{selectedLocations.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-4">
            <div className="grid grid-cols-12 gap-4">
              <div className="col-span-12 lg:col-span-3">
                <Card>
                  <CardHeader className="py-3">
                    <CardTitle className="text-sm flex items-center justify-between">
                      <span>Locations ({selectedLocations.length})</span>
                      {selectedLocations.length < 5 && (
                        <Badge variant="outline" className="text-xs">
                          +{5 - selectedLocations.length} available
                        </Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-2 space-y-1">
                    {selectedLocations.map((loc, idx) => (
                      <div
                        key={idx}
                        onClick={() => setActiveLocationIndex(idx)}
                        className={`flex items-center gap-2 p-2 rounded-md cursor-pointer transition-colors ${
                          activeLocationIndex === idx
                            ? 'bg-primary/10 border border-primary'
                            : 'hover:bg-muted border border-transparent'
                        }`}
                        data-testid={`location-item-${idx}`}
                      >
                        <div 
                          className="w-3 h-3 rounded-full flex-shrink-0"
                          style={{ backgroundColor: LOCATION_COLORS[idx % LOCATION_COLORS.length] }}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">
                            {loc.label || loc.address.split(',')[0]}
                          </p>
                          <p className="text-xs text-muted-foreground truncate">
                            {loc.config.analysisMode === 'distance' 
                              ? `${loc.config.distanceRings.length} ring${loc.config.distanceRings.length !== 1 ? 's' : ''}`
                              : `${loc.config.driveTimes.length} drive time${loc.config.driveTimes.length !== 1 ? 's' : ''}`
                            }
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 flex-shrink-0 hover:bg-destructive hover:text-destructive-foreground"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveLocation(idx);
                            if (activeLocationIndex >= selectedLocations.length - 1) {
                              setActiveLocationIndex(Math.max(0, selectedLocations.length - 2));
                            }
                          }}
                          data-testid={`button-remove-location-${idx}`}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              <div className="col-span-12 lg:col-span-9 space-y-4">
                {selectedLocations[activeLocationIndex] && (() => {
                  const activeLoc = selectedLocations[activeLocationIndex];
                  const tradeAreas = getLocationTradeAreas(activeLoc);
                  const hasLoading = tradeAreas.some(ta => ta.isLoading);
                  const loadedAreas = tradeAreas.filter(ta => ta.demographics);
                  const locationColor = LOCATION_COLORS[activeLocationIndex % LOCATION_COLORS.length];
                  const isDistance = activeLoc.config.analysisMode === 'distance';
                  
                  return (
                    <>
                      <Card>
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div 
                                className="w-3 h-3 rounded-full"
                                style={{ backgroundColor: locationColor }}
                              />
                              <CardTitle className="text-base">{activeLoc.label || activeLoc.address.split(',')[0]}</CardTitle>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                {isDistance ? `${activeLoc.config.distanceRings.length} Distance Ring${activeLoc.config.distanceRings.length !== 1 ? 's' : ''}` : `${activeLoc.config.driveTimes.length} Drive Time${activeLoc.config.driveTimes.length !== 1 ? 's' : ''}`}
                              </Badge>
                              <Popover>
                                <PopoverTrigger asChild>
                                  <Button variant="outline" size="sm" className="h-7">
                                    <Settings className="h-3 w-3 mr-1" />
                                    Settings
                                  </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-80" align="end">
                                  <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                      <h4 className="font-medium text-sm">Trade Area Settings</h4>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="h-7 text-xs"
                                        onClick={() => refetchLocation(activeLocationIndex)}
                                        disabled={hasLoading}
                                      >
                                        <RefreshCw className={`h-3 w-3 mr-1 ${hasLoading ? 'animate-spin' : ''}`} />
                                        Refresh
                                      </Button>
                                    </div>
                                    
                                    <Tabs 
                                      value={activeLoc.config.analysisMode} 
                                      onValueChange={(v) => updateLocationConfig(activeLocationIndex, { 
                                        ...activeLoc.config, 
                                        analysisMode: v as 'distance' | 'drivetime' 
                                      })}
                                    >
                                      <TabsList className="grid w-full grid-cols-2">
                                        <TabsTrigger value="distance" className="text-xs">
                                          <Ruler className="h-3 w-3 mr-1" />
                                          Distance
                                        </TabsTrigger>
                                        <TabsTrigger value="drivetime" className="text-xs">
                                          <Car className="h-3 w-3 mr-1" />
                                          Drive Time
                                        </TabsTrigger>
                                      </TabsList>
                                      
                                      <TabsContent value="distance" className="mt-3">
                                        <div className="space-y-2">
                                          <Label className="text-xs">Distance Rings</Label>
                                          <div className="grid grid-cols-2 gap-2">
                                            {DISTANCE_RINGS.map(ring => {
                                              const isSelected = activeLoc.config.distanceRings.includes(ring.value);
                                              return (
                                                <label
                                                  key={ring.value}
                                                  htmlFor={`active-ring-${ring.value}`}
                                                  className={`flex items-center gap-2 px-2 py-1.5 rounded border text-xs cursor-pointer transition-colors ${
                                                    isSelected
                                                      ? 'bg-primary/10 border-primary text-primary'
                                                      : 'bg-background border-border hover:border-primary/50'
                                                  }`}
                                                >
                                                  <Checkbox
                                                    id={`active-ring-${ring.value}`}
                                                    checked={isSelected}
                                                    onCheckedChange={() => {
                                                      const newRings = isSelected
                                                        ? activeLoc.config.distanceRings.filter(r => r !== ring.value)
                                                        : [...activeLoc.config.distanceRings, ring.value].sort((a, b) => a - b);
                                                      updateLocationConfig(activeLocationIndex, { ...activeLoc.config, distanceRings: newRings });
                                                    }}
                                                    className="h-3.5 w-3.5"
                                                  />
                                                  <span>{ring.label}</span>
                                                </label>
                                              );
                                            })}
                                          </div>
                                        </div>
                                      </TabsContent>
                                      
                                      <TabsContent value="drivetime" className="mt-3">
                                        <div className="space-y-2">
                                          <Label className="text-xs">Drive Times</Label>
                                          <div className="grid grid-cols-2 gap-2">
                                            {DRIVE_TIMES.map(time => {
                                              const isSelected = activeLoc.config.driveTimes.includes(time.value);
                                              const isDisabled = !isSelected && activeLoc.config.driveTimes.length >= 3;
                                              return (
                                                <label
                                                  key={time.value}
                                                  htmlFor={`active-time-${time.value}`}
                                                  className={`flex items-center gap-2 px-2 py-1.5 rounded border text-xs cursor-pointer transition-colors ${
                                                    isDisabled
                                                      ? 'opacity-50 cursor-not-allowed bg-muted'
                                                      : isSelected
                                                        ? 'bg-blue-50 border-blue-500 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                                                        : 'bg-background border-border hover:border-blue-300'
                                                  }`}
                                                >
                                                  <Checkbox
                                                    id={`active-time-${time.value}`}
                                                    checked={isSelected}
                                                    onCheckedChange={() => {
                                                      const newTimes = isSelected
                                                        ? activeLoc.config.driveTimes.filter(t => t !== time.value)
                                                        : [...activeLoc.config.driveTimes, time.value].sort((a, b) => a - b);
                                                      if (newTimes.length <= 3) {
                                                        updateLocationConfig(activeLocationIndex, { ...activeLoc.config, driveTimes: newTimes });
                                                      }
                                                    }}
                                                    disabled={isDisabled}
                                                    className="h-3.5 w-3.5"
                                                  />
                                                  <span>{time.label}</span>
                                                </label>
                                              );
                                            })}
                                          </div>
                                        </div>
                                      </TabsContent>
                                    </Tabs>
                                  </div>
                                </PopoverContent>
                              </Popover>
                            </div>
                          </div>
                          <CardDescription className="text-xs">
                            {activeLoc.address}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="rounded-lg overflow-hidden border" style={{ height: '300px' }}>
                            <GoogleMap
                              key={`single-map-${activeLocationIndex}-${activeLoc.latitude}-${activeLoc.longitude}-${activeLoc.config.analysisMode}-${
                                activeLoc.config.analysisMode === 'distance' 
                                  ? activeLoc.config.distanceRings.join(',') 
                                  : activeLoc.config.driveTimes.join(',')
                              }`}
                              mapContainerStyle={{ width: '100%', height: '100%' }}
                              center={{ lat: activeLoc.latitude, lng: activeLoc.longitude }}
                              zoom={11}
                              options={{
                                mapTypeControl: false,
                                streetViewControl: false,
                                fullscreenControl: true,
                              }}
                            >
                              <Marker
                                position={{ lat: activeLoc.latitude, lng: activeLoc.longitude }}
                                title={activeLoc.address}
                                icon={{
                                  path: google.maps.SymbolPath.CIRCLE,
                                  scale: 8,
                                  fillColor: locationColor,
                                  fillOpacity: 1,
                                  strokeColor: '#ffffff',
                                  strokeWeight: 2,
                                }}
                              />
                              {(() => {
                                const rawRings = isDistance
                                  ? activeLoc.config.distanceRings.map(r => ({ value: r, originalValue: r }))
                                  : activeLoc.config.driveTimes.map(t => {
                                      const driveTime = DRIVE_TIMES.find(d => d.value === t);
                                      return { value: driveTime ? driveTime.estimatedMiles : t * 0.5, originalValue: t };
                                    });
                                const sortedBySize = [...rawRings].sort((a, b) => a.value - b.value);
                                const ringColorMap = new Map(sortedBySize.map((ring, idx) => [ring.originalValue, idx]));
                                const sortedForDrawing = [...rawRings].sort((a, b) => b.value - a.value);
                                
                                return sortedForDrawing.map((ring) => {
                                  const colorIdx = ringColorMap.get(ring.originalValue) ?? 0;
                                  const radiusMeters = ring.value * 1609.34;
                                  return (
                                    <Circle
                                      key={`single-circle-${ring.originalValue}`}
                                      center={{ lat: activeLoc.latitude, lng: activeLoc.longitude }}
                                      radius={radiusMeters}
                                      options={{
                                        fillColor: RING_COLORS[colorIdx % RING_COLORS.length].stroke,
                                        fillOpacity: 0.08,
                                        strokeColor: RING_COLORS[colorIdx % RING_COLORS.length].stroke,
                                        strokeOpacity: 0.9,
                                        strokeWeight: 2.5,
                                      }}
                                    />
                                  );
                                });
                              })()}
                            </GoogleMap>
                          </div>
                        </CardContent>
                      </Card>

                      {hasLoading && (
                        <div className="flex items-center justify-center py-4">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                          <span className="ml-2 text-sm text-muted-foreground">Loading demographics...</span>
                        </div>
                      )}

                      {loadedAreas.length > 0 && (
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle className="text-sm">Demographics by Trade Area</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <Tabs defaultValue={loadedAreas[0]?.label}>
                              <TabsList className="flex flex-wrap h-auto gap-1">
                                {loadedAreas.map((tradeArea, taIdx) => {
                                  const sortedRings = isDistance
                                    ? [...activeLoc.config.distanceRings].sort((a, b) => a - b)
                                    : [...activeLoc.config.driveTimes].sort((a, b) => a - b);
                                  const keyParts = tradeArea.label.split(' ');
                                  const parsedValue = keyParts.length > 0 ? parseFloat(keyParts[0]) : NaN;
                                  const ringValue = isNaN(parsedValue) ? (sortedRings[0] || 0) : parsedValue;
                                  const colorIdx = sortedRings.indexOf(ringValue);
                                  const ringColor = RING_COLORS[colorIdx >= 0 ? colorIdx : taIdx];
                                  
                                  return (
                                    <TabsTrigger 
                                      key={tradeArea.label} 
                                      value={tradeArea.label}
                                      className="text-xs px-3 py-1.5 data-[state=active]:text-white"
                                      style={{ 
                                        '--active-bg': ringColor.stroke,
                                      } as React.CSSProperties}
                                    >
                                      <div 
                                        className="w-2 h-2 rounded-full mr-1.5"
                                        style={{ backgroundColor: ringColor.stroke }}
                                      />
                                      {tradeArea.label}
                                    </TabsTrigger>
                                  );
                                })}
                              </TabsList>
                              
                              {loadedAreas.map((tradeArea, taIdx) => {
                                const sortedRings = isDistance
                                  ? [...activeLoc.config.distanceRings].sort((a, b) => a - b)
                                  : [...activeLoc.config.driveTimes].sort((a, b) => a - b);
                                const keyParts = tradeArea.label.split(' ');
                                const parsedValue = keyParts.length > 0 ? parseFloat(keyParts[0]) : NaN;
                                const ringValue = isNaN(parsedValue) ? (sortedRings[0] || 0) : parsedValue;
                                const colorIdx = sortedRings.indexOf(ringValue);
                                const ringColor = RING_COLORS[colorIdx >= 0 ? colorIdx : taIdx];
                                
                                return (
                                  <TabsContent key={tradeArea.label} value={tradeArea.label} className="mt-4">
                                    <div className="space-y-4">
                                      <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                          <div 
                                            className="w-3 h-3 rounded-full border border-white shadow-sm"
                                            style={{ backgroundColor: ringColor.stroke }}
                                          />
                                          <span className="font-medium text-sm">{tradeArea.label}</span>
                                          <Badge variant="outline" className="text-xs">
                                            ~{tradeArea.radiusMiles.toFixed(1)} mile radius
                                          </Badge>
                                        </div>
                                        {tradeArea.demographics && (
                                          <Badge className="text-xs" style={{ backgroundColor: ringColor.stroke }}>
                                            Pop: {formatNumber(tradeArea.demographics.totalPopulation)}
                                          </Badge>
                                        )}
                                      </div>
                                      
                                      {tradeArea.demographics && (
                                        <TradeAreaDemographicsDisplay data={tradeArea.demographics} />
                                      )}
                                    </div>
                                  </TabsContent>
                                );
                              })}
                            </Tabs>
                          </CardContent>
                        </Card>
                      )}
                    </>
                  );
                })()}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="comparison" className="mt-4">
            {selectedLocations.length < 2 ? (
              <Card className="border-dashed">
                <CardContent className="py-12 text-center">
                  <BarChart3 className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
                  <h3 className="text-lg font-medium mb-2">Add More Locations to Compare</h3>
                  <p className="text-muted-foreground text-sm max-w-md mx-auto">
                    Add at least 2 locations to compare their demographics side by side. You can add up to 5 locations.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <>
                <Card className="mb-4">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Target className="h-4 w-4" />
                      All Locations Map
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="rounded-lg overflow-hidden border" style={{ height: '300px' }}>
                      <GoogleMap
                        key={`comparison-map-${selectedLocations.length}`}
                        mapContainerStyle={{ width: '100%', height: '100%' }}
                        center={selectedLocations.length > 0 
                          ? { lat: selectedLocations[0].latitude, lng: selectedLocations[0].longitude }
                          : defaultMapCenter
                        }
                        zoom={selectedLocations.length === 1 ? 10 : 7}
                        options={{
                          mapTypeControl: false,
                          streetViewControl: false,
                          fullscreenControl: true,
                        }}
                      >
                        {selectedLocations.map((location, locIdx) => {
                          const locationColor = LOCATION_COLORS[locIdx % LOCATION_COLORS.length];
                          return (
                            <Marker
                              key={`marker-${locIdx}`}
                              position={{ lat: location.latitude, lng: location.longitude }}
                              title={location.address}
                              icon={{
                                path: google.maps.SymbolPath.CIRCLE,
                                scale: 10,
                                fillColor: locationColor,
                                fillOpacity: 1,
                                strokeColor: '#ffffff',
                                strokeWeight: 2,
                              }}
                            />
                          );
                        })}
                      </GoogleMap>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {selectedLocations.map((loc, idx) => (
                        <div key={idx} className="flex items-center gap-1.5 text-xs">
                          <div 
                            className="w-2.5 h-2.5 rounded-full"
                            style={{ backgroundColor: LOCATION_COLORS[idx % LOCATION_COLORS.length] }}
                          />
                          <span className="text-muted-foreground">{loc.label || loc.address.split(',')[0]}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5 text-primary" />
                      Side-by-Side Comparison
                    </CardTitle>
                    <CardDescription>Compare demographics across all locations - select which trade area to compare for each</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2 px-3 font-medium w-36">Metric</th>
                            {selectedLocations.map((loc, idx) => {
                              const locKey = `${loc.latitude},${loc.longitude}`;
                              const areaMap = locationData.get(locKey);
                              const tradeAreasList = areaMap ? Array.from(areaMap.entries()).filter(([, ta]) => ta.demographics) : [];
                              const isDistance = loc.config.analysisMode === 'distance';
                              const sortedRings = isDistance
                                ? [...loc.config.distanceRings].sort((a, b) => a - b)
                                : [...loc.config.driveTimes].sort((a, b) => a - b);
                              
                              const sortedTradeAreas = [...tradeAreasList].sort(([keyA], [keyB]) => {
                                const partsA = keyA.split('-');
                                const partsB = keyB.split('-');
                                const valA = partsA.length > 1 ? parseFloat(partsA[1]) : 0;
                                const valB = partsB.length > 1 ? parseFloat(partsB[1]) : 0;
                                return (isNaN(valA) ? 0 : valA) - (isNaN(valB) ? 0 : valB);
                              });
                              
                              const defaultKey = sortedTradeAreas[0]?.[0] || '';
                              const selectedKey = (comparisonTradeAreas[idx] && sortedTradeAreas.some(([k]) => k === comparisonTradeAreas[idx])) 
                                ? comparisonTradeAreas[idx] 
                                : defaultKey;
                              
                              return (
                                <th key={idx} className="py-2 px-2 font-medium min-w-44">
                                  <div className="flex flex-col gap-1">
                                    <div className="flex items-center gap-1.5">
                                      <div 
                                        className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                                        style={{ backgroundColor: LOCATION_COLORS[idx % LOCATION_COLORS.length] }}
                                      />
                                      <span className="text-xs text-muted-foreground truncate max-w-40">
                                        {loc.label || loc.address.split(',')[0]}
                                      </span>
                                    </div>
                                    {sortedTradeAreas.length > 0 && (
                                      <Select
                                        value={selectedKey}
                                        onValueChange={(value) => {
                                          setComparisonTradeAreas(prev => ({ ...prev, [idx]: value }));
                                        }}
                                      >
                                        <SelectTrigger className="h-7 text-xs" data-testid={`select-compare-area-${idx}`}>
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          {sortedTradeAreas.map(([key, ta]) => {
                                            const keyParts = key.split('-');
                                            const parsedRingValue = keyParts.length > 1 ? parseFloat(keyParts[1]) : NaN;
                                            const ringValue = isNaN(parsedRingValue) ? (sortedRings[0] || 0) : parsedRingValue;
                                            const colorIdx = sortedRings.indexOf(ringValue);
                                            const ringColor = RING_COLORS[colorIdx >= 0 ? colorIdx : 0];
                                            
                                            return (
                                              <SelectItem key={key} value={key}>
                                                <div className="flex items-center gap-2">
                                                  <div 
                                                    className="w-2 h-2 rounded-full"
                                                    style={{ backgroundColor: ringColor.stroke }}
                                                  />
                                                  <span>{ta.label}</span>
                                                </div>
                                              </SelectItem>
                                            );
                                          })}
                                        </SelectContent>
                                      </Select>
                                    )}
                                  </div>
                                </th>
                              );
                            })}
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            { label: "Population", key: "totalPopulation", format: formatNumber },
                            { label: "Median Age", key: "medianAge", format: (v: number) => v ? `${v.toFixed(1)} yrs` : "N/A" },
                            { label: "Median Income", key: "medianHouseholdIncome", format: formatCurrency },
                            { label: "Per Capita Income", key: "perCapitaIncome", format: formatCurrency },
                            { label: "Median Home Value", key: "medianHomeValue", format: formatCurrency },
                            { label: "Household Size", key: "householdSize", format: (v: number) => v ? v.toFixed(1) : "N/A" },
                          ].map((metric, mIdx) => (
                            <tr key={mIdx} className="border-b border-muted hover:bg-muted/30">
                              <td className="py-2 px-3 font-medium">{metric.label}</td>
                              {selectedLocations.map((loc, lIdx) => {
                                const locKey = `${loc.latitude},${loc.longitude}`;
                                const areaMap = locationData.get(locKey);
                                const isDistance = loc.config.analysisMode === 'distance';
                                const sortedRings = isDistance
                                  ? [...loc.config.distanceRings].sort((a, b) => a - b)
                                  : [...loc.config.driveTimes].sort((a, b) => a - b);
                                
                                const tradeAreasList = areaMap ? Array.from(areaMap.entries()).filter(([, ta]) => ta.demographics) : [];
                                const sortedTradeAreas = [...tradeAreasList].sort(([keyA], [keyB]) => {
                                  const partsA = keyA.split('-');
                                  const partsB = keyB.split('-');
                                  const valA = partsA.length > 1 ? parseFloat(partsA[1]) : 0;
                                  const valB = partsB.length > 1 ? parseFloat(partsB[1]) : 0;
                                  return (isNaN(valA) ? 0 : valA) - (isNaN(valB) ? 0 : valB);
                                });
                                
                                const defaultKey = sortedTradeAreas[0]?.[0] || '';
                                const selectedKey = (comparisonTradeAreas[lIdx] && sortedTradeAreas.some(([k]) => k === comparisonTradeAreas[lIdx]))
                                  ? comparisonTradeAreas[lIdx]
                                  : defaultKey;
                                const tradeArea = selectedKey && areaMap ? areaMap.get(selectedKey) : null;
                                const value = tradeArea?.demographics?.[metric.key as keyof DemographicSummary];
                                
                                return (
                                  <td key={lIdx} className="text-right py-2 px-3">
                                    <span>{metric.format(value as number)}</span>
                                  </td>
                                );
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </TabsContent>
        </Tabs>
      )}

      {selectedLocations.length === 0 && !fetchDemographicsMutation.isPending && (
        <Card className="border-dashed">
          <CardContent className="py-12 text-center">
            <MapPin className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-lg font-medium mb-2">No Locations Selected</h3>
            <p className="text-muted-foreground text-sm max-w-md mx-auto">
              Search for an address above to view detailed Census demographics including population, income, education, and housing data.
            </p>
          </CardContent>
        </Card>
      )}

      {fetchDemographicsMutation.isPending && selectedLocations.length === 0 && (
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          <span className="ml-3 text-muted-foreground">Loading demographics...</span>
        </div>
      )}

      {showAnalyticsPanel && selectedLocations.length > 0 && (
        <div className="space-y-6">
          {selectedLocations.slice(0, 3).map((loc, idx) => {
            const locKey = `${loc.latitude},${loc.longitude}`;
            const areaMap = locationData.get(locKey);
            const tradeAreasList = areaMap ? Array.from(areaMap.entries()).filter(([, ta]) => ta.demographics) : [];
            const firstTradeArea = tradeAreasList[0]?.[1];
            
            if (!firstTradeArea?.demographics) return null;
            
            return (
              <MarketTrendAnalysis
                key={idx}
                demographics={firstTradeArea.demographics as any}
                locationName={loc.label || loc.address.split(',')[0]}
              />
            );
          })}
          
          {selectedLocations.length >= 2 && (
            <PropertyComparisonPanel
              locations={getComparisonLocationsData().filter(l => l.demographics) as any}
              targetDemographics={targetDemographics || undefined}
            />
          )}
        </div>
      )}
    </div>
  );
}

export default function DemographicsIndex() {
  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-demographics-title">
            Location Demographics
          </h1>
          <p className="text-muted-foreground text-sm" data-testid="text-demographics-description">
            Analyze Census demographics for any U.S. property address
          </p>
        </div>
      </div>

      <LocationAnalysisSection />
    </div>
  );
}
