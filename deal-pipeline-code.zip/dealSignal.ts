export type DealSignal = 'Buy' | 'Conditional' | 'Pass';

export interface DealSignalInput {
  irr?: number | null;
  capRate?: number | null;
  equityMultiple?: number | null;
  cashOnCash?: number | null;
  purchasePrice?: number | null;
  exitValue?: number | null;
  noiGrowthRate?: number | null;
  totalProfit?: number | null;
  exitNetProceeds?: number | null;
  exitMoic?: number | null;
  exitIrr?: number | null;
}

export interface DealSignalResult {
  signal: DealSignal;
  score: number;
  reasons: string[];
  color: string;
  bgColor: string;
  borderColor: string;
}

export function computeDealSignal(input: DealSignalInput): DealSignalResult {
  let score = 50;
  const reasons: string[] = [];
  let dataPoints = 0;

  const irr = normalizePercent(input.irr);
  if (irr != null) {
    dataPoints++;
    if (irr >= 20) { score += 15; reasons.push(`Strong IRR of ${irr.toFixed(1)}% exceeds 20% threshold`); }
    else if (irr >= 15) { score += 10; reasons.push(`Solid IRR of ${irr.toFixed(1)}% meets 15% target`); }
    else if (irr >= 12) { score += 3; reasons.push(`Moderate IRR of ${irr.toFixed(1)}% — below 15% ideal`); }
    else if (irr >= 8) { score -= 5; reasons.push(`Below-target IRR of ${irr.toFixed(1)}% — value-add needed`); }
    else { score -= 15; reasons.push(`Weak IRR of ${irr.toFixed(1)}% — does not meet institutional minimums`); }
  }

  const capRate = normalizePercent(input.capRate);
  if (capRate != null) {
    dataPoints++;
    if (capRate >= 8) { score += 12; reasons.push(`Attractive ${capRate.toFixed(1)}% going-in cap rate`); }
    else if (capRate >= 7) { score += 8; reasons.push(`Healthy ${capRate.toFixed(1)}% going-in cap rate`); }
    else if (capRate >= 6) { score += 2; reasons.push(`Market-rate ${capRate.toFixed(1)}% cap — limited margin of safety`); }
    else if (capRate >= 5) { score -= 5; reasons.push(`Thin ${capRate.toFixed(1)}% cap rate — premium pricing`); }
    else { score -= 12; reasons.push(`Sub-5% cap rate signals aggressive pricing`); }
  }

  const em = input.equityMultiple != null && !isNaN(input.equityMultiple) ? input.equityMultiple : null;
  if (em != null && em > 0) {
    dataPoints++;
    if (em >= 2.5) { score += 10; reasons.push(`Excellent ${em.toFixed(2)}x equity multiple`); }
    else if (em >= 2.0) { score += 7; reasons.push(`Strong ${em.toFixed(2)}x equity multiple`); }
    else if (em >= 1.5) { score += 3; reasons.push(`Adequate ${em.toFixed(2)}x equity multiple`); }
    else { score -= 8; reasons.push(`Low ${em.toFixed(2)}x equity multiple — limited return of capital`); }
  }

  const coc = normalizePercent(input.cashOnCash);
  if (coc != null) {
    dataPoints++;
    if (coc >= 10) { score += 8; reasons.push(`Strong ${coc.toFixed(1)}% cash-on-cash yield`); }
    else if (coc >= 8) { score += 5; reasons.push(`Good ${coc.toFixed(1)}% cash-on-cash yield`); }
    else if (coc >= 6) { score += 1; }
    else { score -= 5; reasons.push(`Low ${coc.toFixed(1)}% cash-on-cash — cash flow constrained`); }
  }

  if (input.purchasePrice != null && input.exitValue != null && input.purchasePrice > 0) {
    dataPoints++;
    const appreciation = ((input.exitValue - input.purchasePrice) / input.purchasePrice) * 100;
    if (appreciation >= 50) { score += 10; reasons.push(`${appreciation.toFixed(0)}% projected value creation`); }
    else if (appreciation >= 25) { score += 5; reasons.push(`${appreciation.toFixed(0)}% projected appreciation`); }
    else if (appreciation >= 10) { score += 2; }
    else if (appreciation < 0) { score -= 10; reasons.push(`Negative value creation — exit below purchase`); }
  }

  if (input.totalProfit != null) {
    dataPoints++;
    if (input.totalProfit > 0) { score += 5; }
    else { score -= 10; reasons.push('Negative total profit projection'); }
  }

  const growth = normalizePercent(input.noiGrowthRate);
  if (growth != null) {
    dataPoints++;
    if (growth >= 3) { score += 5; }
    else if (growth >= 1) { score += 2; }
    else if (growth < 0) { score -= 5; reasons.push('Negative NOI growth trajectory'); }
  }

  if (input.exitNetProceeds != null && input.purchasePrice != null && input.purchasePrice > 0) {
    dataPoints++;
    const exitReturn = ((input.exitNetProceeds - input.purchasePrice) / input.purchasePrice) * 100;
    if (exitReturn >= 100) { score += 12; reasons.push(`Exit net proceeds ${exitReturn.toFixed(0)}% above purchase — strong exit`); }
    else if (exitReturn >= 50) { score += 8; reasons.push(`Exit net proceeds ${exitReturn.toFixed(0)}% above purchase`); }
    else if (exitReturn >= 20) { score += 4; reasons.push(`Modest ${exitReturn.toFixed(0)}% exit gain after costs`); }
    else if (exitReturn >= 0) { score += 1; }
    else { score -= 10; reasons.push(`Exit net proceeds below purchase price — capital loss risk`); }
  } else if (input.exitNetProceeds != null && input.exitNetProceeds > 0 && !input.purchasePrice) {
    dataPoints++;
    score += 3;
    reasons.push(`Exit net proceeds: $${(input.exitNetProceeds / 1000000).toFixed(1)}M modeled`);
  }

  const exitMoic = input.exitMoic != null && !isNaN(input.exitMoic) ? input.exitMoic : null;
  if (exitMoic != null && exitMoic > 0) {
    dataPoints++;
    if (exitMoic >= 3.0) { score += 10; reasons.push(`Exceptional ${exitMoic.toFixed(2)}x exit MOIC`); }
    else if (exitMoic >= 2.0) { score += 7; reasons.push(`Strong ${exitMoic.toFixed(2)}x exit MOIC`); }
    else if (exitMoic >= 1.5) { score += 3; reasons.push(`Adequate ${exitMoic.toFixed(2)}x exit MOIC`); }
    else if (exitMoic >= 1.0) { score -= 2; reasons.push(`Marginal ${exitMoic.toFixed(2)}x exit MOIC`); }
    else { score -= 8; reasons.push(`Below-par ${exitMoic.toFixed(2)}x exit MOIC — capital erosion`); }
  }

  const exitIrr = normalizePercent(input.exitIrr);
  if (exitIrr != null) {
    dataPoints++;
    if (exitIrr >= 25) { score += 8; reasons.push(`Exit-modeled IRR of ${exitIrr.toFixed(1)}% exceeds institutional hurdles`); }
    else if (exitIrr >= 18) { score += 5; reasons.push(`Solid ${exitIrr.toFixed(1)}% exit-modeled IRR`); }
    else if (exitIrr >= 12) { score += 2; }
    else if (exitIrr < 8) { score -= 5; reasons.push(`Weak ${exitIrr.toFixed(1)}% exit-modeled IRR`); }
  }

  if (dataPoints < 2) {
    return {
      signal: 'Conditional',
      score: 0,
      reasons: ['Insufficient data to generate recommendation — add pricing inputs'],
      color: 'text-gray-500',
      bgColor: 'bg-gray-100 dark:bg-gray-800',
      borderColor: 'border-gray-300 dark:border-gray-600',
    };
  }

  score = Math.max(0, Math.min(100, score));

  const topReasons = reasons.slice(0, 4);

  if (score >= 70) {
    return {
      signal: 'Buy',
      score,
      reasons: topReasons,
      color: 'text-green-700 dark:text-green-400',
      bgColor: 'bg-green-50 dark:bg-green-950/30',
      borderColor: 'border-green-300 dark:border-green-700',
    };
  } else if (score >= 50) {
    return {
      signal: 'Conditional',
      score,
      reasons: topReasons,
      color: 'text-amber-700 dark:text-amber-400',
      bgColor: 'bg-amber-50 dark:bg-amber-950/30',
      borderColor: 'border-amber-300 dark:border-amber-700',
    };
  } else {
    return {
      signal: 'Pass',
      score,
      reasons: topReasons,
      color: 'text-red-700 dark:text-red-400',
      bgColor: 'bg-red-50 dark:bg-red-950/30',
      borderColor: 'border-red-300 dark:border-red-700',
    };
  }
}

function normalizePercent(value: number | null | undefined): number | null {
  if (value == null || isNaN(value)) return null;
  if (Math.abs(value) < 1 && value !== 0) return value * 100;
  return value;
}

export function getSignalBadgeProps(signal: DealSignal): { label: string; className: string } {
  switch (signal) {
    case 'Buy':
      return { label: 'Buy', className: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 border-green-200' };
    case 'Conditional':
      return { label: 'Conditional', className: 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300 border-amber-200' };
    case 'Pass':
      return { label: 'Pass', className: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300 border-red-200' };
  }
}


// ═══════════════════════════════════════════════════════════════
// CRITERIA-AWARE DEAL SIGNAL
// ═══════════════════════════════════════════════════════════════

export interface InvestmentCriteria {
  financial?: {
    minCapRate?: number | null;
    maxCapRate?: number | null;
    minNoi?: number | null;
    minEbitda?: number | null;
    minOperatingMargin?: number | null;
  } | null;
  capital?: {
    minIrrTarget?: number | null;
    minCashOnCashReturn?: number | null;
    targetLtvRatio?: number | null;
    targetHoldPeriod?: number | null;
    maxEquityPerDeal?: number | null;
  } | null;
  size?: {
    minTotalSlips?: number | null;
    maxTotalSlips?: number | null;
  } | null;
  location?: {
    targetStates?: string[] | null;
    targetRegions?: string[] | null;
  } | null;
  involvement?: {
    involvementLevel?: string | null;
    requireManagementInPlace?: boolean | null;
  } | null;
  operational?: {
    minOccupancyRate?: number | null;
  } | null;
  weights?: {
    financialWeight?: number;
    capitalWeight?: number;
    locationWeight?: number;
    operationalWeight?: number;
    sizeWeight?: number;
    involvementWeight?: number;
  };
}

export interface CriteriaMatchResult {
  signal: DealSignal;
  score: number;
  reasons: string[];
  criteriaMatches: CriteriaMatch[];
  color: string;
  bgColor: string;
  borderColor: string;
}

export interface CriteriaMatch {
  category: string;
  criterion: string;
  target: string;
  actual: string;
  met: boolean;
  mustHave: boolean;
  impact: number; // -20 to +20
}

export interface DealForCriteria extends DealSignalInput {
  noi?: number | null;
  ebitda?: number | null;
  occupancyRate?: number | null;
  totalSlips?: number | null;
  state?: string | null;
  region?: string | null;
  operatingMargin?: number | null;
  ltv?: number | null;
  equityRequired?: number | null;
  holdPeriod?: number | null;
  hasManagementInPlace?: boolean | null;
}

export function computeCriteriaSignal(
  deal: DealForCriteria,
  criteria: InvestmentCriteria | null
): CriteriaMatchResult {
  // If no criteria, fall back to standard scoring
  if (!criteria) {
    const base = computeDealSignal(deal);
    return { ...base, criteriaMatches: [] };
  }

  let score = 50;
  const reasons: string[] = [];
  const matches: CriteriaMatch[] = [];
  let mustHaveFails = 0;

  const w = criteria.weights || {
    financialWeight: 25, capitalWeight: 10, locationWeight: 20,
    operationalWeight: 15, sizeWeight: 15, involvementWeight: 5,
  };
  const totalWeight = (w.financialWeight || 0) + (w.capitalWeight || 0) + (w.locationWeight || 0) +
    (w.operationalWeight || 0) + (w.sizeWeight || 0) + (w.involvementWeight || 0);

  // ── Financial Criteria ──
  const fin = criteria.financial;
  if (fin) {
    const fWeight = ((w.financialWeight || 25) / Math.max(totalWeight, 1)) * 50;

    // Cap Rate
    const capRate = normalizePercent(deal.capRate);
    if (fin.minCapRate != null && capRate != null) {
      const target = parseFloat(String(fin.minCapRate));
      const met = capRate >= target;
      matches.push({ category: 'Financial', criterion: 'Going-In Cap Rate', target: `≥ ${target}%`, actual: `${capRate.toFixed(1)}%`, met, mustHave: false, impact: met ? fWeight * 0.3 : -fWeight * 0.3 });
      if (met) { score += fWeight * 0.3; reasons.push(`Cap rate ${capRate.toFixed(1)}% meets your ${target}% minimum`); }
      else { score -= fWeight * 0.3; reasons.push(`Cap rate ${capRate.toFixed(1)}% below your ${target}% minimum`); }
    }

    // NOI
    if (fin.minNoi != null && deal.noi != null) {
      const target = parseFloat(String(fin.minNoi));
      const met = deal.noi >= target;
      matches.push({ category: 'Financial', criterion: 'NOI', target: `≥ $${(target/1000).toFixed(0)}K`, actual: `$${(deal.noi/1000).toFixed(0)}K`, met, mustHave: false, impact: met ? fWeight * 0.3 : -fWeight * 0.3 });
      if (met) { score += fWeight * 0.2; } else { score -= fWeight * 0.2; }
    }

    // EBITDA
    if (fin.minEbitda != null && deal.ebitda != null) {
      const target = parseFloat(String(fin.minEbitda));
      const met = deal.ebitda >= target;
      matches.push({ category: 'Financial', criterion: 'EBITDA', target: `≥ $${(target/1000).toFixed(0)}K`, actual: `$${(deal.ebitda/1000).toFixed(0)}K`, met, mustHave: false, impact: met ? fWeight * 0.2 : -fWeight * 0.2 });
      if (met) { score += fWeight * 0.2; } else { score -= fWeight * 0.2; }
    }

    // Operating Margin
    if (fin.minOperatingMargin != null && deal.operatingMargin != null) {
      const target = parseFloat(String(fin.minOperatingMargin)) * 100;
      const actual = deal.operatingMargin * 100;
      const met = actual >= target;
      matches.push({ category: 'Financial', criterion: 'Operating Margin', target: `≥ ${target.toFixed(0)}%`, actual: `${actual.toFixed(0)}%`, met, mustHave: false, impact: met ? fWeight * 0.2 : -fWeight * 0.2 });
      if (met) { score += fWeight * 0.15; } else { score -= fWeight * 0.15; }
    }
  }

  // ── Capital / Returns Criteria ──
  const cap = criteria.capital;
  if (cap) {
    const cWeight = ((w.capitalWeight || 10) / Math.max(totalWeight, 1)) * 50;

    // IRR Target
    const irr = normalizePercent(deal.irr);
    if (cap.minIrrTarget != null && irr != null) {
      const target = parseFloat(String(cap.minIrrTarget));
      const met = irr >= target;
      matches.push({ category: 'Returns', criterion: 'Levered IRR', target: `≥ ${target}%`, actual: `${irr.toFixed(1)}%`, met, mustHave: true, impact: met ? cWeight * 0.5 : -cWeight * 0.5 });
      if (met) { score += cWeight * 0.4; reasons.push(`IRR ${irr.toFixed(1)}% meets your ${target}% target`); }
      else { score -= cWeight * 0.4; reasons.push(`IRR ${irr.toFixed(1)}% misses your ${target}% target`); mustHaveFails++; }
    }

    // Cash on Cash
    const coc = normalizePercent(deal.cashOnCash);
    if (cap.minCashOnCashReturn != null && coc != null) {
      const target = parseFloat(String(cap.minCashOnCashReturn));
      const met = coc >= target;
      matches.push({ category: 'Returns', criterion: 'Cash-on-Cash', target: `≥ ${target}%`, actual: `${coc.toFixed(1)}%`, met, mustHave: false, impact: met ? cWeight * 0.3 : -cWeight * 0.3 });
      if (met) { score += cWeight * 0.3; } else { score -= cWeight * 0.25; }
    }

    // Max equity per deal
    if (cap.maxEquityPerDeal != null && deal.equityRequired != null) {
      const target = parseFloat(String(cap.maxEquityPerDeal));
      const met = deal.equityRequired <= target;
      matches.push({ category: 'Capital', criterion: 'Max Equity', target: `≤ $${(target/1e6).toFixed(1)}M`, actual: `$${(deal.equityRequired/1e6).toFixed(1)}M`, met, mustHave: true, impact: met ? cWeight * 0.2 : -cWeight * 0.3 });
      if (!met) { score -= cWeight * 0.3; reasons.push(`Equity required $${(deal.equityRequired/1e6).toFixed(1)}M exceeds your $${(target/1e6).toFixed(1)}M limit`); mustHaveFails++; }
    }
  }

  // ── Operational Criteria ──
  const ops = criteria.operational;
  if (ops) {
    const oWeight = ((w.operationalWeight || 15) / Math.max(totalWeight, 1)) * 50;

    if (ops.minOccupancyRate != null && deal.occupancyRate != null) {
      const target = parseFloat(String(ops.minOccupancyRate));
      const met = deal.occupancyRate >= target;
      matches.push({ category: 'Operational', criterion: 'Occupancy', target: `≥ ${target}%`, actual: `${deal.occupancyRate.toFixed(0)}%`, met, mustHave: false, impact: met ? oWeight * 0.5 : -oWeight * 0.5 });
      if (met) { score += oWeight * 0.3; } else { score -= oWeight * 0.3; reasons.push(`Occupancy ${deal.occupancyRate.toFixed(0)}% below your ${target}% minimum`); }
    }
  }

  // ── Size Criteria ──
  const sz = criteria.size;
  if (sz) {
    const sWeight = ((w.sizeWeight || 15) / Math.max(totalWeight, 1)) * 50;

    if (sz.minTotalSlips != null && deal.totalSlips != null) {
      const target = sz.minTotalSlips;
      const met = deal.totalSlips >= target;
      matches.push({ category: 'Size', criterion: 'Total Slips', target: `≥ ${target}`, actual: `${deal.totalSlips}`, met, mustHave: false, impact: met ? sWeight * 0.5 : -sWeight * 0.5 });
      if (met) { score += sWeight * 0.3; } else { score -= sWeight * 0.2; }
    }
  }

  // ── Location Criteria ──
  const loc = criteria.location;
  if (loc && deal.state) {
    const lWeight = ((w.locationWeight || 20) / Math.max(totalWeight, 1)) * 50;

    if (loc.targetStates && loc.targetStates.length > 0) {
      const met = loc.targetStates.includes(deal.state);
      matches.push({ category: 'Location', criterion: 'Target State', target: loc.targetStates.join(', '), actual: deal.state, met, mustHave: false, impact: met ? lWeight * 0.5 : -lWeight * 0.3 });
      if (met) { score += lWeight * 0.4; reasons.push(`Located in target state: ${deal.state}`); }
      else { score -= lWeight * 0.2; reasons.push(`${deal.state} not in your target states`); }
    }
  }

  // ── Involvement Criteria ──
  const inv = criteria.involvement;
  if (inv) {
    const iWeight = ((w.involvementWeight || 5) / Math.max(totalWeight, 1)) * 50;

    if (inv.requireManagementInPlace && deal.hasManagementInPlace != null) {
      const met = deal.hasManagementInPlace;
      matches.push({ category: 'Involvement', criterion: 'Management in Place', target: 'Required', actual: met ? 'Yes' : 'No', met, mustHave: false, impact: met ? iWeight * 0.5 : -iWeight * 0.5 });
      if (!met) { score -= iWeight * 0.3; reasons.push('No management in place — you require existing management'); }
    }
  }

  // Add standard metrics scoring (IRR, cap rate, equity multiple) if not already covered by criteria
  if (!criteria.capital?.minIrrTarget) {
    const irr = normalizePercent(deal.irr);
    if (irr != null) {
      if (irr >= 20) score += 10;
      else if (irr >= 15) score += 5;
      else if (irr < 8) score -= 10;
    }
  }

  const em = deal.equityMultiple;
  if (em != null && em > 0) {
    if (em >= 2.5) score += 5;
    else if (em >= 2.0) score += 3;
    else if (em < 1.2) score -= 5;
  }

  // Must-have failures cap the score
  if (mustHaveFails > 0) {
    score = Math.min(score, 45);
    reasons.unshift(`${mustHaveFails} must-have criteria not met`);
  }

  score = Math.max(0, Math.min(100, Math.round(score)));

  const topReasons = reasons.slice(0, 5);
  const signal: DealSignal = score >= 70 ? 'Buy' : score >= 50 ? 'Conditional' : 'Pass';

  const colorMap = {
    Buy: { color: 'text-green-700 dark:text-green-400', bgColor: 'bg-green-50 dark:bg-green-950/30', borderColor: 'border-green-300 dark:border-green-700' },
    Conditional: { color: 'text-amber-700 dark:text-amber-400', bgColor: 'bg-amber-50 dark:bg-amber-950/30', borderColor: 'border-amber-300 dark:border-amber-700' },
    Pass: { color: 'text-red-700 dark:text-red-400', bgColor: 'bg-red-50 dark:bg-red-950/30', borderColor: 'border-red-300 dark:border-red-700' },
  };

  return {
    signal,
    score,
    reasons: topReasons,
    criteriaMatches: matches,
    ...colorMap[signal],
  };
}
